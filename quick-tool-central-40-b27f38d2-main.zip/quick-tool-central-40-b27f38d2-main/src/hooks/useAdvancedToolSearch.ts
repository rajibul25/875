
import { useMemo } from "react";
import * as toolCategories from "@/lib/tool-categories";
import { Tool } from "@/lib/tool-model";

// Optimize search with deburred string normalization
const deburr = (str: string) =>
  str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

// Optimize keyword extraction
const simpleKeywords = (str: string) =>
  deburr(str)
    .replace(/[^a-z0-9 ]/gi, " ")
    .split(/\s+/)
    .filter(Boolean);

// Enhanced fuzzy matching for faster and more relevant results
function fuzzyMatch(tool: Tool, query: string) {
  const allFields = [
    tool.title,
    tool.description || "",
    tool.category || "",
    tool.id || "",
    (tool as any).keywords || "",
  ]
    .join(" ")
    .toLowerCase();

  const delower = deburr(allFields);
  const dquery = deburr(query);

  // Quick exact includes match
  if (delower.includes(dquery)) return true;

  // Match against keywords separately for more relevance
  const words = simpleKeywords(query);

  // Special priority for loan and emi in tool ids & titles
  if (
    (query.toLowerCase().includes("loan") ||
      query.toLowerCase().includes("emi")) &&
    (tool.id?.toLowerCase().includes("loan") ||
      tool.title.toLowerCase().includes("loan") ||
      tool.id?.toLowerCase().includes("emi") ||
      tool.title.toLowerCase().includes("emi"))
  ) {
    return true;
  }

  // Check that all query words appear somewhere in the text fields
  return words.every((w) => delower.includes(w));
}

// Improved semantic scoring for better relevance and boost popular EMI/Loan tools quickly
function semanticScore(tool: Tool, query: string) {
  const q = deburr(query);
  let score = 0;

  // Boost loan/mortgage/emi calculators when the query is about loan or emi
  if (
    tool.id?.includes("loan") ||
    tool.id?.includes("mortgage") ||
    tool.id?.includes("emi") ||
    tool.title.toLowerCase().includes("loan") ||
    tool.title.toLowerCase().includes("emi")
  ) {
    if (q.includes("loan") || q.includes("emi") || q.includes("mortgage")) {
      score += 15; // Boost higher to prioritize these tools
    }
  }

  if (deburr(tool.title).includes(q)) score += 8;
  if (tool.description && deburr(tool.description).includes(q)) score += 3;
  if (tool.category && deburr(tool.category).includes(q)) score += 2;
  if (tool.id && deburr(tool.id).includes(q)) score += 3;

  // Bonus for complete matches of all keywords in title or description or category
  if (
    simpleKeywords(query).every(
      (word) =>
        deburr(tool.title).includes(word) ||
        (tool.description && deburr(tool.description).includes(word)) ||
        (tool.category && deburr(tool.category).includes(word))
    )
  ) {
    score += 5;
  }

  // Small boost if tool is popular or new for better sorting
  if (tool.isPopular) score += 2;
  if (tool.isNew) score += 1;

  return score;
}

export default function useAdvancedToolSearch(query: string) {
  // Cache all tools once
  const allTools = useMemo(() => {
    const arrs = Object.values(toolCategories).filter(Array.isArray) as Tool[][];
    return arrs.flat();
  }, []);

  // Optimized filtering with memoization
  const filteredTools = useMemo(() => {
    if (!query.trim()) return null;

    const matches = allTools
      .filter((tool) => fuzzyMatch(tool, query))
      .map((tool) => ({
        tool,
        score: semanticScore(tool, query),
      }))
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(({ tool }) => tool);

    return matches;
  }, [allTools, query]);

  // Return grouped tools by category after filtering or full list if query empty
  return useMemo(() => {
    if (!query.trim()) {
      const grouped: Record<string, Tool[]> = {};
      allTools.forEach((tool) => {
        const key = tool.category?.toLowerCase() || "other";
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(tool);
      });
      return grouped;
    }

    const grouped: Record<string, Tool[]> = {};
    filteredTools?.forEach((tool) => {
      const key = tool.category?.toLowerCase() || "other";
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(tool);
    });
    return grouped;
  }, [allTools, filteredTools, query]);
}

