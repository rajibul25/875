import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import Index from "./pages/Index";
import MoreTools from "./pages/MoreTools";
import AllToolsMenu from "./components/AllToolsMenu";
import WordCounter from "./pages/tools/WordCounter";
import CharacterCounter from "./pages/tools/CharacterCounter";
import CaseConverter from "./pages/tools/CaseConverter";
import PlagiarismChecker from "./pages/tools/PlagiarismChecker";
import GrammarChecker from "./pages/tools/GrammarChecker";
import TextToSpeech from "./pages/tools/TextToSpeech";
import ComingSoon from "./pages/ComingSoon";
import CodeBeautifier from "./pages/tools/CodeBeautifier";
import JsonFormatter from "./pages/tools/JsonFormatter";
import WebpConverter from "./pages/tools/WebpConverter";
import ImageCompressor from "./pages/tools/ImageCompressor";
import ImageCropper from "./pages/tools/ImageCropper";
import ImageToBase64 from "./pages/tools/ImageToBase64";
import WordToPdf from "./pages/tools/WordToPdf";
import JpgToPdf from "./pages/tools/JpgToPdf";
import ZipFileHandler from "./pages/tools/ZipFileHandler";
import GifMaker from "./pages/tools/GifMaker";
import ImageColorPicker from "./pages/tools/ImageColorPicker";
import CalorieCounter from "./pages/tools/CalorieCounter";
import PregnancyCalculator from "./pages/tools/PregnancyCalculator";
import IdealWeightCalculator from "./pages/tools/IdealWeightCalculator";
import PaceCalculator from "./pages/tools/PaceCalculator";
import SleepCalculator from "./pages/tools/SleepCalculator";
import PasswordGenerator from "./pages/tools/PasswordGenerator";
import MD5Generator from "./pages/tools/MD5Generator";
import SHA256Generator from "./pages/tools/SHA256Generator";
import RandomStringGenerator from "./pages/tools/RandomStringGenerator";
import MetaTagGenerator from "./pages/tools/MetaTagGenerator";
import KeywordDensityChecker from "./pages/tools/KeywordDensityChecker";
import TextDiffChecker from "./pages/tools/TextDiffChecker";
import LoremIpsumGenerator from "./pages/tools/LoremIpsumGenerator";
import TextRepeater from "./pages/tools/TextRepeater";
import WordFrequency from "./pages/tools/WordFrequency";
import ContentDetective from "./pages/tools/ContentDetective";
import EMICalculator from "@/pages/tools/EMI-Calculator";
import LoanInterestCalculator from "@/pages/tools/Loan-Interest-Calculator";
import MortgageCalculator from "@/pages/tools/Mortgage-Calculator";
import SIPCalculator from "./pages/tools/SIP-Calculator";

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/more-tools" element={<MoreTools />} />
        <Route path="/all-tools" element={<AllToolsMenu />} />

        <Route path="/tools/word-counter" element={<WordCounter />} />
        <Route path="/tools/character-counter" element={<CharacterCounter />} />
        <Route path="/tools/case-converter" element={<CaseConverter />} />
        <Route path="/tools/plagiarism-checker" element={<PlagiarismChecker />} />
        <Route path="/tools/grammar-checker" element={<GrammarChecker />} />
        <Route path="/tools/text-to-speech" element={<TextToSpeech />} />
        <Route path="/tools/markdown-editor" element={<ComingSoon />} />
        <Route path="/tools/text-diff-checker" element={<TextDiffChecker />} />
        <Route path="/tools/lorem-ipsum-generator" element={<LoremIpsumGenerator />} />
        <Route path="/tools/text-repeater" element={<TextRepeater />} />
        <Route path="/tools/word-frequency" element={<WordFrequency />} />
        <Route path="/tools/content-detective" element={<ContentDetective />} />

        <Route path="/tools/image-to-png" element={<ComingSoon />} />
        <Route path="/tools/image-resizer" element={<ComingSoon />} />
        <Route path="/tools/pdf-to-word" element={<ComingSoon />} />
        <Route path="/tools/hex-converter" element={<ComingSoon />} />
        <Route path="/tools/image-compressor" element={<ImageCompressor />} />
        <Route path="/tools/webp-converter" element={<WebpConverter />} />
        <Route path="/tools/image-cropper" element={<ImageCropper />} />
        <Route path="/tools/image-to-base64" element={<ImageToBase64 />} />
        <Route path="/tools/word-to-pdf" element={<WordToPdf />} />
        <Route path="/tools/jpg-to-pdf" element={<JpgToPdf />} />
        <Route path="/tools/qr-code-generator" element={<ComingSoon />} />
        <Route path="/tools/zip-file-handler" element={<ZipFileHandler />} />
        <Route path="/tools/gif-maker" element={<GifMaker />} />

        <Route path="/tools/code-beautifier" element={<CodeBeautifier />} />
        <Route path="/tools/sql-formatter" element={<ComingSoon />} />
        <Route path="/tools/json-formatter" element={<JsonFormatter />} />
        <Route path="/tools/api-tester" element={<ComingSoon />} />
        <Route path="/tools/regex-tester" element={<ComingSoon />} />
        <Route path="/tools/svg-editor" element={<ComingSoon />} />

        <Route path="/tools/text-generator" element={<ComingSoon />} />
        <Route path="/tools/chatbot" element={<ComingSoon />} />
        <Route path="/tools/text-summarizer" element={<ComingSoon />} />

        <Route path="/tools/data-visualizer" element={<ComingSoon />} />
        <Route path="/tools/database-analyzer" element={<ComingSoon />} />
        <Route path="/tools/csv-converter" element={<ComingSoon />} />
        <Route path="/tools/data-cleaner" element={<ComingSoon />} />

        <Route path="/tools/calorie-counter" element={<CalorieCounter />} />
        <Route path="/tools/pregnancy-calculator" element={<PregnancyCalculator />} />
        <Route path="/tools/ideal-weight-calculator" element={<IdealWeightCalculator />} />
        <Route path="/tools/pace-calculator" element={<PaceCalculator />} />
        <Route path="/tools/sleep-calculator" element={<SleepCalculator />} />
        <Route path="/tools/image-color-picker" element={<ImageColorPicker />} />

        <Route path="/tools/password-generator" element={<PasswordGenerator />} />
        <Route path="/tools/md5-generator" element={<MD5Generator />} />
        <Route path="/tools/sha256-generator" element={<SHA256Generator />} />
        <Route path="/tools/random-string-generator" element={<RandomStringGenerator />} />
        <Route path="/tools/url-shortener" element={<ComingSoon />} />

        <Route path="/tools/meta-tag-generator" element={<MetaTagGenerator />} />
        <Route path="/tools/keyword-density-checker" element={<KeywordDensityChecker />} />

        <Route path="/admin/tool-checker" element={<ComingSoon />} />

        <Route path="/tools/EMI-Calculator" element={<EMICalculator />} />
        <Route path="/tools/Loan-Interest-Calculator" element={<LoanInterestCalculator />} />
        <Route path="/tools/Mortgage-Calculator" element={<MortgageCalculator />} />
        <Route path="/tools/SIP-Calculator" element={<SIPCalculator />} />
        <Route path="/tools/csv-to-json" element={<ComingSoon />} />
      </Routes>
    </Router>
  );
}

export default App;
