
/**
 * ErrorLoggingService.ts
 * A centralized error logging service for tracking issues across tools
 * Version: 1.0.0
 */
import { toast } from "sonner";

// Types for error logging
export interface ErrorLog {
  toolId: string;
  errorType: string;
  message: string;
  stack?: string;
  timestamp: string;
  userAgent: string;
  url: string;
}

// In-memory error storage (for demo purposes)
// In a real app, this would connect to a backend API
let errorLogs: ErrorLog[] = [];

/**
 * Log an error that occurred in a tool
 */
export const logToolError = (toolId: string, error: Error): void => {
  const errorLog: ErrorLog = {
    toolId,
    errorType: error.name,
    message: error.message,
    stack: error.stack,
    timestamp: new Date().toISOString(),
    userAgent: navigator.userAgent,
    url: window.location.href
  };
  
  console.error(`[${toolId}] Error:`, errorLog);
  
  // Store error in memory
  errorLogs.push(errorLog);
  
  // Show toast notification for visible feedback
  toast.error(`Error in ${toolId}: ${error.message}`);
  
  // In a real app, you would send this to a backend
  // sendErrorToBackend(errorLog);
};

/**
 * Mock function to send errors to a backend
 * In a real app, this would make an API call
 */
const sendErrorToBackend = (errorLog: ErrorLog): void => {
  // This would be an API call in a real implementation
  console.log("Sending error to backend:", errorLog);
};

/**
 * Get all logged errors (for admin panel)
 */
export const getErrorLogs = (): ErrorLog[] => {
  return [...errorLogs];
};

/**
 * Clear all error logs (for admin panel)
 */
export const clearErrorLogs = (): void => {
  errorLogs = [];
};

/**
 * Initialize global error handlers
 */
export const initializeErrorLogging = (): void => {
  // Set up global error handler
  window.onerror = (message, source, lineno, colno, error) => {
    // Extract toolId from URL if possible
    const urlParts = window.location.pathname.split('/');
    const possibleToolId = urlParts[urlParts.length - 1]?.replace('.html', '') || 'unknown';
    
    logToolError(possibleToolId, error || new Error(message as string));
    
    // Don't prevent default error handling
    return false;
  };
  
  // Set up unhandled promise rejection handler
  window.addEventListener('unhandledrejection', (event) => {
    const urlParts = window.location.pathname.split('/');
    const possibleToolId = urlParts[urlParts.length - 1]?.replace('.html', '') || 'unknown';
    
    logToolError(possibleToolId, event.reason);
  });
};
