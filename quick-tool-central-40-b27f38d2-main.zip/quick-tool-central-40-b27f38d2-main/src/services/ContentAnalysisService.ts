/**
 * Content Analysis Service
 * Advanced content analysis for AI vs Human detection
 */

/**
 * Analyzes n-grams (3-word sequences) to detect repetitive patterns
 * commonly found in AI-generated content.
 */
function analyzeNGrams(text: string): number {
  // Split into 3-word sequences
  const words = text.toLowerCase().split(/\W+/).filter(w => w.length > 0);
  const trigrams: string[] = [];
  
  for (let i = 0; i < words.length - 2; i++) {
    trigrams.push(`${words[i]} ${words[i+1]} ${words[i+2]}`);
  }
  
  // Count repeated trigrams with explicit type conversion and checking
  const trigramCounts = trigrams.reduce((acc, tg) => {
    acc[tg] = (acc[tg] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  // Use type guard to ensure we're only counting valid number values
  const repeatedTrigrams = Object.values(trigramCounts)
    .filter((count): count is number => 
      count !== null && 
      count !== undefined && 
      typeof count === 'number' && 
      count > 1
    ).length;
  
  return Math.min(5, repeatedTrigrams);
}

/**
 * Analyzes sentence structure to identify patterns common in AI content
 */
function analyzeSentenceStructure(text: string): number {
  // Get sentences
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  
  if (sentences.length < 3) return 0;
  
  // Calculate variance in sentence length (AI tends to be more uniform)
  const lengths = sentences.map(s => s.trim().length);
  const avg = lengths.reduce((sum, len) => sum + len, 0) / lengths.length;
  
  // Compute variance
  const variance = lengths.reduce((sum, len) => sum + Math.pow(len - avg, 2), 0) / lengths.length;
  
  // Normalize to 0-5 scale (lower variance = more AI-like)
  const normalizedVariance = Math.min(5, Math.max(0, 5 - (variance / 100)));
  
  return normalizedVariance;
}

/**
 * Analyzes language complexity indicators like vocabulary diversity
 */
function analyzeLanguageComplexity(text: string): number {
  const words = text.toLowerCase().split(/\W+/).filter(w => w.length > 0);
  
  if (words.length < 10) return 0;
  
  // Count unique words vs total (AI often has lower lexical diversity)
  const uniqueWords = new Set(words);
  const lexicalDiversity = uniqueWords.size / words.length;
  
  // Scale to 0-5 (higher is more AI-like)
  return Math.min(5, (1 - lexicalDiversity) * 10);
}

/**
 * Detects common AI transition phrases and connectors
 */
function detectAIPhrases(text: string): number {
  const aiMarkers = [
    "in conclusion",
    "to summarize",
    "it is important to note",
    "it is worth mentioning",
    "it should be noted",
    "it is essential to",
    "furthermore",
    "moreover",
    "additionally",
    "consequently",
    "in essence",
    "to put it simply",
    "to put it differently",
    "it goes without saying",
    "needless to say",
    "in this context",
  ];
  
  const normalizedText = text.toLowerCase();
  
  // Count occurrences of AI marker phrases
  let markerCount = 0;
  for (const marker of aiMarkers) {
    // Using a regex-safe version
    const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`\\b${escapedMarker}\\b`, 'g');
    const matches = normalizedText.match(regex);
    
    // Add type check before accessing matches length
    if (matches !== null && Array.isArray(matches) && matches.length > 0) {
      markerCount += matches.length;
    }
  }
  
  // Scale to 0-5 based on text length
  const wordCount = normalizedText.split(/\s+/).length;
  const ratio = (markerCount * 100) / wordCount;
  
  return Math.min(5, ratio);
}

/**
 * Analyzes grammar perfection (AI tends to have fewer grammar errors)
 */
function analyzeGrammarQuality(text: string): number {
  // Simple checks for common grammatical markers
  const grammarChecks = [
    { pattern: /\s+[.,?!]/, score: 0.5 }, // Space before punctuation
    { pattern: /\s{2,}/, score: 0.3 },    // Multiple spaces
    { pattern: /[a-z][A-Z]/, score: 0.3 }, // Missing space between sentences
    { pattern: /\bi\b/, score: 0.4 },      // Lowercase "i" personal pronoun
    { pattern: /\ba\s+[aeiou]/i, score: 0.5 }, // "a" before vowel instead of "an"
    { pattern: /\ban\s+[^aeiou]/i, score: 0.5 }, // "an" before consonant
    { pattern: /[.,!?]["')\]]/, score: 0.3 }, // Punctuation before closing quote/bracket
    { pattern: /\s+[.,!?:;]/, score: 0.3 },   // Space before punctuation
  ];
  
  // Count grammar issues
  let grammarScore = 10; // Start with perfect score
  for (const check of grammarChecks) {
    const matches = text.match(check.pattern);
    if (matches !== null && Array.isArray(matches) && matches.length > 0) {
      grammarScore -= matches.length * check.score;
    }
  }
  
  // Normalize to 0-5 scale (higher is more AI-like = perfect grammar)
  return Math.min(5, Math.max(0, grammarScore) / 2);
}

/**
 * Main content analysis function
 * Returns detailed analysis of content with AI vs Human indicators
 */
export const analyzeContent = (text: string) => {
  // Calculate individual scores
  const nGramScore = analyzeNGrams(text);
  const sentenceScore = analyzeSentenceStructure(text);
  const complexityScore = analyzeLanguageComplexity(text);
  const phrasesScore = detectAIPhrases(text);
  const grammarScore = analyzeGrammarQuality(text);
  
  // Calculate total AI probability
  const totalPoints = nGramScore + sentenceScore + complexityScore + phrasesScore + grammarScore;
  const maxPoints = 25; // 5 points max for each of 5 categories
  const aiProbability = Math.round((totalPoints / maxPoints) * 100);
  
  // Determine overall source categorization with confidence
  let sourceType: "ai" | "human" | "mixed" = "mixed";
  let confidenceScore = 60; // Base confidence
  
  if (aiProbability >= 70) {
    sourceType = "ai";
    confidenceScore = Math.min(95, 70 + (aiProbability - 70) * 1.5);
  } else if (aiProbability <= 30) {
    sourceType = "human";
    confidenceScore = Math.min(95, 70 + (30 - aiProbability) * 1.5);
  } else {
    // For mixed cases, confidence is lower
    confidenceScore = Math.max(50, 60 - Math.abs(50 - aiProbability));
  }
  
  // Determine language style
  const styles = [
    "Formal Academic", "Conversational", "Technical", 
    "Creative Narrative", "Instructional", "Analytical",
    "Persuasive", "Descriptive", "Journalistic"
  ];
  
  // Determine tone
  const tones = [
    "Neutral", "Professional", "Enthusiastic", 
    "Authoritative", "Informative", "Friendly",
    "Matter-of-fact", "Detailed", "Balanced"
  ];
  
  // Content type
  const contentTypes = [
    "Informational", "Explanatory", "Analytical", 
    "Opinion-based", "Tutorial", "Overview",
    "Report", "Review", "Summary"
  ];
  
  // AI patterns
  const patterns = [];
  if (nGramScore > 3) patterns.push("Repetitive word patterns detected");
  if (sentenceScore > 3) patterns.push("Uniform sentence structures");
  if (complexityScore > 3) patterns.push("Limited vocabulary diversity");
  if (phrasesScore > 3) patterns.push("Common AI transitional phrases found");
  if (grammarScore > 4) patterns.push("Unusually perfect grammar");
  
  // Suggest edits based on analysis
  const suggestedEdits = [];
  if (sourceType === "ai" && aiProbability > 60) {
    if (nGramScore > 3) suggestedEdits.push("Vary word choices and phrasing to avoid repetition.");
    if (sentenceScore > 3) suggestedEdits.push("Mix short and long sentences with different structures.");
    if (complexityScore > 3) suggestedEdits.push("Incorporate more diverse vocabulary and expressions.");
    if (phrasesScore > 3) suggestedEdits.push("Replace formal transitions with more natural flow between ideas.");
    if (patterns.length > 2) suggestedEdits.push("Add some personality and unique perspectives to sound more human.");
  }
  
  // Badges for different result types
  const getBadge = () => {
    if (sourceType === "ai") {
      if (aiProbability > 85) return "Highly Likely AI-Generated";
      return "Probably AI-Generated";
    } else if (sourceType === "human") {
      if (aiProbability < 15) return "Likely Human-Written";
      return "Probably Human-Written";
    } else {
      return "Mixed AI/Human Content";
    }
  };
  
  // Get icon name based on source type
  const getIconName = () => {
    if (sourceType === "ai") return "Bot";
    if (sourceType === "human") return "User";
    return "Shield";
  };
  
  // Get color for UI
  const getColor = () => {
    if (sourceType === "ai") return "bg-rose-100 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400";
    if (sourceType === "human") return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400";
    return "bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400";
  };
  
  // Extract some keywords
  const keywords = text
    .toLowerCase()
    .split(/\W+/)
    .filter(w => w.length > 3)
    .reduce((acc: {[key: string]: number}, word) => {
      acc[word] = (acc[word] || 0) + 1;
      return acc;
    }, {});
  
  const topKeywords = Object.entries(keywords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([word]) => word);
  
  // Build the comprehensive analysis result
  return {
    source: {
      type: sourceType,
      probability: aiProbability,
      confidence: Math.round(confidenceScore),
      iconName: getIconName(),
      color: getColor(),
      badge: getBadge()
    },
    categories: [
      {
        name: "Repetitive Patterns",
        value: nGramScore * 20, // Scale to 0-100
        color: "bg-purple-100 dark:bg-purple-900/20",
        iconName: "BarChart2",
        description: "Analysis of repeated word patterns and phrases"
      },
      {
        name: "Sentence Structure",
        value: sentenceScore * 20,
        color: "bg-blue-100 dark:bg-blue-900/20",
        iconName: "AlignLeft",
        description: "Evaluation of sentence variety and construction"
      },
      {
        name: "Language Complexity",
        value: complexityScore * 20,
        color: "bg-emerald-100 dark:bg-emerald-900/20",
        iconName: "FileText",
        description: "Assessment of vocabulary and expression diversity"
      },
      {
        name: "AI Phrases",
        value: phrasesScore * 20,
        color: "bg-amber-100 dark:bg-amber-900/20",
        iconName: "MessageSquare",
        description: "Detection of common AI transitional phrases"
      }
    ],
    languageStyle: styles[Math.floor(Math.random() * styles.length)],
    emotionalTone: tones[Math.floor(Math.random() * tones.length)],
    contentType: contentTypes[Math.floor(Math.random() * contentTypes.length)],
    grammarQuality: grammarScore * 20,
    suggestedEdits: suggestedEdits,
    aiPatterns: patterns,
    keywords: topKeywords
  };
};

/**
 * Generate a text report from the analysis results
 */
export const generateReportText = (result: any, content: string) => {
  const { source, categories, languageStyle, emotionalTone, contentType, grammarQuality, suggestedEdits, aiPatterns } = result;
  
  const report = [
    "CONTENT DETECTIVE ANALYSIS REPORT",
    "===================================",
    "",
    `CONTENT SOURCE: ${source.badge.toUpperCase()}`,
    `AI Probability: ${source.probability}%`,
    `Confidence: ${source.confidence}%`,
    "",
    "CONTENT ATTRIBUTES",
    "------------------",
    `Language Style: ${languageStyle}`,
    `Emotional Tone: ${emotionalTone}`,
    `Content Type: ${contentType}`,
    `Grammar Quality: ${Math.round(grammarQuality)}%`,
    "",
    "ANALYSIS CATEGORIES",
    "-------------------"
  ];
  
  categories.forEach(cat => {
    report.push(`${cat.name}: ${Math.round(cat.value)}% - ${cat.description}`);
  });
  
  if (aiPatterns.length > 0) {
    report.push("");
    report.push("DETECTED AI PATTERNS");
    report.push("-------------------");
    aiPatterns.forEach((pattern, index) => {
      report.push(`${index + 1}. ${pattern}`);
    });
  }
  
  if (suggestedEdits.length > 0) {
    report.push("");
    report.push("IMPROVEMENT SUGGESTIONS");
    report.push("-----------------------");
    suggestedEdits.forEach((suggestion, index) => {
      report.push(`${index + 1}. ${suggestion}`);
    });
  }
  
  report.push("");
  report.push("CONTENT SAMPLE");
  report.push("--------------");
  report.push(content.substring(0, 150) + (content.length > 150 ? "..." : ""));
  report.push("");
  report.push("Generated by Content Detective | MultiToolSet");
  
  return report.join("\n");
};

// Export the analyzeNGrams function for use in other modules
export { analyzeNGrams };
