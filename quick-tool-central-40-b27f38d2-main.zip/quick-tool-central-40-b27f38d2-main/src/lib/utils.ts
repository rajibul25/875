
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Formats a number or string as a currency with the given symbol
 */
export function formatCurrency(amount: number | string, symbol: string = "$"): string {
  // Convert to number, handling both string and number inputs
  const numAmount = typeof amount === 'string' 
    ? parseFloat(amount.replace(/[^\d.-]/g, '')) 
    : amount;
  
  // Handle potential NaN
  const safeAmount = isNaN(numAmount) ? 0 : numAmount;
  
  // Return formatted currency string
  return `${symbol}${safeAmount.toFixed(2)}`;
}
