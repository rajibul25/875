
/**
 * Tool Organization Helper
 * Utilities for organizing tools into categories and managing their structure
 * Version: 1.0.0
 */
import { Tool, ToolCategory } from "./tool-model";

/**
 * Group tools by category
 */
export const groupToolsByCategory = (tools: Tool[]): Record<string, Tool[]> => {
  return tools.reduce((categories, tool) => {
    const category = tool.category || "Uncategorized";
    
    if (!categories[category]) {
      categories[category] = [];
    }
    
    categories[category].push(tool);
    return categories;
  }, {} as Record<string, Tool[]>);
};

/**
 * Create tool path based on category and tool ID
 */
export const createToolPath = (tool: Tool): string => {
  const category = tool.category?.toLowerCase().replace(/\s+/g, '-') || '';
  const id = tool.id.toLowerCase().replace(/\s+/g, '-');
  
  return `/tools/${id}`;
};

/**
 * Create canonical URL for SEO
 */
export const createCanonicalUrl = (tool: Tool, baseUrl: string = "https://tools.domain.com"): string => {
  const path = createToolPath(tool);
  return `${baseUrl}${path}`;
};

/**
 * Get related tools based on category
 */
export const getRelatedTools = (
  currentToolId: string, 
  allTools: Tool[], 
  limit: number = 3
): Tool[] => {
  const currentTool = allTools.find(t => t.id === currentToolId);
  
  if (!currentTool) return [];
  
  return allTools
    .filter(tool => tool.id !== currentToolId && tool.category === currentTool.category)
    .slice(0, limit);
};

/**
 * Create version string for changelog
 */
export const createVersionString = (
  major: number, 
  minor: number, 
  patch: number
): string => {
  return `v${major}.${minor}.${patch}`;
};

/**
 * Parse version string
 */
export const parseVersion = (
  versionString: string
): { major: number; minor: number; patch: number } | null => {
  const match = versionString.match(/^v?(\d+)\.(\d+)\.(\d+)$/);
  
  if (!match) return null;
  
  return {
    major: parseInt(match[1], 10),
    minor: parseInt(match[2], 10),
    patch: parseInt(match[3], 10)
  };
};
