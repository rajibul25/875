import { 
  FileText, 
  Image, 
  FileImage, 
  BarChart, 
  Code, 
  Database, 
  Repeat, 
  Scissors, 
  Zap, 
  Sparkles, 
  MessagesSquare, 
  Binary, 
  Text, 
  Pen, 
  Hash, 
  FileJson, 
  ImagePlus,
  FileBadge,
  QrCode,
  Calculator,
  Columns,
  Brain,
  FolderArchive,
  FolderUp,
  FileArchive,
  Archive,
  Film,
  PenTool,
  Paintbrush,
  Crop,
  FileType,
  FileCode,
  TextQuote,
  Mic,
  Diff,
  AlignLeft,
  BarChart2,
  Search,
  Apple,
  Baby,
  Scale,
  Timer,
  Moon,
  Lock,
  Shield,
  Link
} from "lucide-react";
import React from "react";
import { Tool } from "./tool-model";

const createStyledIcon = (Icon: React.ComponentType<{ className?: string }>, color: string) => {
  return React.createElement(Icon, { className: `h-6 w-6 ${color}` });
};

export const conversionTools: Tool[] = [
  {
    id: "pdf-to-word",
    title: "PDF to Word",
    description: "Convert PDF documents to editable Word files",
    icon: createStyledIcon(FileText, "text-blue-600"),
    path: "/tools/pdf-to-word",
    category: "conversion",
    isPopular: true
  },
  {
    id: "image-to-png",
    title: "Image to PNG",
    description: "Convert various image formats to PNG",
    icon: createStyledIcon(Image, "text-purple-600"),
    path: "/tools/image-to-png",
    category: "conversion"
  },
  {
    id: "image-resizer",
    title: "Image Resizer",
    description: "Resize images to your desired dimensions",
    icon: createStyledIcon(ImagePlus, "text-green-600"),
    path: "/tools/image-resizer",
    category: "conversion"
  },
  {
    id: "image-compressor",
    title: "Image Compressor",
    description: "Compress images while maintaining quality",
    icon: createStyledIcon(FileImage, "text-blue-600"),
    path: "/tools/image-compressor",
    category: "conversion",
    isNew: true
  },
  {
    id: "webp-converter",
    title: "WebP Converter",
    description: "Convert images to and from WebP format",
    icon: createStyledIcon(Repeat, "text-purple-600"),
    path: "/tools/webp-converter",
    category: "conversion",
    isNew: true
  },
  {
    id: "image-cropper",
    title: "Image Cropper",
    description: "Crop images to custom sizes easily",
    icon: createStyledIcon(Crop, "text-yellow-600"),
    path: "/tools/image-cropper",
    category: "conversion"
  },
  {
    id: "image-to-base64",
    title: "Image to Base64",
    description: "Convert images to Base64 encoded strings",
    icon: createStyledIcon(FileType, "text-red-600"),
    path: "/tools/image-to-base64",
    category: "conversion"
  },
  {
    id: "word-to-pdf",
    title: "Word to PDF",
    description: "Convert Word documents to PDF format",
    icon: createStyledIcon(FileBadge, "text-red-600"),
    path: "/tools/word-to-pdf",
    category: "conversion"
  },
  {
    id: "jpg-to-pdf",
    title: "JPG to PDF",
    description: "Convert JPG images to PDF documents",
    icon: createStyledIcon(FileImage, "text-orange-600"),
    path: "/tools/jpg-to-pdf",
    category: "conversion"
  },
  {
    id: "qr-code-generator",
    title: "QR Code Generator",
    description: "Generate QR codes for text, URLs, and more",
    icon: createStyledIcon(QrCode, "text-indigo-600"),
    path: "/tools/qr-code-generator",
    category: "conversion",
    isNew: true
  },
  {
    id: "zip-file-handler",
    title: "ZIP File Handler",
    description: "Upload, extract, and manage ZIP files easily",
    icon: createStyledIcon(Archive, "text-teal-600"),
    path: "/tools/zip-file-handler",
    category: "conversion",
    isNew: true,
    isPopular: true
  },
  {
    id: "gif-maker",
    title: "GIF Maker",
    description: "Create animated GIFs from multiple images",
    icon: createStyledIcon(Film, "text-green-600"),
    path: "/tools/gif-maker",
    category: "conversion",
    isNew: true
  },
];

export const dataTools: Tool[] = [
  {
    id: "data-visualizer",
    title: "Data Visualizer",
    description: "Create interactive charts from your data",
    icon: createStyledIcon(BarChart, "text-blue-600"),
    path: "/tools/data-visualizer",
    category: "data",
    isNew: true
  },
  {
    id: "database-analyzer",
    title: "Database Analyzer",
    description: "Analyze and optimize your database structure",
    icon: createStyledIcon(Database, "text-teal-600"),
    path: "/tools/database-analyzer",
    category: "data",
    isPremium: true
  },
  {
    id: "csv-converter",
    title: "CSV Converter",
    description: "Convert between CSV, JSON, and Excel formats",
    icon: createStyledIcon(Repeat, "text-green-600"),
    path: "/tools/csv-converter",
    category: "data"
  },
  {
    id: "data-cleaning",
    title: "Data Cleaner",
    description: "Clean and normalize your data sets",
    icon: createStyledIcon(Scissors, "text-purple-600"),
    path: "/tools/data-cleaner",
    category: "data",
    isPremium: true
  }
];

export const developerTools: Tool[] = [
  {
    id: "json-formatter",
    title: "JSON Formatter",
    description: "Format and validate JSON data",
    icon: createStyledIcon(FileJson, "text-blue-600"),
    path: "/tools/json-formatter",
    category: "developer",
    isPopular: true
  },
  {
    id: "code-beautifier",
    title: "Code Beautifier",
    description: "Beautify and format your code",
    icon: createStyledIcon(Code, "text-indigo-600"),
    path: "/tools/code-beautifier",
    category: "developer"
  },
  {
    id: "sql-formatter",
    title: "SQL Formatter",
    description: "Format and validate SQL queries",
    icon: createStyledIcon(Database, "text-green-600"),
    path: "/tools/sql-formatter",
    category: "developer"
  },
  {
    id: "api-tester",
    title: "API Tester",
    description: "Test your API endpoints easily",
    icon: createStyledIcon(Zap, "text-yellow-600"),
    path: "/tools/api-tester",
    category: "developer",
    isNew: true
  },
  {
    id: "regex-tester",
    title: "RegEx Tester",
    description: "Test and debug regular expressions",
    icon: createStyledIcon(Hash, "text-red-600"),
    path: "/tools/regex-tester",
    category: "developer"
  },
  {
    id: "hex-converter",
    title: "Binary & Hex Converter",
    description: "Convert between binary, hex, and decimal",
    icon: createStyledIcon(Binary, "text-purple-600"),
    path: "/tools/hex-converter",
    category: "developer"
  },
  {
    id: "svg-editor",
    title: "SVG Editor",
    description: "Edit and customize SVG files easily",
    icon: createStyledIcon(FileCode, "text-emerald-600"),
    path: "/tools/svg-editor",
    category: "developer",
    isNew: true
  }
];

export const contentTools: Tool[] = [
  {
    id: "word-counter",
    title: "Word Counter",
    description: "Count words, characters and more",
    icon: createStyledIcon(Text, "text-blue-600"),
    path: "/tools/word-counter",
    category: "content"
  },
  {
    id: "character-counter",
    title: "Character Counter",
    description: "Count characters with detailed analytics",
    icon: createStyledIcon(Calculator, "text-purple-600"),
    path: "/tools/character-counter",
    category: "content"
  },
  {
    id: "case-converter",
    title: "Case Converter",
    description: "Change text to UPPER, lower, Title case",
    icon: createStyledIcon(TextQuote, "text-indigo-600"),
    path: "/tools/case-converter",
    category: "content"
  },
  {
    id: "plagiarism-checker",
    title: "Plagiarism Checker",
    description: "Check content for originality",
    icon: createStyledIcon(FileText, "text-orange-600"),
    path: "/tools/plagiarism-checker",
    category: "content",
    isPopular: true
  },
  {
    id: "grammar-checker",
    title: "Grammar Checker",
    description: "Fix spelling and grammar errors",
    icon: createStyledIcon(Pen, "text-green-600"),
    path: "/tools/grammar-checker",
    category: "content"
  },
  {
    id: "text-to-speech",
    title: "Text to Speech",
    description: "Convert text into spoken audio",
    icon: createStyledIcon(Mic, "text-teal-600"),
    path: "/tools/text-to-speech",
    category: "content"
  },
  {
    id: "markdown-editor",
    title: "Markdown Editor",
    description: "Write and preview Markdown with syntax highlighting",
    icon: createStyledIcon(Pen, "text-green-600"),
    path: "/tools/markdown-editor",
    category: "content",
    isNew: true
  },
  {
    id: "text-diff-checker",
    title: "Text Diff Checker",
    description: "Compare and find differences between texts",
    icon: createStyledIcon(Diff, "text-red-600"),
    path: "/tools/text-diff-checker",
    category: "content",
    isNew: true
  },
  {
    id: "lorem-ipsum-generator",
    title: "Lorem Ipsum Generator",
    description: "Generate placeholder text for designs",
    icon: createStyledIcon(AlignLeft, "text-yellow-600"),
    path: "/tools/lorem-ipsum-generator",
    category: "content"
  },
  {
    id: "text-repeater",
    title: "Text Repeater",
    description: "Repeat text or emojis multiple times",
    icon: createStyledIcon(Repeat, "text-pink-600"),
    path: "/tools/text-repeater",
    category: "content"
  },
  {
    id: "word-frequency",
    title: "Word Frequency Counter",
    description: "Analyze most common words in text",
    icon: createStyledIcon(BarChart2, "text-indigo-600"),
    path: "/tools/word-frequency",
    category: "content",
    isNew: true
  },
  {
    id: "content-detective",
    title: "Content Detective",
    description: "Detect if content is AI-generated or human-written",
    icon: createStyledIcon(Search, "text-purple-600"),
    path: "/tools/content-detective",
    category: "content",
    isNew: true,
    isPopular: true
  }
];

export const aiTools: Tool[] = [
  {
    id: "text-generator",
    title: "AI Text Generator",
    description: "Generate creative text with advanced AI",
    icon: createStyledIcon(Sparkles, "text-purple-600"),
    path: "/tools/text-generator",
    category: "ai",
    isPopular: true
  },
  {
    id: "chatbot",
    title: "AI Chatbot",
    description: "Interact with our intelligent AI assistant",
    icon: createStyledIcon(MessagesSquare, "text-blue-600"),
    path: "/tools/chatbot",
    category: "ai",
    isNew: true
  },
  {
    id: "image-generator",
    title: "AI Image Generator",
    description: "Create unique images with AI",
    icon: createStyledIcon(Image, "text-green-600"),
    path: "/tools/image-generator",
    category: "ai",
    isPremium: true
  },
  {
    id: "text-summarizer",
    title: "AI Text Summarizer",
    description: "Automatically summarize long texts",
    icon: createStyledIcon(Brain, "text-orange-600"),
    path: "/tools/text-summarizer",
    category: "ai"
  }
];

export const visualTools: Tool[] = [
  {
    id: "image-color-picker",
    title: "Image Color Picker",
    description: "Extract color codes from images",
    icon: createStyledIcon(PenTool, "text-pink-600"),
    path: "/tools/image-color-picker",
    category: "visual",
    isNew: true
  },
  {
    id: "gif-maker",
    title: "GIF Maker",
    description: "Create animated GIFs from multiple images",
    icon: createStyledIcon(Film, "text-green-600"),
    path: "/tools/gif-maker",
    category: "visual",
    isNew: true
  },
  {
    id: "webp-converter",
    title: "WebP Converter",
    description: "Convert images to and from WebP format",
    icon: createStyledIcon(Repeat, "text-purple-600"),
    path: "/tools/webp-converter",
    category: "visual",
    isNew: true
  },
  {
    id: "image-cropper",
    title: "Image Cropper",
    description: "Crop images to custom sizes easily",
    icon: createStyledIcon(Crop, "text-yellow-600"),
    path: "/tools/image-cropper",
    category: "visual"
  }
];

export const healthTools: Tool[] = [
  {
    id: "calorie-counter",
    title: "Calorie Counter",
    description: "Track daily calorie intake",
    icon: createStyledIcon(Apple, "text-green-600"),
    path: "/tools/calorie-counter",
    category: "health",
    isNew: true
  },
  {
    id: "pregnancy-calculator",
    title: "Pregnancy Calculator",
    description: "Calculate due date and more",
    icon: createStyledIcon(Baby, "text-pink-600"),
    path: "/tools/pregnancy-calculator",
    category: "health",
    isNew: true
  },
  {
    id: "ideal-weight-calculator",
    title: "Ideal Weight Calculator",
    description: "Find your ideal weight range",
    icon: createStyledIcon(Scale, "text-blue-600"),
    path: "/tools/ideal-weight-calculator",
    category: "health",
    isNew: true
  },
  {
    id: "pace-calculator",
    title: "Pace Calculator",
    description: "Calculate running/walking pace",
    icon: createStyledIcon(Timer, "text-teal-600"),
    path: "/tools/pace-calculator",
    category: "health",
    isNew: true
  },
  {
    id: "sleep-calculator",
    title: "Sleep Calculator",
    description: "Find ideal bedtime & wake time",
    icon: createStyledIcon(Moon, "text-indigo-600"),
    path: "/tools/sleep-calculator",
    category: "health",
    isNew: true
  }
];

export const securityTools: Tool[] = [
  {
    id: "password-generator",
    title: "Password Generator",
    description: "Generate strong, secure passwords with custom requirements",
    icon: createStyledIcon(Lock, "text-purple-600"),
    path: "/tools/password-generator",
    category: "security",
    isPopular: true,
    bgColor: "bg-purple-100 dark:bg-purple-900/30"
  },
  {
    id: "md5-generator",
    title: "MD5 Hash Generator",
    description: "Create MD5 hash values from any text or string input",
    icon: createStyledIcon(Hash, "text-blue-600"),
    path: "/tools/md5-generator",
    category: "security",
    bgColor: "bg-blue-100 dark:bg-blue-900/30"
  },
  {
    id: "sha256-generator",
    title: "SHA256 Generator",
    description: "Generate secure SHA256 hash values for any text input",
    icon: createStyledIcon(Shield, "text-green-600"),
    path: "/tools/sha256-generator",
    category: "security",
    bgColor: "bg-green-100 dark:bg-green-900/30"
  },
  {
    id: "random-string-generator",
    title: "Random String Generator",
    description: "Create random strings with custom length and character sets",
    icon: createStyledIcon(Text, "text-orange-600"),
    path: "/tools/random-string-generator",
    category: "security",
    bgColor: "bg-orange-100 dark:bg-orange-900/30"
  },
  {
    id: "url-shortener",
    title: "URL Shortener",
    description: "Shorten long URLs into compact, easy-to-share links",
    icon: createStyledIcon(Link, "text-indigo-600"),
    path: "/tools/url-shortener",
    category: "security",
    isNew: true,
    bgColor: "bg-indigo-100 dark:bg-indigo-900/30"
  }
];

export const seoTools = [
  {
    id: "meta-tag-generator",
    title: "Meta Tag Generator",
    description: "Create perfect meta titles and descriptions for better CTR",
    category: "SEO",
    path: "/tools/meta-tag-generator",
    icon: createStyledIcon(FileText, "text-blue-600"),
    bgColor: "bg-blue-100 dark:bg-blue-900/30"
  },
  {
    id: "keyword-density-checker",
    title: "Keyword Density Checker",
    description: "Analyze your content and optimize keyword usage",
    category: "SEO",
    path: "/tools/keyword-density-checker",
    icon: createStyledIcon(Search, "text-purple-600"),
    bgColor: "bg-purple-100 dark:bg-purple-900/30"
  }
];

export const mathTools = [
  {
    id: "percentage-calculator",
    title: "Percentage Calculator",
    description: "Calculate percentages and ratios",
    icon: createStyledIcon(BarChart, "text-blue-600"),
    path: "/tools/percentage-calculator",
    category: "math",
    isPopular: true
  },
  {
    id: "age-calculator",
    title: "Age Calculator",
    description: "Calculate age based on birthdate",
    icon: createStyledIcon(Calculator, "text-purple-600"),
    path: "/tools/age-calculator",
    category: "math"
  },
  {
    id: "bmi-calculator",
    title: "BMI Calculator",
    description: "Calculate Body Mass Index",
    icon: createStyledIcon(Database, "text-teal-600"),
    path: "/tools/bmi-calculator",
    category: "math"
  },
  {
    id: "loan-calculator",
    title: "Loan EMI Calculator",
    description: "Calculate Loan EMI",
    icon: createStyledIcon(Repeat, "text-purple-600"),
    path: "/tools/EMI-Calculator",
    category: "math",
    isPopular: true
  },
  {
    id: "mortgage-calculator",
    title: "Mortgage Calculator",
    description: "Calculate Mortgage",
    icon: createStyledIcon(Crop, "text-yellow-600"),
    path: "/tools/Mortgage-Calculator",
    category: "math",
    isNew: true
  },
  {
    id: "loan-interest-calculator",
    title: "Loan Interest Calculator",
    description: "Calculate Loan Interest",
    icon: createStyledIcon(Hash, "text-red-600"),
    path: "/tools/Loan-Interest-Calculator",
    category: "math",
    isNew: true
  }
];
