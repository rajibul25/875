
export interface Tool {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
  category: string;
  isPopular?: boolean;
  isNew?: boolean;
  isPremium?: boolean;
  tags?: string[];
  href?: string;
  slug?: string;
  bgColor?: string;
}

export interface ToolCategory {
  name: string;
  displayName?: string;
  icon?: string;
  description?: string;
  id?: string;
  tools?: Tool[];
}
