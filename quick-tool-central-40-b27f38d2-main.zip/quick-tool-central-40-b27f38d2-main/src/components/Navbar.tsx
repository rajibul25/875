import { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Search, 
  Menu, 
  ChevronDown, 
  FileText, 
  FileImage, 
  Info, 
  Mail, 
  Shield, 
  Book,
  File,
  Layers,
  ScrollText,
  Settings,
  ExternalLink,
  Heart,
  Users,
  Lock,
  FileLock2,
  Merge,
  FileOutput,
  Download,
  Share2,
  Facebook,
  Twitter,
  Instagram,
  Cpu,
  Database,
  Terminal,
  HardDrive,
  Network,
  Scan,
  Zap,
  BarChart,
  Home
} from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { 
  Collapsible, 
  CollapsibleContent, 
  CollapsibleTrigger 
} from "@/components/ui/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navbar = () => {
  const [open, setOpen] = useState<{[key: string]: boolean}>({
    company: false,
    convertFromPdf: false,
    convertToPdf: false,
    pdfEditor: false,
    systemTools: false
  });

  const toggleCollapsible = (section: string) => {
    setOpen(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const menuCategories = [
    {
      id: "company",
      label: "Company Info",
      icon: <Info className="h-5 w-5 mr-2 text-tool-blue" />,
      children: [
        { 
          label: "About us", 
          to: "/about", 
          icon: <Users className="h-4 w-4 mr-2 text-tool-purple" /> 
        },
        { 
          label: "Contact us", 
          to: "/contact", 
          icon: <Mail className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Privacy Policy", 
          to: "/privacy", 
          icon: <Shield className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Terms & Conditions", 
          to: "/terms", 
          icon: <Book className="h-4 w-4 mr-2 text-tool-orange" /> 
        }
      ]
    },
    {
      id: "convertFromPdf",
      label: "Convert from PDF",
      icon: <FileText className="h-5 w-5 mr-2 text-tool-red" />,
      children: [
        { 
          label: "PDF to Word", 
          to: "/tools/pdf-to-word", 
          icon: <ScrollText className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "PDF to PowerPoint", 
          to: "/tools/pdf-to-powerpoint", 
          icon: <Layers className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "PDF to JPG", 
          to: "/tools/pdf-to-jpg", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "PDF to PNG", 
          to: "/tools/pdf-to-png", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-purple" /> 
        }
      ]
    },
    {
      id: "convertToPdf",
      label: "Convert to PDF",
      icon: <FileText className="h-5 w-5 mr-2 text-tool-green" />,
      children: [
        { 
          label: "Word to PDF", 
          to: "/tools/word-to-pdf", 
          icon: <ScrollText className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "PowerPoint to PDF", 
          to: "/tools/powerpoint-to-pdf", 
          icon: <Layers className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "JPG to PDF", 
          to: "/tools/jpg-to-pdf", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "PNG to PDF", 
          to: "/tools/png-to-pdf", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-purple" /> 
        }
      ]
    },
    {
      id: "pdfEditor",
      label: "PDF Editor Tools",
      icon: <Settings className="h-5 w-5 mr-2 text-tool-purple" />,
      children: [
        { 
          label: "Merge PDF", 
          to: "/tools/merge-pdf", 
          icon: <Merge className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Remove Pages", 
          to: "/tools/remove-pages", 
          icon: <FileOutput className="h-4 w-4 mr-2 text-tool-red" /> 
        },
        { 
          label: "Compress PDF", 
          to: "/tools/compress-pdf", 
          icon: <Download className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Unlock PDF", 
          to: "/tools/unlock-pdf", 
          icon: <FileLock2 className="h-4 w-4 mr-2 text-tool-orange" /> 
        }
      ]
    },
    {
      id: "systemTools",
      label: "Advanced System Tools",
      icon: <Cpu className="h-5 w-5 mr-2 text-tool-blue" />,
      children: [
        { 
          label: "System Monitor", 
          to: "/tools/system-monitor", 
          icon: <Terminal className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Disk Analyzer", 
          to: "/tools/disk-analyzer", 
          icon: <HardDrive className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Network Diagnostics", 
          to: "/tools/network-diagnostics", 
          icon: <Network className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "Database Viewer", 
          to: "/tools/database-viewer", 
          icon: <Database className="h-4 w-4 mr-2 text-tool-purple" /> 
        },
        { 
          label: "Port Scanner", 
          to: "/tools/port-scanner", 
          icon: <Scan className="h-4 w-4 mr-2 text-tool-red" /> 
        },
        { 
          label: "Process Manager", 
          to: "/tools/process-manager", 
          icon: <Zap className="h-4 w-4 mr-2 text-tool-yellow" /> 
        }
      ]
    }
  ];

  const renderDesktopMenu = () => (
    <nav className="hidden md:flex items-center space-x-8">
      <Link to="/" className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
        <span className="inline-flex items-center gap-1.5">
          <Home className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
          <span className="relative">
            Home
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
          </span>
        </span>
      </Link>
      
      {/* Desktop Dropdown Menus */}
      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
          <span className="inline-flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-tool-orange group-hover:scale-110 transition-transform duration-200" />
            <span className="relative">
              Tools
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
            </span>
            <ChevronDown className="ml-0.5 h-4 w-4 group-hover:rotate-180 transition-transform duration-300" />
          </span>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 p-2 rounded-lg shadow-lg border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 animate-fade-in">
          <Link to="/tools">
            <DropdownMenuItem className="cursor-pointer hover:bg-purple-50 dark:hover:bg-gray-800 rounded-md transition-colors duration-200 py-2.5 my-1">
              <Zap className="h-4 w-4 mr-2 text-tool-purple" />
              <span>All Tools</span>
            </DropdownMenuItem>
          </Link>
          <Link to="/more-tools">
            <DropdownMenuItem className="cursor-pointer hover:bg-purple-50 dark:hover:bg-gray-800 rounded-md transition-colors duration-200 py-2.5 my-1">
              <Layers className="h-4 w-4 mr-2 text-tool-blue" />
              <span>Tool Categories</span>
            </DropdownMenuItem>
          </Link>
          <Link to="/tools/pdf-to-word">
            <DropdownMenuItem className="cursor-pointer hover:bg-purple-50 dark:hover:bg-gray-800 rounded-md transition-colors duration-200 py-2.5 my-1">
              <FileText className="h-4 w-4 mr-2 text-tool-red" />
              <span>PDF Converters</span>
            </DropdownMenuItem>
          </Link>
          <Link to="/tools/word-to-pdf">
            <DropdownMenuItem className="cursor-pointer hover:bg-purple-50 dark:hover:bg-gray-800 rounded-md transition-colors duration-200 py-2.5 my-1">
              <FileOutput className="h-4 w-4 mr-2 text-tool-green" />
              <span>File Converters</span>
            </DropdownMenuItem>
          </Link>
        </DropdownMenuContent>
      </DropdownMenu>
      
      {/* Dashboard Link */}
      <Link to="/dashboard" className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
        <span className="inline-flex items-center gap-1.5">
          <BarChart className="w-4 h-4 text-tool-blue group-hover:scale-110 transition-transform duration-200" />
          <span className="relative">
            Dashboard
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
          </span>
        </span>
      </Link>
      
      <Link to="/about" className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
        <span className="inline-flex items-center gap-1.5">
          <Users className="w-4 h-4 text-tool-purple group-hover:scale-110 transition-transform duration-200" />
          <span className="relative">
            About
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
          </span>
        </span>
      </Link>
      
      <Link to="/contact" className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
        <span className="inline-flex items-center gap-1.5">
          <Mail className="w-4 h-4 text-tool-green group-hover:scale-110 transition-transform duration-200" />
          <span className="relative">
            Contact
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
          </span>
        </span>
      </Link>
      
      <Link to="/legal" className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple transition-all duration-200 font-medium group">
        <span className="inline-flex items-center gap-1.5">
          <Shield className="w-4 h-4 text-tool-orange group-hover:scale-110 transition-transform duration-200" />
          <span className="relative">
            Legal
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-tool-purple group-hover:w-full transition-all duration-300"></span>
          </span>
        </span>
      </Link>
      
      <button className="p-2 text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-all duration-200">
        <Search className="w-5 h-5" />
      </button>
      
      <DarkModeToggle />
    </nav>
  );

  const renderMobileMenu = () => (
    <Sheet>
      <SheetTrigger asChild className="md:hidden">
        <button className="text-gray-700 dark:text-gray-200 hover:text-tool-purple dark:hover:text-tool-purple focus:outline-none transition-colors duration-200" aria-label="Open menu">
          <Menu className="h-6 w-6" />
        </button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[320px] p-0 bg-white dark:bg-gray-900 overflow-y-auto shadow-xl">
        <div className="flex flex-col h-full">
          {/* Header with logo and dark mode toggle */}
          <div className="p-5 border-b border-gray-100 dark:border-gray-800 bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-800">
            <div className="flex justify-between items-center">
              <Link to="/" className="flex items-center space-x-2 group">
                <span className="text-tool-blue font-bold text-2xl transition-all duration-300 group-hover:scale-105">
                  <span className="text-tool-navy">Multi</span>
                  tool<span className="text-tool-purple">Set</span>
                </span>
              </Link>
              <DarkModeToggle />
            </div>
          </div>
          
          {/* Social sharing section with improved styling */}
          <div className="px-4 py-5 border-b border-gray-100 dark:border-gray-800 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-gray-800/70 dark:to-gray-800/40">
            <div className="text-center mb-3">
              <p className="text-gray-700 dark:text-gray-200 text-sm font-medium">If you love our tools, please share!</p>
            </div>
            <div className="flex justify-center space-x-6">
              <a href="#" className="text-blue-600 hover:text-blue-700 transition-all duration-200 hover:scale-110" aria-label="Share on Facebook">
                <Facebook className="h-6 w-6 animate-pulse-soft" />
              </a>
              <a href="#" className="text-sky-500 hover:text-sky-600 transition-all duration-200 hover:scale-110" aria-label="Share on Twitter">
                <Twitter className="h-6 w-6 animate-pulse-soft" />
              </a>
              <a href="#" className="text-pink-600 hover:text-pink-700 transition-all duration-200 hover:scale-110" aria-label="Share on Instagram">
                <Instagram className="h-6 w-6 animate-pulse-soft" />
              </a>
            </div>
          </div>
          
          {/* Main navigation links with enhanced styling */}
          <div className="p-3 space-y-2 animate-fade-in">
            <Link 
              to="/" 
              className="flex items-center py-3 px-4 rounded-lg hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 dark:hover:from-gray-800 dark:hover:to-gray-700 transition-all duration-200 font-medium text-gray-800 dark:text-gray-200 group"
            >
              <div className="mr-3 p-2 bg-gradient-to-br from-gray-100 to-white dark:from-gray-800 dark:to-gray-700 shadow-sm rounded-md group-hover:from-tool-purple/10 group-hover:to-tool-blue/10 transition-all duration-200">
                <Home className="w-5 h-5 text-gray-700 dark:text-gray-300 group-hover:text-tool-purple dark:group-hover:text-tool-purple transition-colors duration-200" />
              </div>
              <span className="group-hover:translate-x-1 transition-transform duration-200">Home</span>
            </Link>
            
            <Link 
              to="/tools" 
              className="flex items-center py-3 px-4 rounded-lg hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 dark:hover:from-gray-800 dark:hover:to-gray-700 transition-all duration-200 font-medium text-gray-800 dark:text-gray-200 group"
            >
              <div className="mr-3 p-2 bg-gradient-to-br from-gray-100 to-white dark:from-gray-800 dark:to-gray-700 shadow-sm rounded-md group-hover:from-tool-purple/10 group-hover:to-tool-blue/10 transition-all duration-200">
                <Zap className="w-5 h-5 text-tool-orange group-hover:text-tool-orange/80 transition-colors duration-200" />
              </div>
              <span className="group-hover:translate-x-1 transition-transform duration-200">All Tools</span>
            </Link>
            
            <Link 
              to="/dashboard" 
              className="flex items-center py-3 px-4 rounded-lg hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 dark:hover:from-gray-800 dark:hover:to-gray-700 transition-all duration-200 font-medium text-gray-800 dark:text-gray-200 group"
            >
              <div className="mr-3 p-2 bg-gradient-to-br from-gray-100 to-white dark:from-gray-800 dark:to-gray-700 shadow-sm rounded-md group-hover:from-tool-purple/10 group-hover:to-tool-blue/10 transition-all duration-200">
                <BarChart className="w-5 h-5 text-tool-blue group-hover:text-tool-blue/80 transition-colors duration-200" />
              </div>
              <span className="group-hover:translate-x-1 transition-transform duration-200">Dashboard</span>
            </Link>
            
            <Link 
              to="/more-tools" 
              className="flex items-center py-3 px-4 rounded-lg hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 dark:hover:from-gray-800 dark:hover:to-gray-700 transition-all duration-200 font-medium text-gray-800 dark:text-gray-200 group"
            >
              <div className="mr-3 p-2 bg-gradient-to-br from-gray-100 to-white dark:from-gray-800 dark:to-gray-700 shadow-sm rounded-md group-hover:from-tool-purple/10 group-hover:to-tool-blue/10 transition-all duration-200">
                <Layers className="w-5 h-5 text-tool-green group-hover:text-tool-green/80 transition-colors duration-200" />
              </div>
              <span className="group-hover:translate-x-1 transition-transform duration-200">More Tools</span>
            </Link>
          </div>
          
          {/* Category collapsibles with improved styling */}
          <div className="px-3 py-2 flex-1 overflow-y-auto space-y-3">
            {menuCategories.map((category) => (
              <Collapsible
                key={category.id}
                open={open[category.id]}
                onOpenChange={() => toggleCollapsible(category.id)}
                className="overflow-hidden animate-scale-in"
              >
                <CollapsibleTrigger 
                  className="flex justify-between items-center w-full p-4 bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 
                  hover:from-purple-50 hover:to-blue-50 dark:hover:from-gray-800 dark:hover:to-gray-700 
                  text-left transition-all duration-300 font-medium rounded-lg shadow-sm border border-gray-100 dark:border-gray-700"
                >
                  <div className="flex items-center">
                    <div className="mr-3 p-1.5 bg-white dark:bg-gray-800 rounded-md shadow-sm">
                      {category.icon}
                    </div>
                    <span className="text-gray-800 dark:text-gray-200">{category.label}</span>
                  </div>
                  <ChevronDown 
                    className={`w-5 h-5 text-gray-500 dark:text-gray-400 transition-transform duration-300 ${
                      open[category.id] ? 'rotate-180 text-tool-purple dark:text-tool-purple' : ''
                    }`} 
                  />
                </CollapsibleTrigger>
                <CollapsibleContent className="bg-white dark:bg-gray-900 overflow-hidden rounded-b-lg border-x border-b border-gray-100 dark:border-gray-700 animate-collapsible-down shadow-sm">
                  <div className="py-1">
                    {category.children.map((item, index) => (
                      <Link
                        key={index}
                        to={item.to}
                        className="flex items-center py-3 px-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-200 text-gray-700 dark:text-gray-300 group"
                      >
                        <div className="p-1.5 mr-3 bg-white dark:bg-gray-800 rounded-md shadow-sm group-hover:bg-gray-100 dark:group-hover:bg-gray-700 transition-colors duration-200">
                          {item.icon}
                        </div>
                        <span className="group-hover:translate-x-1 transition-transform duration-200">{item.label}</span>
                      </Link>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
          
          {/* Footer with enhanced styling */}
          <div className="mt-auto p-4 border-t border-gray-100 dark:border-gray-800 text-center bg-gradient-to-r from-purple-50 to-blue-50 dark:from-gray-800/50 dark:to-gray-800/25">
            <div className="text-gray-600 dark:text-gray-400 font-medium text-sm flex items-center justify-center">
              Made with <Heart className="inline-block h-4 w-4 text-red-500 mx-1.5 animate-pulse-soft" fill="currentColor" /> by MultiToolSet
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-800 shadow-sm">
      <div className="container mx-auto flex justify-between items-center py-4 px-6">
        <div className="flex items-center">
          <Link to="/" className="flex items-center space-x-2 group transition-all duration-300">
            <div className="relative overflow-hidden">
              <span className="text-tool-blue font-bold text-3xl relative transition-all duration-300 group-hover:scale-105">
                <span className="text-tool-navy">Multi</span>
                tool<span className="text-tool-purple">Set</span>
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-tool-blue via-tool-purple to-tool-navy group-hover:w-full transition-all duration-500"></span>
              </span>
            </div>
          </Link>
        </div>
        {renderDesktopMenu()}
        {renderMobileMenu()}
      </div>
    </header>
  );
};

export default Navbar;
