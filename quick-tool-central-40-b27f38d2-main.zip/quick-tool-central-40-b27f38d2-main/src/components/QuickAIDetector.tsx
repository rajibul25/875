
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FileSearch, Image } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { analyzeContent } from "@/services/ContentAnalysisService";
import ContentAnalysisProgress from "./ContentAnalysisProgress";

const QuickAIDetector = () => {
  const [text, setText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleAnalyze = () => {
    if (text.trim().length < 20) {
      toast.error("Please enter at least 20 characters to analyze");
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    // Perform analysis
    setTimeout(() => {
      const analysis = analyzeContent(text);
      setResult(analysis);
      setIsAnalyzing(false);
      toast.success("Analysis complete!");
    }, 1500);
  };

  return (
    <Card className="mb-6 border-purple-100 dark:border-purple-900/20 shadow-sm">
      <CardContent className="pt-4 pb-4">
        <div className="flex items-center mb-3">
          <div className="mr-2 p-1.5 bg-purple-100 dark:bg-purple-900/30 rounded-md">
            <FileSearch className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </div>
          <h3 className="text-md font-medium">Quick AI Content Detector</h3>
        </div>
        
        <div className="space-y-3">
          <div className="flex space-x-2">
            <Textarea
              placeholder="Paste a short text sample to quickly check if it's AI-generated..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="min-h-[60px] text-sm resize-none bg-white dark:bg-gray-950 border-purple-100 dark:border-purple-800/30"
            />
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setText("")}
              disabled={!text || isAnalyzing}
              className="text-xs py-1 h-8"
            >
              Clear
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              disabled={isAnalyzing}
              className="text-xs py-1 h-8"
              onClick={() => {
                toast.info("Image detection coming soon!");
              }}
            >
              <Image className="h-3.5 w-3.5 mr-1" />
              Check Image
            </Button>
            
            <Button
              className="ml-auto bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs py-1 h-8"
              size="sm"
              disabled={isAnalyzing || text.trim().length < 20}
              onClick={handleAnalyze}
            >
              {isAnalyzing ? "Analyzing..." : "Analyze Now"}
            </Button>
          </div>

          {(isAnalyzing || result) && (
            <ContentAnalysisProgress 
              isAnalyzing={isAnalyzing}
              aiPercentage={result ? result.source.probability : 50}
            />
          )}
          
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="bg-purple-50 dark:bg-purple-900/10 rounded-md p-3 text-sm"
            >
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{result.source.badge}</span>
                  <span className={`font-bold ${
                    result.source.type === "ai" ? "text-rose-500" : 
                    result.source.type === "human" ? "text-emerald-500" : 
                    "text-blue-500"
                  }`}>
                    {result.source.type === "ai" ? 
                      `${result.source.probability}% AI` : 
                      result.source.type === "human" ? 
                      `${100 - result.source.probability}% Human` : 
                      "Mixed Content"
                    }
                  </span>
                </div>
                
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Writing Style:</span>
                    <span>{result.languageStyle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Tone:</span>
                    <span>{result.emotionalTone}</span>
                  </div>
                </div>
                
                {result.suggestedEdits.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-purple-200 dark:border-purple-800/30">
                    <p className="text-xs">{result.suggestedEdits[0]}</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickAIDetector;
