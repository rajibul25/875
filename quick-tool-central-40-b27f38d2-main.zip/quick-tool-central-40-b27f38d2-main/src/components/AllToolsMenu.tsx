import React, { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { 
  conversionTools, 
  dataTools, 
  developerTools, 
  contentTools, 
  aiTools, 
  visualTools,
  healthTools,
  securityTools,
  seoTools
} from "../lib/tool-categories";
import { Tool } from "../lib/tool-model";
import { Button } from "@/components/ui/button";
import BackButton from "./BackButton";

// All main tool categories (keep this structure in sync across codebase)
const toolCategories = [
  { slug: "conversion", label: "Conversion Tools", tools: conversionTools, gradient: "from-tool-blue via-tool-purple to-tool-pink" },
  { slug: "data", label: "Data & Analytics Tools", tools: dataTools, gradient: "from-tool-pink via-tool-blue to-tool-purple" },
  { slug: "developer", label: "Developer Tools", tools: developerTools, gradient: "from-tool-orange via-tool-yellow to-tool-purple" },
  { slug: "content", label: "Content Creation Tools", tools: contentTools, gradient: "from-tool-purple via-tool-blue to-tool-green" },
  { slug: "ai", label: "AI-Powered Tools", tools: aiTools, gradient: "from-tool-pink via-tool-purple to-tool-blue" },
  { slug: "visual", label: "Visual & Media Tools", tools: visualTools, gradient: "from-tool-blue via-tool-green to-tool-purple" },
  { slug: "health", label: "Health & Wellness Tools", tools: healthTools, gradient: "from-tool-green via-tool-blue to-tool-pink" },
  { slug: "security", label: "Security & Encryption Tools", tools: securityTools, gradient: "from-tool-purple via-tool-blue to-tool-orange" },
  { slug: "seo", label: "SEO Tools", tools: seoTools, gradient: "from-tool-pink via-tool-orange to-tool-yellow" }
];

export default function AllToolsMenu() {
  const [openCategory, setOpenCategory] = useState<string | null>(toolCategories[0].slug);
  const navigate = useNavigate();

  const handleToggleCategory = (categorySlug: string) => {
    setOpenCategory((old) => old === categorySlug ? null : categorySlug);
  };

  return (
    <div className="max-w-2xl mx-auto bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl px-4 py-4 mt-8 mb-12 border border-gray-100">
      <div className="flex items-center gap-2 mb-5">
        <BackButton className="mr-2" />
        <h1 className="text-2xl font-extrabold bg-gradient-to-r from-tool-purple via-tool-blue to-tool-pink text-transparent bg-clip-text select-none">
          All Tools by Category
        </h1>
      </div>
      <div className="flex flex-col gap-4">
        {toolCategories.map((category) => {
          const toolsForCategory = category.tools || [];
          const expanded = openCategory === category.slug;
          return (
            <div
              key={category.slug}
              className={`rounded-2xl border-2 border-transparent shadow-md transition-all duration-300 group
                bg-gradient-to-br ${category.gradient} hover:scale-[1.01] active:scale-[.99]`}
              style={{ boxShadow: expanded ? "0 8px 30px 0 rgba(155,135,245,.19)" : undefined }}
            >
              <button
                className={`
                  w-full flex items-center justify-between px-6 py-5 text-left text-lg font-bold transition 
                  focus:outline-none focus-visible:ring-2 focus-visible:ring-tool-purple/40
                  bg-white/60 backdrop-blur-md rounded-t-2xl group-hover:bg-white/80 dark:bg-gray-900/70
                  ${expanded ? "rounded-b-none" : "rounded-b-2xl" }
                `}
                aria-expanded={expanded}
                onClick={() => handleToggleCategory(category.slug)}
              >
                <span className="flex-1 text-tool-navy font-semibold tracking-tight">{category.label}</span>
                <span className="ml-2">
                  <ChevronDown 
                    size={28}
                    strokeWidth={2.3}
                    className={`transition-transform duration-300 ${expanded ? "rotate-180" : ""} text-tool-purple drop-shadow-md`}
                  />
                </span>
              </button>
              {/* Category content */}
              <div
                className={`
                  overflow-hidden bg-white/90 dark:bg-gray-950/90 px-4 transition-all duration-300 rounded-b-2xl
                  border-t border-tool-purple/10
                  ${expanded ? "max-h-[600px] py-4 opacity-100" : "max-h-0 py-0 opacity-0"}
                `}
                aria-hidden={!expanded}
                style={{ transitionProperty: "max-height, opacity, padding" }}
              >
                {toolsForCategory.length > 0 ? (
                  <ul className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2">
                    {toolsForCategory.map((tool) => (
                      <li key={tool.id} className="py-2 px-2 rounded hover:bg-tool-purple/10 transition">
                        <Link
                          to={`/tools/${tool.id}`}
                          className="text-tool-purple hover:text-tool-blue transition font-medium text-base flex flex-row items-center gap-2"
                        >
                          <span className="truncate">{tool.title}</span>
                          {tool.isNew && (
                            <span className="ml-1 px-1.5 bg-green-100 text-green-800 text-xs rounded font-semibold">New</span>
                          )}
                          {tool.isPopular && (
                            <span className="ml-1 px-1.5 bg-orange-100 text-orange-800 text-xs rounded font-medium">Popular</span>
                          )}
                          {tool.isPremium && (
                            <span className="ml-1 px-1.5 bg-purple-100 text-purple-800 text-xs rounded font-medium">Premium</span>
                          )}
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="px-4 py-3 text-sm text-gray-400 text-center">
                    No tools in this category yet.
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
