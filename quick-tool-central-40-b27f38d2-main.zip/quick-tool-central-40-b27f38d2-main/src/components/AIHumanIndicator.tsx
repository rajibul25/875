
import { motion } from "framer-motion";
import { User, Bot, Shield } from "lucide-react";

interface AIHumanIndicatorProps {
  probability: number;
  isAnalyzing: boolean;
}

const AIHumanIndicator = ({ probability, isAnalyzing }: AIHumanIndicatorProps) => {
  // Determine which icon to show based on probability
  const getIcon = () => {
    if (probability >= 65) return <Bot className="h-8 w-8 text-white" />;
    if (probability <= 35) return <User className="h-8 w-8 text-white" />;
    return <Shield className="h-8 w-8 text-white" />;
  };

  // Get background gradient based on probability
  const getGradient = () => {
    if (probability >= 65) return "from-rose-500 to-purple-600";
    if (probability <= 35) return "from-emerald-500 to-teal-600";
    return "from-blue-500 to-indigo-600";
  };

  return (
    <div className="relative w-full max-w-md mx-auto">
      {/* Background Progress Bar */}
      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          className={`h-full bg-gradient-to-r ${getGradient()}`}
          initial={{ width: "50%" }}
          animate={{ width: `${probability}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>

      {/* Floating Icon */}
      <motion.div
        className={`absolute -top-12 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-gradient-to-br ${getGradient()} flex items-center justify-center shadow-lg`}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ 
          scale: [0.8, 1.1, 1],
          opacity: 1,
        }}
        transition={{ duration: 0.5 }}
      >
        {getIcon()}
      </motion.div>

      {/* Percentage Labels */}
      <div className="flex justify-between mt-1 text-sm text-gray-600 dark:text-gray-400">
        <span>Human: {100 - probability}%</span>
        <span>AI: {probability}%</span>
      </div>

      {/* Analysis Pulse Effect */}
      {isAnalyzing && (
        <motion.div
          className="absolute inset-0 rounded-full bg-white/30 dark:bg-white/10"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}
    </div>
  );
};

export default AIHumanIndicator;
