
import { Search, FileSearch, Bot, User } from "lucide-react";

const ContentDetectiveCard = () => (
  <div className="flex items-center mx-auto my-6 w-full max-w-lg bg-white dark:bg-gray-900 shadow-md border border-purple-100 dark:border-purple-900/20 rounded-lg px-4 py-3 hover:shadow-lg transition-shadow duration-300">
    <div className="flex-shrink-0 mr-4">
      <div className="relative w-12 h-12 flex items-center justify-center rounded-lg bg-purple-50 dark:bg-purple-900/10 border border-purple-200 dark:border-purple-800/30 shadow-sm">
        <div className="absolute top-0 left-0 h-5 w-5 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
          <User className="h-3 w-3 text-white" />
        </div>
        <div className="absolute bottom-0 right-0 h-5 w-5 rounded-full bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center">
          <Bot className="h-3 w-3 text-white" />
        </div>
        <FileSearch
          className="h-6 w-6 text-purple-500 opacity-95"
          strokeWidth={2.1}
          aria-label="Content detective icon"
        />
      </div>
    </div>
    <div className="flex-1 min-w-0">
      <h2 className="text-lg font-bold text-gray-900 dark:text-white leading-tight">
        Content Detective
      </h2>
      <p className="text-xs text-gray-600 dark:text-gray-300 font-medium mt-0.5 mb-1 truncate">
        Advanced AI vs Human content analysis
      </p>
      <div className="flex flex-wrap gap-1.5 text-xs mt-1 mb-2">
        <span className="inline-flex items-center bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 rounded-full px-2 py-0.5 font-semibold">
          AI Detection
        </span>
        <span className="inline-flex items-center bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300 rounded-full px-2 py-0.5 font-semibold">
          Writing Analysis
        </span>
        <span className="inline-flex items-center bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full px-2 py-0.5">
          Private ✔️
        </span>
      </div>
      <a
        href="/tools/content-detective"
        className="inline-block px-3 py-1.5 text-xs font-semibold bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-colors shadow"
        style={{ fontSize: "13px" }}
      >
        Try Content Detective
      </a>
    </div>
  </div>
);

export default ContentDetectiveCard;
