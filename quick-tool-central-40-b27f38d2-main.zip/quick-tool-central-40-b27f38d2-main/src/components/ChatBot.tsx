
import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Bot, X, Send, ChevronDown, User, Mic, Copy, ThumbsUp, ThumbsDown, Image, PaperclipIcon, SmilePlus } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Avatar } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
  isLoading?: boolean;
  feedbackGiven?: "positive" | "negative" | null;
}

interface QuickSuggestion {
  id: string;
  text: string;
}

const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentTool, setCurrentTool] = useState<string | null>(null);
  const [quickSuggestions, setQuickSuggestions] = useState<QuickSuggestion[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState("chat");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { toast } = useToast();
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Detect current tool based on URL
  useEffect(() => {
    const path = location.pathname;
    if (path.includes('/tools/')) {
      const toolId = path.split('/tools/')[1];
      setCurrentTool(toolId);
      
      // Set tool-specific suggestions
      generateToolSpecificSuggestions(toolId);
    } else if (path.includes('/dashboard')) {
      setCurrentTool('dashboard');
      setQuickSuggestions([
        { id: '1', text: 'Show me traffic statistics' },
        { id: '2', text: 'What\'s my user growth?' },
        { id: '3', text: 'Compare tool usage metrics' },
        { id: '4', text: 'Analyze visitor sources' }
      ]);
    } else {
      setCurrentTool(null);
      
      // Set general suggestions
      setQuickSuggestions([
        { id: '1', text: 'What tools do you recommend?' },
        { id: '2', text: 'How can I convert images?' },
        { id: '3', text: 'What\'s the file size limit?' },
        { id: '4', text: 'Can you help with document editing?' }
      ]);
    }
  }, [location]);

  // Generate tool-specific suggestions
  const generateToolSpecificSuggestions = (toolId: string) => {
    switch(toolId) {
      case 'word-counter':
        setQuickSuggestions([
          { id: '1', text: 'How to count specific words?' },
          { id: '2', text: 'What stats are available?' },
          { id: '3', text: 'Can I exclude certain words?' },
          { id: '4', text: 'Is there a character limit?' }
        ]);
        break;
      case 'image-resizer':
        setQuickSuggestions([
          { id: '1', text: 'What formats are supported?' },
          { id: '2', text: 'How to maintain aspect ratio?' },
          { id: '3', text: 'Is there a size limit?' },
          { id: '4', text: 'Can I batch resize images?' }
        ]);
        break;
      default:
        setQuickSuggestions([
          { id: '1', text: 'How do I use this tool?' },
          { id: '2', text: 'What are the limitations?' },
          { id: '3', text: 'Are there any tips for best results?' },
          { id: '4', text: 'Is there a premium version?' }
        ]);
    }
  };

  // Initial greeting based on current tool or homepage
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      let initialMessage = "";
      
      if (currentTool === 'dashboard') {
        initialMessage = "Hello! I can help you understand your dashboard data and provide insights on your analytics. What would you like to know about your statistics?";
      } else if (currentTool) {
        initialMessage = `Hello! I can help you with the ${currentTool.replace(/-/g, ' ')} tool. What would you like to know?`;
      } else {
        initialMessage = "Hi there! I'm your MultiToolSet assistant. I can help you find and use the perfect tools for your task. What are you looking to do today?";
      }
      
      setMessages([{
        id: Date.now().toString(),
        content: initialMessage,
        sender: "bot",
        timestamp: new Date(),
      }]);
    }
  }, [isOpen, currentTool, messages.length]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const toggleChatBot = () => {
    setIsOpen(!isOpen);
  };

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);
    
    try {
      // Here we'd typically call an actual AI API
      // For now, we'll simulate responses based on context
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      let botResponse = "";
      
      // Generate contextual responses based on tool or current page
      if (currentTool === 'dashboard') {
        if (inputMessage.toLowerCase().includes("traffic") || inputMessage.toLowerCase().includes("statistics")) {
          botResponse = "Looking at your traffic statistics, I can see you've had a 15% increase in visits compared to last month. The majority of traffic is coming from search engines (48%), followed by direct visits (24%), social media (16%), and referrals (12%). Would you like more detailed insights on any specific traffic source?";
        } else if (inputMessage.toLowerCase().includes("user") || inputMessage.toLowerCase().includes("growth")) {
          botResponse = "Your user base has grown by 12.5% since last month, with most new users in the 25-34 age demographic. The engagement rate is also up by 3.2%, with users spending an average of 3 minutes and 42 seconds per session. Would you like to see recommendations for improving user retention?";
        } else if (inputMessage.toLowerCase().includes("tool") || inputMessage.toLowerCase().includes("usage")) {
          botResponse = "The most popular tools this month are: Word Counter (1,200 uses), Image Resizer (900 uses), and PNG Converter (800 uses). The PDF Tools category has seen a 15% increase in usage. Would you like me to suggest tools to promote based on current trends?";
        } else {
          botResponse = "Based on your dashboard analytics, your platform is performing well with steady growth in both traffic and tool usage. Is there a specific metric or insight you'd like me to analyze in more detail?";
        }
      } else if (currentTool) {
        if (inputMessage.toLowerCase().includes("how to")) {
          botResponse = `To use the ${currentTool.replace(/-/g, ' ')} tool, follow these steps:\n\n1. Upload your file(s) using the upload button or drag and drop\n2. Configure your preferences in the settings panel\n3. Click the process button to start\n4. Preview the results and make any adjustments\n5. Download your processed file(s)\n\nIs there a specific part of the process you need help with?`;
        } else if (inputMessage.toLowerCase().includes("limit")) {
          botResponse = `The ${currentTool.replace(/-/g, ' ')} tool has the following limitations:\n\n- 100MB file size limit for free users\n- Premium users can process files up to 500MB\n- Maximum of 5 simultaneous conversions for free users\n- Supported formats: JPG, PNG, PDF, DOCX (varies by specific tool)\n\nWould you like to learn about our premium plans for increased limits?`;
        } else {
          botResponse = `I'm happy to help with your ${currentTool.replace(/-/g, ' ')} task! I can provide guidance on best practices, troubleshoot issues, or explain advanced features. Could you provide more details about what you're trying to accomplish?`;
        }
      } else {
        // General responses for homepage
        if (inputMessage.toLowerCase().includes("recommend") || inputMessage.toLowerCase().includes("suggest")) {
          botResponse = "Based on your needs, I'd recommend checking out our:\n\n- Word Counter: Perfect for content writers and SEO optimization\n- Image Resizer: Easily adjust image dimensions while maintaining quality\n- Code Beautifier: Format and clean up your code for better readability\n\nAll these tools are free to use with basic features. Would you like me to suggest more tools based on specific tasks?";
        } else if (inputMessage.toLowerCase().includes("convert")) {
          botResponse = "We have several conversion tools! Here are some popular options:\n\n- Image to PNG: Convert any image format to PNG\n- PDF to Word: Extract editable text from PDFs\n- ZIP File Handler: Compress or extract archives\n- Video Converter: Change video formats for compatibility\n\nWhich type of conversion are you looking to perform?";
        } else {
          botResponse = "Thanks for your message! Our MultiToolSet offers 150+ free online tools to help with file conversion, text processing, image editing, and much more. Our most popular categories include:\n\n- Document tools\n- Image editors\n- Code utilities\n- Data converters\n\nCan you tell me more about the specific task you're trying to accomplish?";
        }
      }
      
      const newBotMessage: Message = {
        id: Date.now().toString(),
        content: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, newBotMessage]);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    
    // Focus on input after selecting a suggestion
    setTimeout(() => {
      const textareaElement = document.querySelector('textarea');
      if (textareaElement) {
        textareaElement.focus();
      }
    }, 0);
  };

  const toggleVoiceRecording = () => {
    // In a real implementation, this would initiate voice recording
    // For now, we'll just toggle the state
    setIsRecording(!isRecording);
    
    if (!isRecording) {
      toast({
        title: "Voice recording started",
        description: "Speak now. Recording will automatically end after a pause.",
      });
      
      // Simulate stopping recording after 3 seconds
      setTimeout(() => {
        setIsRecording(false);
        setInputMessage("This is a simulated voice transcription");
        toast({
          title: "Voice recording completed",
          description: "Your message has been transcribed.",
        });
      }, 3000);
    } else {
      toast({
        title: "Voice recording stopped",
        description: "Recording cancelled.",
      });
    }
  };

  const handleFeedback = (messageId: string, type: "positive" | "negative") => {
    setMessages(messages.map(message => 
      message.id === messageId 
        ? { ...message, feedbackGiven: type } 
        : message
    ));
    
    toast({
      title: type === "positive" ? "Thanks for the positive feedback!" : "We'll improve based on your feedback",
      description: type === "positive" 
        ? "We're glad this response was helpful." 
        : "We've noted your feedback to improve our responses.",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "The message has been copied to your clipboard.",
      });
    }, (err) => {
      toast({
        title: "Error",
        description: "Could not copy text: " + err,
        variant: "destructive",
      });
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen ? (
        <Card className={`${isExpanded ? 'w-80 sm:w-96 h-[500px]' : 'w-80 sm:w-96 h-[400px]'} flex flex-col shadow-lg border border-gray-200 rounded-xl overflow-hidden transition-all duration-300 ease-in-out`}>
          <div className="bg-gradient-to-r from-purple-600 to-blue-500 p-3 text-white flex justify-between items-center">
            <div className="flex items-center">
              <Bot className="h-6 w-6 mr-2" />
              <h3 className="font-semibold">MultiToolSet Assistant</h3>
            </div>
            <div className="flex items-center space-x-1">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={toggleExpanded} 
                className="h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 text-white"
              >
                <ChevronDown className={`h-4 w-4 ${isExpanded ? 'rotate-180' : ''} transition-transform`} />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={toggleChatBot} 
                className="h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 text-white"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="w-full grid grid-cols-2 rounded-none border-b">
              <TabsTrigger value="chat" className="data-[state=active]:bg-muted/50">Chat</TabsTrigger>
              <TabsTrigger value="help" className="data-[state=active]:bg-muted/50">Help</TabsTrigger>
            </TabsList>
            
            <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0">
              <div 
                ref={chatContainerRef}
                className="flex-1 overflow-y-auto p-4 bg-gray-50 dark:bg-gray-800 space-y-4"
              >
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.sender === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`group relative px-4 py-3 rounded-lg max-w-[85%] ${
                        message.sender === "user"
                          ? "bg-gradient-to-br from-purple-500 to-blue-600 text-white"
                          : "bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600"
                      }`}
                    >
                      <div className="flex items-center mb-1 gap-1">
                        {message.sender === "user" ? (
                          <Avatar className="h-5 w-5">
                            <User className="h-3 w-3" />
                          </Avatar>
                        ) : (
                          <Avatar className="h-5 w-5 bg-gradient-to-br from-purple-600 to-blue-500">
                            <Bot className="h-3 w-3" />
                          </Avatar>
                        )}
                        <span className="text-xs opacity-75">
                          {message.timestamp.toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      
                      <p className="whitespace-pre-line text-sm">{message.content}</p>
                      
                      {/* Actions for bot messages */}
                      {message.sender === "bot" && (
                        <div className="absolute -right-1 top-1 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-1 p-1">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button 
                                  onClick={() => copyToClipboard(message.content)}
                                  className="bg-white p-1 rounded-md shadow hover:bg-gray-100 transition-colors"
                                >
                                  <Copy className="h-3 w-3 text-gray-500" />
                                </button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Copy</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      )}
                      
                      {/* Feedback for bot messages */}
                      {message.sender === "bot" && (
                        <div className="flex items-center justify-end mt-1 gap-1">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button 
                                  onClick={() => handleFeedback(message.id, "positive")}
                                  className={`p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors ${
                                    message.feedbackGiven === "positive" ? "text-green-500" : "text-gray-400"
                                  }`}
                                  disabled={message.feedbackGiven !== null}
                                >
                                  <ThumbsUp className="h-3 w-3" />
                                </button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Helpful</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button 
                                  onClick={() => handleFeedback(message.id, "negative")}
                                  className={`p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors ${
                                    message.feedbackGiven === "negative" ? "text-red-500" : "text-gray-400"
                                  }`}
                                  disabled={message.feedbackGiven !== null}
                                >
                                  <ThumbsDown className="h-3 w-3" />
                                </button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Not helpful</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex justify-start mb-3">
                    <div className="px-4 py-3 rounded-lg bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600">
                      <div className="flex space-x-1 items-center">
                        <Avatar className="h-5 w-5 bg-gradient-to-br from-purple-600 to-blue-500 mr-1">
                          <Bot className="h-3 w-3" />
                        </Avatar>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
              
              {/* Quick suggestions */}
              {isExpanded && messages.length > 0 && (
                <div className="px-3 py-2 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Suggested questions:</p>
                  <div className="flex flex-wrap gap-2">
                    {quickSuggestions.map(suggestion => (
                      <button
                        key={suggestion.id}
                        onClick={() => handleSuggestionClick(suggestion.text)}
                        className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-full transition-colors text-gray-700 dark:text-gray-300 truncate max-w-full"
                      >
                        {suggestion.text}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="p-3 border-t dark:border-gray-700 bg-white dark:bg-gray-800">
                <div className="flex flex-col gap-2">
                  <Textarea
                    className="min-h-9 max-h-24 resize-none border rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                    placeholder="Type your message..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                  
                  <div className="flex justify-between">
                    <div className="flex gap-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline" 
                              size="icon"
                              className="h-8 w-8 rounded-full"
                              onClick={toggleVoiceRecording}
                            >
                              <Mic className={`h-3 w-3 ${isRecording ? 'text-red-500 animate-pulse' : ''}`} />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">Voice input</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline" 
                              size="icon"
                              className="h-8 w-8 rounded-full"
                            >
                              <Image className="h-3 w-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">Upload image</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline" 
                              size="icon"
                              className="h-8 w-8 rounded-full"
                            >
                              <PaperclipIcon className="h-3 w-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">Attach file</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    
                    <Button
                      className="rounded-full px-4"
                      onClick={handleSendMessage}
                      disabled={!inputMessage.trim() || isLoading}
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="help" className="flex-1 p-4 overflow-y-auto space-y-4 bg-gray-50 dark:bg-gray-800 m-0">
              <div>
                <h3 className="font-semibold text-sm mb-2">How to use the chatbot</h3>
                <ul className="text-xs space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-start gap-2">
                    <span className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 h-5 w-5 rounded-full flex items-center justify-center text-xs mt-0.5">1</span>
                    <span>Ask specific questions about tools or features</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 h-5 w-5 rounded-full flex items-center justify-center text-xs mt-0.5">2</span>
                    <span>Use voice input by clicking the microphone icon</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 h-5 w-5 rounded-full flex items-center justify-center text-xs mt-0.5">3</span>
                    <span>Upload images or files for context-specific help</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 h-5 w-5 rounded-full flex items-center justify-center text-xs mt-0.5">4</span>
                    <span>Rate responses to help improve the assistant</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-sm mb-2">Common questions</h3>
                <div className="space-y-1">
                  {[
                    "How do I use premium features?",
                    "What file formats are supported?",
                    "How to save my history?",
                    "How to share results with others?",
                    "Where to report issues?"
                  ].map((q, i) => (
                    <button 
                      key={i}
                      onClick={() => {
                        setInputMessage(q);
                        setActiveTab("chat");
                      }}
                      className="block w-full text-left text-xs py-2 px-3 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors text-gray-700 dark:text-gray-300"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="text-xs text-gray-500 dark:text-gray-400 pt-2 border-t border-gray-200 dark:border-gray-700">
                <p className="mb-1">Assistant capabilities:</p>
                <ul className="list-disc list-inside space-y-1 pl-1">
                  <li>Tool guidance and troubleshooting</li>
                  <li>Dashboard insights and analytics help</li>
                  <li>File processing recommendations</li>
                  <li>Feature explanations and tutorials</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      ) : (
        <Button
          onClick={toggleChatBot}
          className="h-14 w-14 rounded-full shadow-lg bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 animate-pulse-soft"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}
    </div>
  );
};

export default ChatBot;
