
import { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import { Rocket, Info, Share2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface ToolLayoutProps {
  title: string;
  description: string;
  children: ReactNode;
  helpText?: string;
}

const ToolLayout = ({ title, description, children, helpText }: ToolLayoutProps) => {
  const shareCurrentTool = () => {
    if (navigator.share) {
      navigator.share({
        title: title,
        text: description,
        url: window.location.href,
      })
      .catch(() => {
        navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied to clipboard!");
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-4">
          <BackButton />
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 mb-8 border border-gray-100 dark:border-gray-700">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2 flex items-center">
                <Rocket className="h-7 w-7 mr-2 text-purple-500" />
                <span className="bg-gradient-to-r from-purple-600 to-blue-500 text-transparent bg-clip-text">
                  {title}
                </span>
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                {description}
              </p>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center space-x-3">
              <Button 
                variant="outline" 
                size="sm"
                className="flex items-center text-sm text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200"
                onClick={shareCurrentTool}
              >
                <Share2 className="h-4 w-4 mr-1" />
                <span>Share</span>
              </Button>
              
              {helpText && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="flex items-center text-sm text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200"
                      >
                        <Info className="h-4 w-4 mr-1" />
                        <span>Help</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs bg-white dark:bg-gray-800 dark:text-gray-200 border dark:border-gray-700">
                      <p>{helpText}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
          </div>
          
          <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            {children}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ToolLayout;
