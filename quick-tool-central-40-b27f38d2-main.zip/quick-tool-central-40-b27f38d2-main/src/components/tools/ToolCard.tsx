
import { cn } from "@/lib/utils";
import { Tool } from "@/lib/tool-model";
import { useState } from "react";

interface ToolCardProps {
  tool: Tool;
  onClick: () => void;
}

const ToolCard = ({ tool, onClick }: ToolCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <div 
      className={cn(
        "bg-white dark:bg-gray-800 rounded-xl p-6 cursor-pointer border shadow-sm transition-all duration-300",
        isHovered 
          ? "border-primary shadow-md transform -translate-y-1" 
          : "border-gray-200 dark:border-gray-700 hover:border-primary/50"
      )}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex flex-col h-full">
        <div className={cn(
          "w-14 h-14 rounded-lg flex items-center justify-center mb-4",
          tool.bgColor
        )}>
          {tool.icon}
        </div>
        
        <h3 className="font-semibold text-lg mb-2">
          {tool.title}
        </h3>
        
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 flex-grow">
          {tool.description}
        </p>
        
        <div className="flex gap-2 mt-auto">
          {tool.isNew && (
            <span className="inline-flex items-center rounded-full bg-green-100 dark:bg-green-900/30 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:text-green-300">
              New
            </span>
          )}
          {tool.isPopular && (
            <span className="inline-flex items-center rounded-full bg-orange-100 dark:bg-orange-900/30 px-2.5 py-0.5 text-xs font-medium text-orange-800 dark:text-orange-300">
              Popular
            </span>
          )}
          {tool.isPremium && (
            <span className="inline-flex items-center rounded-full bg-purple-100 dark:bg-purple-900/30 px-2.5 py-0.5 text-xs font-medium text-purple-800 dark:text-purple-300">
              Premium
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ToolCard;
