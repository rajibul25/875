
import { Tool } from "@/lib/tool-model";
import ToolCard from "./ToolCard";

interface ToolCategorySectionProps {
  title: string;
  tools: Tool[];
  onToolClick: (path: string) => void;
}

const ToolCategorySection = ({ title, tools, onToolClick }: ToolCategorySectionProps) => {
  if (tools.length === 0) {
    return (
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-gray-500 italic">No tools found matching your search.</p>
      </div>
    );
  }

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {tools.map((tool) => (
          <ToolCard
            key={tool.id}
            tool={tool}
            onClick={() => onToolClick(tool.path)}
          />
        ))}
      </div>
    </div>
  );
};

export default ToolCategorySection;
