
import React, { Component, ComponentType, ErrorInfo } from "react";
import { logToolError } from "@/services/ErrorLoggingService";

interface ErrorBoundaryProps {
  toolId: string;
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ToolErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // Log the error to our service
    logToolError(this.props.toolId, error);
    console.error("Tool Error Boundary caught an error:", error, errorInfo);
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <div className="p-6 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
          <h2 className="text-xl font-semibold text-red-700 dark:text-red-400 mb-2">
            Tool Error
          </h2>
          <p className="text-red-600 dark:text-red-300 mb-4">
            Something went wrong with this tool. The error has been logged and will be fixed soon.
          </p>
          <details className="text-sm text-red-500 dark:text-red-400">
            <summary className="cursor-pointer">Error details</summary>
            <pre className="mt-2 p-3 bg-red-100 dark:bg-red-900/40 rounded overflow-auto max-h-40">
              {this.state.error?.toString()}
            </pre>
          </details>
          <button
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
            onClick={() => this.setState({ hasError: false, error: null })}
          >
            Try Again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

// Higher-Order Component to wrap tool components with error boundary
export function withErrorBoundary<P>(
  WrappedComponent: ComponentType<P>,
  toolId: string
): ComponentType<P> {
  return function WithErrorBoundary(props: P) {
    return (
      <ToolErrorBoundary toolId={toolId}>
        <WrappedComponent {...props} />
      </ToolErrorBoundary>
    );
  };
}

export default withErrorBoundary;
