
import React from "react";
import { AlertTriangle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

interface ToolErrorDisplayProps {
  toolId: string;
  error: Error;
  resetError?: () => void;
}

const ToolErrorDisplay: React.FC<ToolErrorDisplayProps> = ({
  toolId,
  error,
  resetError
}) => {
  return (
    <Alert variant="destructive" className="my-4">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>Error in {toolId}</AlertTitle>
      <AlertDescription>
        <div className="mt-2">
          <p>{error.message}</p>
          {error.stack && (
            <details className="mt-2">
              <summary className="cursor-pointer text-sm font-medium">
                View Error Details
              </summary>
              <pre className="mt-2 text-xs whitespace-pre-wrap bg-red-50 dark:bg-red-950 p-2 rounded overflow-auto max-h-40">
                {error.stack}
              </pre>
            </details>
          )}
          {resetError && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetError} 
              className="mt-2"
            >
              Try Again
            </Button>
          )}
        </div>
      </AlertDescription>
    </Alert>
  );
};

export default ToolErrorDisplay;
