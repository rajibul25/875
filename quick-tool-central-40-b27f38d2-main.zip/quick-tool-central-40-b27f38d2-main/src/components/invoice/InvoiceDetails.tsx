
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface InvoiceDetailsProps {
  invoiceDetails: {
    invoiceNumber: string;
    date: string;
    dueDate: string;
    currency: string;
    taxType: string;
    customTaxRate: number;
    notes: string;
    terms: string;
    template: string;
  };
  onInvoiceDetailsChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onSelectChange: (name: string, value: string) => void;
  taxOptions: Array<{ id: string; name: string; rate: number | null }>;
  templates: Array<{ id: string; name: string }>;
}

const InvoiceDetails: React.FC<InvoiceDetailsProps> = ({
  invoiceDetails,
  onInvoiceDetailsChange,
  onSelectChange,
  taxOptions,
  templates,
}) => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Invoice Settings</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="invoiceNumber">Invoice Number</Label>
          <Input
            id="invoiceNumber"
            name="invoiceNumber"
            value={invoiceDetails.invoiceNumber}
            onChange={onInvoiceDetailsChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="currency">Currency</Label>
          <Select 
            value={invoiceDetails.currency} 
            onValueChange={(value) => onSelectChange("currency", value)}
          >
            <SelectTrigger id="currency">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD (US Dollar)</SelectItem>
              <SelectItem value="EUR">EUR (Euro)</SelectItem>
              <SelectItem value="GBP">GBP (British Pound)</SelectItem>
              <SelectItem value="JPY">JPY (Japanese Yen)</SelectItem>
              <SelectItem value="CAD">CAD (Canadian Dollar)</SelectItem>
              <SelectItem value="AUD">AUD (Australian Dollar)</SelectItem>
              <SelectItem value="INR">INR (Indian Rupee)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="date">Invoice Date</Label>
          <Input
            id="date"
            name="date"
            type="date"
            value={invoiceDetails.date}
            onChange={onInvoiceDetailsChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="dueDate">Due Date</Label>
          <Input
            id="dueDate"
            name="dueDate"
            type="date"
            value={invoiceDetails.dueDate}
            onChange={onInvoiceDetailsChange}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="taxType">Tax Settings</Label>
        <Select 
          value={invoiceDetails.taxType} 
          onValueChange={(value) => onSelectChange("taxType", value)}
        >
          <SelectTrigger id="taxType">
            <SelectValue placeholder="Select tax type" />
          </SelectTrigger>
          <SelectContent>
            {taxOptions.map(option => (
              <SelectItem key={option.id} value={option.id}>
                {option.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {invoiceDetails.taxType === "custom" && (
        <div className="space-y-2">
          <Label htmlFor="customTaxRate">Custom Tax Rate (%)</Label>
          <Input
            id="customTaxRate"
            name="customTaxRate"
            type="number"
            min="0"
            max="100"
            step="0.01"
            value={invoiceDetails.customTaxRate}
            onChange={onInvoiceDetailsChange}
          />
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          placeholder="Any additional notes for the client"
          rows={3}
          value={invoiceDetails.notes}
          onChange={onInvoiceDetailsChange}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="terms">Terms & Conditions</Label>
        <Textarea
          id="terms"
          name="terms"
          placeholder="Payment terms and conditions"
          rows={3}
          value={invoiceDetails.terms}
          onChange={onInvoiceDetailsChange}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="template">Invoice Template</Label>
        <Select 
          value={invoiceDetails.template} 
          onValueChange={(value) => onSelectChange("template", value)}
        >
          <SelectTrigger id="template">
            <SelectValue placeholder="Select template" />
          </SelectTrigger>
          <SelectContent>
            {templates.map(template => (
              <SelectItem key={template.id} value={template.id}>
                {template.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default InvoiceDetails;
