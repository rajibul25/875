
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Hash, Calendar, DollarSign, CreditCard } from "lucide-react";

interface InvoiceSummaryProps {
  invoiceNumber: string;
  dueDate: string;
  total: number;
  formatCurrency: (amount: number | string) => string;
}

const InvoiceSummary: React.FC<InvoiceSummaryProps> = ({
  invoiceNumber,
  dueDate,
  total,
  formatCurrency,
}) => {
  return (
    <Card>
      <CardContent className="pt-6">
        <h2 className="text-xl font-semibold mb-4">Invoice Summary</h2>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <Hash className="h-5 w-5 text-gray-500" />
            <div>
              <p className="text-sm text-gray-500">Invoice Number</p>
              <p className="font-medium">{invoiceNumber}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Calendar className="h-5 w-5 text-gray-500" />
            <div>
              <p className="text-sm text-gray-500">Due Date</p>
              <p className="font-medium">{dueDate}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <DollarSign className="h-5 w-5 text-gray-500" />
            <div>
              <p className="text-sm text-gray-500">Total Amount</p>
              <p className="font-medium">{formatCurrency(total)}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <CreditCard className="h-5 w-5 text-gray-500" />
            <div>
              <p className="text-sm text-gray-500">Payment Methods</p>
              <p className="font-medium">Various options available</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InvoiceSummary;
