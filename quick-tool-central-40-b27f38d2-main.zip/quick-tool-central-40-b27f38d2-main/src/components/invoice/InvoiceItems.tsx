import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface InvoiceItem {
  id: number;
  description: string;
  quantity: number;
  price: number;
  total: number;
}

interface InvoiceItemsProps {
  items: InvoiceItem[];
  onItemChange: (id: number, field: string, value: string | number) => void;
  onAddItem: () => void;
  onRemoveItem: (id: number) => void;
  formatCurrency: (amount: number | string) => string;
  currencySymbol: string;
}

const InvoiceItems: React.FC<InvoiceItemsProps> = ({
  items,
  onItemChange,
  onAddItem,
  onRemoveItem,
  formatCurrency,
  currencySymbol,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Invoice Items</h2>
        <Button onClick={onAddItem} size="sm" className="flex items-center gap-1">
          <Plus className="h-4 w-4" />
          Add Item
        </Button>
      </div>
      
      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left p-3 border-b">Description</th>
              <th className="text-right p-3 border-b w-20">Quantity</th>
              <th className="text-right p-3 border-b w-28">Price</th>
              <th className="text-right p-3 border-b w-28">Total</th>
              <th className="text-center p-3 border-b w-16">Action</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                <td className="p-3 border-b">
                  <Input
                    placeholder="Item description"
                    value={item.description}
                    onChange={(e) => onItemChange(item.id, "description", e.target.value)}
                    className="border-none shadow-none focus-visible:ring-0 p-0 h-auto"
                  />
                </td>
                <td className="p-3 border-b">
                  <Input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => onItemChange(item.id, "quantity", parseInt(e.target.value) || 0)}
                    className="border-none shadow-none focus-visible:ring-0 p-0 h-auto text-right"
                  />
                </td>
                <td className="p-3 border-b">
                  <div className="flex items-center justify-end">
                    <span className="mr-1 text-gray-500">{currencySymbol}</span>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.price}
                      onChange={(e) => onItemChange(item.id, "price", parseFloat(e.target.value) || 0)}
                      className="border-none shadow-none focus-visible:ring-0 p-0 h-auto text-right w-full"
                    />
                  </div>
                </td>
                <td className="p-3 border-b text-right">
                  {formatCurrency(item.total)}
                </td>
                <td className="p-3 border-b text-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (items.length === 1) {
                        toast.error("You must have at least one item");
                        return;
                      }
                      onRemoveItem(item.id);
                    }}
                    disabled={items.length === 1}
                    className="h-8 w-8 p-0"
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default InvoiceItems;
