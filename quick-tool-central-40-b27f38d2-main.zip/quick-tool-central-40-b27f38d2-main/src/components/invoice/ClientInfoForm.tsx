
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface ClientInfo {
  name: string;
  contactPerson: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phone: string;
  email: string;
}

interface ClientInfoFormProps {
  clientInfo: ClientInfo;
  onClientInfoChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const ClientInfoForm: React.FC<ClientInfoFormProps> = ({
  clientInfo,
  onClientInfoChange,
}) => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Client Information</h2>
      
      <div className="space-y-2">
        <Label htmlFor="clientName">Client/Company Name</Label>
        <Input
          id="clientName"
          name="name"
          placeholder="Client Company Name"
          value={clientInfo.name}
          onChange={onClientInfoChange}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="clientContactPerson">Contact Person</Label>
        <Input
          id="clientContactPerson"
          name="contactPerson"
          placeholder="Contact Person Name"
          value={clientInfo.contactPerson}
          onChange={onClientInfoChange}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="clientEmail">Email</Label>
          <Input
            id="clientEmail"
            name="email"
            type="email"
            placeholder="client@example.com"
            value={clientInfo.email}
            onChange={onClientInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="clientPhone">Phone</Label>
          <Input
            id="clientPhone"
            name="phone"
            placeholder="(123) 456-7890"
            value={clientInfo.phone}
            onChange={onClientInfoChange}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="clientAddress">Address</Label>
        <Input
          id="clientAddress"
          name="address"
          placeholder="123 Client St"
          value={clientInfo.address}
          onChange={onClientInfoChange}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="clientCity">City</Label>
          <Input
            id="clientCity"
            name="city"
            placeholder="City"
            value={clientInfo.city}
            onChange={onClientInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="clientState">State/Province</Label>
          <Input
            id="clientState"
            name="state"
            placeholder="State"
            value={clientInfo.state}
            onChange={onClientInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="clientZipCode">ZIP/Postal Code</Label>
          <Input
            id="clientZipCode"
            name="zipCode"
            placeholder="ZIP Code"
            value={clientInfo.zipCode}
            onChange={onClientInfoChange}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="clientCountry">Country</Label>
        <Input
          id="clientCountry"
          name="country"
          placeholder="Country"
          value={clientInfo.country}
          onChange={onClientInfoChange}
        />
      </div>
    </div>
  );
};

export default ClientInfoForm;
