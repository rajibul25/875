
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Eye, Settings, Send, Printer, Copy } from "lucide-react";
import { toast } from "sonner";

interface InvoiceActionsProps {
  previewMode: boolean;
  onTogglePreview: () => void;
  onGenerateInvoice: () => void;
}

const InvoiceActions: React.FC<InvoiceActionsProps> = ({
  previewMode,
  onTogglePreview,
  onGenerateInvoice,
}) => {
  const emailInvoice = () => {
    toast.success("Email option would open here!");
  };

  const copyInvoiceLink = () => {
    toast.success("Invoice link copied to clipboard!");
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h2 className="text-xl font-semibold mb-4">Invoice Actions</h2>
        <div className="space-y-3">
          <Button onClick={onTogglePreview} variant="outline" className="w-full flex items-center gap-2">
            {previewMode ? <Settings className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            {previewMode ? "Edit Invoice" : "Preview Invoice"}
          </Button>
          
          <Button onClick={onGenerateInvoice} className="w-full flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download PDF
          </Button>
          
          <Button 
            onClick={emailInvoice} 
            variant="outline" 
            className="w-full flex items-center gap-2"
          >
            <Send className="h-4 w-4" />
            Email Invoice
          </Button>
          
          <Button 
            onClick={() => window.print()} 
            variant="outline" 
            className="w-full flex items-center gap-2"
          >
            <Printer className="h-4 w-4" />
            Print Invoice
          </Button>
          
          <Button 
            onClick={copyInvoiceLink} 
            variant="outline" 
            className="w-full flex items-center gap-2"
          >
            <Copy className="h-4 w-4" />
            Copy Link
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default InvoiceActions;
