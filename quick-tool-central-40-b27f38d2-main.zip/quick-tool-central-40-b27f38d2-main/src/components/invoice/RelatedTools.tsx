
import React from "react";

const RelatedTools: React.FC = () => {
  return (
    <div className="mt-8">
      <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <a href="/tools/resume-builder" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <div className="ml-3">
            <h3 className="font-medium">Resume Builder</h3>
            <p className="text-sm text-gray-500">Create professional resumes</p>
          </div>
        </a>
        <a href="/tools/receipt-generator" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <div className="ml-3">
            <h3 className="font-medium">Receipt Generator</h3>
            <p className="text-sm text-gray-500">Create payment receipts</p>
          </div>
        </a>
        <a href="/tools/quote-generator" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <div className="ml-3">
            <h3 className="font-medium">Quote Generator</h3>
            <p className="text-sm text-gray-500">Create business quotes</p>
          </div>
        </a>
      </div>
    </div>
  );
};

export default RelatedTools;
