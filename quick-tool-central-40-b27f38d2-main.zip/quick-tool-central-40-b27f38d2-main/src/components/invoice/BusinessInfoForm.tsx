
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface BusinessInfo {
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phone: string;
  email: string;
  website: string;
  taxId: string;
  logo: string | null;
}

interface BusinessInfoFormProps {
  businessInfo: BusinessInfo;
  onBusinessInfoChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const BusinessInfoForm: React.FC<BusinessInfoFormProps> = ({
  businessInfo,
  onBusinessInfoChange,
}) => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Business Information</h2>
      
      <div className="space-y-2">
        <Label htmlFor="businessLogo">Business Logo (optional)</Label>
        <div className="flex items-center gap-4">
          {businessInfo.logo && (
            <div className="h-20 w-20 border rounded flex items-center justify-center overflow-hidden">
              <img 
                src={businessInfo.logo} 
                alt="Business Logo" 
                className="max-h-full max-w-full object-contain" 
              />
            </div>
          )}
          <Input
            id="logo"
            name="logo"
            type="file"
            accept="image/*"
            onChange={onBusinessInfoChange}
            className="flex-1"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="businessName">Business Name</Label>
        <Input
          id="businessName"
          name="name"
          placeholder="Your Business Name"
          value={businessInfo.name}
          onChange={onBusinessInfoChange}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="businessEmail">Email</Label>
          <Input
            id="businessEmail"
            name="email"
            type="email"
            placeholder="business@example.com"
            value={businessInfo.email}
            onChange={onBusinessInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="businessPhone">Phone</Label>
          <Input
            id="businessPhone"
            name="phone"
            placeholder="(123) 456-7890"
            value={businessInfo.phone}
            onChange={onBusinessInfoChange}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="businessAddress">Address</Label>
        <Input
          id="businessAddress"
          name="address"
          placeholder="123 Business St"
          value={businessInfo.address}
          onChange={onBusinessInfoChange}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="businessCity">City</Label>
          <Input
            id="businessCity"
            name="city"
            placeholder="City"
            value={businessInfo.city}
            onChange={onBusinessInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="businessState">State/Province</Label>
          <Input
            id="businessState"
            name="state"
            placeholder="State"
            value={businessInfo.state}
            onChange={onBusinessInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="businessZipCode">ZIP/Postal Code</Label>
          <Input
            id="businessZipCode"
            name="zipCode"
            placeholder="ZIP Code"
            value={businessInfo.zipCode}
            onChange={onBusinessInfoChange}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="businessCountry">Country</Label>
          <Input
            id="businessCountry"
            name="country"
            placeholder="Country"
            value={businessInfo.country}
            onChange={onBusinessInfoChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="businessWebsite">Website (optional)</Label>
          <Input
            id="businessWebsite"
            name="website"
            placeholder="www.yourbusiness.com"
            value={businessInfo.website}
            onChange={onBusinessInfoChange}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="businessTaxId">Tax ID/VAT Number (optional)</Label>
        <Input
          id="businessTaxId"
          name="taxId"
          placeholder="Tax ID or VAT Number"
          value={businessInfo.taxId}
          onChange={onBusinessInfoChange}
        />
      </div>
    </div>
  );
};

export default BusinessInfoForm;
