
import React from "react";

const InvoiceFAQ: React.FC = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <h3 className="font-semibold">What format will my invoice be downloaded in?</h3>
          <p className="text-gray-600">Your invoice will be available to download as a PDF, which is widely accepted for business transactions.</p>
        </div>
        <div className="space-y-2">
          <h3 className="font-semibold">Can I save my invoice template for future use?</h3>
          <p className="text-gray-600">Currently, this tool doesn't support saving templates. We recommend completing your invoice in one session.</p>
        </div>
        <div className="space-y-2">
          <h3 className="font-semibold">Is my invoice data secure?</h3>
          <p className="text-gray-600">Yes, all data is processed in your browser and is not stored on our servers, ensuring your business information remains private.</p>
        </div>
        <div className="space-y-2">
          <h3 className="font-semibold">Can I track payments with this tool?</h3>
          <p className="text-gray-600">The current version does not include payment tracking. It's designed for creating professional invoices only.</p>
        </div>
      </div>
    </div>
  );
};

export default InvoiceFAQ;
