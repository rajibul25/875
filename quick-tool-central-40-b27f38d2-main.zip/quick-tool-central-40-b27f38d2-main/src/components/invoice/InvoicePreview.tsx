import React from "react";

interface BusinessInfo {
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phone: string;
  email: string;
  website: string;
  taxId: string;
  logo: string | null;
}

interface ClientInfo {
  name: string;
  contactPerson: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phone: string;
  email: string;
}

interface InvoiceItem {
  id: number;
  description: string;
  quantity: number;
  price: number;
  total: number;
}

interface InvoiceDetails {
  invoiceNumber: string;
  date: string;
  dueDate: string;
  currency: string;
  taxType: string;
  customTaxRate: number;
  notes: string;
  terms: string;
  template: string;
}

interface InvoicePreviewProps {
  businessInfo: BusinessInfo;
  clientInfo: ClientInfo;
  items: InvoiceItem[];
  invoiceDetails: InvoiceDetails;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  formatCurrency: (amount: number | string) => string;
}

const InvoicePreview: React.FC<InvoicePreviewProps> = ({
  businessInfo,
  clientInfo,
  items,
  invoiceDetails,
  subtotal,
  taxRate,
  taxAmount,
  total,
  formatCurrency,
}) => {
  return (
    <div className={`invoice-preview invoice-${invoiceDetails.template} bg-white border rounded-lg p-8 shadow-lg`}>
      <div className="flex justify-between items-start mb-8">
        <div>
          {businessInfo.logo ? (
            <img 
              src={businessInfo.logo} 
              alt={businessInfo.name} 
              className="h-16 mb-4" 
            />
          ) : (
            <h2 className="text-2xl font-bold">{businessInfo.name || "Your Business"}</h2>
          )}
          <div className="text-sm text-gray-600">
            <p>{businessInfo.address || "Business Address"}</p>
            <p>
              {businessInfo.city || "City"}, {businessInfo.state || "State"} {businessInfo.zipCode || "ZIP"}
            </p>
            <p>{businessInfo.country || "Country"}</p>
            <p>{businessInfo.phone || "Phone"}</p>
            <p>{businessInfo.email || "Email"}</p>
            {businessInfo.website && <p>{businessInfo.website}</p>}
            {businessInfo.taxId && <p>Tax ID: {businessInfo.taxId}</p>}
          </div>
        </div>
        <div className="text-right">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">INVOICE</h1>
          <div className="space-y-1 text-sm">
            <p><span className="font-semibold">Invoice #:</span> {invoiceDetails.invoiceNumber}</p>
            <p><span className="font-semibold">Date:</span> {invoiceDetails.date}</p>
            <p><span className="font-semibold">Due Date:</span> {invoiceDetails.dueDate}</p>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-2">Bill To:</h3>
        <div className="text-sm">
          <p className="font-semibold">{clientInfo.name || "Client Name"}</p>
          {clientInfo.contactPerson && <p>Attn: {clientInfo.contactPerson}</p>}
          <p>{clientInfo.address || "Client Address"}</p>
          <p>
            {clientInfo.city || "City"}, {clientInfo.state || "State"} {clientInfo.zipCode || "ZIP"}
          </p>
          <p>{clientInfo.country || "Country"}</p>
          {clientInfo.phone && <p>{clientInfo.phone}</p>}
          {clientInfo.email && <p>{clientInfo.email}</p>}
        </div>
      </div>
      
      <div className="mb-8">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="text-left p-2">Description</th>
              <th className="text-right p-2">Quantity</th>
              <th className="text-right p-2">Price</th>
              <th className="text-right p-2">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className="border-b">
                <td className="p-2">{item.description || "Item description"}</td>
                <td className="p-2 text-right">{item.quantity}</td>
                <td className="p-2 text-right">{formatCurrency(item.price)}</td>
                <td className="p-2 text-right">{formatCurrency(item.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="flex justify-end mb-8">
        <div className="w-48">
          <div className="flex justify-between py-2">
            <span>Subtotal:</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          
          {invoiceDetails.taxType !== "none" && (
            <div className="flex justify-between py-2">
              <span>Tax ({taxRate}%):</span>
              <span>{formatCurrency(taxAmount)}</span>
            </div>
          )}
          
          <div className="flex justify-between py-2 border-t border-gray-400 font-bold">
            <span>Total:</span>
            <span>{formatCurrency(total)}</span>
          </div>
        </div>
      </div>
      
      {(invoiceDetails.notes || invoiceDetails.terms) && (
        <div className="border-t pt-4 text-sm">
          {invoiceDetails.notes && (
            <div className="mb-4">
              <h4 className="font-semibold mb-1">Notes:</h4>
              <p className="text-gray-600">{invoiceDetails.notes}</p>
            </div>
          )}
          
          {invoiceDetails.terms && (
            <div>
              <h4 className="font-semibold mb-1">Terms & Conditions:</h4>
              <p className="text-gray-600">{invoiceDetails.terms}</p>
            </div>
          )}
        </div>
      )}
      
      <div className="text-center mt-8 text-sm text-gray-500">
        <p>Thank you for your business!</p>
      </div>
    </div>
  );
};

export default InvoicePreview;
