
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-white pt-10 pb-6">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-600 hover:text-tool-purple">About us</Link></li>
              <li><Link to="/contact" className="text-gray-600 hover:text-tool-purple">Contact us</Link></li>
              <li><Link to="/privacy" className="text-gray-600 hover:text-tool-purple">Privacy Policy</Link></li>
              <li><Link to="/terms" className="text-gray-600 hover:text-tool-purple">Terms & Conditions</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Convert from PDF</h3>
            <ul className="space-y-2">
              <li><Link to="/tools/pdf-to-word" className="text-gray-600 hover:text-tool-purple">PDF to Word</Link></li>
              <li><Link to="/tools/pdf-to-powerpoint" className="text-gray-600 hover:text-tool-purple">PDF to PowerPoint</Link></li>
              <li><Link to="/tools/pdf-to-jpg" className="text-gray-600 hover:text-tool-purple">PDF to JPG</Link></li>
              <li><Link to="/tools/pdf-to-png" className="text-gray-600 hover:text-tool-purple">PDF to PNG</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Convert to PDF</h3>
            <ul className="space-y-2">
              <li><Link to="/tools/word-to-pdf" className="text-gray-600 hover:text-tool-purple">Word to PDF</Link></li>
              <li><Link to="/tools/powerpoint-to-pdf" className="text-gray-600 hover:text-tool-purple">PowerPoint to PDF</Link></li>
              <li><Link to="/tools/jpg-to-pdf" className="text-gray-600 hover:text-tool-purple">JPG to PDF</Link></li>
              <li><Link to="/tools/png-to-pdf" className="text-gray-600 hover:text-tool-purple">PNG to PDF</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Popular PDF Editor</h3>
            <ul className="space-y-2">
              <li><Link to="/tools/merge-pdf" className="text-gray-600 hover:text-tool-purple">Merge PDF</Link></li>
              <li><Link to="/tools/remove-pages" className="text-gray-600 hover:text-tool-purple">Remove Pages</Link></li>
              <li><Link to="/tools/compress-pdf" className="text-gray-600 hover:text-tool-purple">Compress PDF</Link></li>
              <li><Link to="/tools/unlock-pdf" className="text-gray-600 hover:text-tool-purple">Unlock PDF</Link></li>
            </ul>
          </div>
        </div>

        <div className="text-center pt-5 border-t border-gray-200">
          <p className="text-sm text-gray-500">Made with ❤️ by MultiToolSet</p>
          <div className="flex justify-center space-x-4 mt-3">
            <Link to="#" className="text-gray-500 hover:text-tool-purple">Facebook</Link>
            <Link to="#" className="text-gray-500 hover:text-tool-purple">Instagram</Link>
            <Link to="#" className="text-gray-500 hover:text-tool-purple">YouTube</Link>
            <Link to="#" className="text-gray-500 hover:text-tool-purple">Twitter</Link>
          </div>
          <p className="mt-4 text-sm text-gray-500">Copyright © 2024 - {new Date().getFullYear()}. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
