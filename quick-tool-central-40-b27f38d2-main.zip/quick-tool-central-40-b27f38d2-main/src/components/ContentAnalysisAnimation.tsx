
import { motion } from "framer-motion";
import { Bot, User, Sparkles } from "lucide-react";

interface AnimationProps {
  isAnalyzing: boolean;
}

const ContentAnalysisAnimation = ({ isAnalyzing }: AnimationProps) => {
  if (!isAnalyzing) return null;
  
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative w-32 h-32">
        {/* Background pulse effect */}
        <motion.div
          className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400/30 to-blue-400/30"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.7, 1, 0.7]
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        {/* AI Icon */}
        <motion.div 
          className="absolute top-0 right-0 w-16 h-16 rounded-full bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center shadow-lg"
          animate={{ 
            y: [0, -10, 0],
            scale: [1, 1.1, 1],
            rotate: [0, 5, 0]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        >
          <Bot className="h-8 w-8 text-white" />
        </motion.div>
        
        {/* Human Icon */}
        <motion.div 
          className="absolute top-0 left-0 w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg"
          animate={{ 
            y: [0, -10, 0],
            scale: [1, 1.1, 1],
            rotate: [0, -5, 0]
          }}
          transition={{ 
            duration: 3,
            delay: 0.5,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        >
          <User className="h-8 w-8 text-white" />
        </motion.div>
        
        {/* Center Analysis Icon */}
        <motion.div 
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center shadow-lg"
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 360],
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Sparkles className="h-6 w-6 text-white" />
        </motion.div>

        {/* Connecting Lines */}
        <svg className="absolute inset-0 w-full h-full" overflow="visible">
          <motion.path
            d="M 16,16 L 64,64"
            stroke="url(#line-gradient)"
            strokeWidth="2"
            strokeDasharray="5,5"
            fill="none"
            animate={{
              pathLength: [0, 1, 0],
              opacity: [0.3, 0.8, 0.3]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.path
            d="M 112,16 L 64,64"
            stroke="url(#line-gradient)"
            strokeWidth="2"
            strokeDasharray="5,5"
            fill="none"
            animate={{
              pathLength: [0, 1, 0],
              opacity: [0.3, 0.8, 0.3]
            }}
            transition={{
              duration: 2,
              delay: 0.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          
          <defs>
            <linearGradient id="line-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366f1" />
              <stop offset="100%" stopColor="#8b5cf6" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <motion.div 
        className="mt-6 text-center"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      >
        <h3 className="text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-600">
          Analyzing Content
        </h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Detecting patterns and style characteristics...
        </p>
      </motion.div>
    </div>
  );
};

export default ContentAnalysisAnimation;
