
import React from "react";
import {
  Image as LucideImage,
  FileImage,
  Type,
  FileText,
  Calculator,
  Heart,
  Zap,
  Code,
  Text,
  Grid,
  File,
  Lock,
  Download,
  Share,
  Upload,
  UploadCloud,
  User,
  Clock,
  BarChart,
  Settings,
  FileJson,
  Binary,
  Database,
  Hash,
  Link,
  Instagram,
  Calendar,
  QrCode,
  AtSign,
  Percent,
  Ruler,
  Weight,
  GaugeCircle,
  ThermometerSun,
  Activity,
  Maximize2,
  Minimize2,
  FileType2,
  Image,
  Palette,
  CropIcon as LucideCrop,
  FileCode,
  AlignEndHorizontal,
  GitMerge,
  Scissors,
  Trophy,
  Component,
  DollarSign,
  Percent as CirclePercent,
  Apple,
  Moon,
  Baby,
  Globe,
  Search,
  LayoutGrid,
  Anchor,
  Eye,
  // Removed SquareGantt import as it doesn't exist
  HardDrive,
  Gauge,
  Lightbulb,
  Timer
} from "lucide-react";

const createStyledIcon = (Icon: React.ComponentType<React.SVGProps<SVGSVGElement>>, defaultClassName?: string) => {
  return React.forwardRef<SVGSVGElement, React.SVGProps<SVGSVGElement>>((props, ref) => {
    const className = props.className ? `${defaultClassName || ""} ${props.className}` : defaultClassName;
    return <Icon ref={ref} {...props} className={className} />;
  });
};

export const ImageIcon = createStyledIcon(LucideImage, "text-blue-500");
export const FileImageIcon = createStyledIcon(FileImage, "text-purple-500");
export const UploadIcon = createStyledIcon(Upload, "text-blue-500");
export const UploadCloudIcon = createStyledIcon(UploadCloud, "text-blue-500");
export const DownloadIcon = createStyledIcon(Download, "text-green-500");
export const ShareIcon = createStyledIcon(Share, "text-indigo-500");
export const ResizeIcon = createStyledIcon(Maximize2, "text-blue-400");
export const CompressIcon = createStyledIcon(Minimize2, "text-teal-500");
export const GifIcon = createStyledIcon(FileType2, "text-orange-500");
export const WebpIcon = createStyledIcon(Image, "text-purple-500");
export const ColorPickerIcon = createStyledIcon(Palette, "text-pink-500");
export const CropIcon = createStyledIcon(LucideCrop, "text-yellow-500");
export const Base64Icon = createStyledIcon(FileCode, "text-red-500");
export const SvgIcon = createStyledIcon(Component, "text-emerald-500");

export const TextContentIcon = createStyledIcon(Text, "text-blue-500");
export const TypeIcon = createStyledIcon(Type, "text-purple-500");
export const FileTextIcon = createStyledIcon(FileText, "text-indigo-500");
export const PlagiarismIcon = createStyledIcon(AlignEndHorizontal, "text-red-500");
export const CssIcon = createStyledIcon(Scissors, "text-blue-600");

export const CalculatorIcon = createStyledIcon(Calculator, "text-green-500");
export const ChartIcon = createStyledIcon(BarChart, "text-orange-500");

export const CodeIcon = createStyledIcon(Code, "text-blue-500");
export const JsonIcon = createStyledIcon(FileJson, "text-green-500");
export const BinaryIcon = createStyledIcon(Binary, "text-purple-500");
export const DatabaseIcon = createStyledIcon(Database, "text-indigo-500");
export const HashIcon = createStyledIcon(Hash, "text-red-500");
export const MergeIcon = createStyledIcon(GitMerge, "text-purple-600");

export const HeartIcon = createStyledIcon(Heart, "text-red-500");
export const ActivityIcon = createStyledIcon(Activity, "text-red-500");

export const ZapIcon = createStyledIcon(Zap, "text-yellow-500");
export const GridIcon = createStyledIcon(Grid, "text-blue-500");
export const FileIcon = createStyledIcon(File, "text-gray-500");
export const LockIcon = createStyledIcon(Lock, "text-red-500");
export const UserIcon = createStyledIcon(User, "text-blue-500");
export const ClockIcon = createStyledIcon(Clock, "text-purple-500");
export const SettingsIcon = createStyledIcon(Settings, "text-gray-500");
export const TrophyIcon = createStyledIcon(Trophy, "text-yellow-500");

export const LinkIconStyling = createStyledIcon(Link, "text-pink-500");
export const InstagramIcon = createStyledIcon(Instagram, "text-pink-500");
export const HashtagIcon = createStyledIcon(Hash, "text-green-500");
export const CalendarIcon = createStyledIcon(Calendar, "text-purple-500");
export const AtSignIcon = createStyledIcon(AtSign, "text-blue-500");

export const QrCodeIcon = createStyledIcon(QrCode, "text-blue-500");
export const MetaTagIcon = createStyledIcon(Code, "text-teal-500");
export const KeywordIcon = createStyledIcon(AtSign, "text-blue-500");
export const SitemapIcon = createStyledIcon(Grid, "text-green-500");
export const RobotsIcon = createStyledIcon(Settings, "text-yellow-500");

export const PercentIcon = createStyledIcon(Percent, "text-orange-500");
export const LengthIcon = createStyledIcon(Ruler, "text-red-500");
export const WeightIcon = createStyledIcon(Weight, "text-yellow-500");
export const SpeedIcon = createStyledIcon(Zap, "text-pink-500");
export const TemperatureIcon = createStyledIcon(ThermometerSun, "text-orange-500");

// New converter icons
export const AreaIcon = createStyledIcon(Grid, "text-indigo-500"); // Changed from SquareGantt to Grid
export const DataIcon = createStyledIcon(HardDrive, "text-blue-500");
export const PressureIcon = createStyledIcon(Gauge, "text-green-500");
export const EnergyIcon = createStyledIcon(Lightbulb, "text-yellow-500");
export const TimeIcon = createStyledIcon(Timer, "text-purple-500");

export const LoanIcon = createStyledIcon(Calculator, "text-green-500");

export const WordCounterIcon = createStyledIcon(Text, "text-blue-500");
export const CharacterCounterIcon = createStyledIcon(Text, "text-purple-500");
export const CaseConverterIcon = createStyledIcon(Type, "text-indigo-500");

export const AgeIcon = createStyledIcon(Clock, "text-indigo-500");

export const HtmlIcon = createStyledIcon(FileText, "text-green-500");

export const DollarSignIcon = createStyledIcon(DollarSign, "text-green-500");
export const CirclePercentIcon = createStyledIcon(CirclePercent, "text-orange-500");

export const AppleIcon = createStyledIcon(Apple, "text-green-500");
export const MoonIcon = createStyledIcon(Moon, "text-indigo-500");
export const BabyIcon = createStyledIcon(Baby, "text-pink-500");
export const GlobeIcon = createStyledIcon(Globe, "text-blue-500");
export const UrlAnalyzerIcon = createStyledIcon(Search, "text-blue-600");
export const BacklinkIcon = createStyledIcon(Anchor, "text-indigo-500");
export const SchemaIcon = createStyledIcon(LayoutGrid, "text-green-600");
export const SerpIcon = createStyledIcon(Eye, "text-purple-600");

export default {
  Image: ImageIcon,
  FileImage: FileImageIcon,
  TextContent: TextContentIcon,
  Type: TypeIcon,
  FileText: FileTextIcon,
  Calculator: CalculatorIcon,
  Chart: ChartIcon,
  Code: CodeIcon,
  Json: JsonIcon,
  Binary: BinaryIcon,
  Database: DatabaseIcon,
  Hash: HashIcon,
  Heart: HeartIcon,
  Zap: ZapIcon,
  Grid: GridIcon,
  File: FileIcon,
  Lock: LockIcon,
  Download: DownloadIcon,
  Share: ShareIcon,
  Upload: UploadIcon,
  UploadCloud: UploadCloudIcon,
  User: UserIcon,
  Clock: ClockIcon,
  Settings: SettingsIcon,
  Link: LinkIconStyling,
  Instagram: InstagramIcon,
  Hashtag: HashtagIcon,
  Calendar: CalendarIcon,
  QrCode: QrCodeIcon,
  MetaTag: MetaTagIcon,
  Keyword: KeywordIcon,
  Sitemap: SitemapIcon,
  Robots: RobotsIcon,
  WordCounter: WordCounterIcon,
  CharacterCounter: CharacterCounterIcon,
  CaseConverter: CaseConverterIcon,
  Html: HtmlIcon,
  Loan: LoanIcon,
  Percent: PercentIcon,
  Age: AgeIcon,
  Speed: SpeedIcon,
  Temperature: TemperatureIcon,
  Length: LengthIcon,
  Weight: WeightIcon,
  Area: AreaIcon,
  Data: DataIcon,
  Pressure: PressureIcon,
  Energy: EnergyIcon,
  Time: TimeIcon,
  Activity: ActivityIcon,
  Resize: ResizeIcon,
  Compress: CompressIcon,
  Gif: GifIcon,
  Webp: WebpIcon,
  ColorPicker: ColorPickerIcon,
  Crop: CropIcon,
  Base64: Base64Icon,
  Svg: SvgIcon,
  Plagiarism: PlagiarismIcon,
  Css: CssIcon,
  Merge: MergeIcon,
  Trophy: TrophyIcon,
  Apple: AppleIcon,
  Moon: MoonIcon,
  Baby: BabyIcon,
  Globe: GlobeIcon,
  UrlAnalyzer: UrlAnalyzerIcon,
  Backlink: BacklinkIcon,
  Schema: SchemaIcon,
  Serp: SerpIcon,
};
