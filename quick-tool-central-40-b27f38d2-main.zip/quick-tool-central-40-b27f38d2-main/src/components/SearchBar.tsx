
import { useState, useEffect } from "react";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";
import ToolSearchDialog from "./ToolSearchDialog";

interface SearchBarProps {
  placeholder?: string;
  onSearch?: (query: string) => void;
}

const SearchBar = ({ placeholder = "Search tools...", onSearch }: SearchBarProps) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  // Handle keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        setOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Handle search dialog close
  const handleDialogClose = (newState: boolean) => {
    setOpen(newState);
    if (!newState && onSearch) {
      onSearch("");
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "relative w-full flex items-center border rounded-lg p-4 bg-white dark:bg-gray-800 transition-all hover:shadow cursor-text focus:outline-none",
          "text-gray-500 dark:text-gray-400"
        )}
        aria-label="Open tool search"
        tabIndex={0}
        onKeyDown={e => (e.key === "Enter" || e.key === " ") && setOpen(true)}
      >
        <Search className="w-5 h-5 mr-2 text-tool-purple" />
        <span className="flex-1 text-left text-base text-gray-500 dark:text-gray-400 select-none">
          {placeholder}
        </span>
        <span className="ml-auto text-xs rounded bg-gradient-to-r from-tool-purple to-tool-pink px-3 py-1 text-white shadow font-medium">
          Ctrl+K
        </span>
      </button>
      <ToolSearchDialog 
        open={open} 
        setOpen={handleDialogClose} 
      />
    </>
  );
};

export default SearchBar;
