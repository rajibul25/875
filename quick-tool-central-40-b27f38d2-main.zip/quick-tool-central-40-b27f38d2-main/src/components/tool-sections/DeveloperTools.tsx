
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  FileJson,
  Code,
  FileCode,
  FileText,
  Terminal,
  FileType,
  Table,
  Database,
  Hash,
  KeyRound
} from "lucide-react";
import { Tool } from "@/lib/tool-model";

interface DeveloperToolsProps {
  tools?: Tool[];
}

const DeveloperTools = ({ tools }: DeveloperToolsProps) => {
  const defaultTools = [
    {
      id: "json-formatter",
      title: "JSON Formatter",
      description: "Beautify & validate JSON",
      icon: <FileJson className="w-8 h-8 text-blue-600" />,
      path: "/tools/json-formatter",
      category: "developer",
      isPopular: true,
      bgColor: "bg-purple-100"
    },
    {
      id: "html-to-markdown",
      title: "HTML to Markdown",
      description: "Convert HTML to Markdown",
      icon: <Code className="w-8 h-8 text-green-600" />,
      path: "/tools/html-to-markdown",
      category: "developer",
      bgColor: "bg-orange-100"
    },
    {
      id: "css-minifier",
      title: "CSS Minifier",
      description: "Minify CSS code",
      icon: <FileCode className="w-8 h-8 text-indigo-600" />,
      path: "/tools/css-minifier",
      category: "developer",
      bgColor: "bg-green-100"
    },
    {
      id: "javascript-minifier",
      title: "JavaScript Minifier",
      description: "Minify JavaScript code",
      icon: <FileCode className="w-8 h-8 text-yellow-600" />,
      path: "/tools/javascript-minifier",
      category: "developer",
      bgColor: "bg-blue-100"
    },
    {
      id: "sql-formatter",
      title: "SQL Formatter",
      description: "Format SQL queries",
      icon: <Database className="w-8 h-8 text-teal-600" />,
      path: "/tools/sql-formatter",
      category: "developer",
      bgColor: "bg-teal-100"
    },
    {
      id: "base64-encoder",
      title: "Base64 Encoder",
      description: "Encode/decode Base64",
      icon: <FileType className="w-8 h-8 text-pink-600" />,
      path: "/tools/base64-encoder",
      category: "developer",
      bgColor: "bg-pink-100"
    },
    {
      id: "csv-to-json",
      title: "CSV to JSON",
      description: "Convert CSV to JSON format",
      icon: <Table className="w-8 h-8 text-emerald-600" />,
      path: "/tools/csv-to-json",
      category: "developer",
      isNew: true,
      bgColor: "bg-emerald-100"
    },
    {
      id: "json-to-csv",
      title: "JSON to CSV",
      description: "Convert JSON to CSV format",
      icon: <FileJson className="w-8 h-8 text-red-600" />,
      path: "/tools/json-to-csv",
      category: "developer",
      isNew: true,
      bgColor: "bg-red-100"
    },
    {
      id: "regex-tester",
      title: "RegEx Tester",
      description: "Test regular expressions",
      icon: <Hash className="w-8 h-8 text-amber-600" />,
      path: "/tools/regex-tester",
      category: "developer",
      isPopular: true,
      bgColor: "bg-yellow-100"
    },
    {
      id: "jwt-decoder",
      title: "JWT Decoder",
      description: "Decode JWT tokens",
      icon: <KeyRound className="w-8 h-8 text-violet-600" />,
      path: "/tools/jwt-decoder",
      category: "developer",
      isNew: true,
      bgColor: "bg-indigo-100"
    }
  ];

  const displayTools = tools || defaultTools;

  return (
    <ToolSection 
      title="Developer Tools"
      description="Essential tools for web developers and programmers to boost productivity and ensure clean, optimized code."
    >
      {displayTools.map((tool) => (
        <ToolCard 
          key={tool.id}
          icon={tool.icon} 
          title={tool.title} 
          link={tool.path}
          bgColor={tool.bgColor || "bg-purple-100"}
          isPopular={tool.isPopular}
          isNew={tool.isNew}
          isPremium={tool.isPremium}
          description={tool.description}
        />
      ))}
    </ToolSection>
  );
};

export default DeveloperTools;
