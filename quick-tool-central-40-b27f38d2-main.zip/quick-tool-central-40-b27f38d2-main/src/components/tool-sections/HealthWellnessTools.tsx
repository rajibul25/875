
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  WeightIcon,
  AgeIcon,
  SpeedIcon,
  PercentIcon,
  HeartIcon,
  ActivityIcon,
  AppleIcon,
  MoonIcon,
  BabyIcon
} from "@/components/icons/ToolIcons";

const HealthWellnessTools = () => {
  return (
    <ToolSection 
      title="Health & Wellness Tools"
      description="Track, calculate, and optimize your health and wellness with these powerful tools designed to help you achieve your health goals."
      featured={true}
    >
      <ToolCard 
        icon={<WeightIcon />} 
        title="BMI Calculator" 
        link="/tools/bmi-calculator"
        bgColor="bg-green-100 dark:bg-green-900/30"
        isPopular={true}
        description="Calculate Body Mass Index"
      />
      <ToolCard 
        icon={<AppleIcon />} 
        title="Calorie Counter" 
        link="/tools/calorie-counter"
        bgColor="bg-blue-100 dark:bg-blue-900/30"
        isNew={true}
        description="Track daily calorie intake"
      />
      <ToolCard 
        icon={<BabyIcon />} 
        title="Pregnancy Calculator" 
        link="/tools/pregnancy-calculator"
        bgColor="bg-pink-100 dark:bg-pink-900/30"
        isNew={true}
        description="Calculate due date and more"
      />
      <ToolCard 
        icon={<WeightIcon />} 
        title="Ideal Weight Calculator" 
        link="/tools/ideal-weight-calculator"
        bgColor="bg-purple-100 dark:bg-purple-900/30"
        isNew={true}
        description="Find your ideal weight range"
      />
      <ToolCard 
        icon={<SpeedIcon />} 
        title="Pace Calculator" 
        link="/tools/pace-calculator"
        bgColor="bg-teal-100 dark:bg-teal-900/30"
        isNew={true}
        description="Calculate running/walking pace"
      />
      <ToolCard 
        icon={<MoonIcon />} 
        title="Sleep Calculator" 
        link="/tools/sleep-calculator"
        bgColor="bg-indigo-100 dark:bg-indigo-900/30"
        isNew={true}
        description="Find ideal bedtime & wake time"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Body Fat Calculator" 
        link="/tools/body-fat-calculator"
        bgColor="bg-orange-100 dark:bg-orange-900/30"
        description="Estimate body fat percentage"
      />
      <ToolCard 
        icon={<WeightIcon />} 
        title="Macro Calculator" 
        link="/tools/macro-calculator"
        bgColor="bg-emerald-100 dark:bg-emerald-900/30"
        description="Calculate macronutrient needs"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="BMR Calculator" 
        link="/tools/bmr-calculator"
        bgColor="bg-red-100 dark:bg-red-900/30"
        isNew={true}
        description="Calculate basal metabolic rate"
      />
      <ToolCard 
        icon={<HeartIcon />} 
        title="Heart Rate Calculator" 
        link="/tools/heart-rate-calculator"
        bgColor="bg-rose-100 dark:bg-rose-900/30"
        isNew={true}
        description="Find target heart rate zones"
      />
      <ToolCard 
        icon={<ActivityIcon />} 
        title="Workout Planner" 
        link="/tools/workout-planner"
        bgColor="bg-amber-100 dark:bg-amber-900/30"
        isNew={true}
        description="Create custom workout plans"
      />
      <ToolCard 
        icon={<HeartIcon />} 
        title="Blood Pressure Log" 
        link="/tools/blood-pressure-log"
        bgColor="bg-cyan-100 dark:bg-cyan-900/30"
        isNew={true}
        description="Track blood pressure readings"
      />
    </ToolSection>
  );
};

export default HealthWellnessTools;
