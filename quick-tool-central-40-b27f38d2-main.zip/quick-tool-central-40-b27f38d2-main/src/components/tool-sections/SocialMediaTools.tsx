
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  ImageIcon,
  HashtagIcon,
  CalendarIcon,
  LinkIconStyling
} from "@/components/icons/ToolIcons";
import { Tool } from "@/lib/tool-model";

interface SocialMediaToolsProps {
  tools?: Tool[];
}

const SocialMediaTools = ({ tools }: SocialMediaToolsProps) => {
  // Use provided tools or show default ones if not provided
  const defaultTools = [
    {
      id: "social-post-creator",
      title: "Social Media Post Creator",
      link: "/tools/social-post-creator",
      bgColor: "bg-blue-100",
      isPopular: true,
      description: "Create engaging social posts",
      icon: <ImageIcon />,
      path: "/tools/social-post-creator",
      category: "social"
    },
    {
      id: "hashtag-generator",
      title: "Hashtag Generator",
      link: "/tools/hashtag-generator",
      bgColor: "bg-green-100",
      description: "Generate trending hashtags",
      icon: <HashtagIcon />,
      path: "/tools/hashtag-generator",
      category: "social"
    },
    {
      id: "social-calendar",
      title: "Social Media Calendar",
      link: "/tools/social-calendar",
      bgColor: "bg-purple-100",
      isNew: true,
      description: "Plan your content schedule",
      icon: <CalendarIcon />,
      path: "/tools/social-calendar",
      category: "social"
    },
    {
      id: "bio-link",
      title: "Bio Link Generator",
      link: "/tools/bio-link",
      bgColor: "bg-pink-100",
      description: "Create multi-link bios",
      icon: <LinkIconStyling />,
      path: "/tools/bio-link",
      category: "social"
    }
  ];

  const displayTools = tools || defaultTools;

  return (
    <ToolSection 
      title="Social Media Tools"
      description="Enhance your social media presence with these powerful tools for content creation and management."
    >
      {displayTools.map((tool) => (
        <ToolCard 
          key={tool.id}
          icon={tool.icon} 
          title={tool.title} 
          link={tool.path}
          bgColor={tool.bgColor || "bg-blue-100"}
          isPopular={tool.isPopular}
          isNew={tool.isNew}
          isPremium={tool.isPremium}
          description={tool.description}
        />
      ))}
    </ToolSection>
  );
};

export default SocialMediaTools;
