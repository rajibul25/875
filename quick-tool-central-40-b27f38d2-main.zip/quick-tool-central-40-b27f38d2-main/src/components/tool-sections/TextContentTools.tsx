
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  WordCounterIcon,
  CharacterCounterIcon,
  CaseConverterIcon,
  PlagiarismIcon
} from "@/components/icons/ToolIcons";
import { 
  FileText, 
  Mic, 
  Diff, 
  AlignLeft, 
  Repeat, 
  BarChart2 
} from "lucide-react";

const TextContentTools = () => {
  return (
    <ToolSection 
      title="Text & Content Tools"
      description="Analyze and manipulate text with these powerful text processing tools."
    >
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Word Counter" 
        link="/tools/word-counter"
        bgColor="bg-blue-100"
        isPopular={true}
        description="Count words, characters, and analyze keyword density"
      />
      <ToolCard 
        icon={<CharacterCounterIcon />} 
        title="Character Counter" 
        link="/tools/character-counter"
        bgColor="bg-purple-100"
        description="Count characters with and without spaces"
      />
      <ToolCard 
        icon={<CaseConverterIcon />} 
        title="Case Converter" 
        link="/tools/case-converter"
        bgColor="bg-purple-100"
        description="Convert between text cases"
      />
      <ToolCard 
        icon={<PlagiarismIcon />} 
        title="Plagiarism Checker" 
        link="/tools/plagiarism-checker"
        bgColor="bg-orange-100"
        isPopular={true}
        description="Check content originality"
      />
      <ToolCard 
        icon={<FileText className="h-8 w-8 text-green-500" />} 
        title="Grammar Checker" 
        link="/tools/grammar-checker"
        bgColor="bg-green-100"
        description="Fix grammar errors in text"
      />
      <ToolCard 
        icon={<Mic className="h-8 w-8 text-teal-500" />} 
        title="Text to Speech" 
        link="/tools/text-to-speech"
        bgColor="bg-teal-100"
        description="Convert text to audio"
      />
      <ToolCard 
        icon={<Diff className="h-8 w-8 text-red-500" />} 
        title="Text Diff Checker" 
        link="/tools/text-diff-checker"
        bgColor="bg-red-100"
        isNew={true}
        description="Compare text differences"
      />
      <ToolCard 
        icon={<AlignLeft className="h-8 w-8 text-yellow-500" />} 
        title="Lorem Ipsum Generator" 
        link="/tools/lorem-ipsum-generator"
        bgColor="bg-yellow-100"
        description="Generate placeholder text"
      />
      <ToolCard 
        icon={<Repeat className="h-8 w-8 text-pink-500" />} 
        title="Text Repeater" 
        link="/tools/text-repeater"
        bgColor="bg-pink-100"
        description="Repeat text multiple times"
      />
      <ToolCard 
        icon={<BarChart2 className="h-8 w-8 text-indigo-500" />} 
        title="Word Frequency Counter" 
        link="/tools/word-frequency"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Count word occurrences"
      />
    </ToolSection>
  );
};

export default TextContentTools;
