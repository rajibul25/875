
import React from "react";
import TextContentTools from "@/components/tool-sections/TextContentTools";
import { Tool } from "@/lib/tool-model";

interface TextContentToolsWrapperProps {
  tools?: Tool[];
}

const TextContentToolsWrapper = ({ tools }: TextContentToolsWrapperProps) => {
  // The TextContentTools component doesn't accept a tools prop according to the error
  // So we don't pass the tools prop to it
  return <TextContentTools />;
};

export default TextContentToolsWrapper;
