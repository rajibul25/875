
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  PercentIcon,
  AgeIcon,
  LoanIcon,
  CalculatorIcon,
  DollarSignIcon,
  CirclePercentIcon
} from "@/components/icons/ToolIcons";
import { Tool } from "@/lib/tool-model";

interface MathCalculatorsProps {
  tools?: Tool[];
}

const MathCalculators = ({ tools }: MathCalculatorsProps) => {
  const defaultTools = [
    {
      id: "percentage-calculator",
      title: "Percentage Calculator",
      description: "Calculate percentages easily",
      icon: <PercentIcon />,
      path: "/tools/percentage-calculator",
      category: "math",
      isPopular: true,
      bgColor: "bg-red-100"
    },
    {
      id: "age-calculator",
      title: "Age Calculator",
      description: "Calculate age between dates",
      icon: <AgeIcon />,
      path: "/tools/age-calculator",
      category: "math",
      bgColor: "bg-blue-100"
    },
    {
      id: "bmi-calculator",
      title: "BMI Calculator",
      description: "Calculate Body Mass Index",
      icon: <LoanIcon />,
      path: "/tools/bmi-calculator",
      category: "math",
      bgColor: "bg-green-100"
    },
    {
      id: "loan-calculator",
      title: "Loan EMI Calculator",
      description: "Calculate loan payments",
      icon: <LoanIcon />,
      path: "/tools/loan-calculator",
      category: "math",
      isPopular: true,
      bgColor: "bg-green-100"
    },
    {
      id: "mortgage-calculator",
      title: "Mortgage Calculator",
      description: "Calculate mortgage payments",
      icon: <LoanIcon />,
      path: "/tools/mortgage-calculator",
      category: "math",
      isNew: true,
      bgColor: "bg-blue-100"
    },
    {
      id: "loan-interest-calculator",
      title: "Loan Interest Calculator",
      description: "Compare loan interest types",
      icon: <DollarSignIcon />,
      path: "/tools/loan-interest-calculator", 
      category: "math",
      isNew: true,
      bgColor: "bg-purple-100"
    },
    {
      id: "currency-converter",
      title: "Currency Converter",
      description: "Convert between currencies",
      icon: <CirclePercentIcon />,
      path: "/tools/currency-converter",
      category: "math",
      bgColor: "bg-yellow-100"
    },
    {
      id: "tip-calculator",
      title: "Tip Calculator",
      description: "Calculate tips for bills",
      icon: <CalculatorIcon />,
      path: "/tools/tip-calculator",
      category: "math",
      bgColor: "bg-pink-100"
    },
    {
      id: "compound-interest",
      title: "Compound Interest",
      description: "Calculate compound interest",
      icon: <DollarSignIcon />,
      path: "/tools/compound-interest",
      category: "math",
      isNew: true,
      bgColor: "bg-purple-100"
    },
    {
      id: "discount-calculator",
      title: "Discount Calculator",
      description: "Calculate price after discount",
      icon: <PercentIcon />,
      path: "/tools/discount-calculator",
      category: "math",
      bgColor: "bg-teal-100"
    },
    {
      id: "gst-calculator",
      title: "GST Calculator",
      description: "Calculate tax inclusive prices",
      icon: <CalculatorIcon />,
      path: "/tools/gst-calculator",
      category: "math",
      bgColor: "bg-orange-100"
    },
    {
      id: "scientific-calculator",
      title: "Scientific Calculator",
      description: "Advanced math calculations",
      icon: <CalculatorIcon />,
      path: "/tools/scientific-calculator",
      category: "math",
      isNew: true,
      bgColor: "bg-indigo-100"
    }
  ];

  const displayTools = tools || defaultTools;

  return (
    <ToolSection 
      title="Math & Calculators"
      description="From simple calculations to complex formulas, our math tools help you solve problems quickly."
    >
      {displayTools.map((tool) => (
        <ToolCard 
          key={tool.id}
          icon={tool.icon} 
          title={tool.title} 
          link={tool.path}
          bgColor={tool.bgColor || "bg-red-100"}
          isPopular={tool.isPopular}
          isNew={tool.isNew}
          isPremium={tool.isPremium}
          description={tool.description}
        />
      ))}
    </ToolSection>
  );
};

export default MathCalculators;
