
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import AdBanner from "@/components/AdBanner";
import { 
  ImageIcon,
  QrCodeIcon,
  MetaTagIcon,
  KeywordIcon,
  SitemapIcon,
  RobotsIcon,
  WordCounterIcon,
  CharacterCounterIcon,
  CaseConverterIcon,
  JsonIcon,
  HtmlIcon,
  LoanIcon,
  PercentIcon,
  AgeIcon,
  SpeedIcon,
  TemperatureIcon,
  LengthIcon,
  WeightIcon,
  FileIcon,
  LinkIconStyling,
  GlobeIcon,
  DatabaseIcon,
  UrlAnalyzerIcon,
  BacklinkIcon,
  SchemaIcon,
  SerpIcon
} from "@/components/icons/ToolIcons";
import { Tool } from "@/lib/tool-model";

interface AdditionalCategoriesProps {
  tools?: Tool[];
}

const AdditionalCategories = ({ tools }: AdditionalCategoriesProps) => {
  // Note: This component doesn't directly use the tools prop as it has fixed sections
  // But we add the prop for API consistency

  return (
    <>
      <ToolSection 
        title="SEO Tools"
        description="Optimize your website's search engine visibility with these powerful SEO tools."
      >
        <ToolCard 
          icon={<MetaTagIcon />} 
          title="Meta Tag Generator" 
          link="/tools/meta-tag-generator"
          bgColor="bg-teal-100 dark:bg-teal-900/30"
          isPopular={true}
          description="Generate meta tags for SEO"
        />
        <ToolCard 
          icon={<KeywordIcon />} 
          title="Keyword Density Checker" 
          link="/tools/keyword-density-checker"
          bgColor="bg-blue-100 dark:bg-blue-900/30"
          isPopular={true}
          description="Check keyword usage in content"
        />
        <ToolCard 
          icon={<SitemapIcon />} 
          title="Sitemap Generator" 
          link="/tools/sitemap-generator"
          bgColor="bg-green-100 dark:bg-green-900/30"
          isNew={true}
          description="Create XML sitemaps"
        />
        <ToolCard 
          icon={<RobotsIcon />} 
          title="Robots.txt Generator" 
          link="/tools/robots-txt-generator"
          bgColor="bg-yellow-100 dark:bg-yellow-900/30"
          isNew={true}
          description="Create robots.txt files"
        />
        <ToolCard 
          icon={<GlobeIcon />} 
          title="Google Index Checker" 
          link="/tools/google-index-checker"
          bgColor="bg-blue-100 dark:bg-blue-900/30"
          isNew={true}
          description="Check URL indexing status"
        />
        <ToolCard 
          icon={<DatabaseIcon />} 
          title="Domain Authority Checker" 
          link="/tools/domain-authority"
          bgColor="bg-pink-100 dark:bg-pink-900/30"
          isNew={true}
          description="Check website authority"
        />
        <ToolCard 
          icon={<UrlAnalyzerIcon />} 
          title="URL Analyzer" 
          link="/tools/url-analyzer"
          bgColor="bg-purple-100 dark:bg-purple-900/30"
          description="Analyze URL structure"
        />
        <ToolCard 
          icon={<BacklinkIcon />} 
          title="Backlink Checker" 
          link="/tools/backlink-checker"
          bgColor="bg-orange-100 dark:bg-orange-900/30"
          description="Check website backlinks"
        />
        <ToolCard 
          icon={<SchemaIcon />} 
          title="Schema Markup Generator" 
          link="/tools/schema-generator"
          bgColor="bg-emerald-100 dark:bg-emerald-900/30"
          description="Create JSON-LD schema markup"
        />
        <ToolCard 
          icon={<SerpIcon />} 
          title="SERP Preview Tool" 
          link="/tools/serp-preview"
          bgColor="bg-red-100 dark:bg-red-900/30"
          description="Preview Google search results"
        />
      </ToolSection>
      
      <ToolSection 
        title="Unit Converters"
        description="Convert between different units of measurement with precision and ease."
      >
        <ToolCard 
          icon={<LengthIcon />} 
          title="Length Converter" 
          link="/tools/length-converter"
          bgColor="bg-red-100"
          description="Convert between length units"
          isPopular={true}
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Weight Converter" 
          link="/tools/weight-converter"
          bgColor="bg-yellow-100"
          description="Convert between weight units"
        />
        <ToolCard 
          icon={<SpeedIcon />} 
          title="Speed Converter" 
          link="/tools/speed-converter"
          bgColor="bg-pink-100"
          description="Convert between speed units"
        />
        <ToolCard 
          icon={<TemperatureIcon />} 
          title="Temperature Converter" 
          link="/tools/temperature-converter"
          bgColor="bg-orange-100"
          description="Convert between temperature scales"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Volume Converter" 
          link="/tools/volume-converter"
          bgColor="bg-green-100"
          description="Convert between volume units"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Area Converter" 
          link="/tools/area-converter"
          bgColor="bg-teal-100"
          description="Convert between area units"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Data Converter" 
          link="/tools/data-converter"
          bgColor="bg-blue-100"
          isNew={true}
          description="Convert between data units"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Pressure Converter" 
          link="/tools/pressure-converter"
          bgColor="bg-purple-100"
          isNew={true}
          description="Convert between pressure units"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Energy Converter" 
          link="/tools/energy-converter"
          bgColor="bg-indigo-100"
          isNew={true}
          description="Convert between energy units"
        />
        <ToolCard 
          icon={<WeightIcon />} 
          title="Time Converter" 
          link="/tools/time-converter"
          bgColor="bg-rose-100"
          isNew={true}
          description="Convert between time units"
        />
      </ToolSection>
      
      <AdBanner className="my-8" />
      
      <ToolSection 
        title="Security & Encryption Tools"
        description="Protect your data and information with our secure encryption and security tools."
      >
        <ToolCard 
          icon={<JsonIcon />} 
          title="MD5 Hash Generator" 
          link="/tools/md5-generator"
          bgColor="bg-blue-100"
          description="Generate MD5 hashes"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="SHA256 Generator" 
          link="/tools/sha256-generator"
          bgColor="bg-green-100"
          description="Generate SHA256 hashes"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Password Generator" 
          link="/tools/password-generator"
          bgColor="bg-purple-100"
          isPopular={true}
          description="Create secure passwords"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Random String Generator" 
          link="/tools/random-string"
          bgColor="bg-pink-100"
          description="Generate random strings"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="URL Shortener" 
          link="/tools/url-shortener"
          bgColor="bg-yellow-100"
          description="Create short URLs"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="SSL Certificate Checker" 
          link="/tools/ssl-checker"
          bgColor="bg-teal-100"
          description="Verify SSL certificates"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Encryption/Decryption" 
          link="/tools/encrypt-decrypt"
          bgColor="bg-red-100"
          isNew={true}
          description="Encrypt and decrypt text"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="UUID Generator" 
          link="/tools/uuid-generator"
          bgColor="bg-orange-100"
          isNew={true}
          description="Generate UUIDs/GUIDs"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="HMAC Generator" 
          link="/tools/hmac-generator"
          bgColor="bg-emerald-100"
          isNew={true}
          description="Generate HMAC signatures"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Hash Identifier" 
          link="/tools/hash-identifier"
          bgColor="bg-indigo-100"
          isNew={true}
          description="Identify hash types"
        />
      </ToolSection>
      
      <ToolSection 
        title="Business & Finance Calculators"
        description="Essential business and financial tools to help with accounting, investments and planning."
      >
        <ToolCard 
          icon={<LoanIcon />} 
          title="EMI Calculator" 
          link="/tools/emi-calculator"
          bgColor="bg-green-100"
          isPopular={true}
          description="Calculate loan installments"
        />
        <ToolCard 
          icon={<LoanIcon />} 
          title="Loan Interest Calculator" 
          link="/tools/loan-interest"
          bgColor="bg-teal-100"
          description="Calculate loan interest"
        />
        <ToolCard 
          icon={<LoanIcon />} 
          title="Mortgage Calculator" 
          link="/tools/mortgage-calculator"
          bgColor="bg-blue-100"
          description="Calculate mortgage payments"
        />
        <ToolCard 
          icon={<LoanIcon />} 
          title="SIP Calculator" 
          link="/tools/sip-calculator"
          bgColor="bg-purple-100"
          description="Calculate investment returns"
        />
        <ToolCard 
          icon={<LoanIcon />} 
          title="Income Tax Calculator" 
          link="/tools/income-tax-calculator"
          bgColor="bg-red-100"
          description="Calculate income tax"
        />
        <ToolCard 
          icon={<LoanIcon />} 
          title="GST Calculator" 
          link="/tools/gst-calculator"
          bgColor="bg-orange-100"
          description="Calculate GST taxes"
        />
        <ToolCard 
          icon={<PercentIcon />} 
          title="Profit Margin Calculator" 
          link="/tools/profit-margin"
          bgColor="bg-emerald-100"
          description="Calculate profit margins"
        />
        <ToolCard 
          icon={<PercentIcon />} 
          title="ROI Calculator" 
          link="/tools/roi-calculator"
          bgColor="bg-yellow-100"
          description="Calculate return on investment"
        />
        <ToolCard 
          icon={<PercentIcon />} 
          title="Depreciation Calculator" 
          link="/tools/depreciation-calculator"
          bgColor="bg-indigo-100"
          isNew={true}
          description="Calculate asset depreciation"
        />
        <ToolCard 
          icon={<PercentIcon />} 
          title="Break-even Calculator" 
          link="/tools/break-even"
          bgColor="bg-pink-100"
          isNew={true}
          description="Calculate break-even point"
        />
      </ToolSection>
      
      <ToolSection 
        title="Educational Tools"
        description="Learning resources and calculators to help students, teachers, and lifelong learners."
        columns={4}
      >
        <ToolCard 
          icon={<WordCounterIcon />} 
          title="Flashcard Maker" 
          link="/tools/flashcard-maker"
          bgColor="bg-blue-100"
          isPremium={true}
          description="Create study flashcards"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Citation Generator" 
          link="/tools/citation-generator"
          bgColor="bg-green-100"
          isPopular={true}
          description="Generate MLA, APA citations"
        />
        <ToolCard 
          icon={<WordCounterIcon />} 
          title="Study Timer" 
          link="/tools/study-timer"
          bgColor="bg-purple-100"
          description="Pomodoro timer for studying"
        />
        <ToolCard 
          icon={<PercentIcon />} 
          title="Grade Calculator" 
          link="/tools/grade-calculator"
          bgColor="bg-teal-100"
          description="Calculate final grade needed"
        />
        <ToolCard 
          icon={<WordCounterIcon />} 
          title="Note Taker" 
          link="/tools/note-taker"
          bgColor="bg-pink-100"
          isNew={true}
          description="Organized note-taking app"
        />
        <ToolCard 
          icon={<WordCounterIcon />} 
          title="Vocabulary Builder" 
          link="/tools/vocabulary-builder"
          bgColor="bg-yellow-100"
          description="Expand your vocabulary"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Math Equation Solver" 
          link="/tools/equation-solver"
          bgColor="bg-red-100"
          isNew={true}
          description="Solve complex equations"
        />
        <ToolCard 
          icon={<CaseConverterIcon />} 
          title="Language Translator" 
          link="/tools/language-translator"
          bgColor="bg-indigo-100"
          description="Translate between languages"
        />
      </ToolSection>
      
      <ToolSection 
        title="Miscellaneous Tools"
        description="A collection of other useful tools that don't fit into specific categories."
      >
        <ToolCard 
          icon={<QrCodeIcon />} 
          title="Barcode Generator" 
          link="/tools/barcode-generator"
          bgColor="bg-blue-100"
          description="Generate different barcodes"
        />
        <ToolCard 
          icon={<ImageIcon />} 
          title="Meme Generator" 
          link="/tools/meme-generator"
          bgColor="bg-purple-100"
          description="Create custom memes"
        />
        <ToolCard 
          icon={<HtmlIcon />} 
          title="Resume Builder" 
          link="/tools/resume-builder"
          bgColor="bg-green-100"
          isPopular={true}
          description="Create professional resumes"
        />
        <ToolCard 
          icon={<HtmlIcon />} 
          title="Invoice Generator" 
          link="/tools/invoice-generator"
          bgColor="bg-teal-100"
          description="Create business invoices"
        />
        <ToolCard 
          icon={<AgeIcon />} 
          title="Fake Address Generator" 
          link="/tools/fake-address"
          bgColor="bg-red-100"
          description="Generate test addresses"
        />
        <ToolCard 
          icon={<AgeIcon />} 
          title="Leap Year Checker" 
          link="/tools/leap-year"
          bgColor="bg-yellow-100"
          description="Check if year is leap year"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Color Picker" 
          link="/tools/color-picker"
          bgColor="bg-orange-100"
          isNew={true}
          description="Pick and convert colors"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="IP Address Lookup" 
          link="/tools/ip-lookup"
          bgColor="bg-pink-100"
          isNew={true}
          description="Find IP address information"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Random Number Generator" 
          link="/tools/random-number"
          bgColor="bg-emerald-100"
          isNew={true}
          description="Generate random numbers"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Dictionary" 
          link="/tools/dictionary"
          bgColor="bg-indigo-100"
          isNew={true}
          description="Look up word definitions"
        />
      </ToolSection>
      
      <ToolSection 
        title="Social Media Tools"
        description="Enhance your social media presence with these powerful tools for content creation and management."
      >
        <ToolCard 
          icon={<ImageIcon />} 
          title="Social Media Post Creator" 
          link="/tools/social-post-creator"
          bgColor="bg-blue-100"
          isPopular={true}
          description="Create engaging social posts"
        />
        <ToolCard 
          icon={<ImageIcon />} 
          title="Hashtag Generator" 
          link="/tools/hashtag-generator"
          bgColor="bg-green-100"
          description="Generate trending hashtags"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Social Media Calendar" 
          link="/tools/social-calendar"
          bgColor="bg-purple-100"
          isNew={true}
          description="Plan your content schedule"
        />
        <ToolCard 
          icon={<JsonIcon />} 
          title="Bio Link Generator" 
          link="/tools/bio-link"
          bgColor="bg-pink-100"
          description="Create multi-link bios"
        />
      </ToolSection>
    </>
  );
};

export default AdditionalCategories;
