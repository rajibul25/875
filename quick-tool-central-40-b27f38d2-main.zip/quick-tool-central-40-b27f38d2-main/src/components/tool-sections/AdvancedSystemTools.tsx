
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { Cpu, Database, HardDrive, Network, Terminal, Zap, Scan } from "lucide-react";
import { Tool } from "@/lib/tool-model";

interface AdvancedSystemToolsProps {
  tools?: Tool[];
}

const AdvancedSystemTools = ({ tools }: AdvancedSystemToolsProps) => {
  const defaultTools = [
    {
      id: "system-monitor",
      title: "System Monitor", 
      description: "Monitor system resources in real-time",
      icon: <Terminal className="h-6 w-6 text-blue-600" />,
      path: "/tools/system-monitor",
      category: "advanced",
      isNew: true,
      bgColor: "bg-blue-100"
    },
    {
      id: "disk-analyzer",
      title: "Disk Analyzer", 
      description: "Analyze disk usage and file distribution",
      icon: <HardDrive className="h-6 w-6 text-green-600" />,
      path: "/tools/disk-analyzer",
      category: "advanced",
      isNew: true,
      bgColor: "bg-green-100"
    },
    {
      id: "network-diagnostics",
      title: "Network Diagnostics", 
      description: "Diagnose network connectivity issues",
      icon: <Network className="h-6 w-6 text-orange-600" />,
      path: "/tools/network-diagnostics",
      category: "advanced",
      isNew: true,
      bgColor: "bg-orange-100"
    },
    {
      id: "database-viewer",
      title: "Database Viewer", 
      description: "View and manage databases",
      icon: <Database className="h-6 w-6 text-purple-600" />,
      path: "/tools/database-viewer",
      category: "advanced",
      isPremium: true,
      bgColor: "bg-purple-100"
    },
    {
      id: "process-manager",
      title: "Process Manager", 
      description: "Monitor and manage running processes",
      icon: <Cpu className="h-6 w-6 text-indigo-600" />,
      path: "/tools/process-manager",
      category: "advanced",
      isNew: true,
      bgColor: "bg-indigo-100"
    },
    {
      id: "port-scanner",
      title: "Port Scanner", 
      description: "Scan network ports for security analysis",
      icon: <Scan className="h-6 w-6 text-red-600" />,
      path: "/tools/port-scanner",
      category: "advanced",
      isPremium: true,
      bgColor: "bg-red-100"
    },
    {
      id: "performance-analyzer",
      title: "Performance Analyzer", 
      description: "Analyze and optimize system performance",
      icon: <Zap className="h-6 w-6 text-yellow-600" />,
      path: "/tools/performance-analyzer",
      category: "advanced",
      isNew: true,
      bgColor: "bg-yellow-100"
    },
    {
      id: "command-line",
      title: "Command Line Interface", 
      description: "Access powerful terminal commands",
      icon: <Terminal className="h-6 w-6 text-teal-600" />,
      path: "/tools/command-line",
      category: "advanced",
      isPremium: true,
      bgColor: "bg-teal-100"
    }
  ];

  const displayTools = tools || defaultTools;

  return (
    <ToolSection 
      title="Advanced System Tools"
      description="Professional system utilities and diagnostics for power users and IT professionals."
      featured={true}
      columns={4}
    >
      {displayTools.map((tool) => (
        <ToolCard 
          key={tool.id}
          icon={tool.icon} 
          title={tool.title} 
          link={tool.path}
          bgColor={tool.bgColor || "bg-blue-100"}
          isPopular={tool.isPopular}
          isNew={tool.isNew}
          isPremium={tool.isPremium}
          description={tool.description}
        />
      ))}
    </ToolSection>
  );
};

export default AdvancedSystemTools;
