
import React from "react";
import HealthWellnessTools from "@/components/tool-sections/HealthWellnessTools";
import { Tool } from "@/lib/tool-model";

interface HealthWellnessToolsWrapperProps {
  tools?: Tool[];
}

const HealthWellnessToolsWrapper = ({ tools }: HealthWellnessToolsWrapperProps) => {
  // The HealthWellnessTools component doesn't accept a tools prop according to the error
  // So we don't pass the tools prop to it
  return <HealthWellnessTools />;
};

export default HealthWellnessToolsWrapper;
