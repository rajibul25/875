
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  ImageIcon,
  ResizeIcon,
  CompressIcon,
  QrCodeIcon,
  GifIcon,
  WebpIcon,
  ColorPickerIcon,
  CropIcon,
  Base64Icon,
  SvgIcon
} from "@/components/icons/ToolIcons";
import { Tool } from "@/lib/tool-model";

interface ImageMediaToolsProps {
  tools?: Tool[];
}

const ImageMediaTools = ({ tools }: ImageMediaToolsProps) => {
  const defaultTools = [
    {
      id: "image-to-png",
      title: "Image to PNG Converter",
      description: "Convert JPG, WebP, GIF to PNG",
      icon: <ImageIcon />,
      path: "/tools/image-to-png",
      category: "conversion",
      isPopular: true,
      bgColor: "bg-blue-100"
    },
    {
      id: "image-resizer",
      title: "Image Resizer",
      description: "Resize images to exact dimensions",
      icon: <ResizeIcon />,
      path: "/tools/image-resizer",
      category: "conversion",
      bgColor: "bg-blue-100"
    },
    {
      id: "image-compressor",
      title: "Image Compressor",
      description: "Reduce file size without losing quality",
      icon: <CompressIcon />,
      path: "/tools/image-compressor",
      category: "conversion",
      bgColor: "bg-teal-100"
    },
    {
      id: "qr-code-generator",
      title: "QR Code Generator",
      description: "Create custom QR codes for URLs",
      icon: <QrCodeIcon />,
      path: "/tools/qr-code-generator",
      category: "conversion",
      bgColor: "bg-green-100"
    },
    {
      id: "gif-maker",
      title: "GIF Maker",
      description: "Create animated GIFs from images",
      icon: <GifIcon />,
      path: "/tools/gif-maker",
      category: "conversion",
      isNew: true,
      bgColor: "bg-orange-100"
    },
    {
      id: "webp-converter",
      title: "WebP Converter",
      description: "Convert to/from WebP format",
      icon: <WebpIcon />,
      path: "/tools/webp-converter",
      category: "conversion",
      isNew: true,
      bgColor: "bg-purple-100"
    },
    {
      id: "image-color-picker",
      title: "Image Color Picker",
      description: "Extract colors from images",
      icon: <ColorPickerIcon />,
      path: "/tools/image-color-picker",
      category: "conversion",
      isNew: true,
      bgColor: "bg-pink-100"
    },
    {
      id: "image-cropper",
      title: "Image Cropper",
      description: "Crop images to perfect size",
      icon: <CropIcon />,
      path: "/tools/image-cropper",
      category: "conversion",
      bgColor: "bg-yellow-100"
    },
    {
      id: "image-to-base64",
      title: "Image to Base64",
      description: "Convert images to base64 strings",
      icon: <Base64Icon />,
      path: "/tools/image-to-base64",
      category: "conversion",
      bgColor: "bg-red-100"
    },
    {
      id: "svg-editor",
      title: "SVG Editor",
      description: "Edit SVG files online",
      icon: <SvgIcon />,
      path: "/tools/svg-editor",
      category: "conversion",
      isNew: true,
      bgColor: "bg-emerald-100"
    }
  ];

  const displayTools = tools || defaultTools;

  return (
    <ToolSection 
      title="Image & Media Tools" 
      description="Edit, convert, and optimize your images and media files with these powerful tools."
    >
      {displayTools.map((tool) => (
        <ToolCard 
          key={tool.id}
          icon={tool.icon} 
          title={tool.title} 
          link={tool.path}
          bgColor={tool.bgColor || "bg-blue-100"}
          isPopular={tool.isPopular}
          isNew={tool.isNew}
          isPremium={tool.isPremium}
          description={tool.description}
        />
      ))}
    </ToolSection>
  );
};

export default ImageMediaTools;
