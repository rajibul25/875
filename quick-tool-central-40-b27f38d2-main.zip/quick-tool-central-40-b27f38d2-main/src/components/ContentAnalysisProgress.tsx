
import { motion } from "framer-motion";
import { Bot, User, Sparkles } from "lucide-react";

interface AnalysisProgressProps {
  isAnalyzing: boolean;
  aiPercentage: number;
}

const ContentAnalysisProgress = ({ isAnalyzing, aiPercentage }: AnalysisProgressProps) => {
  const humanPercentage = 100 - aiPercentage;
  
  return (
    <div className="relative w-full max-w-md mx-auto my-8">
      {/* Progress Container */}
      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden relative">
        <motion.div 
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-rose-500 to-purple-600"
          initial={{ width: "50%" }}
          animate={{ width: `${aiPercentage}%` }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
        
        {isAnalyzing && (
          <motion.div 
            className="absolute top-0 left-0 h-full w-full bg-white/30"
            animate={{ 
              x: ["0%", "100%", "0%"],
              opacity: [0.3, 0.6, 0.3]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </div>

      {/* Percentage Labels */}
      <div className="flex justify-between mt-2 text-sm">
        <div className="flex items-center">
          <User className="w-4 h-4 mr-1 text-emerald-500" />
          <span>{humanPercentage}% Human</span>
        </div>
        <div className="flex items-center">
          <span>{aiPercentage}% AI</span>
          <Bot className="w-4 h-4 ml-1 text-rose-500" />
        </div>
      </div>

      {/* Analysis Animation */}
      {isAnalyzing && (
        <motion.div 
          className="absolute -top-12 left-1/2 -translate-x-1/2"
          animate={{ 
            y: [0, -10, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{ 
            duration: 1.5,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default ContentAnalysisProgress;
