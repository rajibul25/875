
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { motion } from "framer-motion";

interface ToolCardProps {
  icon: React.ReactNode;
  title: string;
  link: string;
  bgColor?: string;
  description?: string;
  isNew?: boolean;
  isPopular?: boolean;
  isPremium?: boolean;
}

const ToolCard = ({ 
  icon, 
  title, 
  link, 
  bgColor = "bg-blue-100 dark:bg-blue-900/30", 
  description,
  isNew = false,
  isPopular = false,
  isPremium = false
}: ToolCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Link 
      to={link} 
      className="block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      aria-label={`Open ${title} tool`}
    >
      <motion.div 
        className={cn(
          "flex flex-col items-center p-4 transition-all duration-300 rounded-lg h-full border relative",
          isHovered ? 
            "shadow-md border-primary/50 dark:border-primary/50" : 
            "border-transparent hover:border-gray-200 dark:hover:border-gray-700",
          isNew ? "ring-2 ring-green-400 dark:ring-green-600" : ""
        )}
        whileHover={{ y: -5 }}
        transition={{ type: "spring", stiffness: 300 }}
        data-tool-title={title}
        data-tool-description={description}
        data-is-new={isNew ? "true" : "false"}
      >
        {isNew && (
          <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-sm z-10">
            NEW
          </div>
        )}
        
        <div className={cn("p-3 rounded-lg mb-3 flex items-center justify-center w-16 h-16", bgColor)}>
          {icon}
        </div>
        <span className="text-center text-sm font-medium text-gray-800 dark:text-gray-200 mb-1">{title}</span>
        
        {description && (
          <span className="text-center text-xs text-gray-500 dark:text-gray-400 mt-1 hidden md:block">{description}</span>
        )}
        
        <div className="flex gap-2 mt-2">
          {isNew && (
            <span className="inline-flex items-center rounded-full bg-green-100 dark:bg-green-900/40 px-2 py-0.5 text-xs font-medium text-green-800 dark:text-green-300">
              New
            </span>
          )}
          {isPopular && (
            <span className="inline-flex items-center rounded-full bg-orange-100 dark:bg-orange-900/40 px-2 py-0.5 text-xs font-medium text-orange-800 dark:text-orange-300">
              Popular
            </span>
          )}
          {isPremium && (
            <span className="inline-flex items-center rounded-full bg-purple-100 dark:bg-purple-900/40 px-2 py-0.5 text-xs font-medium text-purple-800 dark:text-purple-300">
              Premium
            </span>
          )}
        </div>
      </motion.div>
    </Link>
  );
};

export default ToolCard;
