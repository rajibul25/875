
import { motion } from "framer-motion";
import { User, Bot, Shield, BarChart2, FileText, Zap, AlignLeft, MessageSquare } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ContentCategory {
  name: string;
  value: number;
  color: string;
  iconName: string;
  description: string;
}

interface ContentSource {
  type: "ai" | "human" | "mixed";
  probability: number;
  confidence: number;
  iconName: string;
  color: string;
  badge: string;
}

export interface ContentAnalysisResult {
  source: ContentSource;
  categories: ContentCategory[];
  languageStyle: string;
  emotionalTone: string;
  contentType: string;
  grammarQuality: number;
  suggestedEdits: string[];
  aiPatterns: string[];
  keywords: string[];
}

interface ResultDisplayProps {
  result: ContentAnalysisResult;
  isAnimating: boolean;
}

const ResultDisplay = ({ result, isAnimating }: ResultDisplayProps) => {
  if (!result) return null;
  
  const { source, categories, languageStyle, emotionalTone, contentType, grammarQuality, suggestedEdits, aiPatterns } = result;
  
  const getBadgeColor = (type: string) => {
    switch(type) {
      case "ai": return "from-rose-500 to-purple-600 text-white";
      case "human": return "from-emerald-500 to-teal-600 text-white";
      default: return "from-blue-500 to-indigo-600 text-white";
    }
  };

  // Helper function to render the correct icon based on name
  const renderIcon = (iconName: string, size: string = "w-4 h-4") => {
    switch(iconName) {
      case "Bot":
        return <Bot className={size} />;
      case "User":
        return <User className={size} />;
      case "Shield":
        return <Shield className={size} />;
      case "BarChart2":
        return <BarChart2 className={size} />;
      case "FileText":
        return <FileText className={size} />;
      case "Zap":
        return <Zap className={size} />;
      default:
        return <Shield className={size} />;
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      {/* Source Detection Result with Animation */}
      <div className="text-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mb-4"
        >
          <div className={`w-20 h-20 rounded-full flex items-center justify-center bg-gradient-to-br ${getBadgeColor(source.type)}`}>
            {renderIcon(source.iconName, "w-10 h-10 text-white")}
          </div>
        </motion.div>
        
        <h2 className="text-2xl font-bold mb-1">{source.badge}</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-3">
          Confidence: <span className="font-medium">{source.confidence}%</span>
        </p>
        
        {/* AI vs Human Progress Bar */}
        <div className="max-w-md mx-auto">
          <div className="flex justify-between text-sm mb-1">
            <span>Human-Written</span>
            <span>AI-Generated</span>
          </div>
          <motion.div className="relative h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: "50%" }}
              animate={{ width: `${source.probability}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-emerald-400 to-rose-500 rounded-full"
            />
            {isAnimating && (
              <motion.div 
                className="absolute top-0 left-0 h-full w-full bg-white/30 dark:bg-white/10"
                animate={{ 
                  x: ["0%", "100%", "0%"],
                  opacity: [0.3, 0.6, 0.3]
                }}
                transition={{ 
                  duration: 2,
                  ease: "easeInOut",
                  repeat: Infinity
                }}
              />
            )}
          </motion.div>
          <div className="flex justify-between text-xs mt-1 text-gray-500 dark:text-gray-400">
            <span>{100 - source.probability}%</span>
            <span>{source.probability}%</span>
          </div>
        </div>
      </div>
      
      {/* Categories Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.map((category, index) => (
          <Card key={index} className="p-4 border border-gray-200 dark:border-gray-800">
            <div className="flex items-center mb-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${category.color}`}>
                {renderIcon(category.iconName)}
              </div>
              <h3 className="ml-2 font-medium">{category.name}</h3>
            </div>
            <div className="mt-2">
              <div className="flex justify-between text-xs mb-1">
                <span>Low</span>
                <span>High</span>
              </div>
              <Progress value={category.value} className="h-2" />
            </div>
            <p className="text-xs mt-2 text-gray-600 dark:text-gray-300">{category.description}</p>
          </Card>
        ))}
      </div>
      
      {/* Detailed Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center mb-2">
            <AlignLeft className="h-4 w-4 mr-2 text-purple-500" />
            <h4 className="font-medium">Language Style</h4>
          </div>
          <p className="text-sm">{languageStyle}</p>
        </div>
        <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center mb-2">
            <MessageSquare className="h-4 w-4 mr-2 text-blue-500" />
            <h4 className="font-medium">Emotional Tone</h4>
          </div>
          <p className="text-sm">{emotionalTone}</p>
        </div>
        <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center mb-2">
            <FileText className="h-4 w-4 mr-2 text-emerald-500" />
            <h4 className="font-medium">Content Type</h4>
          </div>
          <p className="text-sm">{contentType}</p>
        </div>
        <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center mb-2">
            <Zap className="h-4 w-4 mr-2 text-amber-500" />
            <h4 className="font-medium">Grammar Quality</h4>
          </div>
          <div className="mt-1">
            <Progress value={grammarQuality} className="h-2" />
          </div>
        </div>
      </div>
      
      {/* Improvement Suggestions */}
      {suggestedEdits.length > 0 && (
        <div className="border rounded-lg p-4">
          <h3 className="font-semibold mb-3 flex items-center">
            <span className="mr-2">📝</span> Content Improvement Suggestions
          </h3>
          <ul className="space-y-2 text-sm">
            {suggestedEdits.map((edit, index) => (
              <li key={index} className="flex items-start">
                <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                <span>{edit}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* AI Patterns */}
      {aiPatterns.length > 0 && (
        <div className="border rounded-lg p-4">
          <h3 className="font-semibold mb-3 flex items-center">
            <span className="mr-2">🔍</span> Detected AI Patterns
          </h3>
          <ul className="space-y-1 text-sm">
            {aiPatterns.map((pattern, index) => (
              <li key={index} className="flex items-start">
                <span className="mr-2 text-rose-600 dark:text-rose-400">•</span>
                <span>{pattern}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </motion.div>
  );
};

export default ResultDisplay;
