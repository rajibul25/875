
import { cn } from "@/lib/utils";

interface AdBannerProps {
  className?: string;
  size?: "standard" | "large" | "small";
  type?: "horizontal" | "vertical" | "square";
}

const AdBanner = ({ 
  className = "", 
  size = "standard",
  type = "horizontal"
}: AdBannerProps) => {
  const getSizeClasses = () => {
    switch (size) {
      case "large":
        return type === "horizontal" ? "min-h-32" : "min-h-64";
      case "small":
        return "min-h-16";
      default:
        return "min-h-24";
    }
  };

  const getTypeClasses = () => {
    switch (type) {
      case "vertical":
        return "max-w-xs";
      case "square":
        return "max-w-sm aspect-square";
      default:
        return "w-full";
    }
  };

  return (
    <div className={cn(
      "bg-gray-100 rounded-md p-4 flex items-center justify-center border border-gray-200",
      getSizeClasses(),
      getTypeClasses(),
      className
    )}>
      <div className="text-center">
        <p className="text-gray-500 font-medium">Advertisement</p>
        <p className="text-gray-400 text-xs mt-1">Your ad could be here</p>
      </div>
    </div>
  );
};

export default AdBanner;
