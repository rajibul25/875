
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { AlertTriangle } from "lucide-react";

interface MaintenanceMessageProps {
  toolName: string;
}

const MaintenanceMessage: React.FC<MaintenanceMessageProps> = ({ toolName }) => {
  return (
    <Card className="w-full max-w-3xl mx-auto my-8 border-amber-200">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl text-center">{toolName}</CardTitle>
      </CardHeader>
      <CardContent>
        <Alert className="bg-amber-50 border-amber-200">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <AlertTitle className="text-amber-800 mb-2">Tool Under Maintenance</AlertTitle>
          <AlertDescription className="text-amber-700">
            This tool is currently under maintenance. We are working to restore full functionality. 
            Thank you for your patience.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};

export default MaintenanceMessage;
