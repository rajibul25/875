
import { useState, useCallback, useEffect, useMemo } from "react";
import { CommandDialog, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from "@/components/ui/command";
import { useNavigate } from "react-router-dom";
import { Tool } from "@/lib/tool-model";
import * as allToolCategories from "@/lib/tool-categories";

interface ToolSearchDialogProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

// Helper to flatten tools once
const flattenAllTools = () => {
  const allTools = Object.values(allToolCategories).filter(Array.isArray);
  return allTools.flat() as Tool[];
};

// Highlight matched text with <mark>
function highlightMatch(text: string, query: string) {
  if (!query) return text;
  const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, "gi");
  return text.split(regex).map((part, idx) =>
    regex.test(part) ?
      <mark key={idx} className="bg-yellow-200 dark:bg-yellow-800 rounded">{part}</mark> :
      part
  );
}

const ToolSearchDialog = ({ open, setOpen }: ToolSearchDialogProps) => {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const allTools = useMemo(() => flattenAllTools(), []);

  // Reset query when dialog opens
  useEffect(() => {
    if (open) {
      setQuery("");
    }
  }, [open]);

  // Build filtered tool list to display
  const filteredTools = useMemo(() => {
    if (!query.trim()) return allTools;

    const lowerQuery = query.toLowerCase();

    return allTools.filter(tool => {
      // Priority match for loan or emi related queries
      if ((lowerQuery.includes('loan') || lowerQuery.includes('emi')) 
        && (tool.id?.toLowerCase().includes('loan') || tool.title.toLowerCase().includes('loan')
          || tool.id?.toLowerCase().includes('emi') || tool.title.toLowerCase().includes('emi')
        )) {
        return true;
      }

      // Check includes in titles, descriptions, or ids
      return (
        tool.title.toLowerCase().includes(lowerQuery) ||
        (tool.description?.toLowerCase().includes(lowerQuery)) ||
        (tool.id?.toLowerCase().includes(lowerQuery))
      );
    });
  }, [allTools, query]);

  // Group tools by category for display
  const groupedTools = useMemo(() => {
    const grouped: Record<string, Tool[]> = {};
    filteredTools.forEach(tool => {
      const key = tool.category?.toLowerCase() || "other";
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(tool);
    });
    return grouped;
  }, [filteredTools]);

  const handleSelect = useCallback((tool: Tool) => {
    setOpen(false);
    if (tool.path.startsWith("http")) {
      window.open(tool.path, "_blank");
    } else {
      navigate(tool.path);
    }
  }, [navigate, setOpen]);

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput
        placeholder="Search tools by name or description..."
        autoFocus
        value={query}
        onValueChange={setQuery}
        aria-label="Search tools"
      />
      <CommandList>
        <CommandEmpty>No matching tools found.</CommandEmpty>
        {Object.keys(groupedTools).map(category =>
          groupedTools[category]?.length > 0 ? (
            <CommandGroup key={category} heading={category}>
              {groupedTools[category].map(tool => (
                <CommandItem 
                  key={tool.id}
                  onSelect={() => handleSelect(tool)}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  {tool.icon && <span className="text-tool-purple w-5 h-5">{tool.icon}</span>}
                  <span className="flex flex-col">
                    <span className="font-medium">
                      {highlightMatch(tool.title, query)}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {highlightMatch(tool.description ?? "", query)}
                    </span>
                  </span>
                  {tool.isNew && (
                    <span className="ml-2 px-2 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/60 dark:text-green-200 text-xs">
                      New
                    </span>
                  )}
                  {tool.isPopular && !tool.isNew && (
                    <span className="ml-2 px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/60 dark:text-purple-200 text-xs">
                      Popular
                    </span>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
          ) : null
        )}
      </CommandList>
    </CommandDialog>
  );
};

export default ToolSearchDialog;

