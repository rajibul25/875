
import React, { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

// Util functions to get/set theme
function getPreferredTheme() {
  if (typeof window === "undefined") return "light";
  const stored = localStorage.getItem("theme");
  if (stored === "dark" || stored === "light") return stored;
  // Default to light on first visit
  return "light";
}

function setTheme(theme: "light" | "dark") {
  if (typeof window === "undefined") return;
  localStorage.setItem("theme", theme);
  const root = window.document.documentElement;
  if (theme === "dark") {
    root.classList.add("dark");
  } else {
    root.classList.remove("dark");
  }
}

export default function ThemeToggle() {
  const [theme, setThemeState] = useState<"light" | "dark">(getPreferredTheme());

  // On mount: Apply user's theme preference
  useEffect(() => {
    setTheme(theme);
  }, [theme]);

  // On mount: sync with system or localStorage
  useEffect(() => {
    setThemeState(getPreferredTheme());
  }, []);

  function toggleTheme() {
    setThemeState(prev => (prev === "light" ? "dark" : "light"));
  }

  return (
    <button
      onClick={toggleTheme}
      aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
      className="inline-flex items-center px-3 py-2 rounded-full border border-border bg-background hover:bg-muted transition-colors"
      style={{ position: "absolute", top: 16, right: 16, zIndex: 20 }}
    >
      {theme === "light" ? (
        <Sun className="h-5 w-5 text-yellow-500" />
      ) : (
        <Moon className="h-5 w-5 text-purple-400" />
      )}
      <span className="ml-2 text-sm hidden md:inline">
        {theme === "light" ? "Light" : "Dark"}
      </span>
    </button>
  );
}
