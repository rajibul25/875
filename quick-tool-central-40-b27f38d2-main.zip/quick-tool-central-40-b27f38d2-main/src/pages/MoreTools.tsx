
import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SearchBar from "@/components/SearchBar";
import ChatBot from "@/components/ChatBot";
import AdBanner from "@/components/AdBanner";
import ToolSection from "@/components/ToolSection";
import ToolCard from "@/components/ToolCard";

// Import all tool category arrays directly
import { 
  conversionTools,
  dataTools,
  developerTools,
  contentTools,
  aiTools,
  visualTools,
  healthTools,
  securityTools,
  seoTools
} from "@/lib/tool-categories";

// Helper function for fuzzy search (simple implementation)
function fuzzyMatch(str: string, query: string) {
  str = str.toLowerCase();
  query = query.toLowerCase();
  if (str.includes(query)) return true;

  // Fuzzy tolerance — ignore extra spaces, partial words, etc
  const safeQuery = query.replace(/[^a-z0-9]/gi, "");
  const safeStr = str.replace(/[^a-z0-9]/gi, "");
  if (safeStr.includes(safeQuery)) return true;

  // Simple word-level match
  const words = safeQuery.split(" ");
  return words.every(w => safeStr.includes(w));
}

const filterTools = (toolsArr: any[], query: string) => {
  if (!query.trim()) return toolsArr;
  return toolsArr.filter(
    tool =>
      fuzzyMatch(tool.title, query) ||
      (tool.description && fuzzyMatch(tool.description, query)) ||
      (tool.category && fuzzyMatch(tool.category, query))
  );
};

const MoreTools = () => {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Filter tools for each category, memoized so it recalculates only on query change
  const filtered = useMemo(() => ({
    conversion: filterTools(conversionTools, searchQuery),
    data: filterTools(dataTools, searchQuery),
    developer: filterTools(developerTools, searchQuery),
    content: filterTools(contentTools, searchQuery),
    ai: filterTools(aiTools, searchQuery),
    visual: filterTools(visualTools, searchQuery),
    health: filterTools(healthTools, searchQuery),
    security: filterTools(securityTools, searchQuery),
    seo: filterTools(seoTools, searchQuery),
  }), [searchQuery]);

  // For "No Results" message logic:
  const hasAnyResults = Object.values(filtered).some(arr => arr.length > 0);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="max-w-3xl mx-auto mb-8">
          <h1 className="text-4xl font-bold text-center mb-4 text-gradient-blue-purple-pink">All Tools Collection</h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 text-center mb-8">
            Browse our extensive collection of 150+ online tools to help you with your daily tasks.
          </p>
          <div className="max-w-3xl mx-auto transform hover:scale-[1.01] transition-transform duration-300 mb-6">
            <SearchBar 
              placeholder="Search for tools..." 
              onSearch={handleSearch} 
            />
          </div>
        </div>

        {searchQuery && (
          <div className="text-center py-4">
            <h2 className="text-xl font-medium mb-2">Showing results for "{searchQuery}"</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Clear search to see all categories.
            </p>
          </div>
        )}

        {!hasAnyResults && searchQuery && (
          <div className="text-center py-8">
            <h2 className="text-xl font-medium mb-2">No tools found for "{searchQuery}"</h2>
            <p className="text-gray-600 dark:text-gray-300">
              Try searching with different keywords or browse our categories below.
            </p>
          </div>
        )}

        <motion.div 
          className="space-y-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {/* Conversion Tools */}
          {filtered.conversion.length > 0 && (
            <ToolSection title="Conversion Tools">
              {filtered.conversion.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Data & Analytics */}
          {filtered.data.length > 0 && (
            <ToolSection title="Data & Analytics Tools">
              {filtered.data.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Developer Tools */}
          {filtered.developer.length > 0 && (
            <ToolSection title="Developer Tools">
              {filtered.developer.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Content Creation */}
          {filtered.content.length > 0 && (
            <ToolSection title="Content Creation Tools">
              {filtered.content.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* AI & Visual */}
          {filtered.ai.length > 0 && (
            <ToolSection title="AI-Powered Tools">
              {filtered.ai.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {filtered.visual.length > 0 && (
            <ToolSection title="Visual & Media Tools">
              {filtered.visual.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Health Tools */}
          {filtered.health.length > 0 && (
            <ToolSection title="Health & Wellness Tools">
              {filtered.health.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Security */}
          {filtered.security.length > 0 && (
            <ToolSection title="Security & Encryption Tools">
              {filtered.security.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* SEO */}
          {filtered.seo.length > 0 && (
            <ToolSection title="SEO Tools">
              {filtered.seo.map(tool => (
                <ToolCard
                  key={tool.id}
                  icon={tool.icon}
                  title={tool.title}
                  link={tool.path}
                  description={tool.description}
                  isNew={tool.isNew}
                  isPopular={tool.isPopular}
                  isPremium={tool.isPremium}
                  bgColor={tool.bgColor}
                />
              ))}
            </ToolSection>
          )}
          {/* Ad and Chatbot always visible */}
          <AdBanner className="my-8" size="large" />
        </motion.div>
        
        {searchQuery && !hasAnyResults && (
          <div className="mt-12 text-center">
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Looking for a specific tool? Let us know if you couldn't find what you need.
            </p>
            <Link 
              to="/contact" 
              className="text-tool-purple hover:text-tool-blue font-medium transition-colors"
            >
              Request a new tool &rarr;
            </Link>
          </div>
        )}
      </main>
      <Footer />
      <ChatBot />
    </div>
  );
};

export default MoreTools;

