
const Legal = () => {
  return (
    <div className="container mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-6">Legal Information</h1>
      
      <div className="space-y-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Terms of Service</h2>
          <p className="text-gray-700 mb-4">
            By using the MultiToolSet website and its services, you agree to comply with and be bound by the following terms and conditions of use.
          </p>
          <p className="text-gray-700 mb-4">
            Our tools are provided "as is" without any warranties, expressed or implied. MultiToolSet does not warrant that the website will be error-free or uninterrupted.
          </p>
          <p className="text-gray-700">
            You agree to use the tools and services for lawful purposes only and in a way that does not infringe the rights of, restrict, or inhibit anyone else's use and enjoyment of the website.
          </p>
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4">Privacy Policy</h2>
          <p className="text-gray-700 mb-4">
            MultiToolSet is committed to protecting your privacy. We collect minimal information necessary to provide and improve our services.
          </p>
          <p className="text-gray-700 mb-4">
            The files you upload for processing are not stored permanently on our servers. They are automatically deleted after processing or within a maximum of 24 hours.
          </p>
          <p className="text-gray-700 mb-4">
            We use cookies to enhance your experience, analyze site usage, and assist in our marketing efforts.
          </p>
          <p className="text-gray-700">
            We may collect anonymous usage data to improve our tools and services. This information does not identify individual users.
          </p>
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4">Copyright Information</h2>
          <p className="text-gray-700 mb-4">
            All content on this website, including text, graphics, logos, images, and software, is the property of MultiToolSet and is protected by copyright laws.
          </p>
          <p className="text-gray-700">
            You may not reproduce, distribute, modify, or create derivative works from any content on this website without explicit permission from MultiToolSet.
          </p>
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-gray-700 mb-4">
            If you have any questions about our legal terms, please contact us at:
          </p>
          <p className="text-gray-700">
            Email: legal@multitoolset.co
          </p>
        </section>
      </div>
    </div>
  );
};

export default Legal;
