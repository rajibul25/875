
import React from "react";
import { Helmet } from "react-helmet";
import BackButton from "../components/BackButton";
import AllToolsMenu from "../components/AllToolsMenu";

export default function Tools() {
  return (
    <div className="min-h-screen bg-gradient-to-tr from-tool-blue/40 via-tool-purple/30 to-tool-pink/30 transition-all">
      <Helmet>
        <title>All Tools - MultiToolSet</title>
        <meta
          name="description"
          content="Explore our comprehensive collection of free online tools for various tasks and needs."
        />
      </Helmet>
      <AllToolsMenu />
      <div className="container mx-auto px-4 pb-14">
        <div className="mb-8 flex justify-between items-center">
          <h1 className="text-4xl font-black bg-gradient-to-r from-tool-purple via-tool-blue to-tool-pink text-transparent bg-clip-text tracking-tight drop-shadow">All Tools & Utilities</h1>
          <BackButton />
        </div>
        <div className="text-center text-lg text-gray-600 dark:text-gray-400 mb-7">
          Browse every category below. Click a section to view all tools instantly!
        </div>
      </div>
    </div>
  );
}
