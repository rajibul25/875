
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { FileX, Home, ArrowLeft, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  // Extract the tool name from the URL if it's a tool path
  const getToolNameFromPath = () => {
    const path = location.pathname;
    if (path.startsWith('/tools/')) {
      const toolPath = path.replace('/tools/', '');
      // Convert kebab-case to Title Case
      return toolPath
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }
    return null;
  };

  const toolName = getToolNameFromPath();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <div className="text-center max-w-md mx-auto p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md">
        <div className="flex justify-center mb-4">
          <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-full">
            <FileX className="h-12 w-12 text-red-500 dark:text-red-400" />
          </div>
        </div>
        <h1 className="text-4xl font-bold mb-4 text-gray-800 dark:text-gray-100">
          {toolName ? `${toolName} Not Found` : "Page Not Found"}
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">
          {toolName 
            ? `The ${toolName.toLowerCase()} tool you're looking for doesn't seem to exist or may have been moved.`
            : "The page you're looking for doesn't seem to exist or may have been moved."
          }
        </p>
        
        {toolName && (
          <div className="mb-6">
            <p className="text-gray-600 dark:text-gray-300 mb-3">Try one of these health and wellness tools instead:</p>
            <div className="grid grid-cols-2 gap-2 text-left">
              <Link to="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400 py-1">BMI Calculator</Link>
              <Link to="/tools/bmr-calculator" className="text-blue-600 hover:underline dark:text-blue-400 py-1">BMR Calculator</Link>
              <Link to="/tools/heart-rate-calculator" className="text-blue-600 hover:underline dark:text-blue-400 py-1">Heart Rate Calculator</Link>
              <Link to="/tools/workout-planner" className="text-blue-600 hover:underline dark:text-blue-400 py-1">Workout Planner</Link>
              <Link to="/tools/blood-pressure-log" className="text-blue-600 hover:underline dark:text-blue-400 py-1">Blood Pressure Log</Link>
              <Link to="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400 py-1">Calorie Counter</Link>
            </div>
          </div>
        )}
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg flex items-center justify-center gap-2"
            onClick={() => window.history.back()}
          >
            <ArrowLeft className="h-4 w-4" />
            Go Back
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg flex items-center justify-center gap-2"
            asChild
          >
            <Link to="/">
              <Home className="h-4 w-4" />
              Return to Home
            </Link>
          </Button>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
          <Link 
            to="/tools" 
            className="text-purple-600 dark:text-purple-400 hover:underline flex items-center justify-center gap-2 font-medium"
          >
            <Search className="h-4 w-4" />
            Browse All Tools
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
