
import { useState } from "react";
import { PlusCircle, Trash2, BarChart3, Save, Download, Upload, Calculator, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import ToolLayout from "@/components/tools/ToolLayout";

interface GradeItem {
  id: string;
  name: string;
  grade: string;
  weight: string;
  weightedGrade: number;
}

const GradeCalculator = () => {
  const [items, setItems] = useState<GradeItem[]>([
    { id: "1", name: "Midterm Exam", grade: "85", weight: "25", weightedGrade: 21.25 },
    { id: "2", name: "Final Exam", grade: "92", weight: "30", weightedGrade: 27.6 },
    { id: "3", name: "Assignment 1", grade: "78", weight: "10", weightedGrade: 7.8 },
    { id: "4", name: "Assignment 2", grade: "88", weight: "10", weightedGrade: 8.8 },
    { id: "5", name: "Project", grade: "90", weight: "15", weightedGrade: 13.5 },
    { id: "6", name: "Participation", grade: "95", weight: "10", weightedGrade: 9.5 },
  ]);
  
  const [newItem, setNewItem] = useState<{ name: string; grade: string; weight: string }>({
    name: "",
    grade: "",
    weight: "",
  });
  
  const [targetGrade, setTargetGrade] = useState<string>("90");
  const [missingAssignment, setMissingAssignment] = useState<{
    name: string;
    weight: string;
  }>({
    name: "Final Project",
    weight: "20",
  });
  
  const [courseTitle, setCourseTitle] = useState<string>("Course Name");
  
  const { toast } = useToast();
  
  const addItem = () => {
    if (newItem.name && newItem.grade && newItem.weight) {
      const grade = parseFloat(newItem.grade);
      const weight = parseFloat(newItem.weight);
      
      if (isNaN(grade) || grade < 0 || grade > 100) {
        toast({
          variant: "destructive",
          title: "Invalid grade",
          description: "Please enter a grade between 0 and 100."
        });
        return;
      }
      
      if (isNaN(weight) || weight <= 0) {
        toast({
          variant: "destructive",
          title: "Invalid weight",
          description: "Please enter a weight greater than 0."
        });
        return;
      }
      
      const totalWeight = getTotalWeight() + weight;
      if (totalWeight > 100) {
        toast({
          variant: "destructive",
          title: "Weight exceeds 100%",
          description: "The total weight of all items cannot exceed 100%."
        });
        return;
      }
      
      const newId = (items.length + 1).toString();
      const weightedGrade = (grade * weight) / 100;
      
      setItems([
        ...items,
        { 
          id: newId, 
          name: newItem.name, 
          grade: newItem.grade, 
          weight: newItem.weight,
          weightedGrade
        },
      ]);
      
      setNewItem({ name: "", grade: "", weight: "" });
      
      toast({
        title: "Item added",
        description: `${newItem.name} has been added to your grade calculations.`
      });
    } else {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please fill in all fields for the new grade item."
      });
    }
  };
  
  const removeItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
    toast({
      title: "Item removed",
      description: "The grade item has been removed from your calculations."
    });
  };
  
  const getTotalWeight = () => {
    return items.reduce((sum, item) => sum + parseFloat(item.weight), 0);
  };
  
  const getCurrentGrade = () => {
    if (items.length === 0) return 0;
    
    const totalWeightedGrade = items.reduce((sum, item) => {
      const grade = parseFloat(item.grade);
      const weight = parseFloat(item.weight);
      
      if (!isNaN(grade) && !isNaN(weight)) {
        return sum + (grade * weight) / 100;
      }
      
      return sum;
    }, 0);
    
    const totalWeight = getTotalWeight();
    
    if (totalWeight === 0) return 0;
    
    return (totalWeightedGrade * 100) / totalWeight;
  };
  
  const calculateNeededGrade = () => {
    const currentTotalWeight = getTotalWeight();
    const remainingWeight = 100 - currentTotalWeight;
    const missingWeight = parseFloat(missingAssignment.weight);
    
    if (missingWeight <= 0 || missingWeight > remainingWeight) {
      return "Invalid weight";
    }
    
    const target = parseFloat(targetGrade);
    if (isNaN(target)) {
      return "Invalid target";
    }
    
    const currentWeightedScore = getCurrentGrade() * (currentTotalWeight / 100);
    const neededWeightedScore = target - currentWeightedScore;
    const neededScore = (neededWeightedScore * 100) / missingWeight;
    
    if (neededScore < 0) {
      return "You've already exceeded your target grade!";
    }
    
    if (neededScore > 100) {
      return "Impossible to achieve target grade";
    }
    
    return neededScore.toFixed(2) + "%";
  };
  
  const getGradeColor = (grade: number) => {
    if (grade >= 90) return "text-green-600 dark:text-green-400";
    if (grade >= 80) return "text-emerald-600 dark:text-emerald-400";
    if (grade >= 70) return "text-yellow-600 dark:text-yellow-400";
    if (grade >= 60) return "text-orange-600 dark:text-orange-400";
    return "text-red-600 dark:text-red-400";
  };
  
  const getLetterGrade = (grade: number) => {
    if (grade >= 90) return "A";
    if (grade >= 80) return "B";
    if (grade >= 70) return "C";
    if (grade >= 60) return "D";
    return "F";
  };
  
  const currentGrade = getCurrentGrade();
  const letterGrade = getLetterGrade(currentGrade);
  const gradeColor = getGradeColor(currentGrade);
  const gradeNeeded = calculateNeededGrade();
  const totalWeight = getTotalWeight();
  
  const exportGrades = () => {
    const dataToExport = {
      courseTitle,
      items,
      targetGrade,
      missingAssignment,
    };
    
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${courseTitle.replace(/\s+/g, "-")}-grades.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Grades exported",
      description: "Your grade calculations have been exported as a JSON file."
    });
  };
  
  const importGrades = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.courseTitle && data.items && data.targetGrade && data.missingAssignment) {
          setCourseTitle(data.courseTitle);
          setItems(data.items);
          setTargetGrade(data.targetGrade);
          setMissingAssignment(data.missingAssignment);
          
          toast({
            title: "Grades imported",
            description: "Your grade calculations have been imported successfully."
          });
        } else {
          toast({
            variant: "destructive",
            title: "Invalid file format",
            description: "The file does not contain valid grade data."
          });
        }
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error importing file",
          description: "There was an error reading the file."
        });
      }
    };
    reader.readAsText(file);
    
    // Reset the input
    event.target.value = "";
  };
  
  return (
    <ToolLayout
      title="Grade Calculator"
      description="Calculate your current and potential grades with this weighted grade calculator"
      helpText="Enter your assignments, grades, and their weights to calculate your current grade. You can also see what grade you need on future assignments to reach your target grade."
    >
      <div className="space-y-6">
        <Card className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <div>
              <h3 className="text-xl font-bold">Current Grade Summary</h3>
              <div className="text-gray-600 dark:text-gray-400">
                <input 
                  type="text" 
                  value={courseTitle} 
                  onChange={(e) => setCourseTitle(e.target.value)} 
                  className="bg-transparent border-b border-gray-300 dark:border-gray-600 px-1 py-0 outline-none focus:border-primary w-48"
                />
              </div>
            </div>
            <div className="flex space-x-2 mt-4 sm:mt-0">
              <Button variant="outline" size="sm" className="gap-2" onClick={exportGrades}>
                <Download className="h-4 w-4" />
                Export
              </Button>
              <div className="relative">
                <Button variant="outline" size="sm" className="gap-2">
                  <Upload className="h-4 w-4" />
                  Import
                </Button>
                <input 
                  type="file" 
                  accept=".json"
                  onChange={importGrades}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-center">
              <div className="text-gray-500 dark:text-gray-400 text-sm mb-1">Current Grade</div>
              <div className={`text-3xl font-bold ${gradeColor}`}>
                {isNaN(currentGrade) ? "N/A" : currentGrade.toFixed(2) + "%"}
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-center">
              <div className="text-gray-500 dark:text-gray-400 text-sm mb-1">Letter Grade</div>
              <div className={`text-3xl font-bold ${gradeColor}`}>
                {isNaN(currentGrade) ? "N/A" : letterGrade}
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-center">
              <div className="text-gray-500 dark:text-gray-400 text-sm mb-1">Total Weight</div>
              <div className={`text-3xl font-bold ${totalWeight === 100 ? "text-green-600" : "text-orange-500"}`}>
                {totalWeight}%
              </div>
            </div>
          </div>
          
          <div className="pb-4">
            <Progress value={totalWeight} className="h-2" />
          </div>
          
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Assignment</TableHead>
                  <TableHead className="text-right">Grade (%)</TableHead>
                  <TableHead className="text-right">Weight (%)</TableHead>
                  <TableHead className="text-right">Weighted Grade</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.name}</TableCell>
                    <TableCell className="text-right">{item.grade}%</TableCell>
                    <TableCell className="text-right">{item.weight}%</TableCell>
                    <TableCell className="text-right">{item.weightedGrade.toFixed(2)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItem(item.id)}
                      >
                        <Trash2 className="h-4 w-4 text-gray-500 hover:text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="pt-6 border-t mt-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="name">Assignment Name</Label>
                <Input
                  id="name"
                  placeholder="Quiz, Homework, etc."
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="grade">Grade (%)</Label>
                <Input
                  id="grade"
                  type="number"
                  min="0"
                  max="100"
                  placeholder="0-100"
                  value={newItem.grade}
                  onChange={(e) => setNewItem({ ...newItem, grade: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="weight">Weight (%)</Label>
                <Input
                  id="weight"
                  type="number"
                  min="0"
                  max="100"
                  placeholder="0-100"
                  value={newItem.weight}
                  onChange={(e) => setNewItem({ ...newItem, weight: e.target.value })}
                />
              </div>
              <div className="flex items-end">
                <Button onClick={addItem} className="w-full gap-2">
                  <PlusCircle className="h-4 w-4" />
                  Add Item
                </Button>
              </div>
            </div>
          </div>
        </Card>
        
        <Card className="p-6">
          <h3 className="text-xl font-bold mb-6 flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" />
            Grade Needed Calculator
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="target-grade">Target Overall Grade (%)</Label>
                <Input
                  id="target-grade"
                  type="number"
                  min="0"
                  max="100"
                  placeholder="e.g., 90 for an A"
                  value={targetGrade}
                  onChange={(e) => setTargetGrade(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="missing-name">Missing Assignment Name</Label>
                <Input
                  id="missing-name"
                  placeholder="Final Project, Exam, etc."
                  value={missingAssignment.name}
                  onChange={(e) => setMissingAssignment({ ...missingAssignment, name: e.target.value })}
                />
              </div>
              
              <div>
                <Label htmlFor="missing-weight">Missing Assignment Weight (%)</Label>
                <Input
                  id="missing-weight"
                  type="number"
                  min="0"
                  max={100 - getTotalWeight()}
                  placeholder="Weight percentage"
                  value={missingAssignment.weight}
                  onChange={(e) => setMissingAssignment({ ...missingAssignment, weight: e.target.value })}
                />
                <p className="text-sm text-gray-500 mt-1">
                  Remaining weight available: {(100 - getTotalWeight()).toFixed(0)}%
                </p>
              </div>
              
              <Button className="gap-2">
                <Calculator className="h-4 w-4" />
                Calculate Needed Grade
              </Button>
            </div>
            
            <div className="md:col-span-2 bg-gray-50 dark:bg-gray-800 p-6 rounded-xl flex items-center">
              <div className="w-full space-y-4">
                <h4 className="text-lg font-medium text-center">
                  Grade Needed on {missingAssignment.name}
                </h4>
                
                <div className="text-5xl font-bold text-center text-primary">
                  {gradeNeeded}
                </div>
                
                <p className="text-center text-gray-600 dark:text-gray-400">
                  To achieve a {targetGrade}% overall grade, you need to score {gradeNeeded} on your {missingAssignment.name}, which is worth {missingAssignment.weight}% of your total grade.
                </p>
              </div>
            </div>
          </div>
        </Card>
        
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">How to Use the Grade Calculator</h2>
          <p className="mb-4">
            This grade calculator uses weighted averages to determine your current grade and what scores 
            you need on future assignments to reach your target grade.
          </p>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-medium">Understanding Weighted Grades</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Each assignment contributes to your final grade according to its weight. For example, 
                if an exam is worth 30% of your grade and you score 80%, it contributes 24 points (80% × 30%) 
                to your final grade.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Adding Assignments</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Enter the name, grade received, and weight percentage of each assignment. Click "Add Item" 
                to include it in your calculations.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Calculating Required Grades</h3>
              <p className="text-gray-600 dark:text-gray-400">
                To determine what grade you need on a future assignment, enter your target overall grade, 
                the assignment name, and its weight. The calculator will show what minimum score you need.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Saving Your Data</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Use the Export button to save your current grade calculations as a JSON file. You can later 
                Import this file to restore your data.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Common Grading Scales</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium mb-3">Standard Scale</h3>
              <div className="space-y-2">
                <div className="flex justify-between border-b pb-1">
                  <span>A</span>
                  <span className="font-medium">90-100%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>B</span>
                  <span className="font-medium">80-89%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>C</span>
                  <span className="font-medium">70-79%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>D</span>
                  <span className="font-medium">60-69%</span>
                </div>
                <div className="flex justify-between">
                  <span>F</span>
                  <span className="font-medium">0-59%</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-3">4.0 GPA Scale</h3>
              <div className="space-y-2">
                <div className="flex justify-between border-b pb-1">
                  <span>A (4.0)</span>
                  <span className="font-medium">93-100%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>A- (3.7)</span>
                  <span className="font-medium">90-92%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>B+ (3.3)</span>
                  <span className="font-medium">87-89%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>B (3.0)</span>
                  <span className="font-medium">83-86%</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span>B- (2.7)</span>
                  <span className="font-medium">80-82%</span>
                </div>
                <div className="flex justify-between">
                  <span>C+ (2.3)</span>
                  <span className="font-medium">77-79%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add schema markup for SEO
const SchemaMarkup = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Grade Calculator",
    "applicationCategory": "EducationalApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "All",
    "description": "Calculate weighted grades and determine what scores you need to reach your target grade with this free online tool."
  };

  return (
    <script type="application/ld+json">
      {JSON.stringify(schema)}
    </script>
  );
};

// Add meta tags for SEO
const SeoHead = () => {
  return (
    <>
      <title>Grade Calculator - Calculate Weighted Grades & Final Scores | MultiToolSet</title>
      <meta
        name="description"
        content="Calculate your current weighted grade and determine what scores you need on future assignments to reach your target grade with our free online grade calculator."
      />
      <meta
        name="keywords"
        content="grade calculator, weighted grade calculator, final grade calculator, GPA calculator, college grade calculator, academic grade calculator"
      />
      <link rel="canonical" href="https://multitoolset.co/tools/grade-calculator" />
    </>
  );
};

// Export with SEO components
const GradeCalculatorWithSeo = () => {
  return (
    <>
      <SeoHead />
      <SchemaMarkup />
      <GradeCalculator />
    </>
  );
};

export default GradeCalculatorWithSeo;
