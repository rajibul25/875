
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, Copy, RefreshCw, ExternalLink } from "lucide-react";
import { toast } from "sonner";

// Helper function to validate URL
const isValidURL = (url: string) => {
  try {
    const newUrl = new URL(url);
    return newUrl.protocol === 'http:' || newUrl.protocol === 'https:';
  } catch (e) {
    return false;
  }
};

// In a real implementation, this would connect to a backend service
// For demo purposes, we'll create a mock implementation
const URLShortener = () => {
  const [longUrl, setLongUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState("");

  const generateShortUrl = () => {
    // Reset states
    setError("");
    setShortUrl("");
    
    // Validate URL
    if (!longUrl.trim()) {
      setError("Please enter a URL");
      return;
    }
    
    if (!isValidURL(longUrl)) {
      setError("Please enter a valid URL with http:// or https://");
      return;
    }
    
    setIsProcessing(true);
    
    // In a real implementation, this would make an API call to a URL shortening service
    // For demo purposes, we'll just generate a random string
    
    // Simulating API call delay
    setTimeout(() => {
      const randomStr = Math.random().toString(36).substring(2, 8);
      const baseUrl = window.location.origin;
      const demoShortUrl = `${baseUrl}/s/${randomStr}`;
      
      setShortUrl(demoShortUrl);
      setIsProcessing(false);
      
      toast.success("URL shortened successfully!");
    }, 1000);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shortUrl);
      toast.success("Short URL copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy URL");
    }
  };

  const resetForm = () => {
    setLongUrl("");
    setShortUrl("");
    setError("");
  };

  return (
    <ToolLayout
      title="Free URL Shortener | Create Short Links Online"
      description="Shorten long URLs into compact, easy-to-share links with our free URL shortener. No registration required, instant link generation."
      helpText="Enter a long URL and click 'Shorten URL' to create a shortened link. Use the copy button to copy it to your clipboard."
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="longUrl">
                Long URL
              </label>
              <Input
                id="longUrl"
                type="url"
                value={longUrl}
                onChange={(e) => setLongUrl(e.target.value)}
                placeholder="Enter URL to shorten (e.g., https://example.com/very/long/url/that/needs/shortening)"
                className={`w-full ${error ? 'border-red-500' : ''}`}
              />
              {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>

            <div className="flex space-x-2">
              <Button 
                onClick={generateShortUrl}
                className="w-full"
                disabled={isProcessing || !longUrl.trim()}
              >
                <Link className="w-4 h-4 mr-2" />
                {isProcessing ? "Processing..." : "Shorten URL"}
              </Button>
              
              <Button 
                onClick={resetForm}
                variant="outline"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>

            {shortUrl && (
              <div className="mt-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Short URL
                  </label>
                  <div className="relative">
                    <Input
                      value={shortUrl}
                      readOnly
                      className="w-full pr-20 font-mono text-sm"
                    />
                    <div className="absolute right-1 top-1 flex space-x-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={copyToClipboard}
                        className="h-7"
                        title="Copy to clipboard"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <a
                        href={shortUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-center h-7 px-3 rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-background hover:bg-accent hover:text-accent-foreground h-7"
                        title="Open link"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Note: This is a demo implementation. In a production environment, this would connect to a URL shortening service.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-4">Benefits of URL Shortening</h2>
            <div className="prose dark:prose-invert max-w-none">
              <ul className="list-disc pl-5 space-y-2">
                <li>Makes links more manageable and easier to share</li>
                <li>Ideal for social media posts with character limits</li>
                <li>Cleaner appearance in messages and emails</li>
                <li>Easier to remember and type manually</li>
                <li>Can provide basic analytics on link usage (in premium versions)</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">How long do shortened URLs last?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  In a full implementation, shortened URLs typically remain valid indefinitely unless explicitly set with an expiration date or deleted.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Are shortened URLs secure?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Shortened URLs by themselves don't add or remove security. They simply redirect to the original URL. Always be cautious when clicking shortened links from unknown sources.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Can I customize the shortened URL?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  In a full implementation, premium URL shortening services typically offer custom aliases, allowing you to create branded and memorable short links.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolLayout>
  );
};

export default URLShortener;
