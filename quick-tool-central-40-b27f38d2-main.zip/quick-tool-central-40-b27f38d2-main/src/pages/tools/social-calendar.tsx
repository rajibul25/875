
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  Calendar as CalendarIcon, 
  Download, 
  Plus, 
  X, 
  Edit2,
  Trash2,
  ArrowLeft,
  ArrowRight,
  Clock,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Copy
} from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Type definitions
interface PostEvent {
  id: string;
  title: string;
  platform: string;
  date: string;
  time: string;
  content: string;
  hashtags: string;
  color: string;
}

// Platform colors
const platformColors: Record<string, string> = {
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500",
  facebook: "bg-gradient-to-r from-blue-600 to-blue-500",
  twitter: "bg-gradient-to-r from-blue-400 to-blue-300",
  linkedin: "bg-gradient-to-r from-blue-700 to-blue-600",
  tiktok: "bg-gradient-to-r from-black to-gray-800",
};

// Platform icons mapping
const PlatformIcon = ({ platform }: { platform: string }) => {
  switch(platform) {
    case 'instagram': return <Instagram className="h-5 w-5" />;
    case 'facebook': return <Facebook className="h-5 w-5" />;
    case 'twitter': return <Twitter className="h-5 w-5" />;
    case 'linkedin': return <Linkedin className="h-5 w-5" />;
    default: return <Instagram className="h-5 w-5" />;
  }
};

const SocialCalendar = () => {
  const { toast } = useToast();
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [events, setEvents] = useState<PostEvent[]>([]);
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [editingEvent, setEditingEvent] = useState<PostEvent | null>(null);
  const [newEvent, setNewEvent] = useState<Partial<PostEvent>>({
    title: "",
    platform: "instagram",
    date: "",
    time: "12:00",
    content: "",
    hashtags: "",
  });

  // Generate days for the current month
  const getDaysInMonth = (month: number, year: number) => {
    const date = new Date(year, month, 1);
    const days = [];
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }
    
    // Add days of the month
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    
    return days;
  };

  const calendarDays = getDaysInMonth(currentMonth, currentYear);

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const navigateMonth = (direction: number) => {
    if (direction === -1) {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    } else {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    }
  };

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.platform) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const event: PostEvent = {
      id: Date.now().toString(),
      title: newEvent.title || "",
      platform: newEvent.platform || "instagram",
      date: newEvent.date || "",
      time: newEvent.time || "12:00",
      content: newEvent.content || "",
      hashtags: newEvent.hashtags || "",
      color: platformColors[newEvent.platform || "instagram"] || platformColors.instagram,
    };

    if (editingEvent) {
      setEvents(events.map(e => e.id === editingEvent.id ? { ...event, id: editingEvent.id } : e));
      setEditingEvent(null);
      
      toast({
        title: "Event updated",
        description: `"${event.title}" has been updated.`,
      });
    } else {
      setEvents([...events, event]);
      
      toast({
        title: "Event added",
        description: `"${event.title}" has been added to your calendar.`,
      });
    }

    // Reset form
    setNewEvent({
      title: "",
      platform: "instagram",
      date: "",
      time: "12:00",
      content: "",
      hashtags: "",
    });
    
    setIsAddingEvent(false);
  };

  const handleEditEvent = (event: PostEvent) => {
    setEditingEvent(event);
    setNewEvent({
      title: event.title,
      platform: event.platform,
      date: event.date,
      time: event.time,
      content: event.content,
      hashtags: event.hashtags,
    });
    setIsAddingEvent(true);
  };

  const handleDeleteEvent = (id: string) => {
    setEvents(events.filter(event => event.id !== id));
    
    toast({
      title: "Event deleted",
      description: "The event has been removed from your calendar.",
    });
  };

  const getEventsForDate = (day: number | null) => {
    if (day === null) return [];
    
    const date = new Date(currentYear, currentMonth, day);
    const dateStr = date.toISOString().split('T')[0];
    
    return events.filter(event => event.date === dateStr);
  };

  const handleDownloadCalendar = () => {
    if (events.length === 0) {
      toast({
        title: "No events to download",
        description: "Add some events to your calendar first.",
        variant: "destructive",
      });
      return;
    }

    // Create CSV content
    let csvContent = "Date,Time,Platform,Title,Content,Hashtags\n";
    
    events.forEach(event => {
      // Format each field properly for CSV
      const formattedContent = event.content?.replace(/"/g, '""');
      const formattedHashtags = event.hashtags?.replace(/"/g, '""');
      
      csvContent += `"${event.date}","${event.time}","${event.platform}","${event.title}","${formattedContent}","${formattedHashtags}"\n`;
    });
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `social-calendar-${currentYear}-${currentMonth + 1}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Calendar downloaded",
      description: "Your social calendar has been downloaded as a CSV file.",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    
    toast({
      title: "Copied to clipboard",
      description: "Content has been copied to your clipboard.",
    });
  };

  return (
    <ToolLayout 
      title="Social Media Calendar"
      description="Plan and schedule your social media content with an easy-to-use calendar interface."
      helpText="Add posts for different platforms, organize by date, and export your content schedule."
    >
      <div className="space-y-8">
        {/* Calendar Header */}
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="icon"
              onClick={() => navigateMonth(-1)}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-xl font-bold">
              {monthNames[currentMonth]} {currentYear}
            </h2>
            <Button 
              variant="outline" 
              size="icon"
              onClick={() => navigateMonth(1)}
            >
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              variant="outline"
              onClick={handleDownloadCalendar}
            >
              <Download className="h-4 w-4 mr-2" />
              <span>Download</span>
            </Button>
            
            <Dialog open={isAddingEvent} onOpenChange={setIsAddingEvent}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  <span>Add Event</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>
                    {editingEvent ? "Edit Post" : "Schedule New Post"}
                  </DialogTitle>
                  <DialogDescription>
                    Fill in the details for your social media post.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="post-date">Post Date</Label>
                      <Input 
                        id="post-date" 
                        type="date" 
                        value={newEvent.date}
                        onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="post-time">Post Time</Label>
                      <Input 
                        id="post-time" 
                        type="time" 
                        value={newEvent.time}
                        onChange={(e) => setNewEvent({...newEvent, time: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select 
                      value={newEvent.platform} 
                      onValueChange={(value) => setNewEvent({...newEvent, platform: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="instagram">Instagram</SelectItem>
                        <SelectItem value="facebook">Facebook</SelectItem>
                        <SelectItem value="twitter">Twitter</SelectItem>
                        <SelectItem value="linkedin">LinkedIn</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-title">Post Title</Label>
                    <Input 
                      id="post-title" 
                      placeholder="Enter a title for your post" 
                      value={newEvent.title}
                      onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-content">Post Content</Label>
                    <Textarea 
                      id="post-content" 
                      placeholder="Write your post content here..."
                      rows={3}
                      value={newEvent.content}
                      onChange={(e) => setNewEvent({...newEvent, content: e.target.value})}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-hashtags">Hashtags</Label>
                    <Textarea 
                      id="post-hashtags" 
                      placeholder="#socialmedia #marketing"
                      rows={2}
                      value={newEvent.hashtags}
                      onChange={(e) => setNewEvent({...newEvent, hashtags: e.target.value})}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddingEvent(false)}>Cancel</Button>
                  <Button onClick={handleAddEvent}>{editingEvent ? "Update" : "Add"}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1">
          {/* Day headers */}
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day, i) => (
            <div key={i} className="p-2 text-center font-medium text-sm">
              {day}
            </div>
          ))}
          
          {/* Calendar cells */}
          {calendarDays.map((day, index) => {
            const dayEvents = getEventsForDate(day);
            
            return (
              <div
                key={index}
                className={`min-h-[120px] border rounded-lg p-2 ${
                  day ? "bg-white dark:bg-gray-800" : "bg-gray-50 dark:bg-gray-850"
                }`}
              >
                {day && (
                  <>
                    <div className="text-right font-medium text-sm mb-1">
                      {day}
                    </div>
                    <div className="space-y-1">
                      {dayEvents.map((event) => (
                        <div
                          key={event.id}
                          className={`${event.color} text-white p-1.5 rounded-md shadow-sm text-xs overflow-hidden cursor-pointer transition hover:shadow-md`}
                          onClick={() => handleEditEvent(event)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <PlatformIcon platform={event.platform} />
                              <Clock className="h-3 w-3 ml-1 mr-1" />
                              <span>{event.time}</span>
                            </div>
                          </div>
                          <div className="font-medium mt-1 truncate">
                            {event.title}
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Upcoming Posts Section */}
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Upcoming Posts</h2>
          
          {events.length > 0 ? (
            <div className="space-y-3">
              {events
                .sort((a, b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime())
                .slice(0, 5)
                .map((event) => (
                  <Card key={event.id} className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center">
                        <div className={`rounded-full p-1.5 mr-3 ${event.color.replace('bg-gradient-to-r', 'bg')}`}>
                          <PlatformIcon platform={event.platform} />
                        </div>
                        <div>
                          <h3 className="font-medium">{event.title}</h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {new Date(event.date).toLocaleDateString()} at {event.time}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleEditEvent(event)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleDeleteEvent(event.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {event.content && (
                      <div className="mt-2 text-sm text-gray-600 dark:text-gray-300 border-t pt-2">
                        <p className="line-clamp-2">{event.content}</p>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="mt-1 h-6 text-xs"
                          onClick={() => copyToClipboard(event.content)}
                        >
                          <Copy className="h-3 w-3 mr-1" /> Copy
                        </Button>
                      </div>
                    )}
                    
                    {event.hashtags && (
                      <div className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                        <span className="line-clamp-1">{event.hashtags}</span>
                      </div>
                    )}
                  </Card>
                ))}
            </div>
          ) : (
            <div className="text-center py-8 border rounded-lg bg-gray-50 dark:bg-gray-800">
              <CalendarIcon className="h-12 w-12 mx-auto text-gray-400" />
              <p className="mt-2 text-gray-500 dark:text-gray-400">
                No scheduled posts yet. Click "Add Event" to create your first post.
              </p>
            </div>
          )}
        </div>
        
        {/* How to Use Section */}
        <div className="mt-8 border-t pt-6">
          <h2 className="text-xl font-bold mb-4">How to Use This Tool</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-purple-100 dark:bg-purple-900/30 p-2 rounded-full mr-3">
                  <CalendarIcon className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <h3 className="font-medium">Schedule Posts</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Click "Add Event" to schedule a new post. Fill in the details including platform, date, time, and content.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-full mr-3">
                  <Edit2 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-medium">Manage Your Calendar</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Click on any event in the calendar to edit or delete it. Navigate between months to plan your content strategy.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-full mr-3">
                  <Download className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <h3 className="font-medium">Export Your Schedule</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Click "Download" to export your content calendar as a CSV file that you can open in any spreadsheet application.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-orange-100 dark:bg-orange-900/30 p-2 rounded-full mr-3">
                  <Copy className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <h3 className="font-medium">Copy Content</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Use the copy button to quickly copy post content and hashtags to your clipboard when it's time to post.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="mt-8 border-t pt-6">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-4">
              <h3 className="font-semibold text-lg mb-2">Can I import my existing content calendar?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Currently, manual entry is required. We plan to add import features for Google Calendar, Excel, and CSV files in a future update.
              </p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold text-lg mb-2">Will this tool automatically post to my social accounts?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                No, this is a planning tool only. For automatic posting, use the copy button to quickly transfer content to your preferred scheduling tool.
              </p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold text-lg mb-2">Is there a limit to how many posts I can schedule?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                The free version allows unlimited posts in the planner. Data is stored in your browser. For cloud storage, consider upgrading to our premium version.
              </p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold text-lg mb-2">Can I collaborate with my team?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Team collaboration features are coming soon. For now, you can export your calendar and share it with team members.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default SocialCalendar;
