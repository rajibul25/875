
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, Download, Star, Clock, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const HashtagGenerator = () => {
  const { toast } = useToast();
  const [keyword, setKeyword] = useState("");
  const [category, setCategory] = useState("general");
  const [generatedHashtags, setGeneratedHashtags] = useState<string[]>([]);
  const [savedSets, setSavedSets] = useState<{name: string, hashtags: string[]}[]>([]);
  const [loading, setLoading] = useState(false);

  // Categories for hashtag filtering
  const categories = [
    { value: "general", label: "General" },
    { value: "fashion", label: "Fashion" },
    { value: "food", label: "Food" },
    { value: "travel", label: "Travel" },
    { value: "fitness", label: "Fitness" },
    { value: "business", label: "Business" },
    { value: "technology", label: "Technology" },
    { value: "art", label: "Art" },
    { value: "beauty", label: "Beauty" },
  ];

  // Mock trending hashtags
  const trendingHashtags = {
    general: ["#trending", "#viral", "#popular", "#explore", "#follow"],
    fashion: ["#ootd", "#style", "#fashionista", "#trendy", "#outfitoftheday"],
    food: ["#foodie", "#delicious", "#tasty", "#foodporn", "#foodphotography"],
    travel: ["#wanderlust", "#travelgram", "#adventure", "#explore", "#vacation"],
    fitness: ["#fitness", "#workout", "#gym", "#fitfam", "#healthy"],
    business: ["#entrepreneur", "#business", "#success", "#motivation", "#startup"],
    technology: ["#tech", "#innovation", "#digital", "#programming", "#developer"],
    art: ["#artist", "#artwork", "#creative", "#design", "#illustration"],
    beauty: ["#beauty", "#makeup", "#skincare", "#glam", "#cosmetics"],
  };

  const generateHashtags = () => {
    if (!keyword.trim()) {
      toast({
        title: "Keyword required",
        description: "Please enter a keyword to generate hashtags.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    // Simulate API call with setTimeout
    setTimeout(() => {
      const selectedCategory = category as keyof typeof trendingHashtags;
      
      // Generate hashtags based on keyword and category
      const baseHashtags = trendingHashtags[selectedCategory] || trendingHashtags.general;
      const keywordHashtags = [
        `#${keyword.toLowerCase().replace(/\s+/g, '')}`,
        `#${keyword.toLowerCase().replace(/\s+/g, '')}2023`,
        `#${keyword.toLowerCase().replace(/\s+/g, '')}inspiration`,
      ];
      
      // Additional related hashtags
      const relatedWords = getRelatedWords(keyword);
      const relatedHashtags = relatedWords.map(word => `#${word.toLowerCase().replace(/\s+/g, '')}`);
      
      const allHashtags = [...new Set([...keywordHashtags, ...baseHashtags, ...relatedHashtags])];
      setGeneratedHashtags(allHashtags.slice(0, 25)); // Limit to 25 hashtags
      
      setLoading(false);
    }, 1000);
  };

  // Mock function to get related words
  const getRelatedWords = (word: string): string[] => {
    const relatedWordsMap: Record<string, string[]> = {
      "food": ["delicious", "yummy", "tasty", "recipe", "chef", "cooking", "foodlover"],
      "travel": ["adventure", "wanderlust", "vacation", "trip", "explore", "journey", "tourism"],
      "fitness": ["workout", "gym", "exercise", "health", "training", "fit", "muscle"],
      "fashion": ["style", "outfit", "clothes", "trendy", "model", "designer", "accessories"],
      "business": ["entrepreneur", "success", "startup", "marketing", "leadership", "company", "innovation"],
      // Add more mappings as needed
    };

    // If we have specific related words for this keyword, use them
    for (const key in relatedWordsMap) {
      if (word.toLowerCase().includes(key)) {
        return relatedWordsMap[key];
      }
    }
    
    // Default related words if no match is found
    return ["best", "top", "amazing", "awesome", "perfect", "love", "favorite", "great"];
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    
    toast({
      title: "Copied to clipboard!",
      description: "Hashtags have been copied to your clipboard.",
    });
  };

  const downloadHashtags = () => {
    if (generatedHashtags.length === 0) {
      toast({
        title: "No hashtags to download",
        description: "Generate hashtags first before downloading.",
        variant: "destructive",
      });
      return;
    }
    
    const hashtagText = generatedHashtags.join(' ');
    const blob = new Blob([hashtagText], { type: 'text/plain' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `hashtags-${keyword.replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Hashtags downloaded",
      description: "Your hashtags have been downloaded as a text file.",
    });
  };

  const saveHashtagSet = () => {
    if (generatedHashtags.length === 0) {
      toast({
        title: "No hashtags to save",
        description: "Generate hashtags first before saving a set.",
        variant: "destructive",
      });
      return;
    }
    
    const setName = `${category} - ${keyword}`;
    setSavedSets([...savedSets, { name: setName, hashtags: [...generatedHashtags] }]);
    
    toast({
      title: "Hashtag set saved",
      description: `Your hashtag set "${setName}" has been saved.`,
    });
  };

  return (
    <ToolLayout 
      title="Hashtag Generator"
      description="Generate relevant and trending hashtags to boost your social media reach."
      helpText="Enter a keyword and select a category to generate optimized hashtags for your posts."
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <div className="lg:col-span-1 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Enter Keyword</label>
              <Input 
                placeholder="Enter a topic (e.g., food, travel, fashion)"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={generateHashtags} 
              disabled={loading} 
              className="w-full"
            >
              {loading ? "Generating..." : "Generate Hashtags"}
            </Button>
          </div>
          
          {/* Trending Section */}
          <Card className="p-4">
            <div className="flex items-center mb-3">
              <TrendingUp className="w-5 h-5 text-red-500 mr-2" />
              <h3 className="font-semibold">Trending in {categories.find(c => c.value === category)?.label || 'General'}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {(trendingHashtags[category as keyof typeof trendingHashtags] || trendingHashtags.general).map((tag, idx) => (
                <Badge key={idx} variant="outline" className="cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700">
                  {tag}
                </Badge>
              ))}
            </div>
          </Card>
          
          {/* Recently Used */}
          <Card className="p-4">
            <div className="flex items-center mb-3">
              <Clock className="w-5 h-5 text-blue-500 mr-2" />
              <h3 className="font-semibold">Recently Used</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {["#recentlyused", "#lastweek", "#popular2023", "#trending"].map((tag, idx) => (
                <Badge key={idx} variant="outline" className="cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700">
                  {tag}
                </Badge>
              ))}
            </div>
          </Card>
        </div>
        
        {/* Results Panel */}
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="results">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="results">Generated Hashtags</TabsTrigger>
              <TabsTrigger value="saved">Saved Sets</TabsTrigger>
            </TabsList>
            
            <TabsContent value="results" className="space-y-4">
              {generatedHashtags.length > 0 ? (
                <div className="p-4 bg-white dark:bg-gray-800 border rounded-lg shadow-sm">
                  <div className="mb-4 flex flex-wrap gap-2">
                    {generatedHashtags.map((tag, idx) => (
                      <Badge 
                        key={idx} 
                        className="cursor-pointer hover:bg-purple-100 dark:hover:bg-purple-900"
                        onClick={() => copyToClipboard(tag)}
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex space-x-3 mt-4">
                    <Button 
                      onClick={() => copyToClipboard(generatedHashtags.join(' '))}
                      variant="outline" 
                      className="flex-1"
                    >
                      <Copy className="h-4 w-4 mr-2" /> Copy All
                    </Button>
                    <Button 
                      onClick={downloadHashtags}
                      variant="outline" 
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" /> Download
                    </Button>
                    <Button 
                      onClick={saveHashtagSet}
                      className="flex-1"
                    >
                      <Star className="h-4 w-4 mr-2" /> Save Set
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 border rounded-lg bg-gray-50 dark:bg-gray-800">
                  <p className="text-gray-500 dark:text-gray-400">
                    {loading ? "Generating hashtags..." : "Enter a keyword and generate hashtags to see results here."}
                  </p>
                </div>
              )}
              
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Hashtag Tips</h3>
                <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600 dark:text-gray-400">
                  <li>Use 5-10 relevant hashtags for optimal engagement</li>
                  <li>Mix popular and niche hashtags for better reach</li>
                  <li>Update your hashtag strategy regularly</li>
                  <li>Research competitors' hashtags for inspiration</li>
                  <li>Create a branded hashtag for your business</li>
                </ul>
              </Card>
            </TabsContent>
            
            <TabsContent value="saved">
              {savedSets.length > 0 ? (
                <div className="space-y-4">
                  {savedSets.map((set, idx) => (
                    <Card key={idx} className="p-4">
                      <h3 className="font-semibold mb-3">{set.name}</h3>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {set.hashtags.slice(0, 8).map((tag, i) => (
                          <Badge key={i} variant="outline">{tag}</Badge>
                        ))}
                        {set.hashtags.length > 8 && (
                          <Badge variant="outline">+{set.hashtags.length - 8} more</Badge>
                        )}
                      </div>
                      <Button 
                        onClick={() => copyToClipboard(set.hashtags.join(' '))}
                        variant="outline" 
                        size="sm"
                        className="w-full"
                      >
                        <Copy className="h-4 w-4 mr-2" /> Copy All
                      </Button>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 border rounded-lg bg-gray-50 dark:bg-gray-800">
                  <p className="text-gray-500 dark:text-gray-400">
                    You haven't saved any hashtag sets yet. Generate and save a set to see it here.
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          {/* How to Use */}
          <div>
            <h3 className="text-lg font-medium mb-3">How to Use This Tool</h3>
            <ol className="list-decimal pl-5 space-y-2 text-gray-700 dark:text-gray-300">
              <li>Enter a keyword related to your content</li>
              <li>Select the most relevant category</li>
              <li>Click "Generate Hashtags" to get suggestions</li>
              <li>Copy individual hashtags or the entire set</li>
              <li>Save sets for future use or download as a text file</li>
            </ol>
          </div>
        </div>
      </div>
      
      {/* FAQ Section */}
      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">How many hashtags should I use?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Instagram allows up to 30 hashtags per post, but studies show that 5-10 relevant hashtags provide optimal engagement without looking spammy.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Are trending hashtags always better?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Not always. While trending hashtags have more visibility, they also have more competition. Using a mix of trending and niche hashtags is often the best strategy.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">How often should I update my hashtags?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              It's recommended to refresh your hashtag strategy every few weeks to stay relevant and avoid being flagged as spam by the platforms.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Can I use the same hashtags for all platforms?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Each platform has different hashtag best practices. Instagram and TikTok benefit from many hashtags, while Twitter and LinkedIn perform better with just a few focused ones.
            </p>
          </Card>
        </div>
      </div>
    </ToolLayout>
  );
};

export default HashtagGenerator;
