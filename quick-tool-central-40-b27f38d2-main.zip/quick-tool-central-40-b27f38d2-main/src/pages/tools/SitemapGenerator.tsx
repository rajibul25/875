
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Copy, Download, Globe, AlertCircle, Info } from "lucide-react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import AdBanner from "@/components/AdBanner";

const SitemapGenerator = () => {
  const [url, setUrl] = useState("");
  const [isUrlValid, setIsUrlValid] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [sitemapXml, setSitemapXml] = useState("");
  const [sitemapType, setSitemapType] = useState("standard");
  const [changeFreq, setChangeFreq] = useState("weekly");
  const [priority, setPriority] = useState("0.7");
  const [includeDateModified, setIncludeDateModified] = useState(true);
  const [includeImages, setIncludeImages] = useState(false);
  const [urlList, setUrlList] = useState("");
  
  const validateUrl = (inputUrl: string) => {
    if (!inputUrl) return false;
    try {
      new URL(inputUrl);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputUrl = e.target.value;
    setUrl(inputUrl);
    setIsUrlValid(validateUrl(inputUrl));
  };

  const generateSitemap = () => {
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      try {
        const parsedUrl = new URL(url);
        const hostname = parsedUrl.hostname;
        const protocol = parsedUrl.protocol;
        
        let pages = [];
        
        if (urlList.trim()) {
          // Use provided URL list
          pages = urlList.split('\n')
            .map(line => line.trim())
            .filter(line => line && validateUrl(line));
        } else {
          // Generate sample pages for demo
          const demoPages = [
            "",
            "about",
            "contact",
            "blog",
            "blog/post-1",
            "blog/post-2",
            "services",
            "services/service-1",
            "services/service-2",
            "products",
            "products/product-1",
            "products/product-2",
            "faq",
            "terms",
            "privacy"
          ];
          
          pages = demoPages.map(page => `${protocol}//${hostname}/${page}`);
        }
        
        // Generate XML sitemap
        let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
        xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"';
        
        if (includeImages) {
          xml += ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"';
        }
        
        xml += '>\n';
        
        pages.forEach(pageUrl => {
          const now = new Date();
          const lastmod = now.toISOString().split('T')[0];
          
          xml += '  <url>\n';
          xml += `    <loc>${pageUrl}</loc>\n`;
          
          if (includeDateModified) {
            xml += `    <lastmod>${lastmod}</lastmod>\n`;
          }
          
          xml += `    <changefreq>${changeFreq}</changefreq>\n`;
          xml += `    <priority>${priority}</priority>\n`;
          
          if (includeImages && Math.random() > 0.5) {
            xml += '    <image:image>\n';
            xml += `      <image:loc>${pageUrl.replace(/\/$/, '')}/image.jpg</image:loc>\n`;
            xml += '      <image:title>Sample Image</image:title>\n';
            xml += '    </image:image>\n';
          }
          
          xml += '  </url>\n';
        });
        
        xml += '</urlset>';
        
        setSitemapXml(xml);
        setIsLoading(false);
        toast.success("Sitemap generated successfully!");
      } catch (error) {
        console.error("Error generating sitemap:", error);
        setIsLoading(false);
        toast.error("Failed to generate sitemap. Please check the URL and try again.");
      }
    }, 1000);
  };

  const copyToClipboard = () => {
    if (!sitemapXml) return;
    
    navigator.clipboard.writeText(sitemapXml);
    toast.success("Sitemap XML copied to clipboard!");
  };

  const downloadSitemap = () => {
    if (!sitemapXml) return;
    
    const blob = new Blob([sitemapXml], { type: 'text/xml' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sitemap.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success("Sitemap downloaded as sitemap.xml");
  };

  return (
    <ToolLayout
      title="Sitemap Generator"
      description="Create XML sitemaps to help search engines better index your website"
      helpText="A sitemap helps search engines discover and understand the structure of your website, improving SEO."
    >
      <div className="space-y-6">
        <Tabs defaultValue="standard" className="w-full" onValueChange={(value) => setSitemapType(value)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="standard">Standard Sitemap</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Options</TabsTrigger>
          </TabsList>
          
          <TabsContent value="standard" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="website-url">Website URL</Label>
              <div className="flex items-center space-x-2">
                <div className="relative flex-grow">
                  <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    id="website-url"
                    type="url" 
                    className="pl-10"
                    placeholder="https://example.com" 
                    value={url} 
                    onChange={handleUrlChange}
                  />
                </div>
                <Button onClick={generateSitemap} disabled={!isUrlValid || isLoading || !url}>
                  {isLoading ? "Generating..." : "Generate"}
                </Button>
              </div>
              
              {!isUrlValid && url && (
                <p className="text-red-500 text-sm mt-1">Please enter a valid URL (include https://)</p>
              )}
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md text-sm">
              <div className="flex items-start">
                <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium mb-1">Why do you need a sitemap?</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Help search engines discover and index all your website pages</li>
                    <li>Improve your website's SEO and visibility</li>
                    <li>Useful for large websites with many pages</li>
                    <li>Submit to Google Search Console to enhance crawling</li>
                  </ul>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="advanced" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="change-frequency">Change Frequency</Label>
                <Select value={changeFreq} onValueChange={setChangeFreq}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="always">Always</SelectItem>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                    <SelectItem value="never">Never</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="priority">Priority</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1.0">1.0 (Highest)</SelectItem>
                    <SelectItem value="0.9">0.9</SelectItem>
                    <SelectItem value="0.8">0.8</SelectItem>
                    <SelectItem value="0.7">0.7 (Default)</SelectItem>
                    <SelectItem value="0.6">0.6</SelectItem>
                    <SelectItem value="0.5">0.5</SelectItem>
                    <SelectItem value="0.4">0.4</SelectItem>
                    <SelectItem value="0.3">0.3</SelectItem>
                    <SelectItem value="0.2">0.2</SelectItem>
                    <SelectItem value="0.1">0.1 (Lowest)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="lastmod" 
                  checked={includeDateModified} 
                  onCheckedChange={(checked) => setIncludeDateModified(checked as boolean)}
                />
                <Label htmlFor="lastmod" className="cursor-pointer">Include lastmod (date modified)</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="images" 
                  checked={includeImages} 
                  onCheckedChange={(checked) => setIncludeImages(checked as boolean)}
                />
                <Label htmlFor="images" className="cursor-pointer">Include image extension</Label>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="custom-urls">Custom URLs (Optional, one per line)</Label>
              <Textarea 
                id="custom-urls" 
                placeholder="https://example.com/page1&#10;https://example.com/page2&#10;https://example.com/page3" 
                rows={5}
                value={urlList}
                onChange={(e) => setUrlList(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Leave empty to generate a sample sitemap based on your domain
              </p>
            </div>
            
            <div className="flex justify-end">
              <Button onClick={generateSitemap} disabled={!isUrlValid || isLoading || !url}>
                {isLoading ? "Generating..." : "Generate Advanced Sitemap"}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
        
        <AdBanner className="my-4" />

        {sitemapXml && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium flex items-center">
                <FileText className="h-5 w-5 mr-2 text-green-500" />
                Generated Sitemap
              </h3>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadSitemap}>
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>
              </div>
            </div>
            
            <Card className="border border-gray-200 dark:border-gray-700">
              <CardContent className="p-0">
                <pre className="overflow-x-auto bg-gray-50 dark:bg-gray-900 p-4 text-xs font-mono rounded-md">
                  {sitemapXml}
                </pre>
              </CardContent>
            </Card>
            
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-md">
              <h4 className="font-medium mb-2">Next Steps</h4>
              <ol className="text-sm space-y-1 list-decimal pl-5">
                <li>Save this file as <span className="font-mono">sitemap.xml</span> in your website's root directory</li>
                <li>Add this line to your robots.txt file: <span className="font-mono">Sitemap: https://yourdomain.com/sitemap.xml</span></li>
                <li>Submit your sitemap to Google Search Console and Bing Webmaster Tools</li>
                <li>Set up automatic sitemap generation for frequently updated sites</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

export default SitemapGenerator;
