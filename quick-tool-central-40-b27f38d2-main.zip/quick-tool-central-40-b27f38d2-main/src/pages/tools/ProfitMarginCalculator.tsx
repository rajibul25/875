
import { useState } from "react";
import { ArrowRight, Calculator, DollarSign, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import AdBanner from "@/components/AdBanner";
import { Helmet } from "react-helmet";

const ProfitMarginCalculator = () => {
  const [revenue, setRevenue] = useState<string>("");
  const [cost, setCost] = useState<string>("");
  const [profit, setProfit] = useState<number | null>(null);
  const [margin, setMargin] = useState<number | null>(null);
  const [markupPercent, setMarkupPercent] = useState<number | null>(null);
  const { toast } = useToast();

  const calculateProfit = () => {
    const revenueVal = parseFloat(revenue);
    const costVal = parseFloat(cost);
    
    if (isNaN(revenueVal) || isNaN(costVal)) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter valid numbers for revenue and cost."
      });
      return;
    }
    
    if (revenueVal < 0 || costVal < 0) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Revenue and cost must be positive numbers."
      });
      return;
    }
    
    const profitValue = revenueVal - costVal;
    const marginValue = (profitValue / revenueVal) * 100;
    const markup = (profitValue / costVal) * 100;
    
    setProfit(profitValue);
    setMargin(marginValue);
    setMarkupPercent(markup);
    
    toast({
      title: "Calculation complete",
      description: "Profit margin has been calculated successfully."
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateProfit();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Profit Margin Calculator - Calculate Profit Margins & Markup | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate profit margin, markup percentage and profit amount with our free profit margin calculator. Perfect for businesses to analyze profitability."
        />
        <meta
          name="keywords"
          content="profit margin calculator, profit calculator, markup calculator, business calculator, gross margin, net margin"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/profit-margin-calculator" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Profit Margin Calculator",
            "applicationCategory": "BusinessApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "operatingSystem": "All",
            "description": "Free online profit margin calculator. Calculate profit, profit margin percentage, and markup percentage for your business."
          })}
        </script>
      </Helmet>
      
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <BackButton />
          <h1 className="text-3xl font-bold text-center lg:text-left">Profit Margin Calculator</h1>
          <div className="w-[70px]"></div> {/* Empty div for alignment */}
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Calculator className="mr-2 text-tool-purple" />
              Calculate Profit Margin
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Calculate your profit margin, markup percentage and profit amount using this simple calculator.
            </p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Revenue ($)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        type="number"
                        placeholder="Enter your revenue"
                        value={revenue}
                        onChange={(e) => setRevenue(e.target.value)}
                        className="pl-9"
                        step="0.01"
                        min="0"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Cost ($)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        type="number"
                        placeholder="Enter your cost"
                        value={cost}
                        onChange={(e) => setCost(e.target.value)}
                        className="pl-9"
                        step="0.01"
                        min="0"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button 
                  type="submit" 
                  className="gap-2 bg-tool-purple hover:bg-tool-purple/90"
                >
                  Calculate
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </form>
            
            {profit !== null && margin !== null && markupPercent !== null && (
              <div className="mt-8 pt-6 border-t">
                <h3 className="text-lg font-medium mb-4">Results</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Profit</p>
                    <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                      ${profit.toFixed(2)}
                    </p>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Profit Margin</p>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 flex items-center">
                      {margin.toFixed(2)}<Percent className="h-4 w-4 ml-1" />
                    </p>
                  </div>
                  <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Markup Percentage</p>
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 flex items-center">
                      {markupPercent.toFixed(2)}<Percent className="h-4 w-4 ml-1" />
                    </p>
                  </div>
                </div>
              </div>
            )}
          </Card>
          
          <AdBanner className="my-8" />
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">What is a Profit Margin Calculator?</h2>
            <p className="mb-4">
              A profit margin calculator is a financial tool that helps businesses calculate their profit margin, which is the percentage of revenue that exceeds costs. It helps determine how much profit a business makes on each dollar of sales.
            </p>
            
            <h3 className="text-lg font-medium mb-2">Why Calculate Profit Margin?</h3>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Evaluate business profitability and financial health</li>
              <li>Compare performance against industry benchmarks</li>
              <li>Make informed pricing decisions</li>
              <li>Identify areas for cost reduction</li>
              <li>Track profit margin changes over time</li>
            </ul>
            
            <h3 className="text-lg font-medium mb-2">How to Use This Calculator</h3>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li>Enter your total revenue (sales amount)</li>
              <li>Enter your total cost (expenses)</li>
              <li>Click the "Calculate" button</li>
              <li>View your profit, profit margin percentage, and markup percentage</li>
            </ol>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">What's the difference between profit margin and markup?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Profit margin is calculated as (Revenue - Cost) / Revenue, showing what percentage of revenue becomes profit. Markup is calculated as (Revenue - Cost) / Cost, showing how much you mark up your costs when pricing products.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What is a good profit margin?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Good profit margins vary significantly by industry. Retail businesses might have margins of 2-5%, while software companies might have margins of 70-90%. Research industry benchmarks to understand where your margins should be.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How can I improve my profit margin?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  You can improve profit margins by increasing prices, reducing costs, focusing on higher-margin products, increasing operational efficiency, or optimizing your sales mix.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Can I have a negative profit margin?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, if your costs exceed your revenue, you'll have a negative profit margin, indicating that you're losing money on sales.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How often should I calculate my profit margin?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  For small businesses, monthly calculations are typically sufficient. Larger enterprises might track margins weekly or even daily for different product lines or departments.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProfitMarginCalculator;
