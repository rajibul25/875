
import React from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const UnlockPdf = () => {
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is PDF
    if (file.type !== "application/pdf") {
      toast.error("Please upload a PDF file");
      return;
    }

    // Here we would process the file, but for now we'll just show a toast
    toast.success(`File "${file.name}" uploaded successfully. Unlocking will be available in a future update.`);
  };

  return (
    <ToolLayout 
      title="Unlock PDF"
      description="Remove password protection from PDF files online, for free."
    >
      <Helmet>
        <title>Unlock PDF | Remove PDF Password Protection Online | MultiToolSet</title>
        <meta
          name="description"
          content="Unlock password-protected PDF files online for free. Remove restrictions and unlock secured PDF documents with our easy-to-use tool."
        />
      </Helmet>

      <div className="container mx-auto py-8">
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center">
                <Label htmlFor="pdf-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600">
                      Click to upload or drag and drop
                    </span>
                    <span className="text-xs text-gray-500">PDF files only (max 10MB)</span>
                  </div>
                  <Input
                    id="pdf-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,application/pdf"
                    onChange={handleFileUpload}
                  />
                </Label>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast.info("This feature will be available in a future update.");
                  }}
                  size="lg"
                >
                  Unlock PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Unlock PDF Files</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload your password-protected PDF file using the upload button above</li>
              <li>Enter the PDF password if you have it (for owner-protected PDFs) (coming soon)</li>
              <li>Click the "Unlock PDF" button</li>
              <li>Download your unlocked PDF file</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our PDF Unlocker</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Free to use with no watermarks</li>
              <li>Remove user password protection</li>
              <li>Enable editing, printing, and copying from protected PDFs</li>
              <li>Secure and private - files deleted after processing</li>
              <li>No installation required - works in your browser</li>
              <li>Works with PDF files up to 10MB</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default UnlockPdf;
