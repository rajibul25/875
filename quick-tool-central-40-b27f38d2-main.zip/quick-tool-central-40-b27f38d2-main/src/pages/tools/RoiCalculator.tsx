
import { useState } from "react";
import { ArrowRight, Calculator, DollarSign, Percent, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import AdBanner from "@/components/AdBanner";
import { Helmet } from "react-helmet";

const RoiCalculator = () => {
  const [investment, setInvestment] = useState<string>("");
  const [returns, setReturns] = useState<string>("");
  const [period, setPeriod] = useState<string>("");
  const [roi, setRoi] = useState<number | null>(null);
  const [annualizedRoi, setAnnualizedRoi] = useState<number | null>(null);
  const [netProfit, setNetProfit] = useState<number | null>(null);
  const { toast } = useToast();

  const calculateRoi = () => {
    const investmentVal = parseFloat(investment);
    const returnsVal = parseFloat(returns);
    const periodVal = parseFloat(period) || 1; // Default to 1 if not provided
    
    if (isNaN(investmentVal) || isNaN(returnsVal)) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter valid numbers for investment and returns."
      });
      return;
    }
    
    if (investmentVal <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Investment amount must be greater than zero."
      });
      return;
    }
    
    const profit = returnsVal - investmentVal;
    const roiValue = (profit / investmentVal) * 100;
    
    // Calculate annualized ROI if period is different from 1
    let annualizedRoiValue;
    if (periodVal !== 1) {
      annualizedRoiValue = (Math.pow((1 + (roiValue / 100)), (1 / periodVal)) - 1) * 100;
    } else {
      annualizedRoiValue = roiValue;
    }
    
    setRoi(roiValue);
    setAnnualizedRoi(annualizedRoiValue);
    setNetProfit(profit);
    
    toast({
      title: "Calculation complete",
      description: "ROI has been calculated successfully."
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateRoi();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>ROI Calculator - Calculate Return on Investment | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate your return on investment (ROI) with our free ROI calculator. Measure the performance and profitability of your investments."
        />
        <meta
          name="keywords"
          content="ROI calculator, return on investment, investment calculator, investment performance, business calculator, profit calculator"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/roi-calculator" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "ROI Calculator",
            "applicationCategory": "BusinessApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "operatingSystem": "All",
            "description": "Free online ROI calculator. Calculate return on investment and analyze the profitability of your business investments."
          })}
        </script>
      </Helmet>
      
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <BackButton />
          <h1 className="text-3xl font-bold text-center lg:text-left">ROI Calculator</h1>
          <div className="w-[70px]"></div> {/* Empty div for alignment */}
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <TrendingUp className="mr-2 text-tool-purple" />
              Calculate Return on Investment
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Calculate your ROI, annualized ROI, and net profit from your investments with this simple calculator.
            </p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Initial Investment ($)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input
                      type="number"
                      placeholder="Enter your initial investment"
                      value={investment}
                      onChange={(e) => setInvestment(e.target.value)}
                      className="pl-9"
                      step="0.01"
                      min="0"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Final Value/Return ($)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input
                      type="number"
                      placeholder="Enter the final value or return"
                      value={returns}
                      onChange={(e) => setReturns(e.target.value)}
                      className="pl-9"
                      step="0.01"
                      min="0"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Time Period (Years)
                  </label>
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Enter the time period in years (optional)"
                      value={period}
                      onChange={(e) => setPeriod(e.target.value)}
                      step="0.01"
                      min="0.1"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Leave blank for simple ROI calculation</p>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button 
                  type="submit" 
                  className="gap-2 bg-tool-purple hover:bg-tool-purple/90"
                >
                  Calculate ROI
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </form>
            
            {roi !== null && netProfit !== null && (
              <div className="mt-8 pt-6 border-t">
                <h3 className="text-lg font-medium mb-4">Results</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Net Profit</p>
                    <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                      ${netProfit.toFixed(2)}
                    </p>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-400">ROI</p>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 flex items-center">
                      {roi.toFixed(2)}<Percent className="h-4 w-4 ml-1" />
                    </p>
                  </div>
                  {annualizedRoi !== null && (
                    <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                      <p className="text-sm text-gray-600 dark:text-gray-400">Annualized ROI</p>
                      <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 flex items-center">
                        {annualizedRoi.toFixed(2)}<Percent className="h-4 w-4 ml-1" />
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>
          
          <AdBanner className="my-8" />
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">What is an ROI Calculator?</h2>
            <p className="mb-4">
              An ROI (Return on Investment) calculator is a financial tool that helps you evaluate the profitability of an investment by comparing the gain or loss relative to its cost. It is expressed as a percentage or ratio.
            </p>
            
            <h3 className="text-lg font-medium mb-2">Why Calculate ROI?</h3>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Evaluate the profitability of different investment opportunities</li>
              <li>Compare the performance of various investments</li>
              <li>Make data-driven investment decisions</li>
              <li>Measure the success of marketing campaigns or business initiatives</li>
              <li>Justify business expenses to stakeholders</li>
            </ul>
            
            <h3 className="text-lg font-medium mb-2">How to Use This Calculator</h3>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li>Enter your initial investment amount</li>
              <li>Enter the final value or return on your investment</li>
              <li>Optionally, enter the time period in years for annualized ROI</li>
              <li>Click the "Calculate ROI" button</li>
              <li>View your ROI, annualized ROI (if applicable), and net profit</li>
            </ol>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">What is a good ROI?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  A "good" ROI depends on the industry, risk level, and opportunity cost. Generally, an annual ROI of 7% or higher is considered good for many investments, but high-risk investments may require higher returns to be worthwhile.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What's the difference between ROI and annualized ROI?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  ROI measures the total return over the entire investment period, while annualized ROI converts this to an annual rate, making it easier to compare investments with different time periods.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How do I account for ongoing costs in ROI calculations?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Include all costs in your initial investment amount, or subtract ongoing costs from your final return value before calculating ROI to get a more accurate result.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Can ROI be negative?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, if your investment loses value or if the returns are less than the initial investment, you'll have a negative ROI, indicating a loss on your investment.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What are the limitations of ROI?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  ROI doesn't account for risk, time value of money, or the size of the investment. It's best used as one of several metrics when evaluating investments, alongside NPV, IRR, and payback period.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RoiCalculator;
