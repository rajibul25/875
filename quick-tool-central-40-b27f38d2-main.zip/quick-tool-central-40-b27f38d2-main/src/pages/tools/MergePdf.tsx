
import React from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const MergePdf = () => {
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Check if all files are PDFs
    for (let i = 0; i < files.length; i++) {
      if (files[i].type !== "application/pdf") {
        toast.error("Please upload only PDF files");
        return;
      }
    }

    // Here we would process the files, but for now we'll just show a toast
    toast.success(`${files.length} PDF file${files.length > 1 ? 's' : ''} uploaded successfully. Merging will be available in a future update.`);
  };

  return (
    <ToolLayout 
      title="Merge PDF Files"
      description="Combine multiple PDF documents into a single file, for free."
    >
      <Helmet>
        <title>Merge PDF Files | Combine Multiple PDFs Online | MultiToolSet</title>
        <meta
          name="description"
          content="Merge multiple PDF files into one document online for free. Combine PDFs in any order with our easy-to-use PDF merger tool."
        />
      </Helmet>

      <div className="container mx-auto py-8">
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center">
                <Label htmlFor="pdf-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600">
                      Click to upload or drag and drop
                    </span>
                    <span className="text-xs text-gray-500">PDF files only (max 10MB each)</span>
                  </div>
                  <Input
                    id="pdf-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,application/pdf"
                    multiple
                    onChange={handleFileUpload}
                  />
                </Label>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast.info("This feature will be available in a future update.");
                  }}
                  size="lg"
                >
                  Merge PDFs
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Merge PDF Files</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload multiple PDF files using the upload button above</li>
              <li>Rearrange the order of your PDFs if needed (coming soon)</li>
              <li>Click the "Merge PDFs" button</li>
              <li>Download your merged PDF document</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our PDF Merger</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Free to use with no watermarks</li>
              <li>Combine any number of PDF files</li>
              <li>Maintain the quality of your original documents</li>
              <li>Rearrange pages before merging (coming soon)</li>
              <li>Secure and private - files deleted after processing</li>
              <li>No installation required - works in your browser</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default MergePdf;
