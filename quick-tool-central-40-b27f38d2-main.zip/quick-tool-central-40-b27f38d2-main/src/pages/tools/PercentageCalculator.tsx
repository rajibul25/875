
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Percent } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const PercentageCalculatorComponent = () => {
  const [value, setValue] = useState<string>("");
  const [percent, setPercent] = useState<string>("");
  const [result, setResult] = useState<number | null>(null);
  const [percentOf, setPercentOf] = useState<number | null>(null);
  
  const calculatePercent = () => {
    const numValue = parseFloat(value);
    const numPercent = parseFloat(percent);
    
    if (isNaN(numValue) || isNaN(numPercent)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    setResult((numValue * numPercent) / 100);
    setPercentOf((numPercent / 100) * numValue);
    toast.success("Calculation complete!");
  };
  
  return (
    <ToolLayout
      title="Percentage Calculator"
      description="Calculate percentages easily with our simple percentage calculator"
      helpText="Enter a value and percentage to calculate"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="value" className="block text-sm font-medium text-gray-700">
            Value
          </label>
          <Input
            id="value"
            type="number"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Enter value"
            className="w-full"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="percent" className="block text-sm font-medium text-gray-700">
            Percentage (%)
          </label>
          <Input
            id="percent"
            type="number"
            value={percent}
            onChange={(e) => setPercent(e.target.value)}
            placeholder="Enter percentage"
            className="w-full"
          />
        </div>
        
        <Button 
          onClick={calculatePercent}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!value || !percent}
        >
          <Percent className="mr-2 h-4 w-4" /> Calculate
        </Button>
        
        {result !== null && percentOf !== null && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-2">Results</h3>
            <p className="mb-2">
              <span className="font-semibold">{percent}%</span> of{" "}
              <span className="font-semibold">{value}</span> is{" "}
              <span className="font-semibold text-purple-600">{result.toFixed(2)}</span>
            </p>
            <p>
              <span className="font-semibold">{percent}%</span> of{" "}
              <span className="font-semibold">{value}</span> equals{" "}
              <span className="font-semibold text-purple-600">{percentOf.toFixed(2)}</span>
            </p>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const PercentageCalculator = withErrorBoundary(PercentageCalculatorComponent, "percentage-calculator");

export default PercentageCalculator;
