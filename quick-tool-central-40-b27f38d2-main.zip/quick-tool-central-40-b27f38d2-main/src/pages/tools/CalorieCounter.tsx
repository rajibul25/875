
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import { Apple, ChevronRight } from "lucide-react";

// Food calorie database (simplified)
const foodCalories: Record<string, number> = {
  "apple": 52,
  "banana": 89,
  "chicken breast": 165,
  "egg": 78,
  "rice (cooked, 100g)": 130,
  "bread (1 slice)": 80,
  "milk (1 cup)": 122,
  "broccoli (100g)": 34,
  "pasta (cooked, 100g)": 131,
  "salmon (100g)": 208,
  "potato (medium)": 161,
  "avocado (half)": 161,
  "cheese (cheddar, 30g)": 113,
  "peanut butter (1 tbsp)": 94,
  "yogurt (plain, 200g)": 138,
  "orange": 62,
  "carrot (medium)": 25,
  "beef (ground, 100g)": 250,
  "spinach (100g)": 23,
  "oatmeal (cooked, 1 cup)": 158,
};

const CalorieCounter = () => {
  const [foodItems, setFoodItems] = useState<Array<{ name: string; quantity: number; calories: number }>>([]);
  const [currentFood, setCurrentFood] = useState("");
  const [customFood, setCustomFood] = useState("");
  const [customCalories, setCustomCalories] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);
  const [gender, setGender] = useState<string>("female");
  const [age, setAge] = useState<number>(30);
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [activityLevel, setActivityLevel] = useState<string>("moderate");
  const [totalCalories, setTotalCalories] = useState<number>(0);
  const [dailyRecommended, setDailyRecommended] = useState<number>(0);

  // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
  const calculateBMR = () => {
    let bmr = 0;
    if (gender === "male") {
      bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }
    
    // Apply activity multiplier
    let activityMultiplier = 1.2; // sedentary
    if (activityLevel === "light") activityMultiplier = 1.375;
    if (activityLevel === "moderate") activityMultiplier = 1.55;
    if (activityLevel === "active") activityMultiplier = 1.725;
    if (activityLevel === "very active") activityMultiplier = 1.9;
    
    setDailyRecommended(Math.round(bmr * activityMultiplier));
  };

  const addFood = () => {
    if (currentFood) {
      const calories = foodCalories[currentFood] * quantity;
      setFoodItems([...foodItems, { name: currentFood, quantity, calories }]);
      setCurrentFood("");
      setQuantity(1);
      updateTotalCalories([...foodItems, { name: currentFood, quantity, calories }]);
    }
  };

  const addCustomFood = () => {
    if (customFood && customCalories) {
      const calories = customCalories * quantity;
      setFoodItems([...foodItems, { name: customFood, quantity, calories }]);
      setCustomFood("");
      setCustomCalories(0);
      setQuantity(1);
      updateTotalCalories([...foodItems, { name: customFood, quantity, calories }]);
    }
  };

  const removeFood = (index: number) => {
    const newFoodItems = [...foodItems];
    newFoodItems.splice(index, 1);
    setFoodItems(newFoodItems);
    updateTotalCalories(newFoodItems);
  };

  const updateTotalCalories = (items: Array<{ name: string; quantity: number; calories: number }>) => {
    const total = items.reduce((sum, item) => sum + item.calories, 0);
    setTotalCalories(total);
  };

  const clearAll = () => {
    setFoodItems([]);
    setTotalCalories(0);
  };

  return (
    <>
      <Helmet>
        <title>Calorie Counter | Track Daily Calorie Intake | MultitoolSet</title>
        <meta name="description" content="Track your daily calorie intake with our free calorie counter. Add foods from our database or custom foods to monitor your nutrition goals." />
        <meta name="keywords" content="calorie counter, calorie tracker, food calories, nutrition calculator, diet tracker" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How accurate is this calorie counter?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our calorie counter provides reasonable estimates based on average values. For precise measurements, consider weighing foods and consulting nutrition labels."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many calories should I eat per day?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Daily calorie needs vary based on age, gender, weight, height, and activity level. Our calculator uses the Mifflin-St Jeor equation to provide a personalized estimate for maintaining weight."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Can I add custom foods to the calorie counter?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, you can add custom foods with their calorie values using the 'Add Custom Food' tab in our calorie counter."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <ToolLayout
        title="Calorie Counter"
        description="Track your daily calorie intake with our free calorie counter tool"
        helpText="Add foods from our database or enter custom foods to track your daily calorie intake and compare with your recommended daily calorie needs."
      >
        <div className="space-y-8">
          <Tabs defaultValue="food-database">
            <TabsList className="mb-4">
              <TabsTrigger value="food-database">Food Database</TabsTrigger>
              <TabsTrigger value="custom-food">Custom Food</TabsTrigger>
              <TabsTrigger value="calculator">Calorie Needs</TabsTrigger>
            </TabsList>
            
            <TabsContent value="food-database">
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="food-select">Select Food</Label>
                  <Select value={currentFood} onValueChange={setCurrentFood}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a food item" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(foodCalories).map((food) => (
                        <SelectItem key={food} value={food}>
                          {food} ({foodCalories[food]} cal)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex flex-col gap-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="0.25"
                    step="0.25"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                  />
                </div>
                
                <Button onClick={addFood} className="w-full">
                  Add Food <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="custom-food">
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="custom-food">Food Name</Label>
                  <Input
                    id="custom-food"
                    value={customFood}
                    onChange={(e) => setCustomFood(e.target.value)}
                    placeholder="Enter food name"
                  />
                </div>
                
                <div className="flex flex-col gap-2">
                  <Label htmlFor="custom-calories">Calories (per serving)</Label>
                  <Input
                    id="custom-calories"
                    type="number"
                    value={customCalories || ""}
                    onChange={(e) => setCustomCalories(parseInt(e.target.value) || 0)}
                    placeholder="Enter calories"
                  />
                </div>
                
                <div className="flex flex-col gap-2">
                  <Label htmlFor="custom-quantity">Quantity</Label>
                  <Input
                    id="custom-quantity"
                    type="number"
                    min="0.25"
                    step="0.25"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                  />
                </div>
                
                <Button onClick={addCustomFood} className="w-full">
                  Add Custom Food <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="calculator">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select value={gender} onValueChange={setGender}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      value={age}
                      onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(parseInt(e.target.value) || 0)}
                    />
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(parseInt(e.target.value) || 0)}
                    />
                  </div>
                </div>
                
                <div className="flex flex-col gap-2">
                  <Label htmlFor="activity">Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                      <SelectItem value="light">Light (exercise 1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (exercise 3-5 days/week)</SelectItem>
                      <SelectItem value="active">Active (exercise 6-7 days/week)</SelectItem>
                      <SelectItem value="very active">Very Active (intense exercise daily)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button onClick={calculateBMR} className="w-full">
                  Calculate Daily Calories <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                
                {dailyRecommended > 0 && (
                  <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-xl font-bold text-green-800 dark:text-green-300 mb-2">Your Daily Calorie Needs</h3>
                        <p className="text-3xl font-bold">{dailyRecommended} calories</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                          This is an estimate to maintain your current weight. To lose weight, consume less; to gain weight, consume more.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          </Tabs>
          
          {foodItems.length > 0 && (
            <div className="mt-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Your Food Log</h2>
                <Button variant="outline" size="sm" onClick={clearAll}>Clear All</Button>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                  {foodItems.map((item, index) => (
                    <li key={index} className="py-3 flex justify-between items-center">
                      <div>
                        <span className="font-medium">{item.name}</span>
                        <span className="text-gray-500 ml-2">x{item.quantity}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="mr-4">{item.calories} cal</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFood(index)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                        >
                          Remove
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
                  <span className="font-bold text-lg">Total Calories:</span>
                  <span className="font-bold text-lg">{totalCalories} cal</span>
                </div>
                
                {dailyRecommended > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Daily Goal:</span>
                      <span className="font-medium">{dailyRecommended} cal</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Remaining:</span>
                      <span className={`font-medium ${dailyRecommended - totalCalories < 0 ? 'text-red-500' : 'text-green-500'}`}>
                        {dailyRecommended - totalCalories} cal
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Select foods from our database or add custom foods with their calorie values.</li>
              <li>Enter the quantity of each food item you've consumed.</li>
              <li>Track your daily calorie intake with the running total at the bottom.</li>
              <li>Calculate your recommended daily calorie intake based on your personal details.</li>
              <li>Compare your consumption with your recommended daily intake.</li>
            </ol>
          </div>
          
          <div className="mt-6">
            <h2 className="text-2xl font-bold mb-4">FAQs</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">How accurate is this calorie counter?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Our calorie counter provides reasonable estimates based on average values. For precise measurements, consider weighing foods and consulting nutrition labels.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">How many calories should I eat per day?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Daily calorie needs vary based on age, gender, weight, height, and activity level. Our calculator uses the Mifflin-St Jeor equation to provide a personalized estimate for maintaining weight.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">Can I add custom foods to the calorie counter?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Yes, you can add custom foods with their calorie values using the 'Add Custom Food' tab in our calorie counter.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline">Ideal Weight Calculator</a>
              </li>
              <li>
                <a href="/tools/macro-calculator" className="text-blue-600 hover:underline">Macro Calculator</a>
              </li>
              <li>
                <a href="/tools/bmr-calculator" className="text-blue-600 hover:underline">BMR Calculator</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default CalorieCounter;
