
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Copy, Share2, Info, Calculator, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { motion } from "framer-motion";

const metaTitle = "BMI Calculator - Calculate Your Body Mass Index Online";
const metaDescription = "Calculate your Body Mass Index (BMI) with our free online calculator. Find out if your weight is healthy for your height and get personalized health insights.";

const BmiCalculator = () => {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState<string>("");
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  const [healthRisk, setHealthRisk] = useState<string>("");
  const [hasInteracted, setHasInteracted] = useState(false);

  const loadExampleValues = () => {
    if (unit === "metric") {
      setHeight("170");
      setWeight("70");
    } else {
      setHeight("5.6"); // 5 feet 6 inches
      setWeight("154"); // 154 pounds
    }
    setHasInteracted(true);
  };

  const resetValues = () => {
    setHeight("");
    setWeight("");
    setBmi(null);
    setCategory("");
    setHealthRisk("");
    setHasInteracted(false);
  };

  useEffect(() => {
    if (height && weight && Number(height) > 0 && Number(weight) > 0) {
      calculateBmi();
    } else if (hasInteracted) {
      setBmi(null);
      setCategory("");
      setHealthRisk("");
    }
  }, [height, weight, unit, hasInteracted]);

  const handleInputChange = (setter: React.Dispatch<React.SetStateAction<string>>, value: string) => {
    setter(value);
    setHasInteracted(true);
  };

  const calculateBmi = () => {
    let bmiValue = 0;

    if (unit === "metric") {
      const heightInMeters = Number(height) / 100;
      const weightInKg = Number(weight);
      bmiValue = weightInKg / (heightInMeters * heightInMeters);
    } else {
      const heightInInches = Number(height) * 12; // Convert feet to inches
      const weightInLbs = Number(weight);
      bmiValue = (weightInLbs / (heightInInches * heightInInches)) * 703;
    }

    setBmi(Number(bmiValue.toFixed(1)));

    if (bmiValue < 16) {
      setCategory("Severe Thinness");
      setHealthRisk("Very severe health risk");
    } else if (bmiValue < 17) {
      setCategory("Moderate Thinness");
      setHealthRisk("Severe health risk");
    } else if (bmiValue < 18.5) {
      setCategory("Mild Thinness");
      setHealthRisk("Mild health risk");
    } else if (bmiValue < 25) {
      setCategory("Normal");
      setHealthRisk("Low risk");
    } else if (bmiValue < 30) {
      setCategory("Overweight");
      setHealthRisk("Enhanced risk");
    } else if (bmiValue < 35) {
      setCategory("Obese Class I");
      setHealthRisk("High risk");
    } else if (bmiValue < 40) {
      setCategory("Obese Class II");
      setHealthRisk("Very high risk");
    } else {
      setCategory("Obese Class III");
      setHealthRisk("Extremely high risk");
    }
  };

  const copyResults = () => {
    if (bmi !== null) {
      const textToCopy = `BMI: ${bmi} - Category: ${category} - Health Risk: ${healthRisk}`;
      navigator.clipboard.writeText(textToCopy);
      toast.success("BMI results copied to clipboard!");
    }
  };

  const shareResults = () => {
    if (bmi !== null) {
      const shareText = `My BMI is ${bmi} (${category}). Calculate yours:`;
      const shareUrl = window.location.href;
      
      if (navigator.share) {
        navigator.share({
          title: 'BMI Calculator Results',
          text: shareText,
          url: shareUrl,
        }).catch((error) => console.log('Error sharing', error));
      } else {
        const fallbackText = `${shareText} ${shareUrl}`;
        navigator.clipboard.writeText(fallbackText);
        toast.success("Share text copied to clipboard!");
      }
    }
  };

  const getCategoryColor = () => {
    switch (category) {
      case "Severe Thinness":
      case "Moderate Thinness":
        return "text-red-500 dark:text-red-400";
      case "Mild Thinness":
        return "text-amber-500 dark:text-amber-400";
      case "Normal":
        return "text-green-500 dark:text-green-400";
      case "Overweight":
        return "text-amber-500 dark:text-amber-400";
      case "Obese Class I":
        return "text-orange-500 dark:text-orange-400";
      case "Obese Class II":
      case "Obese Class III":
        return "text-red-500 dark:text-red-400";
      default:
        return "text-blue-600 dark:text-blue-400";
    }
  };

  const getHeightPlaceholder = () => {
    return unit === "metric" 
      ? "Enter your height in centimeters" 
      : "Enter your height in feet (e.g., 5.6 for 5'6\")";
  };

  const getWeightPlaceholder = () => {
    return unit === "metric" 
      ? "Enter your weight in kilograms" 
      : "Enter your weight in pounds";
  };

  return (
    <ToolLayout
      title="BMI Calculator"
      description="Calculate your Body Mass Index (BMI) to check if your weight is healthy for your height."
      helpText="BMI is a measurement of a person's weight with respect to their height. It's an indicator of whether you have a healthy body weight."
    >
      <div className="max-w-3xl mx-auto p-4">
        <Tabs defaultValue="metric" value={unit} onValueChange={(val) => setUnit(val as "metric" | "imperial")} className="mb-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="metric">Metric (cm/kg)</TabsTrigger>
            <TabsTrigger value="imperial">Imperial (ft/lbs)</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Card className="border dark:border-gray-700">
          <CardContent className="pt-6">
            <div className="grid gap-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="height" className="flex items-center gap-1">
                    Height {unit === "metric" ? "(cm)" : "(feet)"}
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          {unit === "metric" 
                            ? "Enter your height in centimeters" 
                            : "Enter as decimal, e.g., 5.6 for 5 feet 6 inches"}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                  <Input
                    id="height"
                    type="number"
                    step={unit === "metric" ? "1" : "0.1"}
                    placeholder={getHeightPlaceholder()}
                    value={height}
                    onChange={(e) => handleInputChange(setHeight, e.target.value)}
                    className="focus-within:ring-2 focus-within:ring-purple-500 dark:focus-within:ring-purple-600 dark:bg-gray-800 dark:border-gray-700"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="weight" className="flex items-center gap-1">
                    Weight {unit === "metric" ? "(kg)" : "(lbs)"}
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          {unit === "metric" 
                            ? "Enter your weight in kilograms" 
                            : "Enter your weight in pounds"}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                  <Input
                    id="weight"
                    type="number"
                    step={unit === "metric" ? "0.1" : "1"}
                    placeholder={getWeightPlaceholder()}
                    value={weight}
                    onChange={(e) => handleInputChange(setWeight, e.target.value)}
                    className="focus-within:ring-2 focus-within:ring-purple-500 dark:focus-within:ring-purple-600 dark:bg-gray-800 dark:border-gray-700"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  onClick={loadExampleValues}
                  variant="outline"
                  className="flex items-center gap-2 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 hover:dark:bg-gray-700"
                >
                  <Calculator className="h-4 w-4" />
                  Load Example
                </Button>
                
                <Button 
                  onClick={resetValues}
                  variant="outline"
                  className="flex items-center gap-2 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 hover:dark:bg-gray-700"
                >
                  <RefreshCw className="h-4 w-4" />
                  Reset
                </Button>
              </div>

              {!hasInteracted && (
                <Alert className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 mt-2 border dark:border-blue-900/50">
                  <AlertDescription>
                    Enter your height and weight values above to see your BMI results instantly.
                  </AlertDescription>
                </Alert>
              )}

              {bmi !== null && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 p-6 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-700"
                >
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border dark:border-gray-700">
                      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Your BMI</h3>
                      <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                        {bmi}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border dark:border-gray-700">
                      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Category</h3>
                      <p className={`text-xl font-bold ${getCategoryColor()}`}>
                        {category}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border dark:border-gray-700">
                      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Health Risk</h3>
                      <p className="text-lg font-medium text-gray-800 dark:text-gray-200">
                        {healthRisk}
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={copyResults} className="flex items-center gap-1 dark:border-gray-700">
                      <Copy className="h-4 w-4" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm" onClick={shareResults} className="flex items-center gap-1 dark:border-gray-700">
                      <Share2 className="h-4 w-4" />
                      Share
                    </Button>
                  </div>
                </motion.div>
              )}

              <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                <h4 className="font-semibold mb-2 text-gray-700 dark:text-gray-300">BMI Categories:</h4>
                <ul className="grid gap-1 md:grid-cols-2 md:gap-2">
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-red-500 mr-2"></span>
                    Below 16 - Severe Thinness
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-red-400 mr-2"></span>
                    16 - 16.9 - Moderate Thinness
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-amber-500 mr-2"></span>
                    17 - 18.4 - Mild Thinness
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
                    18.5 - 24.9 - Normal
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-amber-500 mr-2"></span>
                    25 - 29.9 - Overweight
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-orange-500 mr-2"></span>
                    30 - 34.9 - Obese Class I
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-red-500 mr-2"></span>
                    35 - 39.9 - Obese Class II
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-red-600 mr-2"></span>
                    40+ - Obese Class III
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-start border-t pt-6">
            <div className="text-sm text-muted-foreground">
              <p className="mb-2">
                <strong>Note:</strong> The BMI calculator is a screening tool, not a diagnostic tool. 
                Factors such as muscle mass, pregnancy, and age can influence BMI readings.
              </p>
              <p>
                Always consult with a healthcare professional for a complete health assessment.
              </p>
            </div>
          </CardFooter>
        </Card>

        <div className="mt-10 space-y-6">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-bold text-lg mb-2">What is BMI?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Body Mass Index (BMI) is a numerical value calculated from your weight and height. It provides a simple way to categorize whether 
                you have a healthy body weight for your height. BMI is widely used as a screening tool to identify potential weight problems in adults.
              </p>
            </div>
            
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-bold text-lg mb-2">How is BMI calculated?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                BMI is calculated using the formula: BMI = weight(kg) / height²(m²) in metric units, or BMI = 703 × weight(lb) / height²(in²) in imperial units. 
                This calculator automatically performs this calculation for you based on the measurements you provide.
              </p>
            </div>
            
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-bold text-lg mb-2">Is BMI accurate for everyone?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                BMI has limitations and isn't always accurate for all body types. Athletes and muscular individuals may have a higher BMI due to 
                increased muscle mass, not excess fat. Similarly, elderly people and those who have lost muscle mass may have a "normal" BMI despite 
                having excess body fat. BMI should be used as one of several tools to assess overall health.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-10 space-y-6">
          <h2 className="text-2xl font-bold">Related Tools</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="/tools/body-fat-calculator" className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 transition-all hover:shadow-md">
              <h3 className="font-bold text-blue-600 dark:text-blue-400">Body Fat Calculator</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                Estimate your body fat percentage using different measurement methods.
              </p>
            </a>
            
            <a href="/tools/calorie-counter" className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 transition-all hover:shadow-md">
              <h3 className="font-bold text-blue-600 dark:text-blue-400">Calorie Counter</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                Track your daily calorie intake with our easy-to-use counter.
              </p>
            </a>
            
            <a href="/tools/macro-calculator" className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 transition-all hover:shadow-md">
              <h3 className="font-bold text-blue-600 dark:text-blue-400">Macro Calculator</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                Calculate your macronutrient needs based on your goals.
              </p>
            </a>
          </div>
        </div>

        <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "BMI Calculator",
            "description": "Calculate your Body Mass Index (BMI) to check if your weight is healthy for your height.",
            "applicationCategory": "HealthApplication",
            "operatingSystem": "Any",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            }
          })
        }} />

        <meta name="title" content={metaTitle} />
        <meta name="description" content={metaDescription} />
        <meta name="keywords" content="BMI calculator, body mass index, health calculator, weight health, BMI measurement, free BMI calculator" />
      </div>
    </ToolLayout>
  );
};

export default BmiCalculator;
