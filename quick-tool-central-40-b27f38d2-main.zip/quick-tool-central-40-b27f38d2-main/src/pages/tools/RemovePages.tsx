
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const RemovePages = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is PDF
    if (file.type !== "application/pdf") {
      toast.error("Please upload a PDF file");
      return;
    }

    setSelectedFile(file);
    toast.success(`File "${file.name}" uploaded successfully. Page removal will be available in a future update.`);
  };

  return (
    <ToolLayout 
      title="Remove PDF Pages"
      description="Delete specific pages from your PDF documents online, for free."
    >
      <Helmet>
        <title>Remove PDF Pages | Delete Pages from PDF Online | MultiToolSet</title>
        <meta
          name="description"
          content="Remove unwanted pages from PDF documents online for free. Delete, extract, or reorganize PDF pages easily with our PDF editor tool."
        />
      </Helmet>

      <div className="container mx-auto py-8">
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center">
                <Label htmlFor="pdf-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600">
                      Click to upload or drag and drop
                    </span>
                    <span className="text-xs text-gray-500">PDF files only (max 10MB)</span>
                  </div>
                  <Input
                    id="pdf-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,application/pdf"
                    onChange={handleFileUpload}
                  />
                </Label>
              </div>

              {selectedFile && (
                <p className="text-center text-sm text-green-600">
                  {selectedFile.name} uploaded successfully
                </p>
              )}

              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast.info("This feature will be available in a future update.");
                  }}
                  size="lg"
                  disabled={!selectedFile}
                >
                  Remove Pages
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Remove Pages from PDF</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload your PDF file using the upload button above</li>
              <li>Select the pages you want to remove (coming soon)</li>
              <li>Click the "Remove Pages" button</li>
              <li>Download your edited PDF document</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our PDF Page Remover</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Free to use with no watermarks</li>
              <li>Simple interface for selecting pages to remove</li>
              <li>Preview pages before removing (coming soon)</li>
              <li>Maintain the quality of your original document</li>
              <li>Secure and private - files deleted after processing</li>
              <li>No installation required - works in your browser</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default RemovePages;
