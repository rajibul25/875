
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Helmet } from "react-helmet";
import { ChevronRight, Moon, AlarmClock, Bed } from "lucide-react";
import { format, addMinutes, subMinutes, addHours, subHours, parse } from "date-fns";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SleepCalculator = () => {
  const [activeTab, setActiveTab] = useState<"bedtime" | "wakeup" | "cycles">("bedtime");
  const [wakeUpTime, setWakeUpTime] = useState<string>("07:00");
  const [fallAsleepTime, setFallAsleepTime] = useState<number>(14);
  const [sleepDuration, setSleepDuration] = useState<number>(8);
  const [sleepCycles, setSleepCycles] = useState<number>(5);
  const [bedtime, setBedtime] = useState<string>("");
  const [wakeupTimes, setWakeupTimes] = useState<string[]>([]);
  const [ageGroup, setAgeGroup] = useState<string>("adult");
  const [recommendedSleepHours, setRecommendedSleepHours] = useState<{ min: number; max: number }>({ min: 7, max: 9 });
  
  // Calculate bedtime based on wake-up time
  const calculateBedtime = () => {
    try {
      // Parse wake-up time
      const wakeUpDateTime = parse(wakeUpTime, "HH:mm", new Date());
      
      // Calculate total minutes needed before wake-up time
      // Sleep duration in hours * 60 minutes + fall asleep time in minutes
      const totalMinutesNeeded = (sleepDuration * 60) + fallAsleepTime;
      
      // Calculate bedtime
      const bedDateTime = subMinutes(wakeUpDateTime, totalMinutesNeeded);
      const formattedBedtime = format(bedDateTime, "h:mm a");
      
      setBedtime(formattedBedtime);
      
      // Calculate recommended wake-up times based on sleep cycles
      const recommendedWakeupTimes = [];
      
      // A full sleep cycle is approximately 90 minutes
      // Calculate wake-up times for 3 to 6 sleep cycles
      for (let cycles = 4; cycles <= 6; cycles++) {
        const cycleDuration = cycles * 90;
        const cycleWakeupTime = addMinutes(bedDateTime, cycleDuration + fallAsleepTime);
        recommendedWakeupTimes.push({
          cycles,
          time: format(cycleWakeupTime, "h:mm a")
        });
      }
      
      // Convert to array of formatted strings
      setWakeupTimes(recommendedWakeupTimes.map(item => `${item.time} (${item.cycles} cycles)`));
    } catch (error) {
      console.error("Error calculating bedtime:", error);
    }
  };
  
  // Calculate wake-up times based on bedtime
  const calculateWakeupTimes = () => {
    try {
      // Parse bedtime
      const bedDateTime = parse(wakeUpTime, "HH:mm", new Date());
      
      // Calculate recommended wake-up times based on sleep cycles
      const recommendedWakeupTimes = [];
      
      // A full sleep cycle is approximately 90 minutes
      // Calculate wake-up times for 3 to 6 sleep cycles
      for (let cycles = 3; cycles <= 6; cycles++) {
        const cycleDuration = cycles * 90;
        const cycleWakeupTime = addMinutes(bedDateTime, cycleDuration + fallAsleepTime);
        recommendedWakeupTimes.push({
          cycles,
          time: format(cycleWakeupTime, "h:mm a")
        });
      }
      
      // Convert to array of formatted strings
      setWakeupTimes(recommendedWakeupTimes.map(item => `${item.time} (${item.cycles} cycles)`));
    } catch (error) {
      console.error("Error calculating wake-up times:", error);
    }
  };
  
  // Calculate optimal bedtime based on sleep cycles
  const calculateOptimalBedtime = () => {
    try {
      // Parse wake-up time
      const wakeUpDateTime = parse(wakeUpTime, "HH:mm", new Date());
      
      // Calculate optimal bedtime based on sleep cycles
      // A full sleep cycle is approximately 90 minutes
      const cycleDuration = sleepCycles * 90;
      
      // Calculate bedtime by subtracting cycle duration and fall asleep time from wake-up time
      const bedDateTime = subMinutes(wakeUpDateTime, cycleDuration + fallAsleepTime);
      const formattedBedtime = format(bedDateTime, "h:mm a");
      
      setBedtime(formattedBedtime);
      
      // Calculate sleep duration for the given cycles
      const sleepHours = cycleDuration / 60;
      setSleepDuration(sleepHours);
    } catch (error) {
      console.error("Error calculating optimal bedtime:", error);
    }
  };
  
  // Update recommended sleep hours based on age group
  const updateRecommendedSleepHours = (age: string) => {
    setAgeGroup(age);
    
    switch (age) {
      case "infant":
        setRecommendedSleepHours({ min: 12, max: 16 });
        setSleepDuration(14);
        break;
      case "toddler":
        setRecommendedSleepHours({ min: 11, max: 14 });
        setSleepDuration(12);
        break;
      case "preschool":
        setRecommendedSleepHours({ min: 10, max: 13 });
        setSleepDuration(11);
        break;
      case "child":
        setRecommendedSleepHours({ min: 9, max: 12 });
        setSleepDuration(10);
        break;
      case "teen":
        setRecommendedSleepHours({ min: 8, max: 10 });
        setSleepDuration(9);
        break;
      case "adult":
        setRecommendedSleepHours({ min: 7, max: 9 });
        setSleepDuration(8);
        break;
      case "senior":
        setRecommendedSleepHours({ min: 7, max: 8 });
        setSleepDuration(7.5);
        break;
      default:
        setRecommendedSleepHours({ min: 7, max: 9 });
        setSleepDuration(8);
    }
  };

  return (
    <>
      <Helmet>
        <title>Sleep Calculator | Find Your Ideal Bedtime & Wake-up Time | MultitoolSet</title>
        <meta name="description" content="Calculate your ideal bedtime or wake-up time based on sleep cycles and recommended sleep duration. Improve sleep quality and wake up refreshed." />
        <meta name="keywords" content="sleep calculator, bedtime calculator, sleep cycle calculator, wake up time calculator, sleep duration calculator" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How much sleep do I need?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sleep needs vary by age. Adults generally need 7-9 hours, teenagers 8-10 hours, school-age children 9-12 hours, preschoolers 10-13 hours, toddlers 11-14 hours, and infants 12-16 hours."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is a sleep cycle?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A sleep cycle is a progression through various stages of sleep, including light sleep, deep sleep, and REM sleep. Each cycle lasts approximately 90 minutes, and most people need 4-6 complete cycles per night for optimal rest."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How can I improve my sleep quality?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To improve sleep quality: establish a consistent sleep schedule, create a relaxing bedtime routine, limit screen time before bed, avoid caffeine and alcohol near bedtime, exercise regularly, and ensure your sleep environment is comfortable, dark, and quiet."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <ToolLayout
        title="Sleep Calculator"
        description="Calculate your ideal bedtime or wake-up time for better sleep quality"
        helpText="This tool helps you determine the best time to go to bed or wake up based on sleep cycles, ensuring you wake up refreshed and energized."
      >
        <div className="space-y-8">
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-5">
            <div className="flex items-start">
              <div className="bg-blue-100 dark:bg-blue-800/30 p-2 rounded-full mr-4">
                <Moon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="font-bold text-blue-800 dark:text-blue-300">Recommended Sleep Duration</h3>
                <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                  Select your age group to see the recommended sleep duration:
                </p>
                <div className="mt-3">
                  <Select
                    value={ageGroup}
                    onValueChange={updateRecommendedSleepHours}
                  >
                    <SelectTrigger className="w-full md:w-64">
                      <SelectValue placeholder="Select age group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="infant">Infant (4-12 months)</SelectItem>
                      <SelectItem value="toddler">Toddler (1-2 years)</SelectItem>
                      <SelectItem value="preschool">Preschool (3-5 years)</SelectItem>
                      <SelectItem value="child">School-age (6-12 years)</SelectItem>
                      <SelectItem value="teen">Teen (13-17 years)</SelectItem>
                      <SelectItem value="adult">Adult (18-64 years)</SelectItem>
                      <SelectItem value="senior">Senior (65+ years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-lg font-medium mt-3">
                  {recommendedSleepHours.min}-{recommendedSleepHours.max} hours per night
                </p>
              </div>
            </div>
          </div>
          
          <Tabs defaultValue="bedtime" onValueChange={(value) => setActiveTab(value as any)}>
            <TabsList className="mb-4">
              <TabsTrigger value="bedtime">Find Bedtime</TabsTrigger>
              <TabsTrigger value="wakeup">Find Wake-up Time</TabsTrigger>
              <TabsTrigger value="cycles">Sleep Cycles</TabsTrigger>
            </TabsList>
            
            <TabsContent value="bedtime" className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="wake-up-time">Wake-up Time</Label>
                  <Input
                    id="wake-up-time"
                    type="time"
                    value={wakeUpTime}
                    onChange={(e) => setWakeUpTime(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="sleep-duration">Desired Sleep Duration (hours)</Label>
                  <Input
                    id="sleep-duration"
                    type="number"
                    value={sleepDuration}
                    onChange={(e) => setSleepDuration(parseFloat(e.target.value) || 8)}
                    min="4"
                    max="12"
                    step="0.5"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Recommended: {recommendedSleepHours.min}-{recommendedSleepHours.max} hours for your age group
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="fall-asleep-time">Time to Fall Asleep (minutes)</Label>
                  <Input
                    id="fall-asleep-time"
                    type="number"
                    value={fallAsleepTime}
                    onChange={(e) => setFallAsleepTime(parseInt(e.target.value) || 14)}
                    min="0"
                    max="60"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    The average person takes 10-20 minutes to fall asleep
                  </p>
                </div>
                
                <Button onClick={calculateBedtime} className="w-full">
                  Calculate Bedtime <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              {bedtime && (
                <Card className="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="inline-block bg-indigo-100 dark:bg-indigo-800/30 p-3 rounded-full mb-4">
                        <Bed className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <h3 className="text-xl font-bold text-indigo-800 dark:text-indigo-300 mb-2">Ideal Bedtime</h3>
                      <p className="text-3xl font-bold">{bedtime}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                        For {sleepDuration} hours of sleep and waking up at {format(parse(wakeUpTime, "HH:mm", new Date()), "h:mm a")}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {wakeupTimes.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-xl font-bold mb-4">Alternative Wake-up Times</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    These times are based on completing full sleep cycles, which may help you wake up feeling more refreshed.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {wakeupTimes.map((time, index) => (
                      <Card key={index}>
                        <CardContent className="pt-6 text-center">
                          <AlarmClock className="h-5 w-5 text-indigo-500 mx-auto mb-2" />
                          <p className="font-medium">{time}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="wakeup" className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bedtime">Bedtime</Label>
                  <Input
                    id="bedtime"
                    type="time"
                    value={wakeUpTime}
                    onChange={(e) => setWakeUpTime(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="fall-asleep-time-wakeup">Time to Fall Asleep (minutes)</Label>
                  <Input
                    id="fall-asleep-time-wakeup"
                    type="number"
                    value={fallAsleepTime}
                    onChange={(e) => setFallAsleepTime(parseInt(e.target.value) || 14)}
                    min="0"
                    max="60"
                    className="mt-1"
                  />
                </div>
                
                <Button onClick={calculateWakeupTimes} className="w-full">
                  Calculate Wake-up Times <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              {wakeupTimes.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-xl font-bold mb-4">Recommended Wake-up Times</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    These times are based on completing full sleep cycles, which may help you wake up feeling more refreshed.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {wakeupTimes.map((time, index) => (
                      <Card key={index} className={index === wakeupTimes.length - 2 ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800" : ""}>
                        <CardContent className="pt-6 text-center">
                          <AlarmClock className={`h-5 w-5 mx-auto mb-2 ${index === wakeupTimes.length - 2 ? 'text-green-500' : 'text-indigo-500'}`} />
                          <p className="font-medium">{time}</p>
                          {index === wakeupTimes.length - 2 && (
                            <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                              Recommended
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="cycles" className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="wake-up-time-cycles">Wake-up Time</Label>
                  <Input
                    id="wake-up-time-cycles"
                    type="time"
                    value={wakeUpTime}
                    onChange={(e) => setWakeUpTime(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="sleep-cycles">Number of Sleep Cycles</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setSleepCycles(Math.max(3, sleepCycles - 1))}
                    >
                      -
                    </Button>
                    <span className="font-medium text-lg">{sleepCycles} cycles</span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setSleepCycles(Math.min(8, sleepCycles + 1))}
                    >
                      +
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Each cycle is about 90 minutes. 5-6 cycles (7.5-9 hours) is optimal for most adults.
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="fall-asleep-time-cycles">Time to Fall Asleep (minutes)</Label>
                  <Input
                    id="fall-asleep-time-cycles"
                    type="number"
                    value={fallAsleepTime}
                    onChange={(e) => setFallAsleepTime(parseInt(e.target.value) || 14)}
                    min="0"
                    max="60"
                    className="mt-1"
                  />
                </div>
                
                <Button onClick={calculateOptimalBedtime} className="w-full">
                  Calculate Optimal Bedtime <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              {bedtime && (
                <Card className="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="inline-block bg-indigo-100 dark:bg-indigo-800/30 p-3 rounded-full mb-4">
                        <Moon className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <h3 className="text-xl font-bold text-indigo-800 dark:text-indigo-300 mb-2">Optimal Bedtime</h3>
                      <p className="text-3xl font-bold">{bedtime}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                        For {sleepCycles} sleep cycles ({(sleepCycles * 90 / 60).toFixed(1)} hours) and waking up at {format(parse(wakeUpTime, "HH:mm", new Date()), "h:mm a")}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">About Sleep Cycles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-2">Sleep Cycle Phases</h3>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">NREM Stage 1 (Light Sleep):</span>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Transition between wakefulness and sleep, lasting 1-5 minutes.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">NREM Stage 2 (Light Sleep):</span>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Body temperature drops and heart rate slows, lasting 10-25 minutes.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">NREM Stage 3 (Deep Sleep):</span>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Restorative sleep that strengthens memory and supports physical recovery.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">REM Sleep:</span>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Brain activity increases, dreaming occurs, and memory consolidation happens.
                    </p>
                  </li>
                </ol>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Why Sleep Cycles Matter</h3>
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  Each complete sleep cycle takes approximately 90 minutes. Waking up during deep sleep often leads to grogginess and fatigue, known as "sleep inertia."
                </p>
                <p className="text-gray-700 dark:text-gray-300">
                  For optimal rest, try to wake up at the end of a complete sleep cycle when you're in lighter sleep. This calculator helps you time your sleep to wake up between cycles, feeling more refreshed and alert.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Select your age group to see recommended sleep duration for your demographic.</li>
              <li>Choose which calculation you want to perform: finding an ideal bedtime, wake-up time, or calculating by sleep cycles.</li>
              <li>Enter the required information and click the calculate button.</li>
              <li>View your personalized sleep recommendations based on sleep cycles and duration.</li>
            </ol>
          </div>
          
          <div className="mt-6">
            <h2 className="text-2xl font-bold mb-4">FAQs</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">How much sleep do I need?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Sleep needs vary by age. Adults generally need 7-9 hours, teenagers 8-10 hours, school-age children 9-12 hours, preschoolers 10-13 hours, toddlers 11-14 hours, and infants 12-16 hours.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">What is a sleep cycle?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  A sleep cycle is a progression through various stages of sleep, including light sleep, deep sleep, and REM sleep. Each cycle lasts approximately 90 minutes, and most people need 4-6 complete cycles per night for optimal rest.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">How can I improve my sleep quality?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  To improve sleep quality: establish a consistent sleep schedule, create a relaxing bedtime routine, limit screen time before bed, avoid caffeine and alcohol near bedtime, exercise regularly, and ensure your sleep environment is comfortable, dark, and quiet.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/pace-calculator" className="text-blue-600 hover:underline">Pace Calculator</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline">Ideal Weight Calculator</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default SleepCalculator;
