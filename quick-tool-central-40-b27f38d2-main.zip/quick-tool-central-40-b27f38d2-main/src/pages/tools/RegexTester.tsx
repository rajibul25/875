
import React from "react";
import ToolLayout from "@/components/tools/ToolLayout";

const RegexTester = () => {
  return (
    <ToolLayout 
      title="RegEx Tester"
      description="Test and debug regular expressions with live validation."
      helpText="This tool is coming soon. Please check back later."
    >
      <div className="flex flex-col items-center justify-center py-12">
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-6 max-w-md text-center">
          <h2 className="text-xl font-semibold mb-3">Coming Soon</h2>
          <p className="text-gray-600 dark:text-gray-300">
            We're working on implementing this tool. Please check back soon!
          </p>
        </div>
      </div>
    </ToolLayout>
  );
};

export default RegexTester;
