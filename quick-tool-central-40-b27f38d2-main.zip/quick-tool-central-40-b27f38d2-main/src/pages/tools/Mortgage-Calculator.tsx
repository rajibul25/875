
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { Calculator, Home, DollarSign, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import ToolLayout from "@/components/tools/ToolLayout";
import withErrorBoundary from "@/components/tools/withErrorBoundary";

interface MortgageResult {
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
  amortizationSchedule: Array<{
    month: number;
    payment: number;
    principal: number;
    interest: number;
    balance: number;
  }>;
}

const MortgageCalculatorComponent = () => {
  const [loanAmount, setLoanAmount] = useState<string>("500000");
  const [interestRate, setInterestRate] = useState<string>("4.5");
  const [loanTerm, setLoanTerm] = useState<string>("30");
  const [downPayment, setDownPayment] = useState<string>("100000");
  const [result, setResult] = useState<MortgageResult | null>(null);
  
  const calculateMortgage = () => {
    const principal = parseFloat(loanAmount) - parseFloat(downPayment || "0");
    const rate = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const term = parseInt(loanTerm) * 12; // Term in months
    
    if (isNaN(principal) || isNaN(rate) || isNaN(term)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (principal <= 0 || rate <= 0 || term <= 0) {
      toast.error("Values must be greater than zero");
      return;
    }
    
    // Calculate monthly payment
    const x = Math.pow(1 + rate, term);
    const monthlyPayment = (principal * x * rate) / (x - 1);
    
    // Calculate total payment and interest
    const totalPayment = monthlyPayment * term;
    const totalInterest = totalPayment - principal;
    
    // Generate amortization schedule
    const schedule = [];
    let balance = principal;
    
    for (let month = 1; month <= Math.min(term, 360); month++) {
      const interestPayment = balance * rate;
      const principalPayment = monthlyPayment - interestPayment;
      balance -= principalPayment;
      
      if (month <= 12 || month % 60 === 0 || month === term) { // Show first year, every 5 years, and last payment
        schedule.push({
          month,
          payment: monthlyPayment,
          principal: principalPayment,
          interest: interestPayment,
          balance: Math.max(0, balance)
        });
      }
    }
    
    setResult({
      monthlyPayment,
      totalPayment,
      totalInterest,
      amortizationSchedule: schedule
    });
    
    toast.success("Mortgage calculation complete!");
  };
  
  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
    });
  };
  
  return (
    <ToolLayout
      title="Mortgage Calculator"
      description="Calculate your mortgage payments, interest costs, and amortization schedule"
      helpText="Enter loan details to calculate your mortgage payments, total interest, and see how your loan is paid off over time"
    >
      <Helmet>
        <title>Mortgage Calculator | Home Loan Payment Calculator | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate your monthly mortgage payments, total interest costs, and view an amortization schedule with our free mortgage calculator."
        />
        <meta
          name="keywords"
          content="mortgage calculator, home loan calculator, mortgage payment, mortgage amortization, housing loan"
        />
      </Helmet>

      <div className="space-y-6 max-w-3xl mx-auto">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Home className="mr-2 text-purple-600" />
            Calculate Mortgage Payments
          </h2>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="loanAmount" className="block text-sm font-medium text-gray-700">
                Home Price ($)
              </label>
              <Input
                id="loanAmount"
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                placeholder="Enter home price"
                className="w-full"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="downPayment" className="block text-sm font-medium text-gray-700">
                Down Payment ($)
              </label>
              <Input
                id="downPayment"
                type="number"
                value={downPayment}
                onChange={(e) => setDownPayment(e.target.value)}
                placeholder="Enter down payment amount"
                className="w-full"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700">
                Interest Rate (% per annum)
              </label>
              <Input
                id="interestRate"
                type="number"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                placeholder="Enter interest rate"
                className="w-full"
                step="0.01"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="loanTerm" className="block text-sm font-medium text-gray-700">
                Loan Term (years)
              </label>
              <Input
                id="loanTerm"
                type="number"
                value={loanTerm}
                onChange={(e) => setLoanTerm(e.target.value)}
                placeholder="Enter loan term in years"
                className="w-full"
              />
            </div>
            
            <Button 
              onClick={calculateMortgage}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              <Calculator className="mr-2 h-4 w-4" /> Calculate Mortgage
            </Button>
          </div>
        </Card>
        
        {result && (
          <>
            <Card className="p-6 bg-gray-50">
              <h3 className="font-bold text-lg mb-4">Mortgage Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <p className="text-sm text-gray-600">Monthly Payment</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {formatCurrency(result.monthlyPayment)}
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <p className="text-sm text-gray-600">Total Interest</p>
                  <p className="text-2xl font-bold text-red-600">
                    {formatCurrency(result.totalInterest)}
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <p className="text-sm text-gray-600">Total Payment</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {formatCurrency(result.totalPayment)}
                  </p>
                </div>
              </div>
            </Card>
            
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4">Amortization Schedule</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr>
                      <th className="px-4 py-2 bg-gray-50 text-left">Month</th>
                      <th className="px-4 py-2 bg-gray-50 text-right">Payment</th>
                      <th className="px-4 py-2 bg-gray-50 text-right">Principal</th>
                      <th className="px-4 py-2 bg-gray-50 text-right">Interest</th>
                      <th className="px-4 py-2 bg-gray-50 text-right">Remaining Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.amortizationSchedule.map((item) => (
                      <tr key={item.month} className="border-t">
                        <td className="px-4 py-2">{item.month}</td>
                        <td className="px-4 py-2 text-right">{formatCurrency(item.payment)}</td>
                        <td className="px-4 py-2 text-right">{formatCurrency(item.principal)}</td>
                        <td className="px-4 py-2 text-right">{formatCurrency(item.interest)}</td>
                        <td className="px-4 py-2 text-right">{formatCurrency(item.balance)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                * Showing first year, every 5 years, and final payment
              </p>
            </Card>
          </>
        )}
        
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <h2 className="text-xl font-bold mb-4">About Mortgage Calculations</h2>
          <p className="mb-4">
            A mortgage is a loan used to purchase or maintain a home, land, or other types of real estate. 
            The borrower agrees to pay the lender over time, typically in a series of regular payments that 
            are divided into principal and interest.
          </p>
          
          <h3 className="text-lg font-medium mb-2">Understanding Mortgage Terms</h3>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><strong>Principal:</strong> The original amount of the loan.</li>
            <li><strong>Interest Rate:</strong> The percentage charged on the principal.</li>
            <li><strong>Down Payment:</strong> Initial upfront payment toward the home purchase.</li>
            <li><strong>Loan Term:</strong> The time period for repaying the loan (typically 15 or 30 years).</li>
            <li><strong>Amortization:</strong> The process of paying off a loan with regular payments.</li>
          </ul>
          
          <h3 className="text-lg font-medium mb-2">Factors Affecting Mortgage Payments</h3>
          <p>
            Your monthly mortgage payment depends on several factors: loan amount, interest rate, loan term, 
            and down payment. Increasing your down payment or extending your loan term can lower your monthly 
            payments, but extending the term will increase the total interest paid over the life of the loan.
          </p>
        </div>
      </div>
    </ToolLayout>
  );
};

const MortgageCalculator = withErrorBoundary(MortgageCalculatorComponent, "mortgage-calculator");

export default MortgageCalculator;
