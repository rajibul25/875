
import { useState, useRef } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Upload, Download, FileImage, Trash2 } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";

const WebpConverterComponent = () => {
  const [files, setFiles] = useState<{ file: File; url: string; status: string }[]>([]);
  const [convertType, setConvertType] = useState<"to-webp" | "from-webp">("to-webp");
  const [quality, setQuality] = useState<number>(80);
  const [compress, setCompress] = useState<boolean>(true);
  const [isConverting, setIsConverting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (!selectedFiles.length) return;

    // Filter files based on conversion type
    let validFiles: File[] = [];
    if (convertType === "to-webp") {
      validFiles = selectedFiles.filter(file => 
        file.type === "image/jpeg" || 
        file.type === "image/png" || 
        file.type === "image/gif"
      );
    } else {
      validFiles = selectedFiles.filter(file => file.type === "image/webp");
    }

    if (validFiles.length !== selectedFiles.length) {
      toast.warning(`${selectedFiles.length - validFiles.length} files were skipped because they have unsupported formats`);
    }

    // Create preview URLs for each image
    const newFiles = validFiles.map(file => ({
      file,
      url: URL.createObjectURL(file),
      status: "ready" // ready, converting, converted, error
    }));

    setFiles(prev => [...prev, ...newFiles]);
    
    // Reset the input value so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    toast.success(`Added ${validFiles.length} images`);
  };

  const removeFile = (index: number) => {
    setFiles(prev => {
      const newFiles = [...prev];
      // Revoke the URL to prevent memory leaks
      URL.revokeObjectURL(newFiles[index].url);
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const clearAllFiles = () => {
    // Revoke all URLs to prevent memory leaks
    files.forEach(file => URL.revokeObjectURL(file.url));
    setFiles([]);
  };

  const handleConvert = async () => {
    if (files.length === 0) {
      toast.error("Please add at least one image to convert");
      return;
    }

    setIsConverting(true);
    
    try {
      // Update status to "converting" for all files
      setFiles(prev => prev.map(file => ({ ...file, status: "converting" })));
      
      // Simulate conversion process with a delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Update status to "converted" for all files
      setFiles(prev => prev.map(file => ({ ...file, status: "converted" })));
      
      toast.success(`Successfully converted ${files.length} ${files.length === 1 ? "image" : "images"}`);
    } catch (error) {
      toast.error("An error occurred during conversion");
      console.error(error);
      
      // Update status to "error" for all files
      setFiles(prev => prev.map(file => ({ ...file, status: "error" })));
    } finally {
      setIsConverting(false);
    }
  };

  const downloadAll = () => {
    const convertedFiles = files.filter(f => f.status === "converted");
    if (convertedFiles.length === 0) {
      toast.error("No converted files to download");
      return;
    }
    
    // In a real implementation, we would generate actual WebP files
    // For now, we'll just simulate download using the original images
    toast.success(`Downloading ${convertedFiles.length} ${convertedFiles.length === 1 ? "file" : "files"}...`);
    
    // For demo purposes, we'll download the first image
    if (convertedFiles.length > 0) {
      const link = document.createElement('a');
      link.href = convertedFiles[0].url;
      link.download = convertType === "to-webp" 
        ? convertedFiles[0].file.name.replace(/\.[^/.]+$/, "") + ".webp"
        : convertedFiles[0].file.name.replace(/\.webp$/, "") + ".png";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <ToolLayout
      title="WebP Converter"
      description="Convert images to and from WebP format. Support for JPG, PNG, and GIF to WebP conversion and WebP to PNG conversion."
      helpText="WebP is a modern image format that provides superior lossless and lossy compression for images on the web. This tool helps you convert between WebP and traditional formats."
    >
      <div className="space-y-8">
        <Tabs defaultValue="to-webp" onValueChange={(v) => setConvertType(v as "to-webp" | "from-webp")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="to-webp">Convert to WebP</TabsTrigger>
            <TabsTrigger value="from-webp">Convert from WebP</TabsTrigger>
          </TabsList>
          
          <TabsContent value="to-webp" className="mt-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-blue-800 dark:text-blue-300">About WebP Format</h3>
              <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
                WebP offers superior compression and quality characteristics compared to JPG and PNG. 
                Images converted to WebP are typically 25-35% smaller than JPG with equivalent quality.
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="from-webp" className="mt-4">
            <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-purple-800 dark:text-purple-300">Converting from WebP</h3>
              <p className="text-sm text-purple-700 dark:text-purple-400 mt-1">
                While WebP offers excellent compression, some applications or platforms may not support it. 
                This option converts your WebP images to PNG format for maximum compatibility.
              </p>
            </div>
          </TabsContent>
        </Tabs>
        
        <div>
          <h2 className="text-xl font-semibold mb-4">1. Upload Images</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept={convertType === "to-webp" ? "image/jpeg,image/png,image/gif" : "image/webp"}
              multiple
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select Images</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              {convertType === "to-webp" 
                ? "PNG, JPG, or GIF files. Maximum size: 10MB per image." 
                : "WebP files. Maximum size: 10MB per image."}
            </p>
          </div>
        </div>

        {files.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">2. Configure Settings</h2>
            
            {convertType === "to-webp" && (
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="quality" className="text-sm font-medium mb-1">
                      Image Quality: {quality}%
                    </Label>
                  </div>
                  <Slider
                    id="quality"
                    value={[quality]}
                    onValueChange={(value) => setQuality(value[0])}
                    min={10}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Lower quality = smaller file size. Higher quality = better image.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="compress"
                    checked={compress}
                    onCheckedChange={setCompress}
                  />
                  <Label htmlFor="compress">Optimize & compress</Label>
                </div>
              </div>
            )}
            
            {convertType === "from-webp" && (
              <div>
                <RadioGroup defaultValue="png">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="png" id="png" />
                    <Label htmlFor="png">Convert to PNG (best quality, larger size)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="jpg" id="jpg" />
                    <Label htmlFor="jpg">Convert to JPG (smaller size, some quality loss)</Label>
                  </div>
                </RadioGroup>
              </div>
            )}
          </div>
        )}

        {files.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">3. Images to Convert</h2>
              <Button
                onClick={clearAllFiles}
                variant="outline"
                size="sm"
              >
                <Trash2 className="h-4 w-4 mr-1" /> Clear All
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {files.map((file, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-3">
                    <div className="relative aspect-square">
                      <img
                        src={file.url}
                        alt={`Image ${index + 1}`}
                        className="w-full h-full object-contain rounded"
                      />
                      <button
                        onClick={() => removeFile(index)}
                        className="absolute top-2 right-2 bg-black/60 p-1 rounded-full"
                      >
                        <svg className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <line x1="18" y1="6" x2="6" y2="18" />
                          <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                      </button>
                      
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs py-1 px-3">
                        <div className="text-xs truncate">{file.file.name}</div>
                        
                        <div className="flex items-center justify-between mt-1">
                          <span>{(file.file.size / 1024).toFixed(1)}KB</span>
                          
                          {file.status === "ready" && (
                            <span className="text-gray-300">Ready</span>
                          )}
                          {file.status === "converting" && (
                            <span className="text-blue-300">Converting...</span>
                          )}
                          {file.status === "converted" && (
                            <span className="text-green-300">Converted</span>
                          )}
                          {file.status === "error" && (
                            <span className="text-red-300">Error</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {files.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={handleConvert}
              disabled={isConverting || files.length === 0}
              className="flex-1"
            >
              {isConverting 
                ? "Converting..." 
                : `Convert ${files.length} ${files.length === 1 ? "Image" : "Images"}`}
            </Button>
            
            <Button
              onClick={downloadAll}
              disabled={!files.some(f => f.status === "converted")}
              variant="outline"
              className="flex-1"
            >
              <Download className="mr-2 h-4 w-4" />
              Download All
            </Button>
          </div>
        )}

        <AdBanner />

        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What is WebP format?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                WebP is a modern image format developed by Google that provides superior lossless and lossy compression for images on the web. 
                WebP images are typically 25-35% smaller than JPG images of equivalent quality, resulting in faster website loading times.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Which browsers support WebP?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                WebP is supported by Google Chrome, Firefox, Edge, Opera, and Safari (on macOS Big Sur and later). 
                However, some older browsers and applications may not support WebP, which is why our tool also allows you to convert WebP back to traditional formats like PNG.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What's the difference between WebP and JPEG/PNG?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                WebP offers both lossy compression (like JPEG) and lossless compression (like PNG) in a single format. 
                WebP lossy files are typically 25-35% smaller than JPEG files of similar quality, and WebP lossless files are 26% smaller than PNG files.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Is there any quality loss when converting to WebP?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                When using lossy compression, there is some quality loss, but WebP achieves better quality-to-size ratios than JPEG. 
                You can adjust the quality setting in our converter to balance between file size and image quality. 
                Using lossless WebP compression maintains the original image quality with no loss.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Why should I use WebP for my website?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Using WebP can significantly reduce the size of your image files while maintaining visual quality, 
                resulting in faster website loading times, better user experience, and improved SEO rankings as 
                Google considers page speed as a ranking factor.
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const WebpConverter = withErrorBoundary(WebpConverterComponent, "webp-converter");

export default WebpConverter;
