
import React, { useState, useRef, useEffect } from "react";
import { Helmet } from "react-helmet";
import { ImageIcon, Download, RefreshCw, Type, Upload, Sliders, Check, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import ToolLayout from "@/components/tools/ToolLayout";

const MemeGenerator = () => {
  const [topText, setTopText] = useState("");
  const [bottomText, setBottomText] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState(40);
  const [fontColor, setFontColor] = useState("#ffffff");
  const [strokeColor, setStrokeColor] = useState("#000000");
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [fontFamily, setFontFamily] = useState("Impact");
  const [useUppercase, setUseUppercase] = useState(true);
  const [textAlign, setTextAlign] = useState("center");
  const [topTextPaddingTop, setTopTextPaddingTop] = useState(20);
  const [bottomTextPaddingBottom, setBottomTextPaddingBottom] = useState(20);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Stock meme templates
  const memeTemplates = [
    { id: "drake", name: "Drake Hotline Bling", url: "https://i.imgflip.com/30b1gx.jpg" },
    { id: "distracted", name: "Distracted Boyfriend", url: "https://i.imgflip.com/1ur9b0.jpg" },
    { id: "twobuttons", name: "Two Buttons", url: "https://i.imgflip.com/1g8my4.jpg" },
    { id: "expanding", name: "Expanding Brain", url: "https://i.imgflip.com/1jwhww.jpg" },
    { id: "changemymind", name: "Change My Mind", url: "https://i.imgflip.com/24y43o.jpg" },
    { id: "doge", name: "Doge", url: "https://i.imgflip.com/4t0m5.jpg" },
    { id: "spongebob", name: "Evil Kermit", url: "https://i.imgflip.com/1e7ql7.jpg" },
    { id: "buttons", name: "Running Away Balloon", url: "https://i.imgflip.com/261o3j.jpg" },
    { id: "roll", name: "Roll Safe Think About It", url: "https://i.imgflip.com/1h7in3.jpg" },
    { id: "wonka", name: "Condescending Wonka", url: "https://i.imgflip.com/ww55o.jpg" },
  ];
  
  const fontOptions = [
    { value: "Impact", label: "Impact" },
    { value: "Arial", label: "Arial" },
    { value: "Helvetica", label: "Helvetica" },
    { value: "Comic Sans MS", label: "Comic Sans" },
    { value: "Courier New", label: "Courier New" },
    { value: "Times New Roman", label: "Times New Roman" },
  ];
  
  const alignOptions = [
    { value: "left", label: "Left" },
    { value: "center", label: "Center" },
    { value: "right", label: "Right" },
  ];
  
  useEffect(() => {
    // Set a default template
    if (!selectedImage) {
      setSelectedImage(memeTemplates[0].url);
    }
  }, []);
  
  useEffect(() => {
    if (selectedImage) {
      generateMeme();
    }
  }, [
    selectedImage, 
    topText, 
    bottomText, 
    fontSize, 
    fontColor, 
    strokeColor, 
    strokeWidth, 
    fontFamily, 
    useUppercase, 
    textAlign,
    topTextPaddingTop,
    bottomTextPaddingBottom
  ]);
  
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setSelectedImage(result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const useTemplate = (templateUrl: string) => {
    setSelectedImage(templateUrl);
  };
  
  const drawText = (
    context: CanvasRenderingContext2D, 
    text: string, 
    x: number, 
    y: number, 
    maxWidth: number
  ) => {
    context.save();
    context.font = `${fontSize}px ${fontFamily}`;
    context.fillStyle = fontColor;
    context.strokeStyle = strokeColor;
    context.lineWidth = strokeWidth;
    context.textAlign = textAlign as CanvasTextAlign;
    
    let processedText = text;
    if (useUppercase) {
      processedText = text.toUpperCase();
    }
    
    // Word wrap logic
    const words = processedText.split(' ');
    let line = '';
    const lineHeight = fontSize * 1.1;
    let posY = y;
    let posX = x;
    
    if (textAlign === "left") {
      posX = 20;
    } else if (textAlign === "right") {
      posX = maxWidth - 20;
    }
    
    for (let i = 0; i < words.length; i++) {
      const testLine = line + words[i] + ' ';
      const metrics = context.measureText(testLine);
      const testWidth = metrics.width;
      
      if (testWidth > maxWidth - 40 && i > 0) {
        context.strokeText(line, posX, posY);
        context.fillText(line, posX, posY);
        line = words[i] + ' ';
        posY += lineHeight;
      } else {
        line = testLine;
      }
    }
    
    context.strokeText(line, posX, posY);
    context.fillText(line, posX, posY);
    context.restore();
  };
  
  const generateMeme = () => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext('2d');
    
    if (!canvas || !context || !selectedImage) return;
    
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => {
      // Set canvas dimensions to match image
      canvas.width = image.width;
      canvas.height = image.height;
      
      // Draw image
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      
      // Draw top text
      if (topText) {
        drawText(
          context,
          topText,
          canvas.width / 2,
          topTextPaddingTop + fontSize / 2,
          canvas.width
        );
      }
      
      // Draw bottom text
      if (bottomText) {
        drawText(
          context,
          bottomText,
          canvas.width / 2,
          canvas.height - bottomTextPaddingBottom,
          canvas.width
        );
      }
    };
    
    image.onerror = () => {
      toast.error("Failed to load image. Try another one.");
    };
    
    image.src = selectedImage;
  };
  
  const downloadMeme = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Convert canvas to data URL
    const dataURL = canvas.toDataURL("image/png");
    
    // Create download link
    const link = document.createElement("a");
    link.href = dataURL;
    link.download = "meme.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("Meme downloaded successfully!");
  };
  
  const openFileUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  return (
    <ToolLayout
      title="Meme Generator"
      description="Create custom memes with your own images and text."
      helpText="Choose a template or upload your own image, then add top and bottom text. Customize font, color, and size to create the perfect meme."
    >
      <Helmet>
        <title>Free Online Meme Generator - Create Custom Memes | MultiToolSet</title>
        <meta name="description" content="Create custom memes online for free with our easy-to-use meme generator. Add text to templates or upload your own images. Perfect for social media and sharing." />
        <meta name="keywords" content="meme generator, custom memes, funny memes, meme maker, meme creator, image editor, social media content" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Meme Generator",
              "applicationCategory": "WebApplication",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "operatingSystem": "Any",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "183"
              }
            }
          `}
        </script>
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Meme Settings</h2>
            
            <div className="flex flex-col space-y-4">
              <div className="flex flex-col space-y-2">
                <Label htmlFor="topText">Top Text</Label>
                <Input
                  id="topText"
                  value={topText}
                  onChange={(e) => setTopText(e.target.value)}
                  placeholder="Top text"
                />
              </div>
              
              <div className="flex flex-col space-y-2">
                <Label htmlFor="bottomText">Bottom Text</Label>
                <Input
                  id="bottomText"
                  value={bottomText}
                  onChange={(e) => setBottomText(e.target.value)}
                  placeholder="Bottom text"
                />
              </div>
            </div>
            
            <Tabs defaultValue="templates">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="templates">Templates</TabsTrigger>
                <TabsTrigger value="upload">Upload Image</TabsTrigger>
              </TabsList>
              
              <TabsContent value="templates" className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-2">
                  {memeTemplates.map((template) => (
                    <div
                      key={template.id}
                      className={`relative cursor-pointer rounded-lg overflow-hidden border-2 ${
                        selectedImage === template.url ? 'border-primary' : 'border-transparent'
                      }`}
                      onClick={() => useTemplate(template.url)}
                    >
                      <img
                        src={template.url}
                        alt={template.name}
                        className="w-full h-24 object-cover"
                      />
                      {selectedImage === template.url && (
                        <div className="absolute top-1 right-1 bg-primary text-white rounded-full p-1">
                          <Check className="h-3 w-3" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="upload">
                <div className="mt-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <Button
                    onClick={openFileUpload}
                    variant="outline"
                    className="w-full h-32 border-dashed flex flex-col items-center justify-center space-y-2"
                  >
                    <Upload className="h-8 w-8 text-gray-400" />
                    <span>Click to upload an image</span>
                    <span className="text-xs text-gray-500">Supports JPG, PNG, GIF</span>
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
            
            <Tabs defaultValue="text" className="mt-4">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="text">Text Style</TabsTrigger>
                <TabsTrigger value="position">Position</TabsTrigger>
              </TabsList>
              
              <TabsContent value="text" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fontFamily">Font Family</Label>
                    <Select value={fontFamily} onValueChange={setFontFamily}>
                      <SelectTrigger id="fontFamily">
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent>
                        {fontOptions.map((font) => (
                          <SelectItem key={font.value} value={font.value}>
                            {font.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="fontSize">Font Size: {fontSize}px</Label>
                    </div>
                    <Slider
                      id="fontSize"
                      min={16}
                      max={80}
                      step={2}
                      value={[fontSize]}
                      onValueChange={(value) => setFontSize(value[0])}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="fontColor">Font Color</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        id="fontColor"
                        type="color"
                        value={fontColor}
                        onChange={(e) => setFontColor(e.target.value)}
                        className="w-12 h-8 p-1"
                      />
                      <Input 
                        value={fontColor} 
                        onChange={(e) => setFontColor(e.target.value)}
                        className="flex-grow"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="strokeColor">Stroke Color</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        id="strokeColor"
                        type="color"
                        value={strokeColor}
                        onChange={(e) => setStrokeColor(e.target.value)}
                        className="w-12 h-8 p-1"
                      />
                      <Input 
                        value={strokeColor} 
                        onChange={(e) => setStrokeColor(e.target.value)}
                        className="flex-grow"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="strokeWidth">Stroke Width: {strokeWidth}px</Label>
                    </div>
                    <Slider
                      id="strokeWidth"
                      min={0}
                      max={5}
                      step={0.5}
                      value={[strokeWidth]}
                      onValueChange={(value) => setStrokeWidth(value[0])}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="textAlign">Text Alignment</Label>
                    <Select value={textAlign} onValueChange={setTextAlign}>
                      <SelectTrigger id="textAlign">
                        <SelectValue placeholder="Select alignment" />
                      </SelectTrigger>
                      <SelectContent>
                        {alignOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="uppercase"
                      checked={useUppercase}
                      onCheckedChange={setUseUppercase}
                    />
                    <Label htmlFor="uppercase">ALL CAPS Text</Label>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="position" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="topTextPadding">Top Text Padding: {topTextPaddingTop}px</Label>
                    </div>
                    <Slider
                      id="topTextPadding"
                      min={0}
                      max={100}
                      step={5}
                      value={[topTextPaddingTop]}
                      onValueChange={(value) => setTopTextPaddingTop(value[0])}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="bottomTextPadding">Bottom Text Padding: {bottomTextPaddingBottom}px</Label>
                    </div>
                    <Slider
                      id="bottomTextPadding"
                      min={0}
                      max={100}
                      step={5}
                      value={[bottomTextPaddingBottom]}
                      onValueChange={(value) => setBottomTextPaddingBottom(value[0])}
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-6 flex flex-col">
          <h2 className="text-xl font-semibold mb-4">Preview</h2>
          
          <div className="flex-grow flex items-center justify-center bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 p-4 mb-4">
            <div className="relative max-w-full max-h-[60vh] overflow-auto">
              <canvas ref={canvasRef} className="max-w-full"></canvas>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <Button 
              variant="outline" 
              onClick={generateMeme}
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Regenerate
            </Button>
            
            <Button 
              onClick={downloadMeme}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Download Meme
            </Button>
          </div>
        </div>
      </div>
      
      <Separator className="my-8" />
      
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Tips for Creating Great Memes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Keep It Short</h3>
            <p className="text-gray-600 dark:text-gray-300">
              The best memes have short, punchy text that can be read quickly. Avoid lengthy paragraphs.
            </p>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Contrast Matters</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Make sure your text contrasts well with the background image. Use stroke to improve readability.
            </p>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Know Your Audience</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Different platforms have different meme cultures. What works on Reddit might not work on Instagram.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-100 dark:border-blue-800">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <Info className="h-5 w-5 mr-2 text-blue-500" />
          Frequently Asked Questions
        </h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">Can I use these memes commercially?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              While our tool is free to use, the images you use may be subject to copyright. Always check the license of templates or use your own images for commercial purposes.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">What image formats can I upload?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              You can upload JPEG, PNG, and GIF images to use as meme templates.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">How do I share my meme on social media?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              Download your created meme using the download button, then upload it to your preferred social media platform.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">Are my uploaded images stored on your servers?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              No, all image processing is done client-side in your browser. We don't store your images on our servers.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <a href="/tools/image-resizer" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Image Resizer</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Resize your images to exact dimensions</p>
            </div>
          </a>
          
          <a href="/tools/image-compressor" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Image Compressor</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Reduce file size of your images</p>
            </div>
          </a>
          
          <a href="/tools/image-to-png" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Image to PNG Converter</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Convert images to PNG format</p>
            </div>
          </a>
        </div>
      </div>
    </ToolLayout>
  );
};

export default MemeGenerator;
