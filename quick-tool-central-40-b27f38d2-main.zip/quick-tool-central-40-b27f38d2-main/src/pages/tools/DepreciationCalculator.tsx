
import { useState } from "react";
import { ArrowRight, Calculator, DollarSign, Clock, LineChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import AdBanner from "@/components/AdBanner";
import { Helmet } from "react-helmet";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type DepreciationMethod = "straight-line" | "declining-balance" | "sum-of-years-digits" | "units-of-production";

interface DepreciationResult {
  year: number;
  beginningValue: number;
  depreciation: number;
  accumulatedDepreciation: number;
  endingValue: number;
}

const DepreciationCalculator = () => {
  const [assetCost, setAssetCost] = useState<string>("");
  const [salvageValue, setSalvageValue] = useState<string>("");
  const [usefulLife, setUsefulLife] = useState<string>("");
  const [depreciationMethod, setDepreciationMethod] = useState<DepreciationMethod>("straight-line");
  const [depreciationRate, setDepreciationRate] = useState<string>("200"); // for declining balance (default 200%)
  const [results, setResults] = useState<DepreciationResult[]>([]);
  const { toast } = useToast();

  const calculateDepreciation = () => {
    const cost = parseFloat(assetCost);
    const salvage = parseFloat(salvageValue);
    const life = parseInt(usefulLife);
    const rate = parseFloat(depreciationRate) / 100;
    
    if (isNaN(cost) || isNaN(salvage) || isNaN(life)) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter valid numbers for all fields."
      });
      return;
    }
    
    if (cost <= 0 || life <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Asset cost and useful life must be greater than zero."
      });
      return;
    }
    
    if (salvage >= cost) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Salvage value must be less than the asset cost."
      });
      return;
    }
    
    const depreciableAmount = cost - salvage;
    const resultArray: DepreciationResult[] = [];
    
    switch (depreciationMethod) {
      case "straight-line":
        // Calculate straight-line depreciation
        const annualDepreciation = depreciableAmount / life;
        
        for (let year = 1; year <= life; year++) {
          const beginningValue = year === 1 ? cost : resultArray[year - 2].endingValue;
          const depreciation = annualDepreciation;
          const accumulatedDepreciation = year === 1 ? depreciation : resultArray[year - 2].accumulatedDepreciation + depreciation;
          const endingValue = cost - accumulatedDepreciation;
          
          resultArray.push({
            year,
            beginningValue,
            depreciation,
            accumulatedDepreciation,
            endingValue
          });
        }
        break;
        
      case "declining-balance":
        // Calculate declining balance depreciation
        const straightLineRate = 1 / life;
        const dbRate = Math.min(rate * straightLineRate, 1); // Prevent rate from exceeding 100%
        
        for (let year = 1; year <= life; year++) {
          const beginningValue = year === 1 ? cost : resultArray[year - 2].endingValue;
          
          // Switch to straight-line for remaining years if it gives a higher depreciation
          const remainingLife = life - year + 1;
          const remainingValueToDepreciate = beginningValue - salvage;
          const straightLineForRemaining = remainingValueToDepreciate / remainingLife;
          
          const decliningBalanceDepreciation = beginningValue * dbRate;
          const depreciation = Math.min(
            Math.max(decliningBalanceDepreciation, straightLineForRemaining),
            beginningValue - salvage
          );
          
          const accumulatedDepreciation = year === 1 ? depreciation : resultArray[year - 2].accumulatedDepreciation + depreciation;
          const endingValue = Math.max(cost - accumulatedDepreciation, salvage);
          
          resultArray.push({
            year,
            beginningValue,
            depreciation,
            accumulatedDepreciation,
            endingValue
          });
          
          // Stop if fully depreciated to salvage value
          if (endingValue <= salvage + 0.01) break;
        }
        break;
        
      case "sum-of-years-digits":
        // Calculate sum-of-years-digits depreciation
        const sumOfYears = (life * (life + 1)) / 2;
        
        for (let year = 1; year <= life; year++) {
          const beginningValue = year === 1 ? cost : resultArray[year - 2].endingValue;
          const factor = (life - year + 1) / sumOfYears;
          const depreciation = depreciableAmount * factor;
          const accumulatedDepreciation = year === 1 ? depreciation : resultArray[year - 2].accumulatedDepreciation + depreciation;
          const endingValue = cost - accumulatedDepreciation;
          
          resultArray.push({
            year,
            beginningValue,
            depreciation,
            accumulatedDepreciation,
            endingValue
          });
        }
        break;
    }
    
    setResults(resultArray);
    
    toast({
      title: "Calculation complete",
      description: "Depreciation schedule has been calculated successfully."
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateDepreciation();
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Depreciation Calculator - Calculate Asset Depreciation | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate asset depreciation using different methods including straight-line, declining balance, and sum-of-years-digits with our free depreciation calculator."
        />
        <meta
          name="keywords"
          content="depreciation calculator, asset depreciation, straight-line depreciation, declining balance, sum-of-years-digits, business calculator"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/depreciation-calculator" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Depreciation Calculator",
            "applicationCategory": "BusinessApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "operatingSystem": "All",
            "description": "Free online depreciation calculator. Calculate asset depreciation using various methods for accounting and tax purposes."
          })}
        </script>
      </Helmet>
      
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <BackButton />
          <h1 className="text-3xl font-bold text-center lg:text-left">Depreciation Calculator</h1>
          <div className="w-[70px]"></div> {/* Empty div for alignment */}
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <LineChart className="mr-2 text-tool-purple" />
              Calculate Asset Depreciation
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Calculate the depreciation of your assets using different methods to understand how their value decreases over time.
            </p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Asset Cost ($)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        type="number"
                        placeholder="Enter asset cost"
                        value={assetCost}
                        onChange={(e) => setAssetCost(e.target.value)}
                        className="pl-9"
                        step="0.01"
                        min="0"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Salvage Value ($)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        type="number"
                        placeholder="Enter salvage value"
                        value={salvageValue}
                        onChange={(e) => setSalvageValue(e.target.value)}
                        className="pl-9"
                        step="0.01"
                        min="0"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Useful Life (Years)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        type="number"
                        placeholder="Enter useful life in years"
                        value={usefulLife}
                        onChange={(e) => setUsefulLife(e.target.value)}
                        className="pl-9"
                        min="1"
                        max="100"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Depreciation Method
                    </label>
                    <Select 
                      value={depreciationMethod}
                      onValueChange={(value) => setDepreciationMethod(value as DepreciationMethod)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="straight-line">Straight-Line</SelectItem>
                        <SelectItem value="declining-balance">Declining Balance</SelectItem>
                        <SelectItem value="sum-of-years-digits">Sum-of-Years-Digits</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {depreciationMethod === "declining-balance" && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Declining Balance Rate (%)
                      </label>
                      <Input
                        type="number"
                        placeholder="200 for double-declining balance"
                        value={depreciationRate}
                        onChange={(e) => setDepreciationRate(e.target.value)}
                        min="100"
                        max="400"
                      />
                      <p className="text-xs text-gray-500 mt-1">200% for double-declining, 150% for 1.5x declining</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button 
                  type="submit" 
                  className="gap-2 bg-tool-purple hover:bg-tool-purple/90"
                >
                  Calculate Depreciation
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </form>
            
            {results.length > 0 && (
              <div className="mt-8 pt-6 border-t overflow-x-auto">
                <h3 className="text-lg font-medium mb-4">Depreciation Schedule</h3>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Year</TableHead>
                      <TableHead>Beginning Value</TableHead>
                      <TableHead>Depreciation</TableHead>
                      <TableHead>Accumulated Depreciation</TableHead>
                      <TableHead>Ending Value</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.map((result) => (
                      <TableRow key={result.year}>
                        <TableCell>{result.year}</TableCell>
                        <TableCell>{formatCurrency(result.beginningValue)}</TableCell>
                        <TableCell>{formatCurrency(result.depreciation)}</TableCell>
                        <TableCell>{formatCurrency(result.accumulatedDepreciation)}</TableCell>
                        <TableCell>{formatCurrency(result.endingValue)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </Card>
          
          <AdBanner className="my-8" />
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">What is a Depreciation Calculator?</h2>
            <p className="mb-4">
              A depreciation calculator is a financial tool that helps businesses and individuals track how an asset loses value over time. It calculates the annual depreciation expense and book value of an asset throughout its useful life.
            </p>
            
            <h3 className="text-lg font-medium mb-2">Why Calculate Depreciation?</h3>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Accurately report asset values on financial statements</li>
              <li>Plan for asset replacement and maintenance</li>
              <li>Claim depreciation tax deductions</li>
              <li>Calculate business expenses for tax purposes</li>
              <li>Determine the book value of assets at any point in time</li>
            </ul>
            
            <h3 className="text-lg font-medium mb-2">Depreciation Methods Explained</h3>
            <div className="space-y-3">
              <div>
                <h4 className="font-medium">Straight-Line Depreciation</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  The most straightforward method, dividing the depreciable cost equally over the asset's useful life. 
                  Annual Depreciation = (Asset Cost - Salvage Value) / Useful Life
                </p>
              </div>
              
              <div>
                <h4 className="font-medium">Declining Balance Depreciation</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  Accelerates depreciation in the early years by applying a constant rate to the remaining book value.
                  Annual Depreciation = Book Value × Rate
                </p>
              </div>
              
              <div>
                <h4 className="font-medium">Sum-of-Years-Digits Depreciation</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  Another accelerated method using a fraction based on the sum of the years. 
                  Annual Depreciation = (Remaining Life / Sum of Years) × Depreciable Cost
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">What is salvage value?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Salvage value (or residual value) is the estimated amount an asset is worth at the end of its useful life. It represents how much you could sell the asset for after it's fully depreciated.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Which depreciation method should I use?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  The choice depends on your needs and the nature of the asset. Straight-line is simple and commonly used for most assets. Accelerated methods like declining balance may be preferred for assets that lose value quickly early in their life, like technology equipment.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Can I change depreciation methods?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  For tax purposes, changing depreciation methods typically requires IRS approval. For financial reporting, companies can change methods if the new method better represents the asset's consumption pattern.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How does depreciation affect taxes?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Depreciation is a tax-deductible expense that reduces taxable income. The IRS has specific rules (MACRS) regarding depreciation methods and useful life for different asset categories.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What's the difference between book depreciation and tax depreciation?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Book depreciation is used for financial reporting and can use any reasonable method. Tax depreciation follows IRS rules and is used to calculate tax deductions. Companies often maintain separate calculations for each.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default DepreciationCalculator;
