
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Search, Copy, Download, AlertCircle, ExternalLink, Check } from "lucide-react";
import { toast } from "sonner";
import AdBanner from "@/components/AdBanner";

interface UrlAnalysisResult {
  url: string;
  protocol: string;
  domain: string;
  path: string;
  queryParams: Record<string, string>;
  hasHttps: boolean;
  hasWww: boolean;
  hasFavicon: boolean;
  hasTrailingSlash: boolean;
  hasQueryParams: boolean;
  hasFragment: boolean;
  fragment: string;
  isRelative: boolean;
  isAbsolute: boolean;
}

const UrlAnalyzer = () => {
  const [url, setUrl] = useState("");
  const [results, setResults] = useState<UrlAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const analyzeUrl = () => {
    if (!url.trim()) {
      setError("Please enter a URL to analyze");
      return;
    }

    setIsLoading(true);
    setError("");

    // Give a slight delay to show loading state
    setTimeout(() => {
      try {
        let urlToAnalyze = url.trim();
        
        // If the URL doesn't start with http:// or https://, add https://
        if (!/^https?:\/\//i.test(urlToAnalyze)) {
          urlToAnalyze = "https://" + urlToAnalyze;
        }

        const parsedUrl = new URL(urlToAnalyze);
        
        // Extract query parameters
        const queryParams: Record<string, string> = {};
        parsedUrl.searchParams.forEach((value, key) => {
          queryParams[key] = value;
        });

        const analysis: UrlAnalysisResult = {
          url: urlToAnalyze,
          protocol: parsedUrl.protocol,
          domain: parsedUrl.hostname,
          path: parsedUrl.pathname,
          queryParams,
          hasHttps: parsedUrl.protocol === "https:",
          hasWww: parsedUrl.hostname.startsWith("www."),
          hasFavicon: true, // We can't actually check this without fetching the page
          hasTrailingSlash: parsedUrl.pathname.endsWith("/") && parsedUrl.pathname.length > 1,
          hasQueryParams: parsedUrl.search.length > 0,
          hasFragment: parsedUrl.hash.length > 0,
          fragment: parsedUrl.hash,
          isRelative: false, // We converted relative URLs to absolute
          isAbsolute: true   // We're only handling absolute URLs
        };

        setResults(analysis);
        setIsLoading(false);
      } catch (err) {
        setError("Invalid URL. Please enter a valid URL to analyze.");
        setIsLoading(false);
      }
    }, 500);
  };

  const copyToClipboard = () => {
    if (!results) return;
    
    const textToCopy = `
URL Analysis Results:
- URL: ${results.url}
- Protocol: ${results.protocol}
- Domain: ${results.domain}
- Path: ${results.path}
- Has HTTPS: ${results.hasHttps ? 'Yes' : 'No'}
- Has WWW: ${results.hasWww ? 'Yes' : 'No'}
- Has Trailing Slash: ${results.hasTrailingSlash ? 'Yes' : 'No'}
- Has Query Parameters: ${results.hasQueryParams ? 'Yes' : 'No'}
- Has Fragment: ${results.hasFragment ? 'Yes' : 'No'}
`.trim();
    
    navigator.clipboard.writeText(textToCopy);
    toast.success("URL analysis results copied to clipboard!");
  };

  const downloadResults = () => {
    if (!results) return;
    
    const content = JSON.stringify(results, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'url-analysis-results.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success("URL analysis results downloaded as JSON!");
  };

  const openUrl = () => {
    if (!results) return;
    window.open(results.url, '_blank');
  };

  return (
    <ToolLayout
      title="URL Analyzer"
      description="Analyze URL structure, parameters, and SEO features"
      helpText="Enter a URL to analyze its structure, protocol, domain, path, query parameters, and other important SEO features."
    >
      <div className="space-y-6">
        <Tabs defaultValue="analyze" className="w-full">
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="analyze">Analyze URL</TabsTrigger>
          </TabsList>
          
          <TabsContent value="analyze" className="space-y-4 mt-4">
            <div className="flex flex-col md:flex-row gap-2">
              <Input
                type="url"
                placeholder="Enter URL to analyze (e.g., https://example.com/page)"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="flex-grow"
              />
              <Button 
                onClick={analyzeUrl} 
                disabled={isLoading}
                className="whitespace-nowrap"
              >
                <Search className="mr-2 h-4 w-4" />
                {isLoading ? "Analyzing..." : "Analyze URL"}
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-3 rounded-md flex items-center">
            <AlertCircle size={16} className="mr-2 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <AdBanner className="my-4" />

        {results && (
          <div className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">URL Analysis Results</h3>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadResults}>
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </Button>
                <Button variant="outline" size="sm" onClick={openUrl}>
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Open
                </Button>
              </div>
            </div>
            
            <Separator />
            
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Basic URL Information</h4>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md overflow-x-auto">
                      <p className="text-sm truncate"><span className="font-semibold">Full URL:</span> {results.url}</p>
                      <p className="text-sm"><span className="font-semibold">Protocol:</span> {results.protocol}</p>
                      <p className="text-sm"><span className="font-semibold">Domain:</span> {results.domain}</p>
                      <p className="text-sm"><span className="font-semibold">Path:</span> {results.path || "/"}</p>
                      {results.hasFragment && (
                        <p className="text-sm"><span className="font-semibold">Fragment:</span> {results.fragment}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">URL Features</h4>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
                      <div className="flex items-center mb-2">
                        <div className={`h-5 w-5 rounded-full flex items-center justify-center mr-2 ${results.hasHttps ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {results.hasHttps ? <Check size={12} /> : <AlertCircle size={12} />}
                        </div>
                        <p className="text-sm">
                          <span className="font-semibold">HTTPS:</span> {results.hasHttps ? "Yes" : "No"}
                        </p>
                      </div>
                      <div className="flex items-center mb-2">
                        <div className={`h-5 w-5 rounded-full flex items-center justify-center mr-2 ${results.hasWww ? 'bg-gray-100 text-gray-700' : 'bg-gray-100 text-gray-700'}`}>
                          {results.hasWww ? <Check size={12} /> : <AlertCircle size={12} />}
                        </div>
                        <p className="text-sm">
                          <span className="font-semibold">WWW Subdomain:</span> {results.hasWww ? "Yes" : "No"}
                        </p>
                      </div>
                      <div className="flex items-center mb-2">
                        <div className={`h-5 w-5 rounded-full flex items-center justify-center mr-2 ${results.hasTrailingSlash ? 'bg-gray-100 text-gray-700' : 'bg-gray-100 text-gray-700'}`}>
                          {results.hasTrailingSlash ? <Check size={12} /> : <AlertCircle size={12} />}
                        </div>
                        <p className="text-sm">
                          <span className="font-semibold">Trailing Slash:</span> {results.hasTrailingSlash ? "Yes" : "No"}
                        </p>
                      </div>
                      <div className="flex items-center">
                        <div className={`h-5 w-5 rounded-full flex items-center justify-center mr-2 ${results.hasQueryParams ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}`}>
                          {results.hasQueryParams ? <Check size={12} /> : <AlertCircle size={12} />}
                        </div>
                        <p className="text-sm">
                          <span className="font-semibold">Query Parameters:</span> {results.hasQueryParams ? "Yes" : "No"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {results.hasQueryParams && (
                  <div className="space-y-2">
                    <h4 className="font-medium">Query Parameters</h4>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-100 dark:bg-gray-800">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Parameter</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Value</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
                          {Object.entries(results.queryParams).map(([key, value]) => (
                            <tr key={key}>
                              <td className="px-4 py-2 text-sm font-medium">{key}</td>
                              <td className="px-4 py-2 text-sm">{value}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
              <h4 className="font-medium mb-2">SEO Recommendations</h4>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li>{results.hasHttps ? "✓ Great! Your URL uses HTTPS which is good for security and SEO." : "❌ Your URL does not use HTTPS. Consider enabling SSL for better security and SEO benefits."}</li>
                <li>{!results.hasTrailingSlash && !results.path.includes(".") ? "❌ Consider adding a trailing slash to folder URLs for consistency." : "✓ Your URL path formatting is consistent."}</li>
                <li>{results.path.length > 50 ? "❌ Your URL path is quite long. Consider using shorter URLs for better user experience." : "✓ Your URL path has a good length."}</li>
                <li>{Object.keys(results.queryParams).length > 3 ? "❌ Your URL has many query parameters. Consider reducing them for cleaner URLs." : results.hasQueryParams ? "⚠️ Be careful with query parameters in URLs you want indexed." : "✓ No query parameters detected."}</li>
              </ul>
            </div>
            
            <AdBanner className="my-4" />
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

export default UrlAnalyzer;
