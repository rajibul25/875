
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Download, Copy, Image, Facebook, Instagram, Twitter, Linkedin, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const SocialPostCreator = () => {
  const { toast } = useToast();
  const [platform, setPlatform] = useState<string>("instagram");
  const [text, setText] = useState<string>("");
  const [background, setBackground] = useState<string>("#ffffff");
  const [textColor, setTextColor] = useState<string>("#000000");
  const [font, setFont] = useState<string>("Arial");
  const [imageUrl, setImageUrl] = useState<string>("");

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setImageUrl(e.target.result as string);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const copyToClipboard = () => {
    // In a real implementation, this would capture the canvas as an image
    toast({
      title: "Image copied to clipboard",
      description: "Your social media post has been copied to clipboard.",
    });
  };

  const downloadImage = () => {
    // In a real implementation, this would download the canvas as an image
    toast({
      title: "Image downloaded",
      description: "Your social media post has been downloaded.",
    });
  };

  const platformDimensions = {
    instagram: { width: "1080px", height: "1080px", aspectRatio: "1/1" },
    facebook: { width: "1200px", height: "630px", aspectRatio: "1.91/1" },
    twitter: { width: "1200px", height: "675px", aspectRatio: "16/9" },
    linkedin: { width: "1200px", height: "627px", aspectRatio: "1.91/1" },
  };

  const getPlatformIcon = () => {
    switch(platform) {
      case "instagram": return <Instagram className="h-6 w-6" />;
      case "facebook": return <Facebook className="h-6 w-6" />;
      case "twitter": return <Twitter className="h-6 w-6" />;
      case "linkedin": return <Linkedin className="h-6 w-6" />;
      default: return <Instagram className="h-6 w-6" />;
    }
  };

  return (
    <ToolLayout 
      title="Social Media Post Creator"
      description="Create engaging social media graphics for Instagram, Facebook, Twitter, and LinkedIn."
      helpText="Upload images, add text, and customize colors to create professional social media posts."
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Editor Panel */}
        <div className="space-y-6">
          <Tabs defaultValue="content" className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="design">Design</TabsTrigger>
              <TabsTrigger value="templates">Templates</TabsTrigger>
            </TabsList>
            
            <TabsContent value="content" className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Platform</label>
                <Select value={platform} onValueChange={setPlatform}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="twitter">Twitter</SelectItem>
                    <SelectItem value="linkedin">LinkedIn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Text Content</label>
                <Textarea 
                  placeholder="Enter your post text here..." 
                  className="h-32"
                  value={text}
                  onChange={handleTextChange}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Upload Image</label>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" className="w-full" onClick={() => document.getElementById('image-upload')?.click()}>
                    <Upload className="h-4 w-4 mr-2" /> Choose Image
                  </Button>
                  <input 
                    type="file" 
                    id="image-upload" 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                  {imageUrl && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setImageUrl("")}
                    >
                      Clear
                    </Button>
                  )}
                </div>
                {imageUrl && (
                  <div className="mt-2">
                    <p className="text-sm text-green-600 dark:text-green-400">Image uploaded successfully!</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="design" className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Background Color</label>
                <div className="flex items-center space-x-2">
                  <input 
                    type="color" 
                    value={background}
                    onChange={(e) => setBackground(e.target.value)}
                    className="w-10 h-10 rounded cursor-pointer"
                  />
                  <Input
                    value={background}
                    onChange={(e) => setBackground(e.target.value)}
                    className="w-28"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Text Color</label>
                <div className="flex items-center space-x-2">
                  <input 
                    type="color" 
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-10 h-10 rounded cursor-pointer"
                  />
                  <Input
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-28"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Font</label>
                <Select value={font} onValueChange={setFont}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Arial">Arial</SelectItem>
                    <SelectItem value="Helvetica">Helvetica</SelectItem>
                    <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                    <SelectItem value="Georgia">Georgia</SelectItem>
                    <SelectItem value="Courier New">Courier New</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
            
            <TabsContent value="templates" className="grid grid-cols-2 gap-4">
              <button className="border rounded-lg p-4 aspect-square bg-gradient-to-br from-pink-100 to-purple-100 hover:opacity-80 transition-opacity">
                <div className="font-bold text-center">Template 1</div>
              </button>
              <button className="border rounded-lg p-4 aspect-square bg-gradient-to-br from-blue-100 to-green-100 hover:opacity-80 transition-opacity">
                <div className="font-bold text-center">Template 2</div>
              </button>
              <button className="border rounded-lg p-4 aspect-square bg-gradient-to-br from-yellow-100 to-orange-100 hover:opacity-80 transition-opacity">
                <div className="font-bold text-center">Template 3</div>
              </button>
              <button className="border rounded-lg p-4 aspect-square bg-gradient-to-br from-teal-100 to-cyan-100 hover:opacity-80 transition-opacity">
                <div className="font-bold text-center">Template 4</div>
              </button>
            </TabsContent>
          </Tabs>
          
          <div className="flex space-x-3">
            <Button onClick={downloadImage} className="flex-1">
              <Download className="h-4 w-4 mr-2" /> Download
            </Button>
            <Button onClick={copyToClipboard} variant="outline" className="flex-1">
              <Copy className="h-4 w-4 mr-2" /> Copy
            </Button>
          </div>
        </div>
        
        {/* Preview Panel */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 flex flex-col items-center">
          <div className="mb-4 flex items-center space-x-2">
            {getPlatformIcon()}
            <h3 className="text-lg font-medium capitalize">{platform} Preview</h3>
          </div>
          
          <div 
            className="border rounded-lg overflow-hidden shadow-lg w-full"
            style={{
              maxWidth: "100%",
              aspectRatio: platformDimensions[platform as keyof typeof platformDimensions].aspectRatio,
              background: background,
              position: "relative",
            }}
          >
            {imageUrl && (
              <div className="absolute inset-0">
                <img 
                  src={imageUrl} 
                  alt="Background" 
                  className="w-full h-full object-cover" 
                />
              </div>
            )}
            
            {text && (
              <div 
                className="absolute inset-0 p-6 flex items-center justify-center"
                style={{ fontFamily: font }}
              >
                <p style={{ color: textColor, fontSize: "1.5rem", textAlign: "center" }}>
                  {text}
                </p>
              </div>
            )}
          </div>
          
          <div className="mt-6 w-full">
            <h3 className="text-lg font-medium mb-3">How to Use This Tool</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Select your target social media platform</li>
              <li>Enter your text content or upload an image</li>
              <li>Customize design settings like colors and fonts</li>
              <li>Download your finished social media post</li>
            </ol>
          </div>
        </div>
      </div>
      
      {/* FAQ Section */}
      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">What image formats are supported?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Our tool supports all common image formats including JPG, PNG, GIF, and WebP up to 5MB in size.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Can I save my designs for later?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Currently, you can download your designs. Account-based saving will be available in a future update.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">What are the optimal post sizes?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              The tool automatically sets the optimal dimensions for each platform: 1:1 for Instagram, 16:9 for Twitter, etc.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Is this tool completely free?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Yes, the Social Media Post Creator is completely free to use with no watermarks on downloaded files.
            </p>
          </Card>
        </div>
      </div>
    </ToolLayout>
  );
};

export default SocialPostCreator;
