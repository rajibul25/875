
import React, { useState, useRef, ChangeEvent } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, ArrowRight, Copy, Download, File, Upload, Image } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const Base64Encoder = () => {
  const [activeTab, setActiveTab] = useState("text");
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [isEncoding, setIsEncoding] = useState(true);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processText = () => {
    if (!inputText.trim()) {
      toast({
        title: "No text provided",
        description: isEncoding ? "Please enter text to encode" : "Please enter Base64 to decode",
        variant: "destructive"
      });
      return;
    }

    try {
      if (isEncoding) {
        // Encode text to Base64
        const encoded = btoa(encodeURIComponent(inputText));
        setOutputText(encoded);
      } else {
        // Decode Base64 to text
        const decoded = decodeURIComponent(atob(inputText.trim()));
        setOutputText(decoded);
      }

      toast({
        title: isEncoding ? "Text encoded" : "Base64 decoded",
        description: "Process completed successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: isEncoding 
          ? "Failed to encode text. Check for special characters." 
          : "Invalid Base64 string. Please check your input.",
        variant: "destructive"
      });
    }
  };

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    
    // Clear previous preview
    if (filePreview) {
      URL.revokeObjectURL(filePreview);
      setFilePreview(null);
    }
    
    // Read the file
    const reader = new FileReader();
    
    if (isEncoding) {
      // Encode file to Base64
      reader.onloadend = () => {
        const base64 = reader.result as string;
        // Extract the Base64 data part (after the comma)
        const base64Data = base64.split(",")[1];
        setOutputText(base64Data);
        
        // If it's an image, show preview
        if (file.type.startsWith("image/")) {
          setFilePreview(base64);
        }
      };
      reader.readAsDataURL(file);
    } else {
      // Decode Base64 to file
      reader.onloadend = () => {
        try {
          const text = reader.result as string;
          const decoded = atob(text);
          setOutputText(decoded);
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to decode file. Make sure it contains valid Base64.",
            variant: "destructive"
          });
        }
      };
      reader.readAsText(file);
    }
  };

  const copyToClipboard = () => {
    if (outputText) {
      navigator.clipboard.writeText(outputText);
      toast({
        title: "Copied to clipboard",
        description: "Output has been copied to your clipboard",
      });
    }
  };

  const downloadOutput = () => {
    if (!outputText) return;

    if (isEncoding) {
      // Download as text file
      const blob = new Blob([outputText], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "encoded-base64.txt";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      // Try to decode Base64 to binary if it looks like a file
      try {
        const binary = atob(outputText);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const blob = new Blob([bytes]);
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "decoded-file";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        // If it fails, just download as text
        const blob = new Blob([outputText], { type: "text/plain" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "decoded-text.txt";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    }
    
    toast({
      title: "Download started",
      description: isEncoding ? "Encoded content downloaded" : "Decoded content downloaded",
    });
  };

  const clearContent = () => {
    setInputText("");
    setOutputText("");
    setSelectedFile(null);
    if (filePreview) {
      URL.revokeObjectURL(filePreview);
      setFilePreview(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const toggleMode = () => {
    setIsEncoding(!isEncoding);
    clearContent();
  };

  return (
    <ToolLayout 
      title="Base64 Encoder / Decoder"
      description="Encode text or files to Base64, or decode Base64 back to its original form."
      helpText="Use this tool to convert between regular text/files and Base64 format, commonly used for embedding binary data in text documents."
    >
      <div className="space-y-6">
        <Card className="overflow-hidden">
          <div className="border-b border-gray-200 dark:border-gray-700">
            <Tabs defaultValue="text" onValueChange={setActiveTab}>
              <div className="flex justify-between items-center px-4">
                <TabsList className="h-14">
                  <TabsTrigger value="text" className="text-sm sm:text-base">Text</TabsTrigger>
                  <TabsTrigger value="file" className="text-sm sm:text-base">File</TabsTrigger>
                </TabsList>
                <Button onClick={toggleMode} variant="outline" size="sm">
                  Switch to {isEncoding ? "Decode" : "Encode"} Mode
                </Button>
              </div>
              
              <TabsContent value="text" className="m-0">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-4">
                  <CardContent className="p-0">
                    <div className="mb-4">
                      <h2 className="text-lg font-medium">
                        {isEncoding ? "Text Input" : "Base64 Input"}
                      </h2>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {isEncoding ? "Enter text to encode to Base64" : "Enter Base64 to decode"}
                      </p>
                    </div>
                    <Textarea 
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder={isEncoding ? "Type or paste text here..." : "Paste Base64 encoded text here..."}
                      className="min-h-[200px] font-mono"
                    />
                    <div className="flex justify-center mt-4">
                      <Button 
                        onClick={processText}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {isEncoding ? "Encode to Base64" : "Decode Base64"} <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>

                  <CardContent className="p-0">
                    <div className="mb-4 flex justify-between items-center">
                      <div>
                        <h2 className="text-lg font-medium">
                          {isEncoding ? "Base64 Output" : "Decoded Text"}
                        </h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {isEncoding ? "Your Base64 encoded result" : "Your decoded text result"}
                        </p>
                      </div>
                      {outputText && (
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={copyToClipboard}
                          >
                            <Copy className="mr-1 h-4 w-4" /> Copy
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={downloadOutput}
                          >
                            <Download className="mr-1 h-4 w-4" /> Download
                          </Button>
                        </div>
                      )}
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 overflow-auto min-h-[200px] border border-gray-200 dark:border-gray-700">
                      {outputText ? (
                        <pre className="font-mono whitespace-pre-wrap break-all">{outputText}</pre>
                      ) : (
                        <div className="flex items-center justify-center h-full text-gray-400">
                          <p>Output will appear here</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </div>
              </TabsContent>

              <TabsContent value="file" className="m-0">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-4">
                  <CardContent className="p-0">
                    <div className="mb-4">
                      <h2 className="text-lg font-medium">
                        {isEncoding ? "File Input" : "Base64 File Input"}
                      </h2>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {isEncoding ? "Select a file to encode" : "Select a file containing Base64"}
                      </p>
                    </div>
                    <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                      <Input
                        ref={fileInputRef}
                        type="file"
                        className="hidden"
                        onChange={handleFileSelect}
                      />
                      <div className="space-y-2">
                        <div className="flex justify-center">
                          <File className="h-10 w-10 text-gray-400" />
                        </div>
                        <div className="text-gray-900 dark:text-gray-300 text-lg font-medium">
                          {selectedFile ? selectedFile.name : "No file selected"}
                        </div>
                        <p className="text-sm text-gray-500">
                          {selectedFile ? `${(selectedFile.size / 1024).toFixed(2)} KB` : "Upload a file to process"}
                        </p>
                        <Button
                          variant="outline"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Upload className="mr-2 h-4 w-4" />
                          Select File
                        </Button>
                      </div>
                    </div>
                  </CardContent>

                  <CardContent className="p-0">
                    <div className="mb-4 flex justify-between items-center">
                      <div>
                        <h2 className="text-lg font-medium">
                          {isEncoding ? "Base64 Output" : "Decoded Output"}
                        </h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {isEncoding ? "Your file encoded as Base64" : "Your file decoded from Base64"}
                        </p>
                      </div>
                      {outputText && (
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={copyToClipboard}
                          >
                            <Copy className="mr-1 h-4 w-4" /> Copy
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={downloadOutput}
                          >
                            <Download className="mr-1 h-4 w-4" /> Download
                          </Button>
                        </div>
                      )}
                    </div>
                    
                    {filePreview && isEncoding && selectedFile?.type.startsWith("image/") && (
                      <div className="mb-4">
                        <h3 className="text-sm font-medium mb-2">Image Preview:</h3>
                        <div className="border rounded-lg overflow-hidden bg-gray-50 dark:bg-gray-800 flex justify-center">
                          <img 
                            src={filePreview} 
                            alt="Preview" 
                            className="max-h-[200px] object-contain" 
                          />
                        </div>
                      </div>
                    )}
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 overflow-auto max-h-[300px] border border-gray-200 dark:border-gray-700">
                      {outputText ? (
                        <pre className="font-mono whitespace-pre-wrap break-all text-sm">{
                          outputText.length > 5000 
                            ? outputText.substring(0, 5000) + "... (output truncated for display)" 
                            : outputText
                        }</pre>
                      ) : (
                        <div className="flex items-center justify-center h-[200px] text-gray-400">
                          <p>Select a file to see output</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </Card>

        <div className="flex justify-center gap-4">
          <Button 
            onClick={clearContent} 
            variant="outline"
          >
            Clear All
          </Button>
        </div>

        <div className="mt-8 space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal space-y-3 ml-5">
              <li>Choose whether you want to encode text to Base64 or decode Base64 to text using the toggle button.</li>
              <li>Select input type - Text or File.</li>
              <li>For text: Enter or paste your content in the input field.</li>
              <li>For files: Upload the file you want to process.</li>
              <li>Click the "Encode" or "Decode" button to process.</li>
              <li>View your result in the output area.</li>
              <li>Copy or download the result as needed.</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">FAQ</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">What is Base64 encoding?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Base64 is a binary-to-text encoding scheme that represents binary data in ASCII string format. It's commonly used to embed images in HTML/CSS, encode email attachments, and store binary data in text-based formats like JSON.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Why would I need Base64 encoding?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Base64 encoding is useful when you need to include binary data in contexts that only support text, such as embedding images directly in HTML/CSS, transferring binary data in JSON payloads, or working with data in environments that might corrupt binary data.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Is Base64 encoding secure for sensitive information?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  No, Base64 is not an encryption method. It's an encoding scheme that anyone can decode easily. Don't use Base64 as a security measure for sensitive information - it's designed for data transfer, not security.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Why does Base64 encoded data look larger than the original?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Base64 encoding generally increases the data size by about 33% because it represents 3 bytes of binary data with 4 ASCII characters. This overhead is the trade-off for making binary data compatible with text-only systems.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Related Tools</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a href="/tools/image-to-base64" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">Image to Base64</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Specialized tool for converting images to Base64 for embedding in CSS, HTML, or SVG.
                </p>
              </a>
              <a href="/tools/json-formatter" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">JSON Formatter</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Format and validate your JSON data with our clean and intuitive tool.
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default Base64Encoder;
