
import { useState, lazy, Suspense, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { FileSearch, AlertCircle, ClipboardCheck, Link as LinkIcon, User, Bot, Shield, Copy, Share2, Download, FileDown } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import BackButton from "@/components/BackButton";
import { motion } from "framer-motion";
import { toast } from "sonner";

// Import our new analysis service
import { analyzeContent, generateReportText } from "@/services/ContentAnalysisService";

// Import our analysis animation
import ContentAnalysisAnimation from "@/components/ContentAnalysisAnimation";

// Import our comprehensive result display
import ResultDisplay from "@/components/ContentDetectiveResult";

// Import our new QuickAIDetector component
import QuickAIDetector from "@/components/QuickAIDetector";

// Animation configurations for UI transitions
const verificationAnimations = {
  ai: {
    initial: { scale: 0.8, opacity: 0 },
    animate: { scale: 1, opacity: 1, transition: { duration: 0.5 } },
    color: "from-rose-500 to-purple-600"
  },
  human: {
    initial: { scale: 0.8, opacity: 0 },
    animate: { scale: 1, opacity: 1, transition: { duration: 0.5 } },
    color: "from-emerald-500 to-teal-600"
  },
  uncertain: {
    initial: { scale: 0.8, opacity: 0 },
    animate: { scale: 1, opacity: 1, transition: { duration: 0.5 } },
    color: "from-blue-500 to-indigo-600"
  }
};

// Simpler loading placeholder component
const LoadingPlaceholder = () => (
  <div className="flex justify-center items-center p-12">
    <div className="w-6 h-6 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
  </div>
);

const ContentDetective = () => {
  const [inputType, setInputType] = useState<"text" | "url">("text");
  const [text, setText] = useState("");
  const [url, setUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Function to analyze content
  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    
    const contentToAnalyze = inputType === "text" ? text.trim() : url.trim();
    if (!contentToAnalyze) {
      setResult(null);
      return;
    }
    
    setIsAnalyzing(true);
    setResult(null);
    
    // Use a timeout to give the UI time to show animation
    setTimeout(() => {
      // For URL analysis (simplified for demo - in a real app, would fetch content from URL)
      if (inputType === "url") {
        // Simulate URL fetch delay
        setTimeout(() => {
          setIsAnalyzing(false);
          const analysis = analyzeContent(url);
          setResult(analysis);
          toast.success("Content analysis complete!");
        }, 3000);
      } else {
        // Text analysis with our enhanced service
        setTimeout(() => {
          setIsAnalyzing(false);
          const analysis = analyzeContent(text);
          setResult(analysis);
          toast.success("Content analysis complete!");
        }, 2500);
      }
    }, 500);
  };

  // Function to copy results
  const copyResults = () => {
    if (!result) return;
    
    const resultText = generateReportText(result, inputType === "text" ? text : url);
    navigator.clipboard.writeText(resultText);
    toast.success("Analysis results copied to clipboard");
  };

  // Function to download results as a report
  const downloadReport = () => {
    if (!result) return;
    
    const reportText = generateReportText(result, inputType === "text" ? text : url);
    const blob = new Blob([reportText], { type: 'text/plain' });
    const fileUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = fileUrl;
    a.download = 'content-detective-report.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(fileUrl);
    toast.success("Report downloaded successfully");
  };

  // Clear results when switching input type
  useEffect(() => {
    setResult(null);
  }, [inputType]);

  // Preload the image
  useEffect(() => {
    const img = new Image();
    img.onload = () => setImageLoaded(true);
    img.src = "/lovable-uploads/8a5ae2a0-b79e-4933-82ad-f62ab1488761.png";
  }, []);

  // Schema markup for SEO
  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Content Detective AI Tool",
    "applicationCategory": "BrowserApplication",
    "operatingSystem": "Web browser",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "description": "Advanced content analysis tool that detects if text is AI-generated or human-written using sophisticated pattern recognition technology."
  };

  return (
    <div className="container max-w-3xl mx-auto px-4 py-6">
      <Helmet>
        <title>Content Detective - Advanced AI Content Analyzer | MultiToolSet</title>
        <meta 
          name="description" 
          content="Advanced AI Content Detective to detect if text is AI-generated or human-written. Analyzes writing style, tone, and provides detailed reports with improvement suggestions."
        />
        <meta 
          name="keywords" 
          content="AI detector, content analysis, writing style detector, AI content checker, human vs AI writing, content verification, AI detection tool"
        />
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <div className="mb-6">
        <BackButton />
      </div>

      <div className="flex items-center justify-center space-x-4 mb-6">
        {imageLoaded ? (
          <img
            src="/lovable-uploads/8a5ae2a0-b79e-4933-82ad-f62ab1488761.png"
            alt="Content Detective Logo"
            width={64}
            height={64}
            className="w-16 h-16 rounded-lg border border-purple-200 shadow-sm"
          />
        ) : (
          <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center">
            <FileSearch className="w-8 h-8 text-purple-500" />
          </div>
        )}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
            Content Detective
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Advanced AI vs Human content analyzer with detailed breakdown
          </p>
        </div>
      </div>

      {/* Quick AI Detector - New Component */}
      <QuickAIDetector />

      <Card className="mb-6 border-purple-100 dark:border-purple-900/20 shadow-md">
        <CardContent className="pt-6 space-y-6">
          <Tabs defaultValue="text" onValueChange={(value) => setInputType(value as "text" | "url")}>
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="text" className="rounded-l-md">
                <ClipboardCheck className="h-4 w-4 mr-2" />
                Analyze Text
              </TabsTrigger>
              <TabsTrigger value="url" className="rounded-r-md">
                <LinkIcon className="h-4 w-4 mr-2" />
                Analyze URL
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="text">
              <form onSubmit={handleAnalyze}>
                <Textarea
                  placeholder="Paste your content here (4+ sentences for best results)..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="min-h-[180px] mb-4 p-4 text-base resize-y bg-white dark:bg-gray-950 border-purple-100 dark:border-purple-800/30 focus:border-purple-500"
                />
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-medium py-2"
                  disabled={isAnalyzing || !text.trim()}
                >
                  {isAnalyzing ? "Analyzing Content..." : "Analyze Content"}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="url">
              <form onSubmit={handleAnalyze}>
                <Input
                  type="url"
                  placeholder="Enter URL of article to analyze..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="mb-4 p-4 text-base bg-white dark:bg-gray-950 border-purple-100 dark:border-purple-800/30 focus:border-purple-500"
                />
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-medium py-2"
                  disabled={isAnalyzing || !url.trim()}
                >
                  {isAnalyzing ? "Analyzing URL Content..." : "Analyze URL"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          {isAnalyzing && (
            <ContentAnalysisAnimation isAnalyzing={isAnalyzing} />
          )}

          {result && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-6 bg-purple-50 dark:bg-purple-900/10 rounded-lg border border-purple-100 dark:border-purple-800/20 p-5"
            >
              <ResultDisplay result={result} isAnimating={false} />
              
              <div className="mt-5 flex space-x-2 justify-end">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={copyResults}
                  className="text-xs flex items-center"
                >
                  <Copy className="h-3.5 w-3.5 mr-1" />
                  Copy Report
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs flex items-center"
                  onClick={downloadReport}
                >
                  <FileDown className="h-3.5 w-3.5 mr-1" />
                  Download Report
                </Button>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      <Suspense fallback={<LoadingPlaceholder />}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="border-purple-100 dark:border-purple-900/20">
            <CardContent className="pt-6">
              <h2 className="text-lg font-semibold mb-3 text-gray-900 dark:text-gray-100">Advanced Analysis Engine</h2>
              <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Multi-factor detection for enhanced accuracy</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Detects writing style, tone, and language patterns</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Analyzes sentence structure and semantic coherence</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Provides confidence scores with detailed breakdowns</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-purple-100 dark:border-purple-900/20">
            <CardContent className="pt-6">
              <h2 className="text-lg font-semibold mb-3 text-gray-900 dark:text-gray-100">Content Improvement</h2>
              <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Actionable suggestions to humanize AI content</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Identifies overused AI phrases and patterns</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Detailed report with categorized analysis</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-purple-600 dark:text-purple-400">•</span>
                  <span>Grammar quality assessment with context</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </Suspense>

      <Alert className="mb-8 bg-purple-50/50 dark:bg-purple-900/5 border-purple-100 dark:border-purple-800/20">
        <FileSearch className="h-5 w-5 text-purple-600 dark:text-purple-400" />
        <AlertDescription className="text-sm text-gray-700 dark:text-gray-300 ml-2">
          <strong>Privacy Note:</strong> Content Detective processes your text entirely in the browser. 
          Nothing is sent to external servers, ensuring complete privacy for your sensitive content.
        </AlertDescription>
      </Alert>

      <Suspense fallback={<LoadingPlaceholder />}>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <a href="/tools/plagiarism-checker" className="flex items-center p-4 border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Plagiarism Checker</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Check for copied content</p>
              </div>
            </a>
            <a href="/tools/grammar-checker" className="flex items-center p-4 border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Grammar Checker</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Fix grammar mistakes</p>
              </div>
            </a>
            <a href="/tools/word-counter" className="flex items-center p-4 border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Word Counter</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Count words and characters</p>
              </div>
            </a>
          </div>
        </div>
      </Suspense>
    </div>
  );
};

export default ContentDetective;
