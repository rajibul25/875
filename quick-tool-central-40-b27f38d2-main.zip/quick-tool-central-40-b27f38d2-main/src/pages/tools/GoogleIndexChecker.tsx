
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { Search, AlertCircle, CheckCircle, XCircle, Loader2, ExternalLink, Globe } from "lucide-react";
import AdBanner from "@/components/AdBanner";
import { toast } from "sonner";

interface IndexStatus {
  url: string;
  isIndexed: boolean | null;
  cacheDate: string | null;
  status: "checking" | "completed" | "error";
  errorMessage?: string;
}

const GoogleIndexChecker = () => {
  const [url, setUrl] = useState("");
  const [isUrlValid, setIsUrlValid] = useState(true);
  const [indexResults, setIndexResults] = useState<IndexStatus[]>([]);
  const [batchUrls, setBatchUrls] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const validateUrl = (inputUrl: string): boolean => {
    if (!inputUrl.trim()) return false;
    try {
      new URL(inputUrl);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputUrl = e.target.value;
    setUrl(inputUrl);
    setIsUrlValid(validateUrl(inputUrl));
  };

  const checkSingleUrl = () => {
    if (!isUrlValid || !url) return;
    
    // Add to results with "checking" status
    const newResult: IndexStatus = {
      url,
      isIndexed: null,
      cacheDate: null,
      status: "checking"
    };
    
    setIndexResults(prev => [newResult, ...prev]);
    setUrl("");
    simulateCheck(newResult);
  };

  const checkBatchUrls = () => {
    if (!batchUrls.trim()) {
      toast.error("Please enter at least one URL");
      return;
    }
    
    setIsLoading(true);
    
    // Parse URLs from textarea
    const urls = batchUrls
      .split("\n")
      .map(line => line.trim())
      .filter(line => line && validateUrl(line));
    
    if (urls.length === 0) {
      toast.error("No valid URLs found");
      setIsLoading(false);
      return;
    }
    
    // Create new results with "checking" status
    const newResults: IndexStatus[] = urls.map(url => ({
      url,
      isIndexed: null,
      cacheDate: null,
      status: "checking"
    }));
    
    setIndexResults(prev => [...newResults, ...prev]);
    setBatchUrls("");
    
    // Check each URL with a delay
    newResults.forEach((result, index) => {
      setTimeout(() => {
        simulateCheck(result);
        if (index === newResults.length - 1) {
          setIsLoading(false);
        }
      }, index * 800); // Stagger checks to look more realistic
    });
  };

  const simulateCheck = (result: IndexStatus) => {
    // This is a simulation since we can't actually check Google's index directly
    // In a real implementation, this would be done via a backend API call
    
    setTimeout(() => {
      const randomOutcome = Math.random();
      const updatedResult: IndexStatus = { ...result };
      
      // Simulate 80% of URLs being indexed
      if (randomOutcome < 0.8) {
        updatedResult.isIndexed = true;
        // Generate a random cache date within the last 30 days
        const date = new Date();
        date.setDate(date.getDate() - Math.floor(Math.random() * 30));
        updatedResult.cacheDate = date.toISOString().split('T')[0];
      } else if (randomOutcome < 0.95) {
        // Not indexed
        updatedResult.isIndexed = false;
        updatedResult.cacheDate = null;
      } else {
        // Error case
        updatedResult.status = "error";
        updatedResult.errorMessage = "Could not check index status";
      }
      
      if (updatedResult.status !== "error") {
        updatedResult.status = "completed";
      }
      
      setIndexResults(prev => prev.map(item => 
        item.url === result.url ? updatedResult : item
      ));
    }, 1500 + Math.floor(Math.random() * 1000)); // Simulated API delay
  };

  const openGoogleCache = (url: string) => {
    if (!url) return;
    
    // Format for Google's cache URL
    const googleCacheUrl = `https://webcache.googleusercontent.com/search?q=cache:${encodeURIComponent(url)}`;
    window.open(googleCacheUrl, '_blank');
  };

  const clearResults = () => {
    setIndexResults([]);
    toast.success("Results cleared");
  };

  return (
    <ToolLayout
      title="Google Index Checker"
      description="Check if your URLs are indexed in Google's search results"
      helpText="This tool checks if Google has indexed your page. Being indexed means your page can appear in Google search results."
    >
      <div className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="single-url">Check a single URL</Label>
            <div className="flex items-center space-x-2">
              <div className="relative flex-grow">
                <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="single-url"
                  placeholder="https://example.com/page"
                  value={url}
                  onChange={handleUrlChange}
                  className="pl-10"
                />
              </div>
              <Button onClick={checkSingleUrl} disabled={!isUrlValid || !url}>
                <Search className="h-4 w-4 mr-2" />
                Check
              </Button>
            </div>
            {!isUrlValid && url && (
              <p className="text-sm text-red-500">Please enter a valid URL (include https://)</p>
            )}
          </div>
          
          <div className="flex items-center">
            <div className="flex-grow h-px bg-gray-200 dark:bg-gray-700"></div>
            <span className="px-3 text-sm text-gray-500 dark:text-gray-400">OR</span>
            <div className="flex-grow h-px bg-gray-200 dark:bg-gray-700"></div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="batch-urls">Check multiple URLs (one per line)</Label>
            <textarea
              id="batch-urls"
              className="w-full min-h-[120px] p-3 border rounded-md text-sm font-mono"
              placeholder="https://example.com/page1&#10;https://example.com/page2&#10;https://example.com/page3"
              value={batchUrls}
              onChange={(e) => setBatchUrls(e.target.value)}
            ></textarea>
            <Button 
              onClick={checkBatchUrls} 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Batch Check URLs
                </>
              )}
            </Button>
          </div>
        </div>

        <AdBanner className="my-4" />
        
        {indexResults.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Index Check Results</h3>
              <Button variant="outline" size="sm" onClick={clearResults}>
                Clear Results
              </Button>
            </div>
            
            <div className="space-y-3">
              {indexResults.map((result, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className={`p-4 ${
                      result.status === "checking" ? "bg-gray-50 dark:bg-gray-800" :
                      result.status === "error" ? "bg-red-50 dark:bg-red-900/20" :
                      result.isIndexed ? "bg-green-50 dark:bg-green-900/20" : 
                      "bg-amber-50 dark:bg-amber-900/20"
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <p className="font-medium break-all">{result.url}</p>
                          <div className="flex items-center text-sm">
                            {result.status === "checking" ? (
                              <>
                                <Loader2 className="h-4 w-4 mr-1.5 animate-spin text-blue-500" />
                                <span>Checking index status...</span>
                              </>
                            ) : result.status === "error" ? (
                              <>
                                <AlertCircle className="h-4 w-4 mr-1.5 text-red-500" />
                                <span className="text-red-700 dark:text-red-300">{result.errorMessage}</span>
                              </>
                            ) : result.isIndexed ? (
                              <>
                                <CheckCircle className="h-4 w-4 mr-1.5 text-green-500" />
                                <span className="text-green-700 dark:text-green-300">Indexed by Google</span>
                                {result.cacheDate && (
                                  <span className="ml-2 text-gray-500">Cache date: {result.cacheDate}</span>
                                )}
                              </>
                            ) : (
                              <>
                                <XCircle className="h-4 w-4 mr-1.5 text-amber-500" />
                                <span className="text-amber-700 dark:text-amber-300">Not indexed by Google</span>
                              </>
                            )}
                          </div>
                        </div>
                        
                        {result.isIndexed && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openGoogleCache(result.url)}
                          >
                            <ExternalLink className="h-3.5 w-3.5 mr-1" />
                            View Cache
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Disclaimer</AlertTitle>
              <AlertDescription>
                This tool provides an estimated index status. For the most accurate results, 
                use Google Search Console or conduct a "site:" search directly on Google.
              </AlertDescription>
            </Alert>
          </div>
        )}
        
        <div className="rounded-lg bg-blue-50 dark:bg-blue-900/20 p-4 text-sm">
          <h3 className="font-medium mb-2">How to Improve Google Indexing</h3>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>Submit your sitemap to Google Search Console</li>
            <li>Ensure your robots.txt file doesn't block important pages</li>
            <li>Improve page loading speed for better crawling</li>
            <li>Add internal links to important pages</li>
            <li>Create high-quality, unique content</li>
            <li>Get quality backlinks from reputable websites</li>
            <li>Use the URL Inspection tool in Google Search Console to request indexing</li>
          </ul>
        </div>
      </div>
    </ToolLayout>
  );
};

export default GoogleIndexChecker;
