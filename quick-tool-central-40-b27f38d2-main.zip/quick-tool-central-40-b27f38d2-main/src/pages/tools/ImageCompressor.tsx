
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { ImageIcon, Upload, ArrowRight, Download, Trash2, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import BackButton from "@/components/BackButton";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import imageCompression from "browser-image-compression";

interface CompressedFile {
  id: string;
  name: string;
  originalUrl: string;
  originalSize: number;
  compressedUrl: string;
  compressedSize: number;
  compressionRatio: number;
}

const ImageCompressor = () => {
  const navigate = useNavigate();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [compressedFiles, setCompressedFiles] = useState<CompressedFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [compressionLevel, setCompressionLevel] = useState(0.8); // 0 to 1, where 1 is highest quality
  const [maxWidthHeight, setMaxWidthHeight] = useState(1920);
  const [preserveExif, setPreserveExif] = useState(false);
  const [activeTab, setActiveTab] = useState("basic");
  const [processingProgress, setProcessingProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Quality presets
  const qualityPresets = {
    "high": { quality: 0.8, maxWidthHeight: 2048 },
    "medium": { quality: 0.6, maxWidthHeight: 1600 },
    "low": { quality: 0.4, maxWidthHeight: 1200 },
    "very-low": { quality: 0.2, maxWidthHeight: 800 },
  };

  const applyQualityPreset = (preset: keyof typeof qualityPresets) => {
    const { quality, maxWidthHeight } = qualityPresets[preset];
    setCompressionLevel(quality);
    setMaxWidthHeight(maxWidthHeight);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles: File[] = [];
    let invalidFileFound = false;

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) {
        invalidFileFound = true;
        return;
      }
      newFiles.push(file);
    });

    if (invalidFileFound) {
      toast.error("Some files are not images and were skipped");
    }

    if (newFiles.length > 0) {
      setSelectedFiles(prev => [...prev, ...newFiles]);
      toast.success(`${newFiles.length} image${newFiles.length > 1 ? 's' : ''} added`);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;

    const newFiles: File[] = [];
    let invalidFileFound = false;

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) {
        invalidFileFound = true;
        return;
      }
      newFiles.push(file);
    });

    if (invalidFileFound) {
      toast.error("Some files are not images and were skipped");
    }

    if (newFiles.length > 0) {
      setSelectedFiles(prev => [...prev, ...newFiles]);
      toast.success(`${newFiles.length} image${newFiles.length > 1 ? 's' : ''} added`);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const compressImages = async () => {
    if (selectedFiles.length === 0) {
      toast.error("Please select at least one image to compress");
      return;
    }

    setIsProcessing(true);
    setProcessingProgress(0);
    const results: CompressedFile[] = [];

    const options = {
      maxSizeMB: 10, // Max file size (this is a fallback)
      maxWidthOrHeight: maxWidthHeight,
      useWebWorker: true,
      exifOrientation: preserveExif ? 1 : 0, // 0 means remove EXIF, 1 keeps it
      initialQuality: compressionLevel,
    };

    try {
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        const originalUrl = URL.createObjectURL(file);
        
        // Compress the image
        const compressedFile = await imageCompression(file, options);
        const compressedUrl = URL.createObjectURL(compressedFile);

        // Calculate compression ratio
        const originalSize = file.size;
        const compressedSize = compressedFile.size;
        const compressionRatio = (1 - compressedSize / originalSize) * 100;

        results.push({
          id: Math.random().toString(36).substring(2, 9),
          name: file.name,
          originalUrl,
          originalSize,
          compressedUrl,
          compressedSize,
          compressionRatio,
        });

        // Update progress
        setProcessingProgress(Math.round(((i + 1) / selectedFiles.length) * 100));
      }

      setCompressedFiles(results);
      toast.success(`Successfully compressed ${results.length} image${results.length > 1 ? 's' : ''}`);
    } catch (error) {
      console.error("Error compressing images:", error);
      toast.error("Error compressing images");
    } finally {
      setIsProcessing(false);
      setProcessingProgress(100);
    }
  };

  const downloadFile = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.replace(/\.[^/.]+$/, "") + "_compressed" + filename.substring(filename.lastIndexOf('.'));
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    if (compressedFiles.length === 0) return;
    
    compressedFiles.forEach(file => {
      downloadFile(file.compressedUrl, file.name);
    });
    
    toast.success(`Downloaded ${compressedFiles.length} compressed file${compressedFiles.length > 1 ? 's' : ''}`);
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(2) + ' KB';
    else return (bytes / 1048576).toFixed(2) + ' MB';
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center">
          <BackButton className="mr-4" />
          <h1 className="text-3xl font-bold">Image Compressor</h1>
        </div>
        
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-3xl">
          Compress your images to reduce file size while maintaining visual quality. Perfect for websites, emails, and saving storage space.
        </p>
        
        <AdBanner className="mb-8" />
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-bold mb-4">Upload Images</h2>
              
              <div
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center mb-4"
                onDrop={handleDrop}
                onDragOver={handleDragOver}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={handleFileChange}
                  accept="image/*"
                  multiple
                />
                
                <ImageIcon className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                  Drag & drop images here
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  JPG, PNG, WebP, etc. up to 10MB each
                </p>
                
                <Button 
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Select Files
                </Button>
              </div>
              
              <div className="space-y-4">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-2">
                    <TabsTrigger value="basic">Basic Settings</TabsTrigger>
                    <TabsTrigger value="advanced">Advanced Settings</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="basic" className="space-y-4 mt-4">
                    <div>
                      <Label htmlFor="quality-preset">Quality Preset</Label>
                      <Select onValueChange={(value) => applyQualityPreset(value as keyof typeof qualityPresets)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select quality preset" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="high">High Quality (Larger Size)</SelectItem>
                          <SelectItem value="medium">Medium Quality (Balanced)</SelectItem>
                          <SelectItem value="low">Low Quality (Smaller Size)</SelectItem>
                          <SelectItem value="very-low">Very Low Quality (Smallest Size)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="quality">Quality: {Math.round(compressionLevel * 100)}%</Label>
                      <Slider
                        id="quality"
                        min={10}
                        max={100}
                        step={1}
                        value={[Math.round(compressionLevel * 100)]}
                        onValueChange={(value) => setCompressionLevel(value[0] / 100)}
                        className="mt-2"
                      />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="advanced" className="space-y-4 mt-4">
                    <div>
                      <Label htmlFor="max-dimension">Max Dimension (px): {maxWidthHeight}</Label>
                      <Slider
                        id="max-dimension"
                        min={500}
                        max={4000}
                        step={100}
                        value={[maxWidthHeight]}
                        onValueChange={(value) => setMaxWidthHeight(value[0])}
                        className="mt-2"
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="preserve-exif"
                        checked={preserveExif}
                        onCheckedChange={setPreserveExif}
                      />
                      <Label htmlFor="preserve-exif">Preserve EXIF metadata</Label>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={compressImages}
                  disabled={isProcessing || selectedFiles.length === 0}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      Compressing... ({processingProgress}%)
                    </div>
                  ) : (
                    <>
                      Compress Images
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>
            
            <div>
              <h2 className="text-xl font-bold mb-4">Selected Files ({selectedFiles.length})</h2>
              
              {isProcessing && (
                <div className="mb-4">
                  <Progress value={processingProgress} className="h-2" />
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 text-center">
                    Processing: {processingProgress}%
                  </p>
                </div>
              )}
              
              {selectedFiles.length === 0 ? (
                <div className="text-center p-8 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="text-gray-500 dark:text-gray-400">No files selected</p>
                </div>
              ) : (
                <div className="overflow-y-auto max-h-60 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  {selectedFiles.map((file, index) => (
                    <div 
                      key={index} 
                      className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-600 last:border-0"
                    >
                      <div className="flex items-center">
                        <ImageIcon className="h-6 w-6 text-gray-500 dark:text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm font-medium truncate max-w-[200px]">{file.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {formatFileSize(file.size)}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={() => removeFile(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {compressedFiles.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Compressed Images ({compressedFiles.length})</h2>
              <Button
                className="bg-green-600 hover:bg-green-700 text-white"
                onClick={downloadAll}
              >
                <Download className="h-4 w-4 mr-2" />
                Download All
              </Button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {compressedFiles.map((file) => (
                <div 
                  key={file.id} 
                  className="border rounded-lg overflow-hidden flex flex-col bg-gray-50 dark:bg-gray-700"
                >
                  <div className="p-3 bg-gray-100 dark:bg-gray-600">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center justify-center bg-white dark:bg-gray-800 rounded-md overflow-hidden h-32">
                        <img 
                          src={file.originalUrl} 
                          alt="Original" 
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                      
                      <div className="flex items-center justify-center bg-white dark:bg-gray-800 rounded-md overflow-hidden h-32">
                        <img 
                          src={file.compressedUrl} 
                          alt="Compressed" 
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mt-2 text-xs text-center">
                      <div>Original</div>
                      <div>Compressed</div>
                    </div>
                  </div>
                  
                  <div className="p-3">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    
                    <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400 mt-1">
                      <span>Original: {formatFileSize(file.originalSize)}</span>
                      <span>New: {formatFileSize(file.compressedSize)}</span>
                    </div>
                    
                    <div className="mt-2 flex items-center">
                      <BarChart3 className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-sm text-green-600 dark:text-green-400">
                        {file.compressionRatio.toFixed(1)}% smaller
                      </span>
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-3"
                      onClick={() => downloadFile(file.compressedUrl, file.name)}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4">About Image Compression</h2>
          <div className="space-y-4">
            <p>
              Image compression reduces the file size of your images while attempting to maintain visual quality.
              This tool uses lossy compression which achieves higher compression ratios by slightly reducing image quality.
            </p>
            
            <h3 className="text-xl font-semibold">Benefits of Image Compression:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Faster website loading times</li>
              <li>Reduced storage space requirements</li>
              <li>Lower bandwidth usage for mobile users</li>
              <li>Improved SEO as page speed is a ranking factor</li>
              <li>Better user experience with quicker loading images</li>
            </ul>
            
            <h3 className="text-xl font-semibold">Tips for Best Results:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Use higher quality settings for important images</li>
              <li>Lower quality settings work well for background images</li>
              <li>Consider the target device - mobile users benefit more from compression</li>
              <li>PNG images with transparency may not compress as well as JPG</li>
              <li>Remove EXIF data for additional file size reduction</li>
            </ul>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ImageCompressor;
