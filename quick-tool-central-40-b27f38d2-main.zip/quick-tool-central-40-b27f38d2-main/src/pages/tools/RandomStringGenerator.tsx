
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Text, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const RandomStringGenerator = () => {
  const [length, setLength] = useState(16);
  const [randomString, setRandomString] = useState("");
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
    excludeSimilar: false,
    excludeAmbiguous: false
  });

  const generateRandomString = () => {
    let chars = "";
    if (options.uppercase) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (options.lowercase) chars += "abcdefghijklmnopqrstuvwxyz";
    if (options.numbers) chars += "0123456789";
    if (options.symbols) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?";
    
    // Exclude similar characters if option selected
    if (options.excludeSimilar) {
      chars = chars.replace(/[ilLoO01]/g, '');
    }
    
    // Exclude ambiguous characters if option selected
    if (options.excludeAmbiguous) {
      chars = chars.replace(/[{}[\]()\/\\'"~,;:.<>]/g, '');
    }

    if (chars.length === 0) {
      toast.error("Please select at least one character type");
      return;
    }

    // Generate random string
    let result = "";
    const charactersLength = chars.length;
    
    // Use crypto.getRandomValues for more secure randomness
    const randomBuffer = new Uint32Array(length);
    crypto.getRandomValues(randomBuffer);
    
    for (let i = 0; i < length; i++) {
      result += chars.charAt(randomBuffer[i] % charactersLength);
    }
    
    setRandomString(result);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(randomString);
      toast.success("Random string copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy random string");
    }
  };

  return (
    <ToolLayout
      title="Free Random String Generator | Create Secure Random Strings"
      description="Generate secure random strings with custom length and character sets. Perfect for creating tokens, IDs, passwords, and more with our free online tool."
      helpText="Customize your random string settings and click Generate to create a new string. Use the copy button to copy it to your clipboard."
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="length">
                String Length
              </label>
              <Input
                id="length"
                type="number"
                min="1"
                max="1000"
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full"
              />
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium">Character Types</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {[
                  { key: 'uppercase', label: 'Include Uppercase (A-Z)' },
                  { key: 'lowercase', label: 'Include Lowercase (a-z)' },
                  { key: 'numbers', label: 'Include Numbers (0-9)' },
                  { key: 'symbols', label: 'Include Symbols (!@#$...)' },
                  { key: 'excludeSimilar', label: 'Exclude Similar Characters (i, l, 1, o, 0)' },
                  { key: 'excludeAmbiguous', label: 'Exclude Ambiguous Characters ({}, [], /, etc)' }
                ].map(({ key, label }) => (
                  <div key={key} className="flex items-center space-x-2">
                    <Checkbox
                      id={key}
                      checked={options[key as keyof typeof options]}
                      onCheckedChange={(checked) =>
                        setOptions((prev) => ({ ...prev, [key]: checked === true }))
                      }
                    />
                    <label htmlFor={key} className="text-sm font-medium">
                      {label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <Button 
              onClick={generateRandomString}
              className="w-full"
              size="lg"
            >
              <Text className="w-4 h-4 mr-2" />
              Generate Random String
            </Button>

            {randomString && (
              <div className="mt-4 space-y-4">
                <div className="relative">
                  <Input
                    value={randomString}
                    readOnly
                    className="w-full pr-24 font-mono text-lg"
                  />
                  <div className="absolute right-1 top-1 flex space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={copyToClipboard}
                      className="h-7"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={generateRandomString}
                      className="h-7"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-4">About Random String Generator</h2>
            <div className="prose dark:prose-invert max-w-none">
              <p>
                This random string generator creates secure, unpredictable strings based on your specified parameters. 
                The tool uses the Web Crypto API for enhanced randomness, making it suitable for various applications 
                including unique identifiers, temporary passwords, and security tokens.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Use Cases for Random Strings</h2>
            <div className="prose dark:prose-invert max-w-none">
              <ul className="list-disc pl-5 space-y-2">
                <li>Creating secure temporary passwords</li>
                <li>Generating API keys and tokens</li>
                <li>Unique identifiers for databases</li>
                <li>Session tokens for web applications</li>
                <li>Random data for testing and development</li>
                <li>Creating secure URL parameters</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">How secure are these random strings?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Our generator uses the Web Crypto API, which provides cryptographically strong random values. This makes the strings suitable for security applications, though always follow best practices for your specific use case.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">What's the maximum length possible?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  The tool supports generating strings up to 1000 characters, though most applications rarely need strings longer than 64 characters.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Is my data private when using this tool?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, this tool operates entirely in your browser. No data is sent to our servers, ensuring complete privacy.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolLayout>
  );
};

export default RandomStringGenerator;
