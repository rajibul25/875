
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { QrCode, Download, ArrowRight, Check, X, Link as LinkIcon } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import BackButton from "@/components/BackButton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import QRCode from "qrcode";

const QRCodeGenerator = () => {
  const navigate = useNavigate();
  const [content, setContent] = useState("");
  const [activeTab, setActiveTab] = useState("text");
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [size, setSize] = useState(300);
  const [errorCorrection, setErrorCorrection] = useState<"L" | "M" | "Q" | "H">("M");
  const [darkColor, setDarkColor] = useState("#000000");
  const [lightColor, setLightColor] = useState("#FFFFFF");
  const [includeMargin, setIncludeMargin] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const qrContainerRef = useRef<HTMLDivElement>(null);

  // Preset links for demos
  const presetLinks = [
    { title: "Google", url: "https://www.google.com" },
    { title: "YouTube", url: "https://www.youtube.com" },
    { title: "Twitter", url: "https://www.x.com" },
    { title: "Facebook", url: "https://www.facebook.com" },
  ];

  // Content type presets
  const contentPresets = {
    text: "Hello World",
    url: "https://www.example.com",
    email: "email@example.com",
    phone: "+12345678901",
    sms: "+12345678901",
    wifi: {
      ssid: "WiFi Network Name",
      password: "wifi-password",
      security: "WPA",
    },
    contact: {
      name: "John Doe",
      phone: "+12345678901",
      email: "john@example.com",
      address: "123 Main St, City",
      website: "https://www.example.com",
    },
  };

  // Content templates based on tab
  const getContentTemplate = () => {
    switch (activeTab) {
      case "url":
        return contentPresets.url;
      case "email":
        return `mailto:${contentPresets.email}`;
      case "phone":
        return `tel:${contentPresets.phone}`;
      case "sms":
        return `sms:${contentPresets.sms}`;
      case "wifi":
        return `WIFI:S:${contentPresets.wifi.ssid};T:${contentPresets.wifi.security};P:${contentPresets.wifi.password};;`;
      case "contact":
        return `BEGIN:VCARD\nVERSION:3.0\nN:${contentPresets.contact.name}\nTEL:${contentPresets.contact.phone}\nEMAIL:${contentPresets.contact.email}\nADR:${contentPresets.contact.address}\nURL:${contentPresets.contact.website}\nEND:VCARD`;
      default:
        return contentPresets.text;
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setContent(getContentTemplate());
  };

  const handleUsePreset = (url: string) => {
    setContent(url);
    setActiveTab("url");
  };

  const getQROptions = () => {
    return {
      errorCorrectionLevel: errorCorrection,
      width: size,
      margin: includeMargin ? 4 : 0,
      color: {
        dark: darkColor,
        light: lightColor,
      },
    };
  };

  const generateQRCode = async () => {
    if (!content.trim()) {
      toast.error("Please enter content for the QR code");
      return;
    }

    setIsGenerating(true);

    try {
      const canvas = canvasRef.current;
      if (canvas) {
        const options = getQROptions();
        await QRCode.toCanvas(canvas, content, options);

        // Convert canvas to image URL
        const dataUrl = canvas.toDataURL("image/png");
        setQrCodeUrl(dataUrl);
        toast.success("QR Code generated successfully!");
      }
    } catch (error) {
      console.error("Failed to generate QR code:", error);
      toast.error("Failed to generate QR code");
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadQRCode = () => {
    if (!qrCodeUrl) return;

    const link = document.createElement("a");
    link.href = qrCodeUrl;
    link.download = "qrcode.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success("QR code downloaded successfully!");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />

      <main className="flex-grow container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center">
          <BackButton className="mr-4" />
          <h1 className="text-3xl font-bold">QR Code Generator</h1>
        </div>

        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-3xl">
          Create custom QR codes for websites, text, contact information, WiFi networks, and more. Customize colors and download high-quality QR codes for your business or personal use.
        </p>

        <AdBanner className="mb-8" />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
              <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
                <TabsList className="grid grid-cols-4 lg:grid-cols-7 gap-2">
                  <TabsTrigger value="text">Text</TabsTrigger>
                  <TabsTrigger value="url">URL</TabsTrigger>
                  <TabsTrigger value="email">Email</TabsTrigger>
                  <TabsTrigger value="phone">Phone</TabsTrigger>
                  <TabsTrigger value="sms">SMS</TabsTrigger>
                  <TabsTrigger value="wifi">WiFi</TabsTrigger>
                  <TabsTrigger value="contact">Contact</TabsTrigger>
                </TabsList>
                
                <TabsContent value="text" className="mt-4">
                  <Label htmlFor="text-content">Text Content</Label>
                  <Input
                    id="text-content"
                    placeholder="Enter text to encode in QR code"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="mt-1"
                  />
                </TabsContent>
                
                <TabsContent value="url" className="mt-4">
                  <Label htmlFor="url-content">Website URL</Label>
                  <Input
                    id="url-content"
                    placeholder="https://www.example.com"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="mt-1"
                  />
                  
                  <div className="mt-4">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Popular websites:</p>
                    <div className="flex flex-wrap gap-2">
                      {presetLinks.map((preset) => (
                        <Button
                          key={preset.title}
                          variant="outline"
                          size="sm"
                          onClick={() => handleUsePreset(preset.url)}
                          className="flex items-center"
                        >
                          <LinkIcon className="h-3 w-3 mr-1" />
                          {preset.title}
                        </Button>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="email" className="mt-4">
                  <Label htmlFor="email-content">Email Address</Label>
                  <Input
                    id="email-content"
                    placeholder="email@example.com"
                    value={content.replace("mailto:", "")}
                    onChange={(e) => setContent(`mailto:${e.target.value}`)}
                    className="mt-1"
                  />
                </TabsContent>
                
                <TabsContent value="phone" className="mt-4">
                  <Label htmlFor="phone-content">Phone Number</Label>
                  <Input
                    id="phone-content"
                    placeholder="+12345678901"
                    value={content.replace("tel:", "")}
                    onChange={(e) => setContent(`tel:${e.target.value}`)}
                    className="mt-1"
                  />
                </TabsContent>
                
                <TabsContent value="sms" className="mt-4">
                  <Label htmlFor="sms-content">SMS Number</Label>
                  <Input
                    id="sms-content"
                    placeholder="+12345678901"
                    value={content.replace("sms:", "")}
                    onChange={(e) => setContent(`sms:${e.target.value}`)}
                    className="mt-1"
                  />
                </TabsContent>
                
                <TabsContent value="wifi" className="mt-4">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="wifi-ssid">Network Name (SSID)</Label>
                      <Input
                        id="wifi-ssid"
                        placeholder="WiFi Network Name"
                        value={content.match(/S:(.*?);/) ? content.match(/S:(.*?);/)![1] : ""}
                        onChange={(e) => {
                          const ssid = e.target.value;
                          const security = content.match(/T:(.*?);/) ? content.match(/T:(.*?);/)![1] : "WPA";
                          const password = content.match(/P:(.*?);/) ? content.match(/P:(.*?);/)![1] : "";
                          setContent(`WIFI:S:${ssid};T:${security};P:${password};;`);
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="wifi-password">Password</Label>
                      <Input
                        id="wifi-password"
                        type="password"
                        placeholder="WiFi Password"
                        value={content.match(/P:(.*?);/) ? content.match(/P:(.*?);/)![1] : ""}
                        onChange={(e) => {
                          const password = e.target.value;
                          const ssid = content.match(/S:(.*?);/) ? content.match(/S:(.*?);/)![1] : "";
                          const security = content.match(/T:(.*?);/) ? content.match(/T:(.*?);/)![1] : "WPA";
                          setContent(`WIFI:S:${ssid};T:${security};P:${password};;`);
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="wifi-security">Security Type</Label>
                      <Select
                        value={content.match(/T:(.*?);/) ? content.match(/T:(.*?);/)![1] : "WPA"}
                        onValueChange={(value) => {
                          const ssid = content.match(/S:(.*?);/) ? content.match(/S:(.*?);/)![1] : "";
                          const password = content.match(/P:(.*?);/) ? content.match(/P:(.*?);/)![1] : "";
                          setContent(`WIFI:S:${ssid};T:${value};P:${password};;`);
                        }}
                      >
                        <SelectTrigger id="wifi-security">
                          <SelectValue placeholder="Select security type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="WPA">WPA/WPA2</SelectItem>
                          <SelectItem value="WEP">WEP</SelectItem>
                          <SelectItem value="nopass">No Password</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="contact" className="mt-4">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="contact-name">Full Name</Label>
                      <Input
                        id="contact-name"
                        placeholder="John Doe"
                        value={content.match(/N:(.*?)\\n/) ? content.match(/N:(.*?)\\n/)![1] : ""}
                        onChange={(e) => {
                          const currentContent = content;
                          const newContent = currentContent.replace(/N:(.*?)\\n/, `N:${e.target.value}\\n`);
                          setContent(newContent);
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="contact-phone">Phone</Label>
                      <Input
                        id="contact-phone"
                        placeholder="+12345678901"
                        value={content.match(/TEL:(.*?)\\n/) ? content.match(/TEL:(.*?)\\n/)![1] : ""}
                        onChange={(e) => {
                          const currentContent = content;
                          const newContent = currentContent.replace(/TEL:(.*?)\\n/, `TEL:${e.target.value}\\n`);
                          setContent(newContent);
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="contact-email">Email</Label>
                      <Input
                        id="contact-email"
                        placeholder="email@example.com"
                        value={content.match(/EMAIL:(.*?)\\n/) ? content.match(/EMAIL:(.*?)\\n/)![1] : ""}
                        onChange={(e) => {
                          const currentContent = content;
                          const newContent = currentContent.replace(/EMAIL:(.*?)\\n/, `EMAIL:${e.target.value}\\n`);
                          setContent(newContent);
                        }}
                        className="mt-1"
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
                
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">QR Code Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="qr-size">Size: {size}px</Label>
                    <Slider
                      id="qr-size"
                      min={100}
                      max={1000}
                      step={10}
                      value={[size]}
                      onValueChange={(value) => setSize(value[0])}
                      className="mt-2"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="error-correction">Error Correction Level</Label>
                    <Select value={errorCorrection} onValueChange={(value) => setErrorCorrection(value as any)}>
                      <SelectTrigger id="error-correction">
                        <SelectValue placeholder="Select error correction" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L">Low (7%)</SelectItem>
                        <SelectItem value="M">Medium (15%)</SelectItem>
                        <SelectItem value="Q">Quartile (25%)</SelectItem>
                        <SelectItem value="H">High (30%)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="dark-color">QR Code Color</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="dark-color"
                        type="color"
                        value={darkColor}
                        onChange={(e) => setDarkColor(e.target.value)}
                        className="w-12 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={darkColor}
                        onChange={(e) => setDarkColor(e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="light-color">Background Color</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="light-color"
                        type="color"
                        value={lightColor}
                        onChange={(e) => setLightColor(e.target.value)}
                        className="w-12 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={lightColor}
                        onChange={(e) => setLightColor(e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 flex items-center space-x-2">
                  <Switch
                    id="include-margin"
                    checked={includeMargin}
                    onCheckedChange={setIncludeMargin}
                  />
                  <Label htmlFor="include-margin">Include margin around QR code</Label>
                </div>
                
                <Button
                  className="mt-6 bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={generateQRCode}
                  disabled={isGenerating || !content.trim()}
                >
                  {isGenerating ? "Generating..." : "Generate QR Code"}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
              <h3 className="text-lg font-medium mb-4">QR Code Preview</h3>
              <div
                ref={qrContainerRef}
                className="border rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-700 flex items-center justify-center p-4"
              >
                {qrCodeUrl ? (
                  <img
                    src={qrCodeUrl}
                    alt="Generated QR Code"
                    className="max-w-full"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 text-center">
                    <QrCode className="h-16 w-16 text-gray-400 dark:text-gray-500 mb-2" />
                    <p className="text-gray-500 dark:text-gray-400 text-sm">
                      Generate a QR code to see preview
                    </p>
                  </div>
                )}
              </div>
              
              <canvas ref={canvasRef} className="hidden"></canvas>
              
              {qrCodeUrl && (
                <Button
                  className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white"
                  onClick={downloadQRCode}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download QR Code
                </Button>
              )}
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h3 className="text-lg font-medium mb-4">About QR Codes</h3>
              <div className="space-y-3 text-sm text-gray-600 dark:text-gray-300">
                <p>
                  QR codes (Quick Response codes) are two-dimensional barcodes that can be scanned by smartphones and QR readers to quickly access information.
                </p>
                <p>
                  They can store various types of data including URLs, text, contact information, and more.
                </p>
                <p>
                  Higher error correction levels make QR codes more resilient to damage or poor scanning conditions, but require more space.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default QRCodeGenerator;
