
import { useState } from "react";
import { ArrowRight, Calculator, DollarSign, BarChart2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import AdBanner from "@/components/AdBanner";
import { Helmet } from "react-helmet";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const BreakEvenCalculator = () => {
  const [fixedCosts, setFixedCosts] = useState<string>("");
  const [variableCostPerUnit, setVariableCostPerUnit] = useState<string>("");
  const [sellingPricePerUnit, setSellingPricePerUnit] = useState<string>("");
  const [breakEvenUnits, setBreakEvenUnits] = useState<number | null>(null);
  const [breakEvenSales, setBreakEvenSales] = useState<number | null>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const { toast } = useToast();

  const calculateBreakEven = () => {
    const fixedCostsValue = parseFloat(fixedCosts);
    const variableCostPerUnitValue = parseFloat(variableCostPerUnit);
    const sellingPricePerUnitValue = parseFloat(sellingPricePerUnit);
    
    if (isNaN(fixedCostsValue) || isNaN(variableCostPerUnitValue) || isNaN(sellingPricePerUnitValue)) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter valid numbers for all fields."
      });
      return;
    }
    
    if (fixedCostsValue < 0 || variableCostPerUnitValue < 0 || sellingPricePerUnitValue <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "All values must be positive and selling price must be greater than zero."
      });
      return;
    }
    
    if (variableCostPerUnitValue >= sellingPricePerUnitValue) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Variable cost per unit must be less than selling price per unit."
      });
      return;
    }
    
    // Calculate contribution margin per unit
    const contributionMarginPerUnit = sellingPricePerUnitValue - variableCostPerUnitValue;
    
    // Calculate break-even units
    const beUnits = fixedCostsValue / contributionMarginPerUnit;
    
    // Calculate break-even sales
    const beSales = beUnits * sellingPricePerUnitValue;
    
    setBreakEvenUnits(beUnits);
    setBreakEvenSales(beSales);
    
    // Generate chart data
    const maxUnits = Math.ceil(beUnits * 2);
    const increment = Math.ceil(maxUnits / 10);
    const chartDataArray = [];
    
    for (let units = 0; units <= maxUnits; units += increment) {
      const sales = units * sellingPricePerUnitValue;
      const totalVariableCosts = units * variableCostPerUnitValue;
      const totalCosts = fixedCostsValue + totalVariableCosts;
      const profit = sales - totalCosts;
      
      chartDataArray.push({
        units,
        sales,
        fixedCosts: fixedCostsValue,
        totalCosts,
        profit
      });
    }
    
    setChartData(chartDataArray);
    
    toast({
      title: "Calculation complete",
      description: "Break-even point has been calculated successfully."
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateBreakEven();
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Break-Even Calculator - Calculate Business Break-Even Point | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate your business break-even point and analyze the number of units needed to cover your costs with our free break-even calculator."
        />
        <meta
          name="keywords"
          content="break-even calculator, break-even analysis, business calculator, profit calculator, fixed costs, variable costs"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/break-even-calculator" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Break-Even Calculator",
            "applicationCategory": "BusinessApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "operatingSystem": "All",
            "description": "Free online break-even calculator. Calculate your business break-even point and analyze when you'll start making a profit."
          })}
        </script>
      </Helmet>
      
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <BackButton />
          <h1 className="text-3xl font-bold text-center lg:text-left">Break-Even Calculator</h1>
          <div className="w-[70px]"></div> {/* Empty div for alignment */}
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <BarChart2 className="mr-2 text-tool-purple" />
              Calculate Break-Even Point
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Calculate how many units you need to sell to cover your costs and when your business will start making a profit.
            </p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Fixed Costs ($)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input
                      type="number"
                      placeholder="Enter total fixed costs"
                      value={fixedCosts}
                      onChange={(e) => setFixedCosts(e.target.value)}
                      className="pl-9"
                      step="0.01"
                      min="0"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Total costs that don't change with volume</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Variable Cost Per Unit ($)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input
                      type="number"
                      placeholder="Enter variable cost per unit"
                      value={variableCostPerUnit}
                      onChange={(e) => setVariableCostPerUnit(e.target.value)}
                      className="pl-9"
                      step="0.01"
                      min="0"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Cost that changes with each unit produced</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Selling Price Per Unit ($)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input
                      type="number"
                      placeholder="Enter selling price per unit"
                      value={sellingPricePerUnit}
                      onChange={(e) => setSellingPricePerUnit(e.target.value)}
                      className="pl-9"
                      step="0.01"
                      min="0"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Price at which each unit is sold</p>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button 
                  type="submit" 
                  className="gap-2 bg-tool-purple hover:bg-tool-purple/90"
                >
                  Calculate Break-Even
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </form>
            
            {breakEvenUnits !== null && breakEvenSales !== null && (
              <div className="mt-8 pt-6 border-t">
                <h3 className="text-lg font-medium mb-4">Break-Even Results</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg">
                    <h4 className="text-sm uppercase text-blue-600 dark:text-blue-400 font-medium mb-2">Units to Break Even</h4>
                    <p className="text-3xl font-bold text-blue-700 dark:text-blue-300">
                      {Math.ceil(breakEvenUnits).toLocaleString()} units
                    </p>
                    <p className="text-sm text-blue-600 dark:text-blue-400 mt-2">
                      You need to sell {Math.ceil(breakEvenUnits).toLocaleString()} units to cover all costs.
                    </p>
                  </div>
                  
                  <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg">
                    <h4 className="text-sm uppercase text-green-600 dark:text-green-400 font-medium mb-2">Revenue to Break Even</h4>
                    <p className="text-3xl font-bold text-green-700 dark:text-green-300">
                      {formatCurrency(breakEvenSales)}
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                      You need to generate {formatCurrency(breakEvenSales)} in revenue to start making a profit.
                    </p>
                  </div>
                </div>
                
                {chartData.length > 0 && (
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <h4 className="text-lg font-medium mb-4">Break-Even Analysis Chart</h4>
                    <div className="h-80 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={chartData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="units" 
                            label={{ value: 'Units Sold', position: 'insideBottomRight', offset: -5 }} 
                          />
                          <YAxis />
                          <Tooltip 
                            formatter={(value) => formatCurrency(Number(value))} 
                            labelFormatter={(value) => `Units: ${value}`}
                          />
                          <Legend />
                          <Line type="monotone" dataKey="sales" name="Revenue" stroke="#4f46e5" strokeWidth={2} />
                          <Line type="monotone" dataKey="fixedCosts" name="Fixed Costs" stroke="#f59e0b" strokeWidth={2} />
                          <Line type="monotone" dataKey="totalCosts" name="Total Costs" stroke="#ef4444" strokeWidth={2} />
                          <Line type="monotone" dataKey="profit" name="Profit" stroke="#10b981" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-sm text-gray-500 italic text-center mt-2">
                      The point where Revenue and Total Costs lines intersect is your break-even point.
                    </p>
                  </div>
                )}
              </div>
            )}
          </Card>
          
          <AdBanner className="my-8" />
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">What is a Break-Even Calculator?</h2>
            <p className="mb-4">
              A break-even calculator is a financial tool that helps businesses determine the point at which total revenue equals total costs, resulting in neither profit nor loss. Understanding your break-even point is crucial for business planning and pricing decisions.
            </p>
            
            <h3 className="text-lg font-medium mb-2">Important Break-Even Concepts</h3>
            <div className="space-y-3 mb-4">
              <div>
                <h4 className="font-medium">Fixed Costs</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  Expenses that don't change regardless of production levels, such as rent, salaries, insurance, and loan payments.
                </p>
              </div>
              
              <div>
                <h4 className="font-medium">Variable Costs</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  Expenses that change with production volume, such as materials, direct labor, packaging, and sales commissions.
                </p>
              </div>
              
              <div>
                <h4 className="font-medium">Contribution Margin</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  The difference between selling price per unit and variable cost per unit, representing how much each unit contributes to covering fixed costs.
                </p>
              </div>
            </div>
            
            <h3 className="text-lg font-medium mb-2">Break-Even Formulas</h3>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-md space-y-3 mb-4">
              <div>
                <p className="font-medium">Break-Even Point (Units)</p>
                <p className="text-gray-600 dark:text-gray-300">
                  Fixed Costs ÷ (Selling Price per Unit - Variable Cost per Unit)
                </p>
              </div>
              
              <div>
                <p className="font-medium">Break-Even Point (Revenue)</p>
                <p className="text-gray-600 dark:text-gray-300">
                  Fixed Costs ÷ (1 - (Variable Cost per Unit ÷ Selling Price per Unit))
                </p>
              </div>
            </div>
            
            <h3 className="text-lg font-medium mb-2">How to Use This Calculator</h3>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li>Enter your total fixed costs</li>
              <li>Enter the variable cost per unit</li>
              <li>Enter the selling price per unit</li>
              <li>Click the "Calculate Break-Even" button</li>
              <li>View your break-even point in units and dollars, along with a visual chart</li>
            </ol>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">How can I lower my break-even point?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  You can lower your break-even point by reducing fixed costs, reducing variable costs, or increasing your selling price. Each approach has different implications for your business strategy.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What is a good break-even point?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  A "good" break-even point varies by industry and business model. Generally, a lower break-even point is better as it means you'll start making a profit sooner. Compare your break-even point to your expected sales volume to assess if it's realistic.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How does break-even analysis help in business planning?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Break-even analysis helps with pricing decisions, setting sales targets, evaluating new products, planning production levels, and assessing the impact of changes in costs or prices. It's a foundational tool for financial planning.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What are the limitations of break-even analysis?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Break-even analysis assumes linear relationships between costs and units sold, which may not always be accurate. It also doesn't account for changes in market conditions, competition, or consumer behavior.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Should I include opportunity costs in my break-even analysis?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  While traditional break-even analysis focuses on actual cash flows, considering opportunity costs can provide a more comprehensive view of your business decisions. You can incorporate them into your fixed costs if relevant to your decision-making.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default BreakEvenCalculator;
