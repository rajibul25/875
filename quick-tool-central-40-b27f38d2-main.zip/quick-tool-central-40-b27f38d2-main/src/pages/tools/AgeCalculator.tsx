
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar, Clock } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const AgeCalculatorComponent = () => {
  const [birthDate, setBirthDate] = useState<string>("");
  const [age, setAge] = useState<{
    years: number;
    months: number;
    days: number;
    hours: number;
  } | null>(null);
  
  const calculateAge = () => {
    if (!birthDate) {
      toast.error("Please enter your birth date");
      return;
    }
    
    const birth = new Date(birthDate);
    const now = new Date();
    
    if (birth > now) {
      toast.error("Birth date cannot be in the future");
      return;
    }
    
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();
    
    if (months < 0 || (months === 0 && days < 0)) {
      years--;
      months += 12;
    }
    
    if (days < 0) {
      const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 0);
      days += prevMonth.getDate();
      months--;
    }
    
    // Calculate hours (approx)
    const diffMs = now.getTime() - birth.getTime();
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    
    setAge({ years, months, days, hours });
    toast.success("Age calculated successfully!");
  };
  
  return (
    <ToolLayout
      title="Age Calculator"
      description="Calculate your exact age in years, months, days, and hours"
      helpText="Enter your birth date to calculate your age"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700">
            Birth Date
          </label>
          <Input
            id="birthDate"
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="w-full"
          />
        </div>
        
        <Button 
          onClick={calculateAge}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!birthDate}
        >
          <Calendar className="mr-2 h-4 w-4" /> Calculate Age
        </Button>
        
        {age && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-2">Your Age</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-purple-600">{age.years}</p>
                <p className="text-gray-600">Years</p>
              </div>
              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-purple-600">{age.months}</p>
                <p className="text-gray-600">Months</p>
              </div>
              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-purple-600">{age.days}</p>
                <p className="text-gray-600">Days</p>
              </div>
              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-purple-600">{age.hours.toLocaleString()}</p>
                <p className="text-gray-600">Hours</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const AgeCalculator = withErrorBoundary(AgeCalculatorComponent, "age-calculator");

export default AgeCalculator;
