
import React from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const CompressPdf = () => {
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is PDF
    if (file.type !== "application/pdf") {
      toast.error("Please upload a PDF file");
      return;
    }

    // Here we would process the file, but for now we'll just show a toast
    toast.success(`File "${file.name}" uploaded successfully. Compression will be available in a future update.`);
  };

  return (
    <ToolLayout 
      title="Compress PDF"
      description="Reduce PDF file size online while maintaining quality, for free."
    >
      <Helmet>
        <title>Compress PDF | Reduce PDF File Size Online | MultiToolSet</title>
        <meta
          name="description"
          content="Compress and reduce PDF file size online for free. Optimize your PDF documents while maintaining quality with our PDF compression tool."
        />
      </Helmet>

      <div className="container mx-auto py-8">
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center">
                <Label htmlFor="pdf-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600">
                      Click to upload or drag and drop
                    </span>
                    <span className="text-xs text-gray-500">PDF files only (max 10MB)</span>
                  </div>
                  <Input
                    id="pdf-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,application/pdf"
                    onChange={handleFileUpload}
                  />
                </Label>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast.info("This feature will be available in a future update.");
                  }}
                  size="lg"
                >
                  Compress PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Compress PDF Files</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload your PDF file using the upload button above</li>
              <li>Select compression level (coming soon)</li>
              <li>Click the "Compress PDF" button</li>
              <li>Download your compressed PDF file</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our PDF Compressor</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Free to use with no watermarks</li>
              <li>Multiple compression levels (coming soon)</li>
              <li>Reduce file size while maintaining readability</li>
              <li>Optimize PDF for web, email, or printing</li>
              <li>Secure and private - files deleted after processing</li>
              <li>No installation required - works in your browser</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default CompressPdf;
