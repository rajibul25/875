import { useState } from "react";
import { Book, Copy, Check, Link, ArrowRight, Newspaper, User, Building, Clock, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import ToolLayout from "@/components/tools/ToolLayout";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const CitationGenerator = () => {
  const [citationType, setCitationType] = useState<"website" | "book" | "journal" | "newspaper">("website");
  const [citationStyle, setCitationStyle] = useState<"apa" | "mla" | "chicago" | "harvard">("apa");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    year: "",
    month: "",
    day: "",
    publisher: "",
    websiteUrl: "",
    dateAccessed: new Date().toISOString().split('T')[0],
    edition: "",
    place: "",
    journalName: "",
    volume: "",
    issue: "",
    pages: "",
    doi: "",
    newspaperName: "",
    section: ""
  });
  
  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleResetForm = () => {
    setFormData({
      title: "",
      author: "",
      year: "",
      month: "",
      day: "",
      publisher: "",
      websiteUrl: "",
      dateAccessed: new Date().toISOString().split('T')[0],
      edition: "",
      place: "",
      journalName: "",
      volume: "",
      issue: "",
      pages: "",
      doi: "",
      newspaperName: "",
      section: ""
    });
  };
  
  const formatAuthor = (author: string, style: string): string => {
    if (!author) return "";
    
    const authors = author.split(',').map(a => a.trim());
    
    if (style === "apa") {
      return authors.map(a => {
        const parts = a.split(' ');
        if (parts.length < 2) return a;
        
        const lastName = parts[parts.length - 1];
        const initials = parts.slice(0, parts.length - 1).map(name => `${name.charAt(0)}.`).join(' ');
        
        return `${lastName}, ${initials}`;
      }).join(', ');
    }
    
    if (style === "mla") {
      return authors.map(a => a).join(', ');
    }
    
    return author;
  };
  
  const formatDate = (year: string, month: string, day: string, style: string): string => {
    if (!year) return "";
    
    if (style === "apa") {
      if (month && day) {
        return `(${year}, ${MONTHS[parseInt(month) - 1]} ${day})`;
      }
      if (month) {
        return `(${year}, ${MONTHS[parseInt(month) - 1]})`;
      }
      return `(${year})`;
    }
    
    if (style === "mla") {
      if (day && month) {
        return `${day} ${MONTHS[parseInt(month) - 1]} ${year}`;
      }
      return year;
    }
    
    return year;
  };
  
  const generateCitation = (): string => {
    const {
      title,
      author,
      year,
      month,
      day,
      publisher,
      websiteUrl,
      dateAccessed,
      edition,
      place,
      journalName,
      volume,
      issue,
      pages,
      doi,
      newspaperName,
      section
    } = formData;
    
    const formattedAuthor = formatAuthor(author, citationStyle);
    const formattedDate = formatDate(year, month, day, citationStyle);
    
    if (citationStyle === "apa") {
      if (citationType === "website") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${formattedDate}. ${title}. ${publisher ? publisher + '. ' : ''}${websiteUrl}`;
      }
      
      if (citationType === "book") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${formattedDate}. ${title}${edition ? ` (${edition} ed.)` : ''}. ${publisher ? publisher + '.' : ''}${place ? ' ' + place + '.' : ''}`;
      }
      
      if (citationType === "journal") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${formattedDate}. ${title}. ${journalName}${volume ? ', ' + volume : ''}${issue ? '(' + issue + ')' : ''}${pages ? ', ' + pages : ''}. ${doi ? 'https://doi.org/' + doi : ''}`;
      }
      
      if (citationType === "newspaper") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${formattedDate}. ${title}. ${newspaperName}${day && month ? ', ' + parseInt(day) + ' ' + MONTHS[parseInt(month) - 1] : ''} ${year}${section ? ', ' + section : ''}${pages ? ': ' + pages : ''}.`;
      }
    }
    
    if (citationStyle === "mla") {
      if (citationType === "website") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}"${title}." ${publisher ? publisher + ', ' : ''}${formattedDate}. Web. ${new Date(dateAccessed).toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}.`;
      }
      
      if (citationType === "book") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}${title}. ${edition ? edition + ' ed., ' : ''}${place ? place + ': ' : ''}${publisher ? publisher + ', ' : ''}${year}.`;
      }
      
      if (citationType === "journal") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}"${title}." ${journalName} ${volume ? 'vol. ' + volume : ''}${issue ? ', no. ' + issue : ''}${year ? ', ' + year : ''}${pages ? ', pp. ' + pages : ''}.`;
      }
      
      if (citationType === "newspaper") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}"${title}." ${newspaperName}${day && month ? ', ' + parseInt(day) + ' ' + MONTHS[parseInt(month) - 1] : ''} ${year}${section ? ', ' + section : ''}${pages ? ': ' + pages : ''}.`;
      }
    }
    
    if (citationStyle === "chicago") {
      if (citationType === "website") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}"${title}." ${publisher ? publisher + '. ' : ''}Accessed ${new Date(dateAccessed).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}. ${websiteUrl}.`;
      }
      
      if (citationType === "book") {
        return `${formattedAuthor ? formattedAuthor + '. ' : ''}${title}. ${edition ? edition + ' ed. ' : ''}${place ? place + ': ' : ''}${publisher ? publisher + ', ' : ''}${year}.`;
      }
      
      // Add other Chicago style formats as needed
    }
    
    if (citationStyle === "harvard") {
      if (citationType === "website") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${year ? year + '. ' : ''}${title}. [online] ${publisher ? publisher + '. ' : ''}Available at: ${websiteUrl} [Accessed ${new Date(dateAccessed).toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}].`;
      }
      
      if (citationType === "book") {
        return `${formattedAuthor ? formattedAuthor + ' ' : ''}${year ? '(' + year + '). ' : ''}${title}. ${edition ? edition + ' ed. ' : ''}${place ? place + ': ' : ''}${publisher}.`;
      }
      
      // Add other Harvard style formats as needed
    }
    
    return "Please fill in the required fields to generate a citation.";
  };
  
  const citation = generateCitation();
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(citation);
    setCopied(true);
    toast({
      title: "Citation copied",
      description: "The citation has been copied to your clipboard."
    });
    
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };
  
  const renderSourceInputs = () => {
    switch (citationType) {
      case "website":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Website Title*</Label>
                <Input 
                  id="title"
                  value={formData.title}
                  onChange={(e) => updateFormData("title", e.target.value)}
                  placeholder="Enter website title"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author(s)</Label>
                <Input 
                  id="author"
                  value={formData.author}
                  onChange={(e) => updateFormData("author", e.target.value)}
                  placeholder="Author name(s), separate with commas"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Year</Label>
                <Input 
                  id="year"
                  value={formData.year}
                  onChange={(e) => updateFormData("year", e.target.value)}
                  placeholder="YYYY"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="month">Month</Label>
                <Input 
                  id="month"
                  value={formData.month}
                  onChange={(e) => updateFormData("month", e.target.value)}
                  placeholder="MM"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="day">Day</Label>
                <Input 
                  id="day"
                  value={formData.day}
                  onChange={(e) => updateFormData("day", e.target.value)}
                  placeholder="DD"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="websiteUrl">Website URL*</Label>
                <Input 
                  id="websiteUrl"
                  value={formData.websiteUrl}
                  onChange={(e) => updateFormData("websiteUrl", e.target.value)}
                  placeholder="https://example.com"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="publisher">Publisher/Website Name</Label>
                <Input 
                  id="publisher"
                  value={formData.publisher}
                  onChange={(e) => updateFormData("publisher", e.target.value)}
                  placeholder="Website or publisher name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateAccessed">Date Accessed</Label>
                <Input 
                  id="dateAccessed"
                  type="date"
                  value={formData.dateAccessed}
                  onChange={(e) => updateFormData("dateAccessed", e.target.value)}
                />
              </div>
            </div>
          </div>
        );
        
      case "book":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Book Title*</Label>
                <Input 
                  id="title"
                  value={formData.title}
                  onChange={(e) => updateFormData("title", e.target.value)}
                  placeholder="Enter book title"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author(s)*</Label>
                <Input 
                  id="author"
                  value={formData.author}
                  onChange={(e) => updateFormData("author", e.target.value)}
                  placeholder="Author name(s), separate with commas"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Year Published*</Label>
                <Input 
                  id="year"
                  value={formData.year}
                  onChange={(e) => updateFormData("year", e.target.value)}
                  placeholder="YYYY"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edition">Edition</Label>
                <Input 
                  id="edition"
                  value={formData.edition}
                  onChange={(e) => updateFormData("edition", e.target.value)}
                  placeholder="e.g., 2nd"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="place">Place of Publication</Label>
                <Input 
                  id="place"
                  value={formData.place}
                  onChange={(e) => updateFormData("place", e.target.value)}
                  placeholder="City, Country"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="publisher">Publisher*</Label>
                <Input 
                  id="publisher"
                  value={formData.publisher}
                  onChange={(e) => updateFormData("publisher", e.target.value)}
                  placeholder="Publishing company"
                  required
                />
              </div>
            </div>
          </div>
        );
        
      case "journal":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Article Title*</Label>
                <Input 
                  id="title"
                  value={formData.title}
                  onChange={(e) => updateFormData("title", e.target.value)}
                  placeholder="Enter article title"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author(s)*</Label>
                <Input 
                  id="author"
                  value={formData.author}
                  onChange={(e) => updateFormData("author", e.target.value)}
                  placeholder="Author name(s), separate with commas"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="journalName">Journal Name*</Label>
                <Input 
                  id="journalName"
                  value={formData.journalName}
                  onChange={(e) => updateFormData("journalName", e.target.value)}
                  placeholder="Name of the journal"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Year Published*</Label>
                <Input 
                  id="year"
                  value={formData.year}
                  onChange={(e) => updateFormData("year", e.target.value)}
                  placeholder="YYYY"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="volume">Volume</Label>
                <Input 
                  id="volume"
                  value={formData.volume}
                  onChange={(e) => updateFormData("volume", e.target.value)}
                  placeholder="e.g., 12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="issue">Issue</Label>
                <Input 
                  id="issue"
                  value={formData.issue}
                  onChange={(e) => updateFormData("issue", e.target.value)}
                  placeholder="e.g., 3"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pages">Pages</Label>
                <Input 
                  id="pages"
                  value={formData.pages}
                  onChange={(e) => updateFormData("pages", e.target.value)}
                  placeholder="e.g., 45-67"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="doi">DOI</Label>
                <Input 
                  id="doi"
                  value={formData.doi}
                  onChange={(e) => updateFormData("doi", e.target.value)}
                  placeholder="Digital Object Identifier"
                />
              </div>
            </div>
          </div>
        );
        
      case "newspaper":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Article Title*</Label>
                <Input 
                  id="title"
                  value={formData.title}
                  onChange={(e) => updateFormData("title", e.target.value)}
                  placeholder="Enter article title"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author(s)</Label>
                <Input 
                  id="author"
                  value={formData.author}
                  onChange={(e) => updateFormData("author", e.target.value)}
                  placeholder="Author name(s), separate with commas"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="newspaperName">Newspaper Name*</Label>
                <Input 
                  id="newspaperName"
                  value={formData.newspaperName}
                  onChange={(e) => updateFormData("newspaperName", e.target.value)}
                  placeholder="Name of the newspaper"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Year Published*</Label>
                <Input 
                  id="year"
                  value={formData.year}
                  onChange={(e) => updateFormData("year", e.target.value)}
                  placeholder="YYYY"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="month">Month</Label>
                <Input 
                  id="month"
                  value={formData.month}
                  onChange={(e) => updateFormData("month", e.target.value)}
                  placeholder="MM"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="day">Day</Label>
                <Input 
                  id="day"
                  value={formData.day}
                  onChange={(e) => updateFormData("day", e.target.value)}
                  placeholder="DD"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="section">Section</Label>
                <Input 
                  id="section"
                  value={formData.section}
                  onChange={(e) => updateFormData("section", e.target.value)}
                  placeholder="e.g., Business, Politics"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pages">Pages</Label>
                <Input 
                  id="pages"
                  value={formData.pages}
                  onChange={(e) => updateFormData("pages", e.target.value)}
                  placeholder="e.g., A1, 12-13"
                />
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <ToolLayout
      title="Citation Generator"
      description="Create perfectly formatted citations for your research papers and essays"
      helpText="Select a citation style and source type, then fill in the details to generate an accurately formatted citation for your academic work."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-medium mb-4">Citation Style</h3>
            <RadioGroup 
              defaultValue="apa" 
              value={citationStyle} 
              onValueChange={(value) => setCitationStyle(value as any)}
              className="grid grid-cols-2 gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="apa" id="apa" />
                <Label htmlFor="apa">APA (7th ed.)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="mla" id="mla" />
                <Label htmlFor="mla">MLA (9th ed.)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="chicago" id="chicago" />
                <Label htmlFor="chicago">Chicago</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="harvard" id="harvard" />
                <Label htmlFor="harvard">Harvard</Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-medium mb-4">Source Type</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                variant={citationType === "website" ? "default" : "outline"}
                onClick={() => setCitationType("website")}
                className="flex flex-col items-center gap-1 h-auto py-3"
              >
                <Link className="h-5 w-5" />
                <span>Website</span>
              </Button>
              <Button
                variant={citationType === "book" ? "default" : "outline"}
                onClick={() => setCitationType("book")}
                className="flex flex-col items-center gap-1 h-auto py-3"
              >
                <Book className="h-5 w-5" />
                <span>Book</span>
              </Button>
              <Button
                variant={citationType === "journal" ? "default" : "outline"}
                onClick={() => setCitationType("journal")}
                className="flex flex-col items-center gap-1 h-auto py-3"
              >
                <User className="h-5 w-5" />
                <span>Journal</span>
              </Button>
              <Button
                variant={citationType === "newspaper" ? "default" : "outline"}
                onClick={() => setCitationType("newspaper")}
                className="flex flex-col items-center gap-1 h-auto py-3"
              >
                <Newspaper className="h-5 w-5" />
                <span>Newspaper</span>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
            {citationType === "website" ? <Link className="h-5 w-5" /> :
             citationType === "book" ? <Book className="h-5 w-5" /> :
             citationType === "journal" ? <User className="h-5 w-5" /> : 
             <Newspaper className="h-5 w-5" />}
            {citationType.charAt(0).toUpperCase() + citationType.slice(1)} Citation Details
          </h2>
          
          {renderSourceInputs()}
          
          <div className="mt-6 flex flex-wrap gap-3">
            <Button 
              onClick={() => {}} 
              variant="outline" 
              className="gap-2"
            >
              <ArrowRight className="h-4 w-4" />
              Generate Citation
            </Button>
            <Button
              onClick={handleResetForm}
              variant="outline"
            >
              Clear Form
            </Button>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Generated Citation</h2>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {citationStyle.toUpperCase()} format
              </span>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 mb-4 min-h-[100px]">
            <p className="font-medium">
              {citation}
            </p>
          </div>
          
          <Button
            onClick={copyToClipboard}
            className="w-full sm:w-auto gap-2"
            disabled={!citation.length}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied!" : "Copy Citation"}
          </Button>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-xl font-semibold mb-4">Citation Styles Guide</h2>
          <Tabs defaultValue="apa">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="apa">APA</TabsTrigger>
              <TabsTrigger value="mla">MLA</TabsTrigger>
              <TabsTrigger value="chicago">Chicago</TabsTrigger>
              <TabsTrigger value="harvard">Harvard</TabsTrigger>
            </TabsList>
            <TabsContent value="apa" className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <h3 className="font-medium text-lg mb-2">APA (7th Edition)</h3>
              <p className="mb-2">
                The American Psychological Association style is commonly used in social sciences.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Author's last name, followed by initials</li>
                <li>Publication date in parentheses</li>
                <li>Title in sentence case (only first word and proper nouns capitalized)</li>
                <li>For journals: Include volume number in italics, issue number in parentheses</li>
                <li>DOIs should be formatted as URLs (https://doi.org/xxx)</li>
              </ul>
            </TabsContent>
            <TabsContent value="mla" className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <h3 className="font-medium text-lg mb-2">MLA (9th Edition)</h3>
              <p className="mb-2">
                The Modern Language Association style is commonly used in humanities.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Author's name (last name, first name)</li>
                <li>Title of source in quotation marks</li>
                <li>Title of container in italics</li>
                <li>Other contributors, version, number, publisher, date, location</li>
                <li>For websites: Include "Accessed" date at the end</li>
              </ul>
            </TabsContent>
            <TabsContent value="chicago" className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <h3 className="font-medium text-lg mb-2">Chicago (17th Edition)</h3>
              <p className="mb-2">
                The Chicago Manual of Style offers two citation systems: notes-bibliography and author-date.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Author's name (first name first in bibliography, last name first in notes)</li>
                <li>Title in headline case (major words capitalized)</li>
                <li>Publication information (place: publisher, date)</li>
                <li>For websites: Include access date</li>
              </ul>
            </TabsContent>
            <TabsContent value="harvard" className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <h3 className="font-medium text-lg mb-2">Harvard</h3>
              <p className="mb-2">
                Harvard style is commonly used in humanities and social sciences.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Author's name (last name, initials)</li>
                <li>Year of publication in parentheses</li>
                <li>Title in sentence case (only first word and proper nouns capitalized)</li>
                <li>Publication information (place: publisher)</li>
                <li>For websites: Include "Available at:" URL and "Accessed on:" date</li>
              </ul>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ToolLayout>
  );
};

const SchemaMarkup = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Citation Generator",
    "applicationCategory": "EducationalApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "All",
    "description": "Create perfectly formatted citations in APA, MLA, Chicago, and Harvard styles for academic papers."
  };

  return (
    <script type="application/ld+json">
      {JSON.stringify(schema)}
    </script>
  );
};

const SeoHead = () => {
  return (
    <>
      <title>Citation Generator - Create APA, MLA & More Citations | MultiToolSet</title>
      <meta
        name="description"
        content="Generate perfectly formatted citations in APA, MLA, Chicago, and Harvard styles for books, websites, journals, and newspapers. Free online citation tool."
      />
      <meta
        name="keywords"
        content="citation generator, bibliography maker, APA citation, MLA citation, Chicago citation, Harvard citation, reference generator"
      />
      <link rel="canonical" href="https://multitoolset.co/tools/citation-generator" />
    </>
  );
};

const CitationGeneratorWithSeo = () => {
  return (
    <>
      <SeoHead />
      <SchemaMarkup />
      <CitationGenerator />
    </>
  );
};

export default CitationGeneratorWithSeo;
