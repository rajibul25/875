
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Helmet } from "react-helmet";
import { PercentIcon } from "@/components/icons/ToolIcons";

const BodyFatCalculator = () => {
  const [gender, setGender] = useState<"male" | "female">("male");
  const [method, setMethod] = useState<"navy" | "caliper" | "measurements">("navy");
  const [age, setAge] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [height, setHeight] = useState<string>("");
  const [neck, setNeck] = useState<string>("");
  const [waist, setWaist] = useState<string>("");
  const [hip, setHip] = useState<string>("");
  const [skinfolds, setSkinfolds] = useState<{
    triceps: string;
    suprailiac: string;
    thigh: string;
    chest: string;
    abdomen: string;
    subscapular: string;
  }>({
    triceps: "",
    suprailiac: "",
    thigh: "",
    chest: "",
    abdomen: "",
    subscapular: ""
  });
  const [unitSystem, setUnitSystem] = useState<"metric" | "imperial">("metric");
  const [results, setResults] = useState<{
    bodyFatPercentage: number;
    fatMass: number;
    leanMass: number;
    category: string;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateNavyMethodBF = () => {
    // Parse inputs
    const heightValue = parseFloat(height);
    const waistValue = parseFloat(waist);
    const neckValue = parseFloat(neck);
    const hipValue = parseFloat(hip);
    
    let bodyFatPercentage;
    
    // Navy Method for Males
    if (gender === "male") {
      bodyFatPercentage = 495 / (1.0324 - 0.19077 * Math.log10(waistValue - neckValue) + 0.15456 * Math.log10(heightValue)) - 450;
    } 
    // Navy Method for Females (includes hip measurement)
    else {
      bodyFatPercentage = 495 / (1.29579 - 0.35004 * Math.log10(waistValue + hipValue - neckValue) + 0.22100 * Math.log10(heightValue)) - 450;
    }
    
    return bodyFatPercentage;
  };

  const calculateCaliperMethodBF = () => {
    // Parse inputs for 3-site measurements
    const tricepsValue = parseFloat(skinfolds.triceps);
    const suprailiacValue = parseFloat(skinfolds.suprailiac);
    const thighValue = parseFloat(skinfolds.thigh);
    const chestValue = parseFloat(skinfolds.chest);
    const abdomenValue = parseFloat(skinfolds.abdomen);
    const subscapularValue = parseFloat(skinfolds.subscapular);
    const ageValue = parseInt(age);
    
    let bodyFatPercentage;
    let sumOfSkinfolds;
    
    // For Males (chest, abdomen, thigh)
    if (gender === "male") {
      sumOfSkinfolds = chestValue + abdomenValue + thighValue;
      bodyFatPercentage = 495 / (1.10938 - 0.0008267 * sumOfSkinfolds + 0.0000016 * Math.pow(sumOfSkinfolds, 2) - 0.0002574 * ageValue) - 450;
    } 
    // For Females (triceps, suprailiac, thigh)
    else {
      sumOfSkinfolds = tricepsValue + suprailiacValue + thighValue;
      bodyFatPercentage = 495 / (1.089733 - 0.0009245 * sumOfSkinfolds + 0.0000025 * Math.pow(sumOfSkinfolds, 2) - 0.0000979 * ageValue) - 450;
    }
    
    return bodyFatPercentage;
  };

  const calculateMeasurementsMethodBF = () => {
    // This is a simplified formula based on waist-to-height ratio
    // Not as accurate as other methods but provides an estimate
    const heightValue = parseFloat(height);
    const waistValue = parseFloat(waist);
    const hipValue = parseFloat(hip);
    const ageValue = parseInt(age);
    
    let bodyFatPercentage;
    
    if (gender === "male") {
      // Male formula based on waist and height
      const waistToHeightRatio = waistValue / heightValue;
      bodyFatPercentage = (64 - (20 * (heightValue / waistValue))) + (0.15 * ageValue);
    } else {
      // Female formula based on waist, hip, and height
      const waistToHipRatio = waistValue / hipValue;
      bodyFatPercentage = (76 - (20 * (heightValue / waistValue))) + (0.15 * ageValue);
    }
    
    // Cap the percentage to reasonable values
    bodyFatPercentage = Math.max(3, Math.min(bodyFatPercentage, 45));
    
    return bodyFatPercentage;
  };

  const getBodyFatCategory = (percentage: number) => {
    if (gender === "male") {
      if (percentage < 6) return "Essential Fat";
      if (percentage < 14) return "Athletic";
      if (percentage < 18) return "Fitness";
      if (percentage < 25) return "Average";
      return "Obese";
    } else {
      if (percentage < 13) return "Essential Fat";
      if (percentage < 21) return "Athletic";
      if (percentage < 25) return "Fitness";
      if (percentage < 32) return "Average";
      return "Obese";
    }
  };

  const calculateBodyFat = () => {
    try {
      setIsCalculating(true);
      
      // Validate basic inputs
      if (!weight) {
        toast.error("Please enter your weight.");
        setIsCalculating(false);
        return;
      }
      
      // Convert imperial to metric if needed for calculation
      let weightValue = parseFloat(weight);
      if (unitSystem === "imperial") {
        // Convert pounds to kg
        weightValue = weightValue * 0.453592;
      }
      
      let bodyFatPercentage = 0;
      
      // Calculate based on selected method
      if (method === "navy") {
        // Validate Navy method inputs
        if (!height || !neck || !waist || (gender === "female" && !hip)) {
          toast.error("Please fill in all required measurements.");
          setIsCalculating(false);
          return;
        }
        bodyFatPercentage = calculateNavyMethodBF();
      } 
      else if (method === "caliper") {
        // Validate caliper method inputs
        if (!age) {
          toast.error("Please enter your age.");
          setIsCalculating(false);
          return;
        }
        
        if (gender === "male" && (!skinfolds.chest || !skinfolds.abdomen || !skinfolds.thigh)) {
          toast.error("Please enter all required skinfold measurements.");
          setIsCalculating(false);
          return;
        }
        
        if (gender === "female" && (!skinfolds.triceps || !skinfolds.suprailiac || !skinfolds.thigh)) {
          toast.error("Please enter all required skinfold measurements.");
          setIsCalculating(false);
          return;
        }
        
        bodyFatPercentage = calculateCaliperMethodBF();
      }
      else if (method === "measurements") {
        // Validate measurements method inputs
        if (!height || !waist || !age || (gender === "female" && !hip)) {
          toast.error("Please fill in all required measurements.");
          setIsCalculating(false);
          return;
        }
        bodyFatPercentage = calculateMeasurementsMethodBF();
      }
      
      // Round to 1 decimal place
      bodyFatPercentage = Math.round(bodyFatPercentage * 10) / 10;
      
      // Calculate fat mass and lean mass
      const fatMass = (bodyFatPercentage / 100) * weightValue;
      const leanMass = weightValue - fatMass;
      
      // Get body fat category
      const category = getBodyFatCategory(bodyFatPercentage);
      
      // Simulate a small delay for feedback
      setTimeout(() => {
        setResults({
          bodyFatPercentage,
          fatMass: Math.round(fatMass * 10) / 10,
          leanMass: Math.round(leanMass * 10) / 10,
          category
        });
        setIsCalculating(false);
        toast.success("Body fat calculated successfully!");
      }, 600);
      
    } catch (error) {
      setIsCalculating(false);
      toast.error("Error calculating body fat. Please check your inputs.");
      console.error("Body fat calculation error:", error);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setWeight("");
    setHeight("");
    setNeck("");
    setWaist("");
    setHip("");
    setSkinfolds({
      triceps: "",
      suprailiac: "",
      thigh: "",
      chest: "",
      abdomen: "",
      subscapular: ""
    });
    setResults(null);
  };

  return (
    <>
      <Helmet>
        <title>Body Fat Calculator | Calculate Your Body Fat Percentage | MultitoolSet</title>
        <meta name="description" content="Calculate your body fat percentage using the Navy method, caliper measurements, or basic body measurements. Free online body fat calculator for accurate results." />
        <meta name="keywords" content="body fat calculator, body fat percentage, navy method calculator, skinfold calculator, calculate body fat, fat mass calculator" />
        <link rel="canonical" href="https://multitoolset.com/tools/body-fat-calculator" />
        <meta property="og:title" content="Body Fat Calculator | Calculate Your Body Fat Percentage" />
        <meta property="og:description" content="Calculate your body fat percentage using multiple methods for accurate results." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/body-fat-calculator" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Body Fat Calculator | Calculate Your Body Fat Percentage" />
        <meta name="twitter:description" content="Calculate your body fat percentage using multiple methods for accurate results." />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Body Fat Calculator",
              "description": "Calculate your body fat percentage using the Navy method, caliper measurements, or basic body measurements.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What is a healthy body fat percentage?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Healthy body fat percentages differ by gender. For men, 10-20% is generally considered healthy, with athletes often in the 6-13% range. For women, 18-28% is healthy, with female athletes often in the 14-20% range. Essential fat levels are around 3-5% for men and 10-13% for women."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Which body fat measurement method is most accurate?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "DEXA scans are considered the gold standard, but they're expensive and require special equipment. For at-home measurements, the Navy method offers good accuracy for most people. Skinfold caliper measurements can be accurate but require proper technique. Basic measurements are convenient but least accurate."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How can I reduce my body fat percentage?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To reduce body fat: create a moderate calorie deficit through diet, increase protein intake to preserve muscle, incorporate strength training 2-3 times per week, add regular cardio (both HIIT and steady-state), prioritize quality sleep, manage stress levels, and stay consistent with these habits over time."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
    
      <ToolLayout
        title="Body Fat Calculator"
        description="Calculate your body fat percentage using the Navy method, caliper measurements, or basic body measurements. Free online body fat calculator for accurate results."
        helpText="Choose a calculation method and enter your measurements to determine your body fat percentage, fat mass, and lean mass."
      >
        <div className="mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
        
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="calculate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculate">Calculate Body Fat</TabsTrigger>
                <TabsTrigger value="about">About Body Fat</TabsTrigger>
              </TabsList>
              
              <TabsContent value="calculate" className="space-y-6 pt-4">
                <div className="flex justify-end mb-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Label>Units:</Label>
                    <Select 
                      value={unitSystem} 
                      onValueChange={(value) => setUnitSystem(value as "metric" | "imperial")}
                    >
                      <SelectTrigger className="w-28">
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric</SelectItem>
                        <SelectItem value="imperial">Imperial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="gender" className="block mb-2">Gender</Label>
                    <RadioGroup 
                      defaultValue="male" 
                      value={gender}
                      onValueChange={(value) => setGender(value as "male" | "female")}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male">Male</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female">Female</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <Label htmlFor="method" className="block mb-2">Calculation Method</Label>
                    <Select 
                      value={method} 
                      onValueChange={(value) => setMethod(value as "navy" | "caliper" | "measurements")}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select calculation method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="navy">Navy Method (Most Accurate)</SelectItem>
                        <SelectItem value="caliper">Skinfold Caliper Method</SelectItem>
                        <SelectItem value="measurements">Basic Measurements Method</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="weight">
                      Weight ({unitSystem === "metric" ? "kg" : "lbs"})
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter your weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min={unitSystem === "metric" ? "30" : "66"}
                      step="0.1"
                      className="mt-1"
                    />
                  </div>
                  
                  {method === "navy" && (
                    <>
                      <div>
                        <Label htmlFor="height">
                          Height ({unitSystem === "metric" ? "cm" : "inches"})
                        </Label>
                        <Input
                          id="height"
                          type="number"
                          placeholder={`Enter your height in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          min={unitSystem === "metric" ? "130" : "50"}
                          step="0.1"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="neck">
                          Neck Circumference ({unitSystem === "metric" ? "cm" : "inches"})
                        </Label>
                        <Input
                          id="neck"
                          type="number"
                          placeholder={`Measure at the narrowest point`}
                          value={neck}
                          onChange={(e) => setNeck(e.target.value)}
                          min="0"
                          step="0.1"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="waist">
                          Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})
                        </Label>
                        <Input
                          id="waist"
                          type="number"
                          placeholder={`Measure at navel level while relaxed`}
                          value={waist}
                          onChange={(e) => setWaist(e.target.value)}
                          min="0"
                          step="0.1"
                          className="mt-1"
                        />
                      </div>
                      
                      {gender === "female" && (
                        <div>
                          <Label htmlFor="hip">
                            Hip Circumference ({unitSystem === "metric" ? "cm" : "inches"})
                          </Label>
                          <Input
                            id="hip"
                            type="number"
                            placeholder={`Measure at the widest point`}
                            value={hip}
                            onChange={(e) => setHip(e.target.value)}
                            min="0"
                            step="0.1"
                            className="mt-1"
                          />
                        </div>
                      )}
                    </>
                  )}
                  
                  {method === "caliper" && (
                    <>
                      <div>
                        <Label htmlFor="age">Age</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="Enter your age"
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                          min="18"
                          max="80"
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="border-t pt-4 mt-4">
                        <h3 className="font-medium mb-2">Skinfold Measurements ({unitSystem === "metric" ? "mm" : "inches"})</h3>
                        
                        {gender === "male" ? (
                          <>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="chest">Chest</Label>
                                <Input
                                  id="chest"
                                  type="number"
                                  placeholder="Diagonal fold at the pectoral"
                                  value={skinfolds.chest}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, chest: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                              <div>
                                <Label htmlFor="abdomen">Abdomen</Label>
                                <Input
                                  id="abdomen"
                                  type="number"
                                  placeholder="Vertical fold beside navel"
                                  value={skinfolds.abdomen}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, abdomen: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                              <div>
                                <Label htmlFor="thigh">Thigh</Label>
                                <Input
                                  id="thigh"
                                  type="number"
                                  placeholder="Vertical fold on front of thigh"
                                  value={skinfolds.thigh}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, thigh: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="triceps">Triceps</Label>
                                <Input
                                  id="triceps"
                                  type="number"
                                  placeholder="Vertical fold on back of arm"
                                  value={skinfolds.triceps}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, triceps: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                              <div>
                                <Label htmlFor="suprailiac">Suprailiac</Label>
                                <Input
                                  id="suprailiac"
                                  type="number"
                                  placeholder="Diagonal fold above iliac crest"
                                  value={skinfolds.suprailiac}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, suprailiac: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                              <div>
                                <Label htmlFor="thigh">Thigh</Label>
                                <Input
                                  id="thigh"
                                  type="number"
                                  placeholder="Vertical fold on front of thigh"
                                  value={skinfolds.thigh}
                                  onChange={(e) => setSkinfolds({ ...skinfolds, thigh: e.target.value })}
                                  min="0"
                                  step="0.1"
                                  className="mt-1"
                                />
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    </>
                  )}
                  
                  {method === "measurements" && (
                    <>
                      <div>
                        <Label htmlFor="age">Age</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="Enter your age"
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                          min="18"
                          max="80"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="height">
                          Height ({unitSystem === "metric" ? "cm" : "inches"})
                        </Label>
                        <Input
                          id="height"
                          type="number"
                          placeholder={`Enter your height in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          min={unitSystem === "metric" ? "130" : "50"}
                          step="0.1"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="waist">
                          Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})
                        </Label>
                        <Input
                          id="waist"
                          type="number"
                          placeholder={`Measure at navel level while relaxed`}
                          value={waist}
                          onChange={(e) => setWaist(e.target.value)}
                          min="0"
                          step="0.1"
                          className="mt-1"
                        />
                      </div>
                      
                      {gender === "female" && (
                        <div>
                          <Label htmlFor="hip">
                            Hip Circumference ({unitSystem === "metric" ? "cm" : "inches"})
                          </Label>
                          <Input
                            id="hip"
                            type="number"
                            placeholder={`Measure at the widest point`}
                            value={hip}
                            onChange={(e) => setHip(e.target.value)}
                            min="0"
                            step="0.1"
                            className="mt-1"
                          />
                        </div>
                      )}
                    </>
                  )}
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={calculateBodyFat} 
                      className="flex-1"
                      disabled={isCalculating}
                    >
                      {isCalculating ? "Calculating..." : "Calculate Body Fat"}
                    </Button>
                    <Button variant="outline" onClick={resetCalculator}>Reset</Button>
                  </div>
                </div>
                
                {results && (
                  <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-900/50 dark:border-slate-800">
                    <h3 className="font-semibold text-lg mb-4">Your Body Composition</h3>
                    
                    <div className="mb-6 text-center">
                      <div className="inline-block bg-gray-100 p-4 rounded-full dark:bg-gray-800">
                        <div className="relative h-32 w-32">
                          <svg viewBox="0 0 36 36" className="h-32 w-32 -rotate-90">
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#E5E7EB"
                              strokeWidth="2"
                              className="dark:stroke-gray-700"
                            />
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#3B82F6"
                              strokeWidth="2"
                              strokeDasharray={`${results.bodyFatPercentage}, 100`}
                              className="dark:stroke-blue-500"
                            />
                          </svg>
                          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">{results.bodyFatPercentage}%</div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">Body Fat</div>
                          </div>
                        </div>
                      </div>
                      <p className="mt-4 text-xl font-semibold">{results.category}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-white rounded border dark:bg-slate-800 dark:border-slate-700">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Fat Mass</p>
                        <p className="text-xl font-bold">{results.fatMass} {unitSystem === "metric" ? "kg" : "lbs"}</p>
                      </div>
                      <div className="p-3 bg-white rounded border dark:bg-slate-800 dark:border-slate-700">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Lean Mass</p>
                        <p className="text-xl font-bold">{results.leanMass} {unitSystem === "metric" ? "kg" : "lbs"}</p>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Body Fat Range</span>
                      </div>
                      <div className="h-4 w-full bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700">
                        <div className="h-4 flex">
                          <div className="h-full bg-blue-900 w-[5%]" title="Essential Fat"></div>
                          <div className="h-full bg-blue-600 w-[10%]" title="Athletic"></div>
                          <div className="h-full bg-green-500 w-[20%]" title="Fitness"></div>
                          <div className="h-full bg-yellow-500 w-[30%]" title="Average"></div>
                          <div className="h-full bg-red-500 w-[35%]" title="Obese"></div>
                        </div>
                      </div>
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Essential</span>
                        <span>Athletic</span>
                        <span>Fitness</span>
                        <span>Average</span>
                        <span>Obese</span>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="about" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">What is Body Fat Percentage?</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Body fat percentage is the amount of fat mass in your body, compared to everything else (lean mass). It's a more useful metric than weight alone because it tells you about your body composition rather than just how heavy you are.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Body Fat Categories</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full mt-2 border-collapse">
                      <thead>
                        <tr className="bg-slate-100 dark:bg-slate-800">
                          <th className="p-2 text-left border dark:border-slate-700">Category</th>
                          <th className="p-2 text-left border dark:border-slate-700">Men</th>
                          <th className="p-2 text-left border dark:border-slate-700">Women</th>
                          <th className="p-2 text-left border dark:border-slate-700">Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Essential Fat</td>
                          <td className="p-2 border dark:border-slate-700">3-5%</td>
                          <td className="p-2 border dark:border-slate-700">10-13%</td>
                          <td className="p-2 border dark:border-slate-700">Minimum needed for basic health</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Athletic</td>
                          <td className="p-2 border dark:border-slate-700">6-13%</td>
                          <td className="p-2 border dark:border-slate-700">14-20%</td>
                          <td className="p-2 border dark:border-slate-700">Typical for elite athletes</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Fitness</td>
                          <td className="p-2 border dark:border-slate-700">14-17%</td>
                          <td className="p-2 border dark:border-slate-700">21-24%</td>
                          <td className="p-2 border dark:border-slate-700">Lean, defined muscles</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Average</td>
                          <td className="p-2 border dark:border-slate-700">18-24%</td>
                          <td className="p-2 border dark:border-slate-700">25-31%</td>
                          <td className="p-2 border dark:border-slate-700">Typical for many adults</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Obese</td>
                          <td className="p-2 border dark:border-slate-700">25%+</td>
                          <td className="p-2 border dark:border-slate-700">32%+</td>
                          <td className="p-2 border dark:border-slate-700">Excessive fat, health risks</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">About Our Calculation Methods</h3>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium">Navy Method</h4>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">
                        The U.S. Navy method estimates body fat using height, neck, waist, and (for women) hip measurements. It's one of the most accessible and reasonably accurate methods for home use.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium">Skinfold Caliper Method</h4>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">
                        This method uses measurements from skinfold calipers at specific sites on the body. It can be very accurate when done correctly, but requires proper technique and equipment.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium">Basic Measurements Method</h4>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">
                        This simplified method uses height, waist, age, and (for women) hip measurements to estimate body fat percentage. It's less accurate than other methods but requires minimal measurements.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">How to Measure Accurately</h3>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li>Take measurements in the morning before eating or drinking</li>
                    <li>Use a flexible tape measure and pull it snug, but not tight</li>
                    <li>For waist measurement, measure at navel level while relaxed (not sucking in)</li>
                    <li>For neck measurement, measure at the narrowest point</li>
                    <li>For hip measurement, measure at the widest point around your buttocks</li>
                    <li>For skinfold measurements, pinch the skin and measure only the fat fold thickness</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Reducing Body Fat</h3>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li>Create a moderate calorie deficit (250-500 calories below maintenance)</li>
                    <li>Increase protein intake (1.6-2.2g per kg of bodyweight)</li>
                    <li>Incorporate strength training 2-4 times per week</li>
                    <li>Include both HIIT and steady-state cardio</li>
                    <li>Prioritize whole foods over processed foods</li>
                    <li>Ensure adequate sleep (7-9 hours for most adults)</li>
                    <li>Manage stress levels</li>
                    <li>Stay consistent with your habits</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-full bg-blue-100 flex items-center justify-center dark:bg-blue-900/30">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="mt-2 font-semibold">Accurate Tracking</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Track your body fat % over time to see progress and make adjustments.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-full bg-green-100 flex items-center justify-center dark:bg-green-900/30">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="mt-2 font-semibold">Multiple Methods</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Choose from different calculation methods based on available measurements.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-full bg-purple-100 flex items-center justify-center dark:bg-purple-900/30">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-600 dark:text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="mt-2 font-semibold">Actionable Insights</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Get personalized category classification and body composition details.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Bottom Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/macro-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Macro Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Ideal Weight Calculator</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default BodyFatCalculator;
