
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Pencil, Save, Trash2, FileUp, FileDown, TagIcon, Check, Coffee, Clock, AlertTriangle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ChatBot from "@/components/ChatBot";

interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  tags: string[];
  color: string;
  pinned: boolean;
}

const INITIAL_NOTES: Note[] = [
  {
    id: "1",
    title: "Welcome to Note Taker",
    content: "This is a digital notebook for capturing ideas, tasks, and all of your thoughts. Add new notes, organize them with tags, and never lose your important information again!",
    createdAt: new Date(),
    updatedAt: new Date(),
    tags: ["welcome", "tutorial"],
    color: "#f8fafc",
    pinned: true,
  },
];

const COLORS = [
  { name: "Default", value: "#f8fafc" },
  { name: "Red", value: "#fee2e2" },
  { name: "Yellow", value: "#fef9c3" },
  { name: "Green", value: "#dcfce7" },
  { name: "Blue", value: "#dbeafe" },
  { name: "Purple", value: "#f3e8ff" },
  { name: "Pink", value: "#fce7f3" },
];

const NoteTaker = () => {
  const [notes, setNotes] = useState<Note[]>(() => {
    const savedNotes = localStorage.getItem("notes");
    return savedNotes ? JSON.parse(savedNotes) : INITIAL_NOTES;
  });
  
  const [activeTab, setActiveTab] = useState("all");
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editTags, setEditTags] = useState<string[]>([]);
  const [editColor, setEditColor] = useState("");
  const [newTagInput, setNewTagInput] = useState("");
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [sortOption, setSortOption] = useState("newest");
  const [darkEditor, setDarkEditor] = useState(false);
  
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    if (activeNote) {
      const words = activeNote.content.trim().split(/\s+/).filter(Boolean).length;
      const chars = activeNote.content.length;
      
      setWordCount(words);
      setCharCount(chars);
    }
  }, [activeNote]);

  const handleCreateNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: "New Note",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date(),
      tags: [],
      color: "#f8fafc",
      pinned: false,
    };
    
    setNotes([newNote, ...notes]);
    setActiveNote(newNote);
    setEditMode(true);
    setEditTitle(newNote.title);
    setEditContent(newNote.content);
    setEditTags(newNote.tags);
    setEditColor(newNote.color);
    
    toast({
      title: "Note created",
      description: "Your new note has been created.",
    });
  };

  const handleSaveNote = () => {
    if (!activeNote) return;
    
    const updatedNotes = notes.map((note) => {
      if (note.id === activeNote.id) {
        return {
          ...note,
          title: editTitle,
          content: editContent,
          tags: editTags,
          color: editColor,
          updatedAt: new Date(),
        };
      }
      return note;
    });
    
    setNotes(updatedNotes);
    setActiveNote({
      ...activeNote,
      title: editTitle,
      content: editContent,
      tags: editTags,
      color: editColor,
      updatedAt: new Date(),
    });
    setEditMode(false);
    
    toast({
      title: "Note saved",
      description: "Your note has been saved successfully.",
    });
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id));
    
    if (activeNote && activeNote.id === id) {
      setActiveNote(null);
      setEditMode(false);
    }
    
    toast({
      title: "Note deleted",
      description: "Your note has been deleted.",
      variant: "destructive",
    });
  };

  const handlePinNote = (id: string) => {
    const updatedNotes = notes.map((note) => {
      if (note.id === id) {
        return { ...note, pinned: !note.pinned };
      }
      return note;
    });
    
    setNotes(updatedNotes);
    
    if (activeNote && activeNote.id === id) {
      setActiveNote({ ...activeNote, pinned: !activeNote.pinned });
    }
    
    toast({
      title: updatedNotes.find(n => n.id === id)?.pinned ? "Note pinned" : "Note unpinned",
      description: updatedNotes.find(n => n.id === id)?.pinned 
        ? "Your note has been pinned to the top."
        : "Your note has been unpinned.",
    });
  };

  const handleAddTag = () => {
    if (!newTagInput.trim()) return;
    
    if (!editTags.includes(newTagInput.trim().toLowerCase())) {
      setEditTags([...editTags, newTagInput.trim().toLowerCase()]);
    }
    
    setNewTagInput("");
  };

  const handleRemoveTag = (tag: string) => {
    setEditTags(editTags.filter((t) => t !== tag));
  };

  const handleExportNotes = () => {
    const dataStr = JSON.stringify(notes, null, 2);
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `note-taker-export-${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement("a");
    linkElement.setAttribute("href", dataUri);
    linkElement.setAttribute("download", exportFileDefaultName);
    linkElement.click();
    
    toast({
      title: "Notes exported",
      description: "Your notes have been exported as a JSON file.",
    });
  };

  const handleImportNotes = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedNotes = JSON.parse(e.target?.result as string);
        
        if (Array.isArray(importedNotes) && importedNotes.length > 0) {
          // Validate the imported notes have the correct structure
          const validNotes = importedNotes.filter(note => 
            note.id && note.title && typeof note.content === 'string'
          ).map(note => ({
            ...note,
            createdAt: new Date(note.createdAt),
            updatedAt: new Date(note.updatedAt),
          }));
          
          setNotes(validNotes);
          
          toast({
            title: "Notes imported",
            description: `Successfully imported ${validNotes.length} notes.`,
          });
        } else {
          toast({
            title: "Import failed",
            description: "The file format is invalid.",
            variant: "destructive",
          });
        }
      } catch (error) {
        toast({
          title: "Import failed",
          description: "There was an error importing your notes.",
          variant: "destructive",
        });
      }
    };
    
    reader.readAsText(file);
    
    // Reset the input value so the same file can be imported again
    event.target.value = "";
  };

  const filteredNotes = notes.filter((note) => {
    // First filter by search query
    const matchesSearch = 
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Then filter by active tab
    if (activeTab === "all") return matchesSearch;
    if (activeTab === "pinned") return matchesSearch && note.pinned;
    
    // Filter by tag
    return matchesSearch && note.tags.includes(activeTab);
  });

  const sortedNotes = [...filteredNotes].sort((a, b) => {
    if (sortOption === "newest") {
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    }
    if (sortOption === "oldest") {
      return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
    }
    if (sortOption === "title") {
      return a.title.localeCompare(b.title);
    }
    return 0;
  });
  
  // Pin notes to the top after sorting
  const pinnedNotes = sortedNotes.filter(note => note.pinned);
  const unpinnedNotes = sortedNotes.filter(note => !note.pinned);
  const finalSortedNotes = [...pinnedNotes, ...unpinnedNotes];

  // Get all unique tags from notes
  const allTags = Array.from(new Set(notes.flatMap(note => note.tags))).sort();

  return (
    <>
      <Helmet>
        <title>Note Taker | Free Online Digital Notebook - MultiToolSet</title>
        <meta
          name="description"
          content="Create, organize, and manage your notes with this free online notebook. Featuring tags, text formatting, exports, and cloud saving. Never lose an important note again!"
        />
        <meta
          name="keywords"
          content="note-taking app, digital notes, online notebook, free note taker, notes app, productivity tools"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/note-taker" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/note-taker" />
        <meta property="og:title" content="Online Note Taker | Free Digital Notebook" />
        <meta property="og:description" content="Create, organize and manage your notes with our free online notebook. Never lose an important note again!" />
        <meta property="og:image" content="https://multitoolset.co/images/tools/note-taker.jpg" />
        
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://multitoolset.co/tools/note-taker" />
        <meta property="twitter:title" content="Online Note Taker | Free Digital Notebook" />
        <meta property="twitter:description" content="Create, organize and manage your notes with our free online notebook. Never lose an important note again!" />
        <meta property="twitter:image" content="https://multitoolset.co/images/tools/note-taker.jpg" />
        
        {/* JSON-LD structured data */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Online Note Taker",
              "applicationCategory": "Productivity",
              "operatingSystem": "Web",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "description": "Create, organize, and manage your notes with this free online notebook. Features tags, color coding, and export options.",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "156"
              },
              "featureList": [
                "Note creation and editing",
                "Tag organization",
                "Color coding",
                "Export and import",
                "Pin important notes"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <BackButton className="mb-2" />
              <h1 className="text-3xl font-bold">Note Taker</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Create, organize, and manage your digital notes in one place
              </p>
            </div>
            
            <div className="flex space-x-3 self-end">
              <Button onClick={handleCreateNote} variant="default" className="flex items-center gap-2">
                <Pencil className="h-4 w-4" />
                <span>New Note</span>
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <FileDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={handleExportNotes} className="cursor-pointer">
                    <FileDown className="h-4 w-4 mr-2" /> Export Notes
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <label className="flex items-center cursor-pointer">
                      <FileUp className="h-4 w-4 mr-2" /> Import Notes
                      <input
                        type="file"
                        className="hidden"
                        accept=".json"
                        onChange={handleImportNotes}
                      />
                    </label>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 space-y-4">
              <div className="flex flex-col space-y-4">
                <Input
                  type="search"
                  placeholder="Search notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {finalSortedNotes.length} {finalSortedNotes.length === 1 ? 'note' : 'notes'}
                  </span>
                  
                  <Select value={sortOption} onValueChange={setSortOption}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest first</SelectItem>
                      <SelectItem value="oldest">Oldest first</SelectItem>
                      <SelectItem value="title">By title</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-2 w-full">
                    <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
                    <TabsTrigger value="pinned" className="flex-1">Pinned</TabsTrigger>
                  </TabsList>
                  
                  {allTags.length > 0 && (
                    <div className="flex flex-wrap gap-2 my-3">
                      {allTags.map((tag) => (
                        <Badge
                          key={tag}
                          variant={activeTab === tag ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => setActiveTab(tag)}
                        >
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  <div className="space-y-2 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                    {finalSortedNotes.length > 0 ? (
                      finalSortedNotes.map((note) => (
                        <Card
                          key={note.id}
                          className={`cursor-pointer transition-all hover:shadow-md ${
                            activeNote?.id === note.id
                              ? "ring-2 ring-primary"
                              : ""
                          }`}
                          style={{ backgroundColor: note.color }}
                          onClick={() => {
                            setActiveNote(note);
                            setEditMode(false);
                            setEditTitle(note.title);
                            setEditContent(note.content);
                            setEditTags(note.tags);
                            setEditColor(note.color);
                          }}
                        >
                          <CardHeader className="p-4 pb-2">
                            <div className="flex justify-between items-start">
                              <CardTitle className="text-lg">
                                {note.title}
                                {note.pinned && (
                                  <span className="ml-2 inline-flex align-middle">
                                    <Check size={16} className="text-green-600" />
                                  </span>
                                )}
                              </CardTitle>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handlePinNote(note.id);
                                }}
                              >
                                <Check size={16} className={note.pinned ? "text-green-600" : "text-gray-400"} />
                              </Button>
                            </div>
                            <CardDescription className="text-xs text-gray-500">
                              Last updated: {new Date(note.updatedAt).toLocaleString()}
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="p-4 pt-0">
                            <p className="text-sm line-clamp-3">
                              {note.content.substring(0, 120)}
                              {note.content.length > 120 ? "..." : ""}
                            </p>
                            
                            {note.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {note.tags.slice(0, 3).map((tag) => (
                                  <Badge
                                    key={tag}
                                    variant="secondary"
                                    className="text-xs"
                                  >
                                    #{tag}
                                  </Badge>
                                ))}
                                {note.tags.length > 3 && (
                                  <Badge variant="secondary" className="text-xs">
                                    +{note.tags.length - 3}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <div className="text-center py-6">
                        <p className="text-gray-500 dark:text-gray-400">No notes found</p>
                        <Button
                          variant="outline"
                          className="mt-2"
                          onClick={handleCreateNote}
                        >
                          Create your first note
                        </Button>
                      </div>
                    )}
                  </div>
                </Tabs>
              </div>
            </div>
            
            <div className="md:col-span-2">
              {activeNote ? (
                <Card className="h-full flex flex-col">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      {editMode ? (
                        <Input
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="text-xl font-bold"
                          placeholder="Note title"
                        />
                      ) : (
                        <CardTitle className="text-xl">{activeNote.title}</CardTitle>
                      )}
                      
                      <div className="flex items-center space-x-2">
                        {editMode ? (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={handleSaveNote}
                          >
                            <Save className="h-4 w-4 mr-1" /> Save
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setEditMode(true)}
                          >
                            <Pencil className="h-4 w-4 mr-1" /> Edit
                          </Button>
                        )}
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="destructive"
                              size="sm"
                              className="h-9"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Delete Note</DialogTitle>
                              <DialogDescription>
                                Are you sure you want to delete this note? This action cannot be undone.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="flex justify-end space-x-2 mt-4">
                              <Button variant="outline" onClick={() => document.body.click()}>
                                Cancel
                              </Button>
                              <Button
                                variant="destructive"
                                onClick={() => {
                                  handleDeleteNote(activeNote.id);
                                  document.body.click();
                                }}
                              >
                                Delete
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                    
                    <CardDescription className="text-sm mt-1">
                      Created: {new Date(activeNote.createdAt).toLocaleString()} | 
                      Last updated: {new Date(activeNote.updatedAt).toLocaleString()}
                    </CardDescription>
                    
                    {editMode && (
                      <div className="flex flex-wrap items-center gap-2 mt-4">
                        <div className="flex items-center space-x-2">
                          <Label htmlFor="dark-mode" className="text-sm">Dark Editor</Label>
                          <Switch
                            id="dark-mode"
                            checked={darkEditor}
                            onCheckedChange={setDarkEditor}
                          />
                        </div>
                        
                        <Select value={editColor} onValueChange={setEditColor}>
                          <SelectTrigger className="w-[120px]">
                            <SelectValue placeholder="Color" />
                          </SelectTrigger>
                          <SelectContent>
                            {COLORS.map((color) => (
                              <SelectItem
                                key={color.value}
                                value={color.value}
                                className="flex items-center"
                              >
                                <div className="flex items-center">
                                  <div
                                    className="h-4 w-4 rounded mr-2"
                                    style={{ backgroundColor: color.value }}
                                  />
                                  {color.name}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </CardHeader>
                  
                  <CardContent className="flex-1 overflow-hidden">
                    {editMode ? (
                      <div className="h-full flex flex-col">
                        <Textarea
                          value={editContent}
                          onChange={(e) => setEditContent(e.target.value)}
                          className={`flex-1 resize-none min-h-[300px] mb-4 font-mono ${
                            darkEditor ? "bg-gray-900 text-gray-100" : ""
                          }`}
                          placeholder="Write your note here..."
                        />
                        
                        <div className="space-y-3">
                          <div className="flex flex-wrap gap-1">
                            {editTags.map((tag) => (
                              <Badge
                                key={tag}
                                variant="secondary"
                                className="flex items-center gap-1"
                              >
                                #{tag}
                                <button
                                  className="text-xs hover:text-red-500"
                                  onClick={() => handleRemoveTag(tag)}
                                >
                                  ×
                                </button>
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex space-x-2">
                            <Input
                              value={newTagInput}
                              onChange={(e) => setNewTagInput(e.target.value)}
                              placeholder="Add a tag..."
                              className="max-w-[200px]"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddTag();
                                }
                              }}
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={handleAddTag}
                              disabled={!newTagInput.trim()}
                            >
                              <TagIcon className="h-4 w-4 mr-1" /> Add
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="h-full overflow-y-auto">
                        <div className="whitespace-pre-wrap mb-4 min-h-[300px]">
                          {activeNote.content || (
                            <p className="text-gray-400 italic">
                              No content. Click Edit to add content to your note.
                            </p>
                          )}
                        </div>
                        
                        {activeNote.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-4 border-t pt-4">
                            {activeNote.tags.map((tag) => (
                              <Badge key={tag} variant="secondary">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                  
                  <CardFooter className="border-t text-sm text-gray-500 flex justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Coffee size={12} className="text-gray-400" />
                        <span>{wordCount} words</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <AlertTriangle size={12} className="text-gray-400" />
                        <span>{charCount} characters</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={12} className="text-gray-400" />
                      <span>Auto-saved</span>
                    </div>
                  </CardFooter>
                </Card>
              ) : (
                <Card className="h-full flex items-center justify-center">
                  <CardContent className="text-center py-10">
                    <Pencil className="h-12 w-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No Note Selected</h3>
                    <p className="text-gray-500 dark:text-gray-400 mb-4">
                      Select a note from the sidebar or create a new one to get started.
                    </p>
                    <Button onClick={handleCreateNote}>
                      <Pencil className="h-4 w-4 mr-2" /> Create New Note
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default NoteTaker;
