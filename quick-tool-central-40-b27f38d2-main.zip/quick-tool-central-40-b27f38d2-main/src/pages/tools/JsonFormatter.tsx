
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Check, Copy, Download, ArrowRight } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const JsonFormatter = () => {
  const [input, setInput] = useState("");
  const [formatted, setFormatted] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [indentation, setIndentation] = useState(2);
  const [isCompact, setIsCompact] = useState(false);

  const formatJson = () => {
    if (!input.trim()) {
      toast({
        title: "No JSON provided",
        description: "Please enter some JSON to format",
        variant: "destructive"
      });
      return;
    }

    try {
      // Parse the JSON to validate it
      const parsedJson = JSON.parse(input);
      
      // Format it with the specified indentation (or compact if requested)
      const formattedJson = isCompact 
        ? JSON.stringify(parsedJson)
        : JSON.stringify(parsedJson, null, indentation);
        
      setFormatted(formattedJson);
      setError(null);
      
      toast({
        title: "JSON formatted successfully",
        description: "Your JSON has been formatted and validated",
        variant: "default"
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid JSON");
      setFormatted("");
      
      toast({
        title: "Invalid JSON",
        description: err instanceof Error ? err.message : "There was an error parsing your JSON",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = () => {
    if (formatted) {
      navigator.clipboard.writeText(formatted);
      toast({
        title: "Copied to clipboard",
        description: "JSON has been copied to your clipboard",
      });
    }
  };

  const downloadJson = () => {
    if (formatted) {
      const blob = new Blob([formatted], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "formatted-json.json";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "JSON downloaded",
        description: "Your formatted JSON has been downloaded",
      });
    }
  };

  const clearContent = () => {
    setInput("");
    setFormatted("");
    setError(null);
  };

  return (
    <ToolLayout 
      title="JSON Formatter"
      description="Format, validate and beautify your JSON data with this easy-to-use online tool."
      helpText="Paste your JSON, adjust formatting options, and get beautifully formatted and validated JSON."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-4">
              <div className="mb-4">
                <h2 className="text-lg font-medium">Input JSON</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Paste your JSON data here
                </p>
              </div>
              <Textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your JSON here..."
                className="min-h-[300px] font-mono"
              />
              <div className="flex flex-wrap items-center gap-4 mt-4">
                <div className="flex items-center space-x-2">
                  <Label htmlFor="indentation">Indentation:</Label>
                  <select 
                    id="indentation"
                    value={indentation}
                    onChange={(e) => setIndentation(Number(e.target.value))}
                    className="border rounded px-2 py-1 dark:bg-gray-800"
                    disabled={isCompact}
                  >
                    {[2, 4, 6, 8].map(size => (
                      <option key={size} value={size}>{size} spaces</option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="compact-mode"
                    checked={isCompact}
                    onCheckedChange={setIsCompact}
                  />
                  <Label htmlFor="compact-mode">Compact mode (no indentation)</Label>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="mb-4 flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-medium">Formatted JSON</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Your beautified JSON will appear here
                  </p>
                </div>
                {formatted && (
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={copyToClipboard}
                    >
                      <Copy className="mr-1 h-4 w-4" /> Copy
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={downloadJson}
                    >
                      <Download className="mr-1 h-4 w-4" /> Download
                    </Button>
                  </div>
                )}
              </div>

              {error ? (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                  <div className="flex">
                    <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-red-800 dark:text-red-400">Invalid JSON</p>
                      <p className="text-sm text-red-700 dark:text-red-300 mt-1">{error}</p>
                    </div>
                  </div>
                </div>
              ) : formatted ? (
                <pre className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 overflow-auto min-h-[300px] font-mono">
                  {formatted}
                </pre>
              ) : (
                <div className="min-h-[300px] border border-dashed rounded-lg flex items-center justify-center">
                  <p className="text-gray-500 dark:text-gray-400">Format your JSON to see the result here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center gap-4">
          <Button 
            onClick={formatJson} 
            className="bg-purple-600 hover:bg-purple-700"
          >
            Format JSON <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            onClick={clearContent}
          >
            Clear All
          </Button>
        </div>

        <div className="mt-8 space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal space-y-3 ml-5">
              <li>Enter or paste your JSON data in the input field.</li>
              <li>Choose formatting options (indentation, compact mode).</li>
              <li>Click the "Format JSON" button to process.</li>
              <li>View your formatted JSON in the output area.</li>
              <li>Copy or download the formatted JSON as needed.</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">FAQ</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">What is JSON formatting?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  JSON formatting is the process of structuring JSON data with proper indentation and line breaks to make it more readable for humans, while maintaining its validity for machines.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Why does my JSON show an error?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Common JSON errors include missing commas, unmatched brackets or braces, trailing commas, unquoted property names, or using single quotes instead of double quotes.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Is my JSON data secure when using this tool?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Yes, all processing happens locally in your browser. Your data is never sent to our servers.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">What's the difference between pretty and compact JSON?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Pretty (indented) JSON is formatted for human readability with proper spacing and line breaks. Compact JSON removes all unnecessary whitespace to minimize file size, which is better for production but harder to read.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Related Tools</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a href="/tools/json-to-csv" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">JSON to CSV Converter</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Convert your JSON data to CSV format for use in spreadsheets.
                </p>
              </a>
              <a href="/tools/csv-to-json" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">CSV to JSON Converter</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Transform CSV data into structured JSON format.
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default JsonFormatter;
