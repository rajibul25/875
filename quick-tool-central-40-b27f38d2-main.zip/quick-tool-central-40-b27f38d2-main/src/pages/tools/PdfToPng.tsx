
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "../../components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { FileType, Upload, Download, CheckCircle2 } from "lucide-react";

const PdfToPng = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [converting, setConverting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error("Please select a PDF file");
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB
      toast.error("File size exceeds 10MB limit");
      return;
    }

    setSelectedFile(file);
    toast.success("PDF file selected successfully");
  };

  const handleConvert = () => {
    if (!selectedFile) {
      toast.error("Please select a PDF file first");
      return;
    }

    setConverting(true);
    // Simulate conversion process
    setTimeout(() => {
      setConverting(false);
      toast.success("Conversion complete! Your PNG images are ready for download.");
    }, 2000);
  };

  // Schema markup for rich search results
  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "PDF to PNG Converter",
    "applicationCategory": "Utility",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "Web browser",
    "description": "Free online tool to convert PDF files to high-quality PNG images with transparency support."
  };

  return (
    <>
      <Helmet>
        <title>PDF to PNG Converter | Convert PDF to Transparent PNG Images</title>
        <meta name="description" content="Convert PDF documents to high-quality PNG images with transparency support. Free online tool, no registration required. Fast and secure PDF to PNG conversion." />
        <meta name="keywords" content="pdf to png, pdf converter, convert pdf to png, pdf to image converter, transparent png, online converter" />
        <link rel="canonical" href="https://multitoolset.co/tools/pdf-to-png" />
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
        <meta property="og:title" content="PDF to PNG Converter | Convert PDF to Transparent PNG Images" />
        <meta property="og:description" content="Convert PDF documents to high-quality PNG images with transparency support. Free online tool, no registration required." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/pdf-to-png" />
      </Helmet>

      <ToolLayout
        title="PDF to PNG Converter"
        description="Convert PDF files to PNG images"
        helpText="Upload your PDF file and convert each page to a transparent PNG image."
      >
        <div className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-10 text-center">
                  <Label htmlFor="pdf-upload" className="cursor-pointer">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <Upload className="h-10 w-10 text-gray-400" />
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        {selectedFile ? selectedFile.name : "Click to upload or drag and drop"}
                      </span>
                      <span className="text-xs text-gray-500">PDF files only (max 10MB)</span>
                    </div>
                    <Input
                      id="pdf-upload"
                      type="file"
                      className="hidden"
                      accept=".pdf,application/pdf"
                      onChange={handleFileChange}
                    />
                  </Label>
                </div>

                <div className="flex justify-center">
                  <Button
                    onClick={handleConvert}
                    disabled={!selectedFile || converting}
                    className="w-full md:w-auto"
                  >
                    {converting ? "Converting..." : "Convert to PNG"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6 max-w-3xl mx-auto">
            <div>
              <h2 className="text-2xl font-bold mb-3">How to Convert PDF to PNG</h2>
              <ol className="list-decimal pl-6 space-y-2">
                <li>Upload your PDF file using the button above</li>
                <li>Click the "Convert to PNG" button</li>
                <li>Wait for the conversion process to complete</li>
                <li>Download your converted PNG images</li>
              </ol>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-3">Why Use Our PDF to PNG Converter</h2>
              <ul className="list-disc pl-6 space-y-2">
                <li>High-quality image conversion with transparency support</li>
                <li>Convert multi-page PDFs to individual PNG images</li>
                <li>Secure and private - your files are deleted after processing</li>
                <li>Free to use with no watermarks</li>
                <li>No installation required - works in your browser</li>
                <li>Customizable image resolution (coming soon)</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h2 className="text-xl font-bold mb-3">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium">What is a PNG file?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    PNG (Portable Network Graphics) is a raster graphics file format that supports lossless data compression and transparency. 
                    It's ideal for images that need a transparent background or sharp details.
                  </p>
                </div>
                <div>
                  <h3 className="font-medium">Why convert PDF to PNG?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Converting PDFs to PNG allows you to use the content in image editing software, presentations, 
                    websites, or any platform that doesn't support PDF files directly. PNGs also support transparency.
                  </p>
                </div>
                <div>
                  <h3 className="font-medium">Is there a limit to the file size?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Yes, currently our tool supports PDF files up to 10MB in size. For larger files, we recommend splitting your PDF into smaller parts first.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default PdfToPng;
