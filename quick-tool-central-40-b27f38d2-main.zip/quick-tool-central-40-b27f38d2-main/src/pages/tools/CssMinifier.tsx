
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { ArrowRight, Copy, Download, RefreshCcw } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const CssMinifier = () => {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [preserveComments, setPreserveComments] = useState(false);
  const [preserveImportant, setPreserveImportant] = useState(true);
  
  // Function to minify CSS
  const minifyCss = () => {
    if (!input.trim()) {
      toast({
        title: "No CSS provided",
        description: "Please enter some CSS to minify",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Simple CSS minification
      let minified = input;
      
      // Remove comments if not preserving them
      if (!preserveComments) {
        minified = minified.replace(/\/\*[\s\S]*?\*\//g, "");
      }
      
      // Remove whitespace
      minified = minified
        .replace(/\s+/g, " ") // Convert multiple spaces to single space
        .replace(/\s*{\s*/g, "{") // Remove spaces around {
        .replace(/\s*}\s*/g, "}") // Remove spaces around }
        .replace(/\s*:\s*/g, ":") // Remove spaces around :
        .replace(/\s*;\s*/g, ";") // Remove spaces around ;
        .replace(/\s*,\s*/g, ",") // Remove spaces around ,
        .replace(/\s*>\s*/g, ">") // Remove spaces around >
        .replace(/\s*\+\s*/g, "+") // Remove spaces around +
        .replace(/\s*~\s*/g, "~") // Remove spaces around ~
        .trim();
      
      // Preserve !important if needed
      if (!preserveImportant) {
        minified = minified.replace(/\s*!important/g, "!important");
      }
      
      // Remove last semicolons in blocks
      minified = minified.replace(/;\}/g, "}");
      
      setOutput(minified);
      
      const originalSize = new Blob([input]).size;
      const minifiedSize = new Blob([minified]).size;
      const savedPercentage = ((originalSize - minifiedSize) / originalSize * 100).toFixed(2);
      
      toast({
        title: "CSS minified successfully",
        description: `Reduced size by ${savedPercentage}% (${originalSize} → ${minifiedSize} bytes)`,
      });
    } catch (error) {
      toast({
        title: "Error minifying CSS",
        description: "There was an error processing your CSS.",
        variant: "destructive"
      });
    }
  };

  // Function to beautify CSS (simple formatter)
  const beautifyCss = () => {
    if (!input.trim()) {
      toast({
        title: "No CSS provided",
        description: "Please enter some CSS to format",
        variant: "destructive"
      });
      return;
    }
    
    try {
      let formatted = input;
      
      // Remove existing whitespace first
      formatted = formatted
        .replace(/\s+/g, " ")
        .replace(/\s*{\s*/g, " {\n    ")
        .replace(/\s*}\s*/g, "\n}\n")
        .replace(/\s*;\s*/g, ";\n    ")
        .replace(/\s*:\s*/g, ": ")
        .replace(/\n\s*\n/g, "\n")
        .trim();
      
      // Fix extra spaces at end of lines
      formatted = formatted.replace(/\s+$/gm, "");
      
      setOutput(formatted);
      
      toast({
        title: "CSS beautified",
        description: "Your CSS has been formatted for readability",
      });
    } catch (error) {
      toast({
        title: "Error formatting CSS",
        description: "There was an error processing your CSS.",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = () => {
    if (output) {
      navigator.clipboard.writeText(output);
      toast({
        title: "Copied to clipboard",
        description: "CSS has been copied to your clipboard",
      });
    }
  };

  const downloadCss = () => {
    if (output) {
      const blob = new Blob([output], { type: "text/css" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "minified.min.css";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "CSS downloaded",
        description: "Your minified CSS file has been downloaded",
      });
    }
  };

  const clearContent = () => {
    setInput("");
    setOutput("");
  };

  return (
    <ToolLayout 
      title="CSS Minifier"
      description="Minify your CSS code to reduce file size and improve website loading speed."
      helpText="Remove unnecessary characters from your CSS without changing its functionality to create smaller files for production use."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-4">
              <div className="mb-4">
                <h2 className="text-lg font-medium">CSS Input</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Paste your CSS code here
                </p>
              </div>
              <Textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="/* Paste your CSS code here */\n.example {\n    color: #333;\n    margin: 20px;\n    padding: 10px;\n}"
                className="min-h-[300px] font-mono text-sm"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="mb-4 flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-medium">Minified Output</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Your minified CSS will appear here
                  </p>
                </div>
                {output && (
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={copyToClipboard}
                    >
                      <Copy className="mr-1 h-4 w-4" /> Copy
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={downloadCss}
                    >
                      <Download className="mr-1 h-4 w-4" /> Download
                    </Button>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 overflow-auto min-h-[300px] font-mono text-sm">
                {output ? (
                  <pre className="whitespace-pre-wrap break-all">{output}</pre>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <p>Minified CSS will appear here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center space-x-2">
              <Switch 
                id="preserve-comments"
                checked={preserveComments}
                onCheckedChange={setPreserveComments}
              />
              <Label htmlFor="preserve-comments">Preserve comments</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="preserve-important"
                checked={preserveImportant}
                onCheckedChange={setPreserveImportant}
              />
              <Label htmlFor="preserve-important">Preserve !important</Label>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={minifyCss} 
              className="bg-purple-600 hover:bg-purple-700"
            >
              Minify CSS <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            
            <Button 
              variant="outline" 
              onClick={beautifyCss}
            >
              <RefreshCcw className="mr-2 h-4 w-4" /> Beautify
            </Button>
            
            <Button 
              variant="outline" 
              onClick={clearContent}
            >
              Clear All
            </Button>
          </div>
        </div>

        <div className="mt-8 space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal space-y-3 ml-5">
              <li>Paste your CSS code into the input field.</li>
              <li>Choose minification options (preserve comments, preserve !important).</li>
              <li>Click the "Minify CSS" button to process.</li>
              <li>View your minified CSS in the output area.</li>
              <li>Copy the minified code or download it as a .min.css file.</li>
              <li>Optional: Use the "Beautify" button to format your CSS for readability.</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">FAQ</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">What is CSS minification?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  CSS minification is the process of removing unnecessary characters (whitespace, comments, etc.) from CSS files to reduce their size. This makes your website load faster without changing how the styles work.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Is minified CSS harder to edit?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Yes, minified CSS is harder to read and edit. It's best to keep an unminified version for development, and use the minified version only for production.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Why should I minify my CSS?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Minification can reduce file sizes by 25-50%, leading to faster page loads, better user experience, improved SEO rankings, and reduced bandwidth costs.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Will minification break my CSS?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Our minifier is designed to preserve functionality while removing only unnecessary characters. However, it's always good practice to test your minified CSS on your website before deploying.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Related Tools</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a href="/tools/javascript-minifier" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">JavaScript Minifier</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Minify your JavaScript code to improve website performance.
                </p>
              </a>
              <a href="/tools/html-to-markdown" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">HTML to Markdown Converter</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Convert HTML code to clean, readable Markdown format.
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default CssMinifier;
