
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FileText, Copy, Info, Check, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";

const MetaTagGenerator = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [keywords, setKeywords] = useState("");
  const [ogTitle, setOgTitle] = useState("");
  const [ogDescription, setOgDescription] = useState("");
  const [ogImage, setOgImage] = useState("");
  const [twitterCard, setTwitterCard] = useState("summary_large_image");
  const [canonicalUrl, setCanonicalUrl] = useState("");
  const [generatedMeta, setGeneratedMeta] = useState("");
  const [activeTab, setActiveTab] = useState("basic");
  const [copied, setCopied] = useState(false);

  const getTitleStatus = () => {
    if (!title) return "empty";
    if (title.length < 30) return "short";
    if (title.length > 60) return "long";
    return "good";
  };

  const getDescriptionStatus = () => {
    if (!description) return "empty";
    if (description.length < 120) return "short";
    if (description.length > 160) return "long";
    return "good";
  };

  const titleStatus = getTitleStatus();
  const descriptionStatus = getDescriptionStatus();

  const generateMetaTags = () => {
    let metaTags = `<title>${title}</title>\n`;
    
    if (description) {
      metaTags += `<meta name="description" content="${description}" />\n`;
    }
    
    if (keywords) {
      metaTags += `<meta name="keywords" content="${keywords}" />\n`;
    }
    
    if (canonicalUrl) {
      metaTags += `<link rel="canonical" href="${canonicalUrl}" />\n`;
    }
    
    // Open Graph tags
    if (ogTitle || title) {
      metaTags += `<meta property="og:title" content="${ogTitle || title}" />\n`;
    }
    
    if (ogDescription || description) {
      metaTags += `<meta property="og:description" content="${ogDescription || description}" />\n`;
    }
    
    if (canonicalUrl) {
      metaTags += `<meta property="og:url" content="${canonicalUrl}" />\n`;
    }
    
    metaTags += `<meta property="og:type" content="website" />\n`;
    
    if (ogImage) {
      metaTags += `<meta property="og:image" content="${ogImage}" />\n`;
    }
    
    // Twitter Card tags
    metaTags += `<meta name="twitter:card" content="${twitterCard}" />\n`;
    
    if (ogTitle || title) {
      metaTags += `<meta name="twitter:title" content="${ogTitle || title}" />\n`;
    }
    
    if (ogDescription || description) {
      metaTags += `<meta name="twitter:description" content="${ogDescription || description}" />\n`;
    }
    
    if (ogImage) {
      metaTags += `<meta name="twitter:image" content="${ogImage}" />\n`;
    }
    
    setGeneratedMeta(metaTags);
    toast.success("Meta tags generated successfully!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedMeta);
    setCopied(true);
    toast.success("Meta tags copied to clipboard!");
    
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  // Schema markup for rich search results
  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Meta Tag Generator",
    "applicationCategory": "WebApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "description": "Free online tool to generate optimized meta tags for better SEO and social media sharing."
  };

  return (
    <>
      <Helmet>
        <title>Meta Tag Generator | Create SEO & Social Media Tags | MultiToolSet</title>
        <meta name="description" content="Free online meta tag generator to create perfect SEO meta tags and social media sharing tags (Open Graph, Twitter Cards). Improve your website's visibility in search results." />
        <meta name="keywords" content="meta tag generator, SEO meta tags, Open Graph tags, Twitter Card tags, meta description generator, SEO tools" />
        <link rel="canonical" href="https://multitoolset.co/tools/meta-tag-generator" />
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
        <meta property="og:title" content="Meta Tag Generator | Create SEO & Social Media Tags" />
        <meta property="og:description" content="Free online meta tag generator to create perfect SEO meta tags and social media sharing tags (Open Graph, Twitter Cards)." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/meta-tag-generator" />
      </Helmet>

      <ToolLayout
        title="Meta Tag Generator"
        description="Create perfect meta titles and descriptions for better CTR"
        helpText="Enter your page title and description to generate optimized meta tags for SEO."
      >
        <div className="space-y-6">
          <Tabs defaultValue="basic" onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="basic">Basic SEO</TabsTrigger>
              <TabsTrigger value="social">Social Media</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="title" className="text-sm font-medium">Page Title</Label>
                      <div className="text-xs">
                        {titleStatus === "good" && <span className="text-green-600 flex items-center"><Check className="h-3 w-3 mr-1" /> Perfect length</span>}
                        {titleStatus === "short" && <span className="text-amber-600 flex items-center"><AlertTriangle className="h-3 w-3 mr-1" /> Too short</span>}
                        {titleStatus === "long" && <span className="text-red-600 flex items-center"><AlertTriangle className="h-3 w-3 mr-1" /> Too long</span>}
                      </div>
                    </div>
                    <Input
                      id="title"
                      placeholder="Enter your page title (50-60 characters recommended)"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      maxLength={100}
                      className={`${
                        titleStatus === "long" ? "border-red-300 focus:border-red-500" : 
                        titleStatus === "short" ? "border-amber-300" : 
                        titleStatus === "good" ? "border-green-300" : ""
                      }`}
                    />
                    <div className="flex justify-between">
                      <p className="text-xs text-gray-500">{title.length}/60 characters</p>
                      {titleStatus === "long" && <p className="text-xs text-red-500">May be truncated in search results</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="description" className="text-sm font-medium">Meta Description</Label>
                      <div className="text-xs">
                        {descriptionStatus === "good" && <span className="text-green-600 flex items-center"><Check className="h-3 w-3 mr-1" /> Perfect length</span>}
                        {descriptionStatus === "short" && <span className="text-amber-600 flex items-center"><AlertTriangle className="h-3 w-3 mr-1" /> Too short</span>}
                        {descriptionStatus === "long" && <span className="text-red-600 flex items-center"><AlertTriangle className="h-3 w-3 mr-1" /> Too long</span>}
                      </div>
                    </div>
                    <Textarea
                      id="description"
                      placeholder="Enter your meta description (120-160 characters recommended)"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className={`${
                        descriptionStatus === "long" ? "border-red-300 focus:border-red-500" : 
                        descriptionStatus === "short" ? "border-amber-300" : 
                        descriptionStatus === "good" ? "border-green-300" : ""
                      }`}
                    />
                    <div className="flex justify-between">
                      <p className="text-xs text-gray-500">{description.length}/160 characters</p>
                      {descriptionStatus === "long" && <p className="text-xs text-red-500">May be truncated in search results</p>}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="keywords" className="text-sm font-medium">Keywords (comma-separated)</Label>
                    <Input
                      id="keywords"
                      placeholder="keyword1, keyword2, keyword3"
                      value={keywords}
                      onChange={(e) => setKeywords(e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      <Info className="h-3 w-3 inline mr-1" />
                      While less important for rankings, keywords can help with content categorization
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="canonical" className="text-sm font-medium">Canonical URL</Label>
                    <Input
                      id="canonical"
                      placeholder="https://yourdomain.com/page"
                      value={canonicalUrl}
                      onChange={(e) => setCanonicalUrl(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="social" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg text-sm mb-2">
                    <p className="text-blue-700 dark:text-blue-300 flex items-start">
                      <Info className="h-4 w-4 mr-2 mt-0.5" />
                      Social media tags help control how your content appears when shared on platforms like Facebook, Twitter, and LinkedIn
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="ogTitle" className="text-sm font-medium">Social Media Title (Open Graph)</Label>
                    <Input
                      id="ogTitle"
                      placeholder="Enter title for social sharing (will use page title if empty)"
                      value={ogTitle}
                      onChange={(e) => setOgTitle(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="ogDescription" className="text-sm font-medium">Social Media Description</Label>
                    <Textarea
                      id="ogDescription"
                      placeholder="Enter description for social sharing (will use meta description if empty)"
                      value={ogDescription}
                      onChange={(e) => setOgDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="ogImage" className="text-sm font-medium">Social Media Image URL</Label>
                    <Input
                      id="ogImage"
                      placeholder="https://yourdomain.com/image.jpg"
                      value={ogImage}
                      onChange={(e) => setOgImage(e.target.value)}
                    />
                    <p className="text-xs text-gray-500">Recommended size: 1200×630 pixels</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="twitterCard" className="text-sm font-medium">Twitter Card Type</Label>
                    <select
                      id="twitterCard"
                      className="w-full border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 bg-background"
                      value={twitterCard}
                      onChange={(e) => setTwitterCard(e.target.value)}
                    >
                      <option value="summary">Summary (small image)</option>
                      <option value="summary_large_image">Summary with Large Image</option>
                      <option value="app">App</option>
                      <option value="player">Player</option>
                    </select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="advanced" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Advanced settings coming soon. This will include robots directives, language settings, and viewport configuration.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Button onClick={generateMetaTags} className="w-full">
            <FileText className="mr-2 h-4 w-4" />
            Generate Meta Tags
          </Button>

          {generatedMeta && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Generated Meta Tags</h3>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center"
                  onClick={copyToClipboard}
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 mr-1 text-green-500" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-1" /> Copy
                    </>
                  )}
                </Button>
              </div>
              
              <Card>
                <CardContent className="p-0">
                  <pre className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg overflow-x-auto text-xs md:text-sm">
                    <code>{generatedMeta}</code>
                  </pre>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold text-lg mb-3">How to Add Meta Tags to Your Website</h3>
                  <ol className="list-decimal pl-5 space-y-2 text-sm text-gray-700 dark:text-gray-300">
                    <li>Copy the generated code above</li>
                    <li>Open your website's HTML file or template</li>
                    <li>Paste the code inside the <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">&lt;head&gt;</code> section of your HTML</li>
                    <li>Save your file and upload it to your web server</li>
                    <li>Test your page using <a href="https://developers.facebook.com/tools/debug/" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">Facebook's Sharing Debugger</a> or <a href="https://cards-dev.twitter.com/validator" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">Twitter Card Validator</a></li>
                  </ol>
                </CardContent>
              </Card>
            </div>
          )}
          
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <h2 className="text-lg font-semibold mb-3">Meta Tag SEO Best Practices</h2>
            <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
              <li><span className="font-medium">Title Tags:</span> Keep between 50-60 characters with primary keyword near the beginning</li>
              <li><span className="font-medium">Meta Descriptions:</span> Keep between 120-160 characters with compelling call-to-action</li>
              <li><span className="font-medium">Unique Content:</span> Create unique meta tags for each page of your website</li>
              <li><span className="font-medium">Keyword Relevance:</span> Include relevant keywords naturally, but avoid keyword stuffing</li>
              <li><span className="font-medium">Social Images:</span> Use high-quality images in the correct dimensions for each platform</li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default MetaTagGenerator;
