
import React, { useState, useEffect } from "react";
import { Copy, RotateCw, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import ChatBot from "@/components/ChatBot";
import Helmet from "react-helmet";

const VolumeConverter = () => {
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState<number | string>("");
  const [result, setResult] = useState<number | string>("");
  const [fromUnit, setFromUnit] = useState("liter");
  const [toUnit, setToUnit] = useState("gallon_us");
  const [recentConversions, setRecentConversions] = useState<Array<{
    from: string,
    to: string,
    input: number | string,
    output: number | string,
    timestamp: Date
  }>>([]);

  // Unit conversion rates to liter (base unit)
  const volumeUnits = {
    liter: 1,
    milliliter: 1000,
    cubic_meter: 0.001,
    cubic_centimeter: 1000,
    cubic_inch: 61.0237,
    cubic_foot: 0.0353147,
    gallon_us: 0.264172,
    gallon_uk: 0.219969,
    quart_us: 1.05669,
    quart_uk: 0.879877,
    pint_us: 2.11338,
    pint_uk: 1.75975,
    cup: 4.22675,
    fluid_ounce_us: 33.814,
    fluid_ounce_uk: 35.1951,
    tablespoon_us: 67.628,
    tablespoon_uk: 66.6667,
    teaspoon_us: 202.884,
    teaspoon_uk: 200
  };

  const unitNames = {
    liter: "Liter",
    milliliter: "Milliliter",
    cubic_meter: "Cubic meter",
    cubic_centimeter: "Cubic centimeter",
    cubic_inch: "Cubic inch",
    cubic_foot: "Cubic foot",
    gallon_us: "US gallon",
    gallon_uk: "UK gallon",
    quart_us: "US quart",
    quart_uk: "UK quart",
    pint_us: "US pint",
    pint_uk: "UK pint",
    cup: "Cup",
    fluid_ounce_us: "US fluid ounce",
    fluid_ounce_uk: "UK fluid ounce",
    tablespoon_us: "US tablespoon",
    tablespoon_uk: "UK tablespoon",
    teaspoon_us: "US teaspoon",
    teaspoon_uk: "UK teaspoon"
  };

  const unitSymbols = {
    liter: "L",
    milliliter: "mL",
    cubic_meter: "m³",
    cubic_centimeter: "cm³",
    cubic_inch: "in³",
    cubic_foot: "ft³",
    gallon_us: "US gal",
    gallon_uk: "UK gal",
    quart_us: "US qt",
    quart_uk: "UK qt",
    pint_us: "US pt",
    pint_uk: "UK pt",
    cup: "cup",
    fluid_ounce_us: "US fl oz",
    fluid_ounce_uk: "UK fl oz",
    tablespoon_us: "US tbsp",
    tablespoon_uk: "UK tbsp",
    teaspoon_us: "US tsp",
    teaspoon_uk: "UK tsp"
  };

  useEffect(() => {
    if (inputValue !== "") {
      convertVolume();
    }
  }, [inputValue, fromUnit, toUnit]);

  const convertVolume = () => {
    if (inputValue === "" || isNaN(Number(inputValue))) {
      setResult("");
      return;
    }

    // Convert from the input unit to liters (base unit)
    const liters = Number(inputValue) / volumeUnits[fromUnit as keyof typeof volumeUnits];
    
    // Convert from liters to the output unit
    const convertedValue = liters * volumeUnits[toUnit as keyof typeof volumeUnits];
    
    // Round to a reasonable number of decimal places
    let roundedValue: number;
    if (convertedValue < 0.01) {
      roundedValue = Number(convertedValue.toFixed(6));
    } else if (convertedValue < 1) {
      roundedValue = Number(convertedValue.toFixed(4));
    } else {
      roundedValue = Number(convertedValue.toFixed(2));
    }
    
    setResult(roundedValue);
    
    // Save to recent conversions
    if (inputValue !== "") {
      const newConversion = {
        from: fromUnit,
        to: toUnit,
        input: inputValue,
        output: roundedValue,
        timestamp: new Date()
      };
      
      setRecentConversions(prev => {
        const updated = [newConversion, ...prev].slice(0, 5);
        return updated;
      });
    }
  };

  const handleCopy = () => {
    if (result !== "") {
      navigator.clipboard.writeText(`${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]}`);
      toast({
        title: "Copied!",
        description: `${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]} has been copied to clipboard.`,
      });
    }
  };

  const handleReset = () => {
    setInputValue("");
    setResult("");
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  // Group units for a cleaner dropdown
  const unitGroups = {
    "Metric": ["liter", "milliliter", "cubic_meter", "cubic_centimeter"],
    "Imperial & US": ["gallon_us", "gallon_uk", "quart_us", "quart_uk", "pint_us", "pint_uk", "cup", "fluid_ounce_us", "fluid_ounce_uk"],
    "Other": ["cubic_inch", "cubic_foot"],
    "Cooking": ["tablespoon_us", "tablespoon_uk", "teaspoon_us", "teaspoon_uk"]
  };

  return (
    <>
      <Helmet>
        <title>Free Online Volume Converter Tool | Convert L, gal, mL, fl oz</title>
        <meta name="description" content="Convert volume units instantly with our free online volume converter. Easily convert between liters, gallons, milliliters, cups, and more with accurate results." />
        <meta name="keywords" content="volume converter, liter to gallon, milliliter to ounce, cup to liter, fluid measurements, cooking volume conversions" />
        <meta property="og:title" content="Free Online Volume Converter Tool" />
        <meta property="og:description" content="Convert between liters, gallons, cups, fluid ounces and more with our free online volume converter tool." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/volume-converter" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Free Online Volume Converter Tool" />
        <meta name="twitter:description" content="Convert between liters, gallons, cups, fluid ounces and more with our free online volume converter tool." />
        <link rel="canonical" href="https://multitoolset.co/tools/volume-converter" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Volume Converter Tool",
              "url": "https://multitoolset.co/tools/volume-converter",
              "description": "Convert volume units instantly with our free online volume converter. Easily convert between liters, gallons, milliliters, cups, and more with accurate results.",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How many liters are in a gallon?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "There are approximately 3.785 liters in a US gallon and 4.546 liters in a UK (Imperial) gallon."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is the difference between US and UK fluid measurements?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "US and UK fluid measurements have different values. For example, a US gallon is about 3.785 liters, while a UK gallon is about 4.546 liters. Similar differences exist for quarts, pints, fluid ounces, and other fluid measurements."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many milliliters are in a cup?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A standard metric cup contains 250 milliliters. However, a US customary cup is 236.588 milliliters, while a US legal cup (used in nutrition labeling) is 240 milliliters."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <h1 className="text-3xl font-bold text-center flex-grow text-gray-800 dark:text-gray-100">
              Volume Converter
            </h1>
            <div className="w-[70px]"></div> {/* Spacer for balance */}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-lg border-2 border-gray-100 dark:border-gray-800">
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="fromValue" className="text-base font-medium">
                        From
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="fromValue"
                            type="number"
                            placeholder="Enter value"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="text-lg"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={fromUnit} onValueChange={setFromUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(unitGroups).map(([groupName, units]) => (
                                <React.Fragment key={groupName}>
                                  <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400">
                                    {groupName}
                                  </div>
                                  {units.map((unit) => (
                                    <SelectItem key={unit} value={unit}>
                                      {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                    </SelectItem>
                                  ))}
                                  {groupName !== "Cooking" && <div className="h-px my-1 bg-gray-100 dark:bg-gray-800" />}
                                </React.Fragment>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={swapUnits}
                      className="mx-auto md:mx-0 h-10 w-10 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
                    >
                      <ArrowRightLeft className="h-5 w-5" />
                    </Button>
                    
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="toValue" className="text-base font-medium">
                        To
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="toValue"
                            readOnly
                            value={result}
                            className="text-lg bg-gray-50 dark:bg-gray-800"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={toUnit} onValueChange={setToUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(unitGroups).map(([groupName, units]) => (
                                <React.Fragment key={groupName}>
                                  <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400">
                                    {groupName}
                                  </div>
                                  {units.map((unit) => (
                                    <SelectItem key={unit} value={unit}>
                                      {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                    </SelectItem>
                                  ))}
                                  {groupName !== "Cooking" && <div className="h-px my-1 bg-gray-100 dark:bg-gray-800" />}
                                </React.Fragment>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex-grow">
                      {result !== "" && (
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <p className="text-lg font-medium">
                            <span className="text-gray-500 dark:text-gray-400">Result:</span>{" "}
                            <span className="font-bold text-tool-purple">
                              {inputValue} {unitSymbols[fromUnit as keyof typeof unitSymbols]} = {result} {unitSymbols[toUnit as keyof typeof unitSymbols]}
                            </span>
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button onClick={handleCopy} disabled={result === ""}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="mt-6">
                <Tabs defaultValue="howto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="howto">How to Use</TabsTrigger>
                    <TabsTrigger value="formulas">Conversion Formulas</TabsTrigger>
                    <TabsTrigger value="history">Recent Conversions</TabsTrigger>
                  </TabsList>
                  <TabsContent value="howto" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">How to Use the Volume Converter</h2>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Enter the value you want to convert in the "From" field.</li>
                      <li>Select the unit you're converting from using the dropdown menu.</li>
                      <li>Select the unit you want to convert to using the second dropdown menu.</li>
                      <li>The result will be calculated automatically and displayed instantly.</li>
                      <li>Use the "Copy" button to copy the result to your clipboard.</li>
                      <li>Use the "Reset" button to clear all fields and start over.</li>
                    </ol>
                  </TabsContent>
                  <TabsContent value="formulas" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Common Volume Conversion Formulas</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Liter to US Gallon:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 liter = 0.264172 US gallons</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">US Gallon to Liter:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 US gallon = 3.78541 liters</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Milliliter to US Fluid Ounce:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 milliliter = 0.033814 US fluid ounces</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Cup to Milliliter:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 cup = 236.588 milliliters</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">US Tablespoon to Milliliter:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 US tablespoon = 14.7868 milliliters</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Cubic Meter to Cubic Foot:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 cubic meter = 35.3147 cubic feet</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="history" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Recent Conversions</h2>
                    {recentConversions.length > 0 ? (
                      <div className="space-y-2">
                        {recentConversions.map((conversion, index) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md flex justify-between">
                            <div>
                              <span className="font-medium">
                                {conversion.input} {unitSymbols[conversion.from as keyof typeof unitSymbols]} = {conversion.output} {unitSymbols[conversion.to as keyof typeof unitSymbols]}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {conversion.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No recent conversions yet.</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How many liters are in a gallon?</h3>
                    <p className="mt-2">There are approximately 3.785 liters in a US gallon and 4.546 liters in a UK (Imperial) gallon.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What is the difference between US and UK fluid measurements?</h3>
                    <p className="mt-2">US and UK fluid measurements have different values. For example, a US gallon is about 3.785 liters, while a UK gallon is about 4.546 liters. Similar differences exist for quarts, pints, fluid ounces, and other fluid measurements.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How many milliliters are in a cup?</h3>
                    <p className="mt-2">A standard metric cup contains 250 milliliters. However, a US customary cup is 236.588 milliliters, while a US legal cup (used in nutrition labeling) is 240 milliliters.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <AdBanner 
                size="large" 
                type="vertical"
                className="sticky top-24"
              />
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Related Converters</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/tools/length-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Length Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/weight-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Weight Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/temperature-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Temperature Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/speed-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Speed Converter
                    </a>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Common Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("liter");
                        setToUnit("gallon_us");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 liter to US gallons
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("cup");
                        setToUnit("milliliter");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 cup to milliliters
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("gallon_us");
                        setToUnit("liter");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 US gallon to liters
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("tablespoon_us");
                        setToUnit("milliliter");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 US tablespoon to milliliters
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("fluid_ounce_us");
                        setToUnit("milliliter");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 US fluid ounce to milliliters
                    </button>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Cooking Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("cup");
                        setToUnit("fluid_ounce_us");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 cup to fluid ounces
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("tablespoon_us");
                        setToUnit("teaspoon_us");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 tablespoon to teaspoons
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(250);
                        setFromUnit("milliliter");
                        setToUnit("cup");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      250 mL to cups
                    </button>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
          
          <div className="mt-8">
            <AdBanner type="horizontal" size="large" />
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default VolumeConverter;
