
import { useState } from "react";
import { PlusCircle, Save, X, Edit, Trash2, Check, Book } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import ToolLayout from "@/components/tools/ToolLayout";

interface Flashcard {
  id: string;
  question: string;
  answer: string;
}

interface FlashcardSet {
  id: string;
  name: string;
  cards: Flashcard[];
}

const FlashcardMaker = () => {
  const [sets, setSets] = useState<FlashcardSet[]>([]);
  const [currentSetId, setCurrentSetId] = useState<string | null>(null);
  const [newSetName, setNewSetName] = useState("");
  const [newQuestion, setNewQuestion] = useState("");
  const [newAnswer, setNewAnswer] = useState("");
  const [showAnswer, setShowAnswer] = useState<Record<string, boolean>>({});
  const [editingCard, setEditingCard] = useState<string | null>(null);
  const [editQuestion, setEditQuestion] = useState("");
  const [editAnswer, setEditAnswer] = useState("");
  
  const { toast } = useToast();
  
  const createNewSet = () => {
    if (!newSetName.trim()) {
      toast({
        variant: "destructive",
        title: "Set name required",
        description: "Please enter a name for your flashcard set."
      });
      return;
    }
    
    const newSet: FlashcardSet = {
      id: `set-${Date.now()}`,
      name: newSetName,
      cards: []
    };
    
    setSets([...sets, newSet]);
    setCurrentSetId(newSet.id);
    setNewSetName("");
    
    toast({
      title: "Set created",
      description: `"${newSet.name}" has been created.`
    });
  };
  
  const addCardToCurrentSet = () => {
    if (!currentSetId) return;
    if (!newQuestion.trim() || !newAnswer.trim()) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please enter both a question and an answer."
      });
      return;
    }
    
    const newCard: Flashcard = {
      id: `card-${Date.now()}`,
      question: newQuestion,
      answer: newAnswer
    };
    
    setSets(sets.map(set => {
      if (set.id === currentSetId) {
        return {
          ...set,
          cards: [...set.cards, newCard]
        };
      }
      return set;
    }));
    
    setNewQuestion("");
    setNewAnswer("");
    
    toast({
      title: "Card added",
      description: "New flashcard has been added to your set."
    });
  };
  
  const deleteCard = (cardId: string) => {
    if (!currentSetId) return;
    
    setSets(sets.map(set => {
      if (set.id === currentSetId) {
        return {
          ...set,
          cards: set.cards.filter(card => card.id !== cardId)
        };
      }
      return set;
    }));
    
    toast({
      title: "Card deleted",
      description: "Flashcard has been removed from your set."
    });
  };
  
  const deleteSet = (setId: string) => {
    setSets(sets.filter(set => set.id !== setId));
    if (currentSetId === setId) {
      setCurrentSetId(null);
    }
    
    toast({
      title: "Set deleted",
      description: "Flashcard set has been deleted."
    });
  };
  
  const toggleShowAnswer = (cardId: string) => {
    setShowAnswer(prev => ({
      ...prev,
      [cardId]: !prev[cardId]
    }));
  };
  
  const startEditing = (card: Flashcard) => {
    setEditingCard(card.id);
    setEditQuestion(card.question);
    setEditAnswer(card.answer);
  };
  
  const saveEdit = (cardId: string) => {
    if (!currentSetId) return;
    if (!editQuestion.trim() || !editAnswer.trim()) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please enter both a question and an answer."
      });
      return;
    }
    
    setSets(sets.map(set => {
      if (set.id === currentSetId) {
        return {
          ...set,
          cards: set.cards.map(card => {
            if (card.id === cardId) {
              return {
                ...card,
                question: editQuestion,
                answer: editAnswer
              };
            }
            return card;
          })
        };
      }
      return set;
    }));
    
    setEditingCard(null);
    toast({
      title: "Card updated",
      description: "Flashcard has been updated."
    });
  };
  
  const cancelEdit = () => {
    setEditingCard(null);
  };
  
  const currentSet = sets.find(set => set.id === currentSetId);
  
  return (
    <ToolLayout
      title="Flashcard Maker"
      description="Create, study, and master any subject with custom flashcards"
      helpText="Create a set, add questions and answers, then flip cards to test yourself. Perfect for exam prep and learning new topics."
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Set management sidebar */}
        <div className="lg:col-span-3 bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h2 className="text-lg font-semibold mb-4">Your Flashcard Sets</h2>
          
          <div className="space-y-2 mb-6">
            <Input
              placeholder="New set name"
              value={newSetName}
              onChange={(e) => setNewSetName(e.target.value)}
              className="mb-2"
            />
            <Button 
              onClick={createNewSet} 
              className="w-full gap-2"
            >
              <PlusCircle className="h-4 w-4" />
              Create New Set
            </Button>
          </div>
          
          <div className="space-y-2">
            {sets.length > 0 ? (
              sets.map(set => (
                <div 
                  key={set.id}
                  className={`p-3 rounded-lg cursor-pointer flex justify-between items-center ${
                    currentSetId === set.id 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-white dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600"
                  }`}
                  onClick={() => setCurrentSetId(set.id)}
                >
                  <div>
                    <div className="font-medium">{set.name}</div>
                    <div className="text-xs">{set.cards.length} cards</div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteSet(set.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-gray-500">
                No flashcard sets yet. Create your first set!
              </div>
            )}
          </div>
        </div>
        
        {/* Main content area */}
        <div className="lg:col-span-9">
          {currentSet ? (
            <>
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <Book className="mr-2 h-6 w-6 text-primary" />
                {currentSet.name}
              </h2>
              
              {/* Add new card form */}
              <Card className="p-4 mb-8">
                <h3 className="font-medium mb-3">Add a New Card</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">Question</label>
                    <Textarea
                      placeholder="Enter your question"
                      value={newQuestion}
                      onChange={(e) => setNewQuestion(e.target.value)}
                      className="resize-none"
                      rows={2}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Answer</label>
                    <Textarea
                      placeholder="Enter the answer"
                      value={newAnswer}
                      onChange={(e) => setNewAnswer(e.target.value)}
                      className="resize-none"
                      rows={2}
                    />
                  </div>
                  <Button onClick={addCardToCurrentSet} className="gap-2">
                    <PlusCircle className="h-4 w-4" />
                    Add Card
                  </Button>
                </div>
              </Card>
              
              {/* Flashcards display */}
              {currentSet.cards.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentSet.cards.map(card => (
                    <motion.div
                      key={card.id}
                      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden"
                      whileHover={{ y: -5, boxShadow: "0 10px 30px -15px rgba(0,0,0,0.2)" }}
                      transition={{ duration: 0.2 }}
                    >
                      {editingCard === card.id ? (
                        <div className="p-4">
                          <div className="space-y-3">
                            <div>
                              <label className="block text-sm font-medium mb-1">Question</label>
                              <Textarea
                                value={editQuestion}
                                onChange={(e) => setEditQuestion(e.target.value)}
                                className="resize-none"
                                rows={2}
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Answer</label>
                              <Textarea
                                value={editAnswer}
                                onChange={(e) => setEditAnswer(e.target.value)}
                                className="resize-none"
                                rows={2}
                              />
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                size="sm" 
                                onClick={() => saveEdit(card.id)}
                                className="gap-2"
                              >
                                <Check className="h-4 w-4" />
                                Save
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={cancelEdit}
                                className="gap-2"
                              >
                                <X className="h-4 w-4" />
                                Cancel
                              </Button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
                            <p className="font-medium">{card.question}</p>
                          </div>
                          
                          <div className="p-4">
                            {showAnswer[card.id] ? (
                              <p>{card.answer}</p>
                            ) : (
                              <Button 
                                variant="ghost" 
                                className="text-primary"
                                onClick={() => toggleShowAnswer(card.id)}
                              >
                                Show Answer
                              </Button>
                            )}
                          </div>
                          
                          <div className="bg-gray-50 dark:bg-gray-700 p-2 flex justify-end space-x-2">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => startEditing(card)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="text-red-500 hover:text-red-600" 
                              onClick={() => deleteCard(card.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h3 className="text-xl font-medium mb-2">No cards yet</h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    Add your first card to start studying!
                  </p>
                  <div className="flex justify-center">
                    <svg 
                      className="text-gray-300 dark:text-gray-600 h-32 w-32" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24" 
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect width="18" height="14" x="3" y="5" rx="2" strokeWidth="2" />
                      <path strokeLinecap="round" strokeWidth="2" d="M3 7l9 6 9-6" />
                    </svg>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-20 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h3 className="text-2xl font-medium mb-2">Welcome to Flashcard Maker</h3>
              <p className="text-gray-500 dark:text-gray-400 max-w-lg mx-auto mb-6">
                Create personalized flashcard sets to study any subject. Perfect for exams, language learning, or testing your knowledge.
              </p>
              <Button 
                onClick={() => setNewSetName("My First Set")} 
                className="gap-2"
              >
                <PlusCircle className="h-4 w-4" />
                Create Your First Set
              </Button>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

// Add schema markup for SEO
const SchemaMarkup = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Flashcard Maker",
    "applicationCategory": "EducationalApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "All",
    "description": "Create and study with custom flashcards for better learning and exam preparation."
  };

  return (
    <script type="application/ld+json">
      {JSON.stringify(schema)}
    </script>
  );
};

// Add meta tags for SEO
const SeoHead = () => {
  return (
    <>
      <title>Flashcard Maker - Create & Study Custom Flashcards | MultiToolSet</title>
      <meta
        name="description"
        content="Create, organize and study with custom flashcards for better learning and exam preparation. Perfect for students and lifelong learners."
      />
      <meta
        name="keywords"
        content="flashcard maker, study cards, digital flashcards, exam prep, learning tool, educational tool"
      />
      <link rel="canonical" href="https://multitoolset.co/tools/flashcard-maker" />
    </>
  );
};

// Export with SEO components
const FlashcardMakerWithSeo = () => {
  return (
    <>
      <SeoHead />
      <SchemaMarkup />
      <FlashcardMaker />
    </>
  );
};

export default FlashcardMakerWithSeo;
