
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Copy, Download, AlertCircle } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import AdBanner from "@/components/AdBanner";

interface KeywordData {
  keyword: string;
  count: number;
  density: number;
}

const KeywordDensityChecker = () => {
  const [content, setContent] = useState("");
  const [url, setUrl] = useState("");
  const [results, setResults] = useState<KeywordData[]>([]);
  const [totalWords, setTotalWords] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const calculateDensity = () => {
    if (!content.trim()) {
      setError("Please enter content to analyze");
      return;
    }

    setIsLoading(true);
    setError("");

    // Give a slight delay to show loading state
    setTimeout(() => {
      try {
        const cleanedContent = content.toLowerCase().replace(/[^\w\s]/g, ' ');
        const words = cleanedContent.match(/\b\w+\b/g) || [];
        const totalWordCount = words.length;
        setTotalWords(totalWordCount);
        
        // Skip common words (stopwords)
        const stopwords = new Set([
          'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
          'be', 'been', 'being', 'to', 'of', 'for', 'in', 'on', 'at', 'by',
          'with', 'about', 'against', 'between', 'into', 'through', 'during',
          'before', 'after', 'above', 'below', 'from', 'up', 'down', 'this',
          'that', 'these', 'those', 'it', 'its', 'they', 'them', 'their'
        ]);
        
        const wordCount: { [key: string]: number } = {};
        words.forEach(word => {
          if (!stopwords.has(word) && word.length > 1) {
            wordCount[word] = (wordCount[word] || 0) + 1;
          }
        });

        const keywordData = Object.entries(wordCount)
          .map(([keyword, count]) => ({
            keyword,
            count,
            density: (count / totalWordCount) * 100
          }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 20);

        setResults(keywordData);
        setIsLoading(false);
      } catch (err) {
        setError("Error analyzing content. Please try again.");
        setIsLoading(false);
      }
    }, 500);
  };

  const copyToClipboard = () => {
    if (results.length === 0) return;
    
    const textToCopy = results
      .map(item => `${item.keyword}: ${item.count} occurrences (${item.density.toFixed(2)}%)`)
      .join('\n');
    
    navigator.clipboard.writeText(textToCopy);
    toast.success("Keyword density results copied to clipboard!");
  };

  const downloadResults = () => {
    if (results.length === 0) return;
    
    const csvContent = "Keyword,Count,Density\n" +
      results.map(item => `"${item.keyword}",${item.count},${item.density.toFixed(2)}%`).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'keyword-density-results.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success("Keyword density results downloaded as CSV!");
  };

  return (
    <ToolLayout
      title="Keyword Density Checker"
      description="Analyze your content to optimize keyword usage and improve SEO"
      helpText="Enter your content to analyze keyword density. Higher percentages may indicate keyword stuffing, which could negatively impact SEO."
    >
      <div className="space-y-6">
        <Tabs defaultValue="content" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="content">Analyze Text</TabsTrigger>
            <TabsTrigger value="url" disabled>Analyze URL (Coming Soon)</TabsTrigger>
          </TabsList>
          
          <TabsContent value="content" className="space-y-4 mt-4">
            <Textarea
              placeholder="Paste your content here to analyze keyword density..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              className="min-h-[200px] font-mono text-sm"
            />
          </TabsContent>
          
          <TabsContent value="url" className="space-y-4 mt-4">
            <div className="flex items-center space-x-2">
              <Input
                type="url"
                placeholder="https://example.com/page-to-analyze"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
              <Button disabled>Fetch</Button>
            </div>
            <p className="text-sm text-muted-foreground">
              URL analysis feature coming soon. Please use the text analyzer for now.
            </p>
          </TabsContent>
        </Tabs>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-3 rounded-md flex items-center">
            <AlertCircle size={16} className="mr-2 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <AdBanner className="my-4" />

        <Button 
          onClick={calculateDensity} 
          className="w-full" 
          disabled={isLoading}
        >
          <Search className="mr-2 h-4 w-4" />
          {isLoading ? "Analyzing..." : "Analyze Keywords"}
        </Button>

        {results.length > 0 && (
          <div className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Analysis Results</h3>
              <p className="text-sm text-muted-foreground">Total Words: {totalWords}</p>
            </div>
            
            <Separator />
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadResults}>
                <Download className="h-4 w-4 mr-1" />
                Download CSV
              </Button>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <div className="grid grid-cols-3 gap-4 p-4 font-medium border-b">
                  <div>Keyword</div>
                  <div>Count</div>
                  <div>Density</div>
                </div>
                <div className="divide-y">
                  {results.map((item, index) => (
                    <div key={index} className="grid grid-cols-3 gap-4 p-4 hover:bg-muted/50">
                      <div className="font-medium">{item.keyword}</div>
                      <div>{item.count}</div>
                      <div className={item.density > 3 ? "text-amber-600 font-semibold" : ""}>{item.density.toFixed(2)}%</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
              <h4 className="font-medium mb-2">SEO Recommendations</h4>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li>Aim for keyword density between 1-3% for primary keywords</li>
                <li>Use related keywords and synonyms instead of repeating the same keyword</li>
                <li>Ensure your content reads naturally and provides value to readers</li>
                <li>Avoid keyword stuffing which can negatively impact SEO</li>
              </ul>
            </div>
            
            <AdBanner className="my-4" />
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

export default KeywordDensityChecker;
