
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { Calculator, Percent, DollarSign, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ToolLayout from "@/components/tools/ToolLayout";
import withErrorBoundary from "@/components/tools/withErrorBoundary";

interface LoanResult {
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
}

const LoanInterestCalculatorComponent = () => {
  const [loanAmount, setLoanAmount] = useState<string>("100000");
  const [interestRate, setInterestRate] = useState<string>("8");
  const [loanTerm, setLoanTerm] = useState<string>("5");
  const [loanType, setLoanType] = useState<"reducing" | "flat">("reducing");
  const [result, setResult] = useState<LoanResult | null>(null);
  
  const calculateLoan = () => {
    const amount = parseFloat(loanAmount);
    const rate = parseFloat(interestRate) / 100;
    const term = parseInt(loanTerm);
    
    if (isNaN(amount) || isNaN(rate) || isNaN(term)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (amount <= 0 || rate <= 0 || term <= 0) {
      toast.error("All values must be greater than zero");
      return;
    }
    
    if (loanType === "reducing") {
      // Calculate for reducing balance (compound interest)
      const monthlyRate = rate / 12;
      const months = term * 12;
      
      // EMI formula: P * r * (1+r)^n / ((1+r)^n - 1)
      const monthlyPayment = (amount * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
      const totalPayment = monthlyPayment * months;
      const totalInterest = totalPayment - amount;
      
      setResult({
        monthlyPayment,
        totalPayment,
        totalInterest
      });
    } else {
      // Calculate for flat rate (simple interest)
      const totalInterest = amount * rate * term;
      const totalPayment = amount + totalInterest;
      const monthlyPayment = totalPayment / (term * 12);
      
      setResult({
        monthlyPayment,
        totalPayment,
        totalInterest
      });
    }
    
    toast.success("Loan interest calculation complete!");
  };
  
  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 2
    });
  };
  
  return (
    <ToolLayout
      title="Loan Interest Calculator"
      description="Calculate loan interest, EMI, and total payment for different loan types"
      helpText="Compare reducing balance and flat rate interest calculations for your loans"
    >
      <Helmet>
        <title>Loan Interest Calculator | EMI & Interest Calculator | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate loan EMI, interest and total payment with our free loan interest calculator. Compare reducing balance vs flat rate interest methods."
        />
        <meta
          name="keywords"
          content="loan calculator, interest calculator, EMI calculator, flat rate calculator, reducing balance calculator"
        />
      </Helmet>

      <div className="space-y-6 max-w-3xl mx-auto">
        <Tabs value={loanType} onValueChange={(v) => setLoanType(v as "reducing" | "flat")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="reducing">Reducing Balance</TabsTrigger>
            <TabsTrigger value="flat">Flat Rate</TabsTrigger>
          </TabsList>
          
          <TabsContent value="reducing" className="pt-4">
            <p className="text-sm text-gray-600 mb-4">
              Reducing balance method calculates interest on the outstanding loan amount, which decreases with each payment.
              This is the most common method used for home loans, car loans, and personal loans.
            </p>
          </TabsContent>
          
          <TabsContent value="flat" className="pt-4">
            <p className="text-sm text-gray-600 mb-4">
              Flat rate method calculates interest on the initial loan amount for the entire loan term.
              This typically results in higher interest payments compared to the reducing balance method.
            </p>
          </TabsContent>
        </Tabs>
        
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Percent className="mr-2 text-purple-600" />
            Calculate Loan Interest
          </h2>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="loanAmount" className="block text-sm font-medium text-gray-700">
                Loan Amount ($)
              </label>
              <Input
                id="loanAmount"
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                placeholder="Enter loan amount"
                className="w-full"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700">
                Interest Rate (% per annum)
              </label>
              <Input
                id="interestRate"
                type="number"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                placeholder="Enter interest rate"
                className="w-full"
                step="0.01"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="loanTerm" className="block text-sm font-medium text-gray-700">
                Loan Term (years)
              </label>
              <Input
                id="loanTerm"
                type="number"
                value={loanTerm}
                onChange={(e) => setLoanTerm(e.target.value)}
                placeholder="Enter loan term in years"
                className="w-full"
              />
            </div>
            
            <Button 
              onClick={calculateLoan}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              <Calculator className="mr-2 h-4 w-4" /> Calculate Interest
            </Button>
          </div>
        </Card>
        
        {result && (
          <Card className="p-6 bg-gray-50">
            <h3 className="font-bold text-lg mb-4">Loan Summary ({loanType === "reducing" ? "Reducing Balance" : "Flat Rate"})</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Monthly EMI</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(result.monthlyPayment)}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Total Interest</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(result.totalInterest)}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Effective Rate: {((result.totalInterest / (parseFloat(loanAmount) * parseInt(loanTerm))) * 100).toFixed(2)}% per annum
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Total Payment</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatCurrency(result.totalPayment)}
                </p>
              </div>
            </div>
          </Card>
        )}
        
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <h2 className="text-xl font-bold mb-4">Reducing Balance vs. Flat Rate</h2>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium">Reducing Balance (Compound Interest)</h3>
              <p className="text-gray-600">
                In a reducing balance loan, interest is calculated on the outstanding principal amount, 
                which decreases with each payment. This is the most common method used for home loans, 
                auto loans, and personal loans.
              </p>
              <p className="text-gray-600 mt-2">
                <strong>Advantages:</strong> Lower total interest cost, interest charges decrease over time.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium">Flat Rate (Simple Interest)</h3>
              <p className="text-gray-600">
                In a flat rate loan, interest is calculated on the full initial loan amount for the entire 
                loan period, regardless of how much of the principal has been repaid. This typically results 
                in a higher effective interest rate.
              </p>
              <p className="text-gray-600 mt-2">
                <strong>Pros:</strong> Simpler to calculate.
                <br />
                <strong>Cons:</strong> More expensive, higher total interest cost.
              </p>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="text-md font-medium">Example</h3>
              <p className="text-sm text-gray-600">
                For a $10,000 loan at 10% interest for 5 years:
                <br />
                - Reducing balance: Total interest = approx. $2,748
                <br />
                - Flat rate: Total interest = $5,000
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

const LoanInterestCalculator = withErrorBoundary(LoanInterestCalculatorComponent, "loan-interest-calculator");

export default LoanInterestCalculator;
