
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { 
  BookOpen, 
  Plus, 
  Edit, 
  Trash2, 
  RefreshCw, 
  Search, 
  FileUp, 
  FileDown, 
  Star,
  StarOff,
  Check,
  X,
  Volume2
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import ChatBot from "@/components/ChatBot";

interface VocabularyWord {
  id: string;
  word: string;
  definition: string;
  examples: string[];
  category: string;
  isFavorite: boolean;
  dateAdded: Date;
  lastReviewed: Date | null;
  masteryLevel: number; // 0-5 for spaced repetition
}

const SAMPLE_WORDS: VocabularyWord[] = [
  {
    id: "1",
    word: "Ephemeral",
    definition: "Lasting for a very short time; transitory; fleeting.",
    examples: [
      "The ephemeral nature of cherry blossoms makes them more precious.",
      "Fame can be ephemeral, here today and gone tomorrow."
    ],
    category: "Advanced Vocabulary",
    isFavorite: true,
    dateAdded: new Date(),
    lastReviewed: null,
    masteryLevel: 0
  },
  {
    id: "2",
    word: "Ubiquitous",
    definition: "Present, appearing, or found everywhere.",
    examples: [
      "Mobile phones have become ubiquitous in modern society.",
      "The ubiquitous smell of coffee filled the café."
    ],
    category: "Advanced Vocabulary",
    isFavorite: false,
    dateAdded: new Date(),
    lastReviewed: null,
    masteryLevel: 0
  },
  {
    id: "3",
    word: "Serendipity",
    definition: "The occurrence and development of events by chance in a happy or beneficial way.",
    examples: [
      "Finding her dream job was a case of pure serendipity.",
      "Their meeting was a serendipitous event that changed both their lives."
    ],
    category: "Advanced Vocabulary",
    isFavorite: false,
    dateAdded: new Date(),
    lastReviewed: null,
    masteryLevel: 0
  }
];

const CATEGORIES = [
  "Academic",
  "Business",
  "Casual",
  "Technical",
  "Scientific",
  "Literary",
  "Medical",
  "Legal",
  "Advanced Vocabulary",
  "Basic Vocabulary",
  "Foreign Words",
  "Idioms",
  "Phrasal Verbs",
  "SAT/GRE Prep",
  "Other"
];

const VocabularyBuilder = () => {
  const [words, setWords] = useState<VocabularyWord[]>(() => {
    const savedWords = localStorage.getItem("vocabularyWords");
    return savedWords ? JSON.parse(savedWords) : SAMPLE_WORDS;
  });
  
  const [newWordDialogOpen, setNewWordDialogOpen] = useState(false);
  const [editWordDialogOpen, setEditWordDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortOption, setSortOption] = useState("alphabetical");
  const [viewMode, setViewMode] = useState<"list" | "cards" | "study">("list");
  const [showDefinition, setShowDefinition] = useState(true);
  const [activeTabId, setActiveTabId] = useState("all");
  
  // State for adding/editing a word
  const [formWord, setFormWord] = useState("");
  const [formDefinition, setFormDefinition] = useState("");
  const [formExamples, setFormExamples] = useState("");
  const [formCategory, setFormCategory] = useState("Advanced Vocabulary");
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);
  
  // State for study mode
  const [studyWords, setStudyWords] = useState<VocabularyWord[]>([]);
  const [currentStudyIndex, setCurrentStudyIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  const { toast } = useToast();
  
  // Save to localStorage whenever words change
  useEffect(() => {
    localStorage.setItem("vocabularyWords", JSON.stringify(words));
  }, [words]);
  
  // Setup study mode words when entering study mode or when words change
  useEffect(() => {
    if (viewMode === "study") {
      // Shuffle words for study
      const shuffledWords = [...filteredWords].sort(() => Math.random() - 0.5);
      setStudyWords(shuffledWords);
      setCurrentStudyIndex(0);
      setIsFlipped(false);
    }
  }, [viewMode]);
  
  const handleAddWord = () => {
    if (!formWord.trim() || !formDefinition.trim()) {
      toast({
        title: "Error",
        description: "Word and definition are required.",
        variant: "destructive",
      });
      return;
    }
    
    const newWord: VocabularyWord = {
      id: Date.now().toString(),
      word: formWord.trim(),
      definition: formDefinition.trim(),
      examples: formExamples.split('\n').filter(ex => ex.trim() !== ''),
      category: formCategory,
      isFavorite: false,
      dateAdded: new Date(),
      lastReviewed: null,
      masteryLevel: 0
    };
    
    setWords([...words, newWord]);
    resetForm();
    setNewWordDialogOpen(false);
    
    toast({
      title: "Word added",
      description: `"${formWord}" has been added to your vocabulary list.`
    });
  };
  
  const handleUpdateWord = () => {
    if (!currentEditId || !formWord.trim() || !formDefinition.trim()) {
      toast({
        title: "Error",
        description: "Word and definition are required.",
        variant: "destructive",
      });
      return;
    }
    
    const updatedWords = words.map(word => {
      if (word.id === currentEditId) {
        return {
          ...word,
          word: formWord.trim(),
          definition: formDefinition.trim(),
          examples: formExamples.split('\n').filter(ex => ex.trim() !== ''),
          category: formCategory
        };
      }
      return word;
    });
    
    setWords(updatedWords);
    resetForm();
    setEditWordDialogOpen(false);
    
    toast({
      title: "Word updated",
      description: `"${formWord}" has been updated.`
    });
  };
  
  const handleDeleteWord = (id: string) => {
    const wordToDelete = words.find(w => w.id === id);
    setWords(words.filter(word => word.id !== id));
    
    toast({
      title: "Word deleted",
      description: `"${wordToDelete?.word}" has been removed from your vocabulary list.`,
      variant: "destructive"
    });
  };
  
  const handleToggleFavorite = (id: string) => {
    const updatedWords = words.map(word => {
      if (word.id === id) {
        return {
          ...word,
          isFavorite: !word.isFavorite
        };
      }
      return word;
    });
    
    setWords(updatedWords);
    
    const word = updatedWords.find(w => w.id === id);
    toast({
      title: word?.isFavorite ? "Added to favorites" : "Removed from favorites",
      description: `"${word?.word}" has been ${word?.isFavorite ? "added to" : "removed from"} favorites.`
    });
  };
  
  const handleEditWord = (id: string) => {
    const wordToEdit = words.find(word => word.id === id);
    if (wordToEdit) {
      setFormWord(wordToEdit.word);
      setFormDefinition(wordToEdit.definition);
      setFormExamples(wordToEdit.examples.join('\n'));
      setFormCategory(wordToEdit.category);
      setCurrentEditId(id);
      setEditWordDialogOpen(true);
    }
  };
  
  const handleExportVocabulary = () => {
    const dataStr = JSON.stringify(words, null, 2);
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `vocabulary-list-${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement("a");
    linkElement.setAttribute("href", dataUri);
    linkElement.setAttribute("download", exportFileDefaultName);
    linkElement.click();
    
    toast({
      title: "Vocabulary exported",
      description: `${words.length} words have been exported successfully.`
    });
  };
  
  const handleImportVocabulary = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedWords = JSON.parse(e.target?.result as string);
        
        if (Array.isArray(importedWords) && importedWords.length > 0) {
          // Validate each word has at least the required properties
          const validWords = importedWords.filter(word => 
            word.id && word.word && word.definition
          ).map(word => ({
            ...word,
            dateAdded: new Date(word.dateAdded),
            lastReviewed: word.lastReviewed ? new Date(word.lastReviewed) : null
          }));
          
          setWords(validWords);
          
          toast({
            title: "Import successful",
            description: `${validWords.length} words have been imported.`
          });
        } else {
          toast({
            title: "Import failed",
            description: "The file format appears to be invalid.",
            variant: "destructive"
          });
        }
      } catch (error) {
        toast({
          title: "Import failed",
          description: "There was an error processing your file.",
          variant: "destructive"
        });
      }
    };
    
    reader.readAsText(file);
    event.target.value = "";
  };
  
  const resetForm = () => {
    setFormWord("");
    setFormDefinition("");
    setFormExamples("");
    setFormCategory("Advanced Vocabulary");
    setCurrentEditId(null);
  };
  
  const handleNextStudyWord = () => {
    if (currentStudyIndex < studyWords.length - 1) {
      setCurrentStudyIndex(prevIndex => prevIndex + 1);
      setIsFlipped(false);
      
      // Update the lastReviewed date and mastery level
      const updatedWords = words.map(word => {
        if (word.id === studyWords[currentStudyIndex].id) {
          return {
            ...word,
            lastReviewed: new Date(),
            masteryLevel: Math.min(5, word.masteryLevel + 1)
          };
        }
        return word;
      });
      
      setWords(updatedWords);
    } else {
      toast({
        title: "Study session complete",
        description: "You've reviewed all the words in this set!"
      });
      
      // Return to list view after completing study
      setViewMode("list");
    }
  };
  
  const handleMarkAsLearned = (isLearned: boolean) => {
    if (currentStudyIndex < studyWords.length) {
      const updatedWords = words.map(word => {
        if (word.id === studyWords[currentStudyIndex].id) {
          return {
            ...word,
            lastReviewed: new Date(),
            masteryLevel: isLearned 
              ? Math.min(5, word.masteryLevel + 1) 
              : Math.max(0, word.masteryLevel - 1)
          };
        }
        return word;
      });
      
      setWords(updatedWords);
      
      toast({
        title: isLearned ? "Marked as learned" : "Marked for review",
        description: isLearned 
          ? "This word has been marked as learned and will appear less frequently." 
          : "This word will appear more frequently in your study sessions."
      });
      
      // Move to next word
      handleNextStudyWord();
    }
  };
  
  const speakWord = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    } else {
      toast({
        title: "Speech synthesis not supported",
        description: "Your browser does not support text-to-speech functionality.",
        variant: "destructive"
      });
    }
  };
  
  // Filter words based on search, category, and tab
  const filteredWords = words.filter(word => {
    const matchesSearch = 
      word.word.toLowerCase().includes(searchQuery.toLowerCase()) ||
      word.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
      word.examples.some(ex => ex.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = categoryFilter === "all" || word.category === categoryFilter;
    
    const matchesTab = 
      activeTabId === "all" || 
      (activeTabId === "favorites" && word.isFavorite) ||
      (activeTabId === "mastered" && word.masteryLevel >= 4) ||
      (activeTabId === "learning" && word.masteryLevel > 0 && word.masteryLevel < 4) ||
      (activeTabId === "unreviewed" && word.masteryLevel === 0);
    
    return matchesSearch && matchesCategory && matchesTab;
  });
  
  // Sort filtered words
  const sortedWords = [...filteredWords].sort((a, b) => {
    switch (sortOption) {
      case "alphabetical":
        return a.word.localeCompare(b.word);
      case "reverseAlphabetical":
        return b.word.localeCompare(a.word);
      case "dateAdded":
        return new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime();
      case "lastReviewed":
        if (!a.lastReviewed) return 1;
        if (!b.lastReviewed) return -1;
        return new Date(b.lastReviewed).getTime() - new Date(a.lastReviewed).getTime();
      default:
        return 0;
    }
  });
  
  // Get all unique categories from words
  const uniqueCategories = Array.from(new Set(words.map(word => word.category))).sort();
  
  return (
    <>
      <Helmet>
        <title>Vocabulary Builder | Learn and Memorize New Words - MultiToolSet</title>
        <meta
          name="description"
          content="Expand your vocabulary with our free vocabulary builder tool. Create word lists, study with flashcards, track progress, and improve your language skills."
        />
        <meta
          name="keywords"
          content="vocabulary builder, word learning, language tools, vocabulary flashcards, vocabulary list, language learning"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/vocabulary-builder" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/vocabulary-builder" />
        <meta property="og:title" content="Vocabulary Builder | Learn and Memorize New Words" />
        <meta property="og:description" content="Expand your vocabulary with our free vocabulary builder tool. Create word lists, study with flashcards, and improve your language skills." />
        <meta property="og:image" content="https://multitoolset.co/images/tools/vocabulary-builder.jpg" />
        
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://multitoolset.co/tools/vocabulary-builder" />
        <meta property="twitter:title" content="Vocabulary Builder | Learn and Memorize New Words" />
        <meta property="twitter:description" content="Expand your vocabulary with our free vocabulary builder tool. Create word lists, study with flashcards, and improve your language skills." />
        <meta property="twitter:image" content="https://multitoolset.co/images/tools/vocabulary-builder.jpg" />
        
        {/* JSON-LD structured data */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Vocabulary Builder",
              "applicationCategory": "Education",
              "operatingSystem": "Web",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "description": "Expand your vocabulary with our free vocabulary builder tool. Create word lists, study with flashcards, track progress, and improve your language skills.",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "142"
              },
              "featureList": [
                "Create and manage vocabulary lists",
                "Study with flashcards",
                "Track learning progress",
                "Import and export word lists",
                "Text-to-speech pronunciation"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <BackButton className="mb-2" />
              <h1 className="text-3xl font-bold">Vocabulary Builder</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Expand your vocabulary and track your learning progress
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2 self-end">
              <Dialog open={newWordDialogOpen} onOpenChange={setNewWordDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="default" className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    <span>Add Word</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Word</DialogTitle>
                    <DialogDescription>
                      Enter the word, definition, and examples to add to your vocabulary list.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="word">Word</Label>
                      <Input
                        id="word"
                        value={formWord}
                        onChange={(e) => setFormWord(e.target.value)}
                        placeholder="Enter a word or phrase"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="definition">Definition</Label>
                      <Textarea
                        id="definition"
                        value={formDefinition}
                        onChange={(e) => setFormDefinition(e.target.value)}
                        placeholder="Enter the definition"
                        rows={3}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="examples">
                        Example Sentences (one per line)
                      </Label>
                      <Textarea
                        id="examples"
                        value={formExamples}
                        onChange={(e) => setFormExamples(e.target.value)}
                        placeholder="Enter example sentences (one per line)"
                        rows={3}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={formCategory} onValueChange={setFormCategory}>
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setNewWordDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddWord}>Add Word</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              <Dialog open={editWordDialogOpen} onOpenChange={setEditWordDialogOpen}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Edit Word</DialogTitle>
                    <DialogDescription>
                      Update the details for this vocabulary word.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-word">Word</Label>
                      <Input
                        id="edit-word"
                        value={formWord}
                        onChange={(e) => setFormWord(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-definition">Definition</Label>
                      <Textarea
                        id="edit-definition"
                        value={formDefinition}
                        onChange={(e) => setFormDefinition(e.target.value)}
                        rows={3}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-examples">
                        Example Sentences (one per line)
                      </Label>
                      <Textarea
                        id="edit-examples"
                        value={formExamples}
                        onChange={(e) => setFormExamples(e.target.value)}
                        rows={3}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-category">Category</Label>
                      <Select value={formCategory} onValueChange={setFormCategory}>
                        <SelectTrigger id="edit-category">
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => {
                        resetForm();
                        setEditWordDialogOpen(false);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button onClick={handleUpdateWord}>Update Word</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <FileDown className="h-4 w-4" />
                    <span>Export/Import</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={handleExportVocabulary} className="cursor-pointer">
                    <FileDown className="h-4 w-4 mr-2" /> Export Vocabulary
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <label className="flex items-center cursor-pointer w-full">
                      <FileUp className="h-4 w-4 mr-2" /> Import Vocabulary
                      <input
                        type="file"
                        className="hidden"
                        accept=".json"
                        onChange={handleImportVocabulary}
                      />
                    </label>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button
                variant={viewMode === "study" ? "default" : "outline"}
                onClick={() => setViewMode("study")}
                className="flex items-center gap-2"
              >
                <BookOpen className="h-4 w-4" />
                <span>Study Mode</span>
              </Button>
            </div>
          </div>
          
          {viewMode === "study" ? (
            <div className="max-w-3xl mx-auto">
              {studyWords.length > 0 ? (
                <>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <span className="text-sm text-gray-500">
                        Card {currentStudyIndex + 1} of {studyWords.length}
                      </span>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 h-1 mt-1 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-purple-500 h-full rounded-full"
                          style={{
                            width: `${((currentStudyIndex + 1) / studyWords.length) * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="show-definition" className="text-sm">
                        Show Definition by Default
                      </Label>
                      <Switch
                        id="show-definition"
                        checked={showDefinition}
                        onCheckedChange={setShowDefinition}
                      />
                    </div>
                  </div>
                  
                  <Card className="mb-6">
                    <div
                      className={`min-h-[40vh] flex items-center justify-center p-8 transition-all duration-700 ${
                        isFlipped ? "bg-gray-50 dark:bg-gray-800" : ""
                      }`}
                      onClick={() => setIsFlipped(!isFlipped)}
                    >
                      <div className="text-center cursor-pointer">
                        <div className="mb-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              speakWord(studyWords[currentStudyIndex].word);
                            }}
                            className="rounded-full"
                          >
                            <Volume2 className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <h2 className="text-3xl font-bold mb-2">
                          {studyWords[currentStudyIndex].word}
                        </h2>
                        
                        {studyWords[currentStudyIndex].category && (
                          <Badge className="mb-4" variant="outline">
                            {studyWords[currentStudyIndex].category}
                          </Badge>
                        )}
                        
                        {(isFlipped || showDefinition) && (
                          <div className="mt-6 max-w-xl mx-auto animate-fade-in">
                            <p className="text-lg mb-4">
                              {studyWords[currentStudyIndex].definition}
                            </p>
                            
                            {studyWords[currentStudyIndex].examples.length > 0 && (
                              <div className="mt-6 text-gray-700 dark:text-gray-300">
                                <p className="text-sm font-semibold mb-2">Examples:</p>
                                <ul className="text-left list-disc pl-5 space-y-2">
                                  {studyWords[currentStudyIndex].examples.map((example, i) => (
                                    <li key={i} className="text-sm italic">
                                      "{example}"
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}
                        
                        {!isFlipped && !showDefinition && (
                          <p className="text-gray-500 mt-4">
                            Click to reveal definition
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <CardFooter className="flex justify-between p-4 border-t">
                      <Button
                        variant="outline"
                        onClick={() => setViewMode("list")}
                      >
                        Exit Study Mode
                      </Button>
                      
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          className="flex items-center gap-1"
                          onClick={() => handleMarkAsLearned(false)}
                        >
                          <X className="h-4 w-4 text-red-500" />
                          <span>Still Learning</span>
                        </Button>
                        
                        <Button
                          className="flex items-center gap-1"
                          onClick={() => handleMarkAsLearned(true)}
                        >
                          <Check className="h-4 w-4" />
                          <span>Learned It</span>
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                </>
              ) : (
                <Card className="p-8 text-center">
                  <CardContent>
                    <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h2 className="text-2xl font-bold mb-2">No Words to Study</h2>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Your vocabulary list is empty or no words match your current filters.
                    </p>
                    <Button onClick={() => setNewWordDialogOpen(true)}>
                      Add Your First Word
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-8">
                <div className="col-span-1 md:col-span-2 lg:col-span-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      type="search"
                      placeholder="Search words, definitions, examples..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {uniqueCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={sortOption} onValueChange={setSortOption}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Sort" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="alphabetical">A-Z</SelectItem>
                      <SelectItem value="reverseAlphabetical">Z-A</SelectItem>
                      <SelectItem value="dateAdded">Newest</SelectItem>
                      <SelectItem value="lastReviewed">Last Reviewed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Tabs value={activeTabId} onValueChange={setActiveTabId}>
                <TabsList className="mb-6">
                  <TabsTrigger value="all">All Words ({words.length})</TabsTrigger>
                  <TabsTrigger value="favorites">
                    Favorites ({words.filter(w => w.isFavorite).length})
                  </TabsTrigger>
                  <TabsTrigger value="mastered">
                    Mastered ({words.filter(w => w.masteryLevel >= 4).length})
                  </TabsTrigger>
                  <TabsTrigger value="learning">
                    Learning ({words.filter(w => w.masteryLevel > 0 && w.masteryLevel < 4).length})
                  </TabsTrigger>
                  <TabsTrigger value="unreviewed">
                    Unreviewed ({words.filter(w => w.masteryLevel === 0).length})
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value={activeTabId} className="mt-0">
                  {sortedWords.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {sortedWords.map((word) => (
                        <Card key={word.id} className="overflow-hidden">
                          <CardHeader className="pb-2">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-2">
                                <div>
                                  <CardTitle className="text-xl flex items-center gap-2">
                                    {word.word}
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => speakWord(word.word)}
                                      className="h-6 w-6 p-0 rounded-full"
                                    >
                                      <Volume2 className="h-3 w-3" />
                                    </Button>
                                  </CardTitle>
                                  
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    <Badge variant="outline" className="text-xs">
                                      {word.category}
                                    </Badge>
                                    
                                    {word.masteryLevel > 0 && (
                                      <Badge
                                        className="text-xs"
                                        variant={
                                          word.masteryLevel >= 4
                                            ? "default"
                                            : "secondary"
                                        }
                                      >
                                        {word.masteryLevel >= 4
                                          ? "Mastered"
                                          : `Level ${word.masteryLevel}`}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex space-x-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleToggleFavorite(word.id)}
                                >
                                  {word.isFavorite ? (
                                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                  ) : (
                                    <StarOff className="h-4 w-4 text-gray-400" />
                                  )}
                                </Button>
                                
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleEditWord(word.id)}
                                >
                                  <Edit className="h-4 w-4 text-gray-400" />
                                </Button>
                                
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleDeleteWord(word.id)}
                                >
                                  <Trash2 className="h-4 w-4 text-gray-400" />
                                </Button>
                              </div>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="pb-4">
                            <p className="text-sm">{word.definition}</p>
                            
                            {word.examples.length > 0 && (
                              <div className="mt-3 text-gray-600 dark:text-gray-400">
                                <p className="text-xs font-medium mb-1">Examples:</p>
                                <ul className="text-xs space-y-1 italic">
                                  {word.examples.slice(0, 2).map((example, i) => (
                                    <li key={i} className="line-clamp-1">
                                      "{example}"
                                    </li>
                                  ))}
                                  {word.examples.length > 2 && (
                                    <li className="text-gray-400 dark:text-gray-500 not-italic">
                                      + {word.examples.length - 2} more examples...
                                    </li>
                                  )}
                                </ul>
                              </div>
                            )}
                          </CardContent>
                          
                          <CardFooter className="pt-0 text-xs text-gray-500 flex justify-between">
                            <div>
                              Added: {new Date(word.dateAdded).toLocaleDateString()}
                            </div>
                            {word.lastReviewed && (
                              <div>
                                Last reviewed: {new Date(word.lastReviewed).toLocaleDateString()}
                              </div>
                            )}
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <BookOpen className="h-16 w-16 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No Words Found</h3>
                      <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
                        {words.length === 0
                          ? "Your vocabulary list is empty. Start by adding some words!"
                          : "No words match your current filters. Try changing your search or category filter."}
                      </p>
                      <div className="flex justify-center space-x-4">
                        {words.length === 0 ? (
                          <Button onClick={() => setNewWordDialogOpen(true)}>
                            <Plus className="h-4 w-4 mr-2" /> Add Your First Word
                          </Button>
                        ) : (
                          <>
                            <Button variant="outline" onClick={() => {
                              setSearchQuery("");
                              setCategoryFilter("all");
                              setActiveTabId("all");
                            }}>
                              <RefreshCw className="h-4 w-4 mr-2" /> Clear Filters
                            </Button>
                            <Button onClick={() => setNewWordDialogOpen(true)}>
                              <Plus className="h-4 w-4 mr-2" /> Add New Word
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default VocabularyBuilder;
