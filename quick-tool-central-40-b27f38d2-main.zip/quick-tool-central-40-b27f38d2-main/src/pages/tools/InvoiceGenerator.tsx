import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { format } from "date-fns";
import ToolLayout from "@/components/tools/ToolLayout";
import { formatCurrency } from "@/lib/utils";
import BusinessInfoForm from "@/components/invoice/BusinessInfoForm";
import ClientInfoForm from "@/components/invoice/ClientInfoForm";
import InvoiceItems from "@/components/invoice/InvoiceItems";
import InvoiceDetails from "@/components/invoice/InvoiceDetails";
import InvoicePreview from "@/components/invoice/InvoicePreview";
import InvoiceActions from "@/components/invoice/InvoiceActions";
import InvoiceSummary from "@/components/invoice/InvoiceSummary";
import InvoiceFAQ from "@/components/invoice/InvoiceFAQ";
import RelatedTools from "@/components/invoice/RelatedTools";
import { FileText } from "lucide-react";

const CURRENCY_SYMBOLS = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  CAD: "C$",
  AUD: "A$",
  INR: "₹",
};

const INVOICE_TEMPLATES = [
  { id: "classic", name: "Classic" },
  { id: "modern", name: "Modern" },
  { id: "minimal", name: "Minimal" },
  { id: "professional", name: "Professional" },
  { id: "creative", name: "Creative" },
];

const TAX_OPTIONS = [
  { id: "none", name: "No Tax", rate: 0 },
  { id: "vat", name: "VAT (20%)", rate: 20 },
  { id: "sales", name: "Sales Tax (10%)", rate: 10 },
  { id: "gst", name: "GST (7%)", rate: 7 },
  { id: "custom", name: "Custom Tax Rate", rate: null },
];

const InvoiceGenerator = () => {
  const [businessInfo, setBusinessInfo] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    phone: "",
    email: "",
    website: "",
    taxId: "",
    logo: null,
  });

  const [clientInfo, setClientInfo] = useState({
    name: "",
    contactPerson: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    phone: "",
    email: "",
  });

  const [invoiceDetails, setInvoiceDetails] = useState({
    invoiceNumber: `INV-${Date.now().toString().substring(9)}`,
    date: format(new Date(), "yyyy-MM-dd"),
    dueDate: format(new Date(new Date().setDate(new Date().getDate() + 30)), "yyyy-MM-dd"),
    currency: "USD",
    taxType: "none",
    customTaxRate: 0,
    notes: "",
    terms: "Payment is due within 30 days of issue.",
    template: "classic",
  });

  const [items, setItems] = useState([
    { id: 1, description: "", quantity: 1, price: 0, total: 0 },
  ]);

  const [previewMode, setPreviewMode] = useState(false);

  const handleBusinessInfoChange = (e) => {
    const { name, value, files }  = e.target;
    
    if (name === "logo" && files && files[0]) {
      const file = files[0];
      const reader = new FileReader();
      
      reader.onloadend = () => {
        setBusinessInfo(prev => ({ ...prev, logo: reader.result }));
      };
      
      reader.readAsDataURL(file);
    } else {
      setBusinessInfo(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleClientInfoChange = (e) => {
    const { name, value } = e.target;
    setClientInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleInvoiceDetailsChange = (e) => {
    const { name, value } = e.target;
    setInvoiceDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name, value) => {
    setInvoiceDetails(prev => ({ ...prev, [name]: value }));
  };

  const addItem = () => {
    setItems(prev => [
      ...prev, 
      { id: Date.now(), description: "", quantity: 1, price: 0, total: 0 }
    ]);
  };

  const removeItem = (id) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const handleItemChange = (id: number, field: string, value: string | number) => {
    setItems(prev =>
      prev.map(item => {
        if (item.id === id) {
          const updatedItem = { ...item, [field]: value };

          if (field === "quantity" || field === "price") {
            const quantityNum = Number(field === "quantity" ? value : item.quantity);
            const priceNum = Number(field === "price" ? value : item.price);
            updatedItem.quantity = quantityNum;
            updatedItem.price = priceNum;
            updatedItem.total = quantityNum * priceNum;
          }

          return updatedItem;
        }
        return item;
      })
    );
  };

  const calculateTotals = () => {
    const subtotal = items.reduce((sum, item) => sum + (item.total || 0), 0);
    
    let taxRate = 0;
    if (invoiceDetails.taxType !== "none") {
      const selectedTax = TAX_OPTIONS.find(tax => tax.id === invoiceDetails.taxType);
      taxRate = selectedTax && selectedTax.rate !== null 
        ? selectedTax.rate 
        : invoiceDetails.customTaxRate || 0;
    }
    
    const taxAmount = subtotal * (taxRate / 100);
    const total = subtotal + taxAmount;
    
    return { subtotal, taxRate, taxAmount, total };
  };

  const formatInvoiceCurrency = (amount: number | string): string => {
    const symbol = CURRENCY_SYMBOLS[invoiceDetails.currency] || "$";
    return formatCurrency(String(amount), symbol);
  };

  const generateInvoice = () => {
    toast.success("Invoice generated successfully! Download starting...");
    setTimeout(() => {
      toast.info("In a production environment, this would download a PDF file.");
    }, 1500);
  };

  const togglePreviewMode = () => {
    setPreviewMode(!previewMode);
  };

  const { subtotal, taxRate, taxAmount, total } = calculateTotals();
  
  return (
    <ToolLayout
      title="Invoice Generator"
      description="Create and customize professional invoices for your business"
      helpText="Fill in your business and client details, add invoice items, and generate a professional invoice in seconds."
    >
      <Helmet>
        <title>Free Invoice Generator | Create Professional Invoices Online | MultiToolSet</title>
        <meta
          name="description"
          content="Create professional invoices for free with our easy-to-use invoice generator. Customize your business details, add line items, calculate taxes, and download as PDF."
        />
        <meta
          name="keywords"
          content="invoice generator, free invoice maker, invoice template, billing software, invoice PDF, business invoice, professional invoice, freelancer invoice"
        />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Invoice Generator",
              "applicationCategory": "BusinessApplication",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "operatingSystem": "Any",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "189"
              }
            }
          `}
        </script>
      </Helmet>

      <div className="flex flex-col-reverse lg:flex-row gap-8">
        {!previewMode ? (
          <div className="w-full lg:w-2/3 space-y-6">
            <Tabs defaultValue="business" className="w-full">
              <TabsList className="grid grid-cols-4 mb-4">
                <TabsTrigger value="business">Business</TabsTrigger>
                <TabsTrigger value="client">Client</TabsTrigger>
                <TabsTrigger value="items">Items</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              <TabsContent value="business">
                <BusinessInfoForm 
                  businessInfo={businessInfo}
                  onBusinessInfoChange={handleBusinessInfoChange}
                />
              </TabsContent>

              <TabsContent value="client">
                <ClientInfoForm
                  clientInfo={clientInfo}
                  onClientInfoChange={handleClientInfoChange}
                />
              </TabsContent>

              <TabsContent value="items">
                <InvoiceItems
                  items={items}
                  onItemChange={handleItemChange}
                  onAddItem={addItem}
                  onRemoveItem={removeItem}
                  formatCurrency={formatInvoiceCurrency}
                  currencySymbol={CURRENCY_SYMBOLS[invoiceDetails.currency] || "$"}
                />
              </TabsContent>

              <TabsContent value="settings">
                <InvoiceDetails
                  invoiceDetails={invoiceDetails}
                  onInvoiceDetailsChange={handleInvoiceDetailsChange}
                  onSelectChange={handleSelectChange}
                  taxOptions={TAX_OPTIONS}
                  templates={INVOICE_TEMPLATES}
                />
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="w-full lg:w-2/3">
            <InvoicePreview
              businessInfo={businessInfo}
              clientInfo={clientInfo}
              items={items}
              invoiceDetails={invoiceDetails}
              subtotal={subtotal}
              taxRate={taxRate}
              taxAmount={taxAmount}
              total={total}
              formatCurrency={formatInvoiceCurrency}
            />
          </div>
        )}

        <div className="w-full lg:w-1/3">
          <div className="sticky top-6 space-y-6">
            <InvoiceActions
              previewMode={previewMode}
              onTogglePreview={togglePreviewMode}
              onGenerateInvoice={generateInvoice}
            />
            
            <InvoiceSummary
              invoiceNumber={invoiceDetails.invoiceNumber}
              dueDate={invoiceDetails.dueDate}
              total={total}
              formatCurrency={formatInvoiceCurrency}
            />
            
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 mb-2 flex items-center">
                <FileText className="h-4 w-4 mr-2" />
                Invoice Tips
              </h3>
              <ul className="text-sm text-blue-700 space-y-2 list-disc pl-5">
                <li>Include clear payment terms and due dates</li>
                <li>Number your invoices sequentially</li>
                <li>Be specific in your item descriptions</li>
                <li>Include your tax ID or business registration</li>
                <li>Send invoices promptly after services are rendered</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Separator className="my-8" />

      <InvoiceFAQ />
      <RelatedTools />
    </ToolLayout>
  );
};

export default InvoiceGenerator;
