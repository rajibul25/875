
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Helmet } from "react-helmet";
import { PieChart, AppleIcon } from "lucide-react";

const MacroCalculator = () => {
  const [gender, setGender] = useState<"male" | "female">("male");
  const [age, setAge] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [height, setHeight] = useState<string>("");
  const [activityLevel, setActivityLevel] = useState<string>("moderate");
  const [goal, setGoal] = useState<string>("maintain");
  const [unitSystem, setUnitSystem] = useState<"metric" | "imperial">("metric");
  const [results, setResults] = useState<{
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const activityLevels = {
    sedentary: { label: "Sedentary (little or no exercise)", factor: 1.2 },
    light: { label: "Lightly active (light exercise 1-3 days/week)", factor: 1.375 },
    moderate: { label: "Moderately active (moderate exercise 3-5 days/week)", factor: 1.55 },
    active: { label: "Very active (hard exercise 6-7 days/week)", factor: 1.725 },
    extreme: { label: "Extremely active (very hard exercise, physical job or training twice a day)", factor: 1.9 }
  };

  const goals = {
    lose: { label: "Lose weight (20% deficit)", factor: 0.8 },
    maintain: { label: "Maintain weight", factor: 1 },
    gain: { label: "Gain weight (20% surplus)", factor: 1.2 }
  };

  const calculateBMR = () => {
    // Parse inputs
    const ageValue = parseInt(age);
    let weightValue = parseFloat(weight);
    let heightValue = parseFloat(height);
    
    // Convert imperial to metric if needed for calculation
    if (unitSystem === "imperial") {
      // Convert pounds to kg
      weightValue = weightValue * 0.453592;
      // Convert inches to cm
      heightValue = heightValue * 2.54;
    }
    
    // Calculate BMR using Mifflin-St Jeor Equation
    let bmr;
    if (gender === "male") {
      bmr = 10 * weightValue + 6.25 * heightValue - 5 * ageValue + 5;
    } else {
      bmr = 10 * weightValue + 6.25 * heightValue - 5 * ageValue - 161;
    }
    
    return bmr;
  };

  const calculateMacros = () => {
    try {
      setIsCalculating(true);
      
      // Validate inputs
      if (!age || !weight || !height) {
        toast.error("Please fill in all required fields.");
        setIsCalculating(false);
        return;
      }
      
      const ageValue = parseInt(age);
      const weightValue = parseFloat(weight);
      const heightValue = parseFloat(height);
      
      if (ageValue < 15 || ageValue > 80) {
        toast.error("Please enter a valid age between 15 and 80.");
        setIsCalculating(false);
        return;
      }
      
      if ((unitSystem === "metric" && weightValue < 40) || 
          (unitSystem === "imperial" && weightValue < 88)) {
        toast.error("Please enter a valid weight.");
        setIsCalculating(false);
        return;
      }
      
      if ((unitSystem === "metric" && heightValue < 130) || 
          (unitSystem === "imperial" && heightValue < 50)) {
        toast.error("Please enter a valid height.");
        setIsCalculating(false);
        return;
      }
      
      // Calculate BMR
      const bmr = calculateBMR();
      
      // Calculate TDEE (Total Daily Energy Expenditure)
      const activityFactor = activityLevels[activityLevel as keyof typeof activityLevels].factor;
      const tdee = bmr * activityFactor;
      
      // Apply goal adjustment
      const goalFactor = goals[goal as keyof typeof goals].factor;
      const calorieTarget = Math.round(tdee * goalFactor);
      
      // Calculate macros
      let proteinPercentage, carbPercentage, fatPercentage;
      
      // Different macro ratios based on goals
      if (goal === "lose") {
        proteinPercentage = 0.40; // 40% protein
        fatPercentage = 0.35; // 35% fat
        carbPercentage = 0.25; // 25% carbs
      } else if (goal === "gain") {
        proteinPercentage = 0.30; // 30% protein
        carbPercentage = 0.45; // 45% carbs
        fatPercentage = 0.25; // 25% fat
      } else {
        proteinPercentage = 0.30; // 30% protein
        carbPercentage = 0.40; // 40% carbs
        fatPercentage = 0.30; // 30% fat
      }
      
      // Calculate grams of each macro
      const proteinCalories = calorieTarget * proteinPercentage;
      const carbCalories = calorieTarget * carbPercentage;
      const fatCalories = calorieTarget * fatPercentage;
      
      // Convert calories to grams
      const proteinGrams = Math.round(proteinCalories / 4); // 4 calories per gram of protein
      const carbGrams = Math.round(carbCalories / 4); // 4 calories per gram of carbs
      const fatGrams = Math.round(fatCalories / 9); // 9 calories per gram of fat
      
      // Simulate a small delay for feedback
      setTimeout(() => {
        setResults({
          calories: calorieTarget,
          protein: proteinGrams,
          carbs: carbGrams,
          fats: fatGrams
        });
        setIsCalculating(false);
        toast.success("Macros calculated successfully!");
      }, 600);
      
    } catch (error) {
      setIsCalculating(false);
      toast.error("Error calculating macros. Please check your inputs.");
      console.error("Macro calculation error:", error);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setWeight("");
    setHeight("");
    setActivityLevel("moderate");
    setGoal("maintain");
    setResults(null);
  };

  return (
    <>
      <Helmet>
        <title>Macro Calculator | Calculate Your Macronutrient Needs | MultitoolSet</title>
        <meta name="description" content="Calculate your optimal macronutrient ratio for weight loss, maintenance, or muscle gain. Free online macro calculator for personalized nutrition plans." />
        <meta name="keywords" content="macro calculator, macronutrient calculator, protein calculator, carb calculator, fat calculator, nutrition calculator, diet macros" />
        <link rel="canonical" href="https://multitoolset.com/tools/macro-calculator" />
        <meta property="og:title" content="Macro Calculator | Calculate Your Macronutrient Needs" />
        <meta property="og:description" content="Calculate your optimal macronutrient ratio for weight loss, maintenance, or muscle gain." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/macro-calculator" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Macro Calculator | Calculate Your Macronutrient Needs" />
        <meta name="twitter:description" content="Calculate your optimal macronutrient ratio for weight loss, maintenance, or muscle gain." />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Macro Calculator",
              "description": "Calculate your optimal macronutrient ratio for weight loss, maintenance, or muscle gain.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What are macros and why are they important?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Macros (macronutrients) are the three main nutrients your body needs in large amounts: protein, carbohydrates, and fats. They provide energy (calories) and are essential for various bodily functions including muscle repair, hormone production, and energy regulation. Tracking macros can help optimize body composition and performance beyond just counting calories."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much protein do I need daily?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Protein needs vary based on your goals, but general guidelines suggest 0.8-1g of protein per pound of bodyweight for active individuals looking to build or maintain muscle mass. For weight loss, higher protein intakes (around 30-40% of total calories) may help preserve muscle mass and increase satiety."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Should I adjust my macros for different goals?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, different goals require different macro ratios. For weight loss, higher protein and moderate fat with lower carbs may work best. For muscle gain, moderate-to-high protein with higher carbs supports muscle growth and workout performance. For maintenance, a balanced approach of roughly equal proportions often works well. This calculator adjusts ratios automatically based on your selected goal."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
    
      <ToolLayout
        title="Macro Calculator"
        description="Calculate your optimal macronutrient ratio for weight loss, maintenance, or muscle gain. Free online macro calculator for personalized nutrition plans."
        helpText="Enter your details below to calculate your recommended daily calorie intake and macronutrient breakdown."
      >
        <div className="mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
        
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="calculate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculate">Calculate Macros</TabsTrigger>
                <TabsTrigger value="about">About Macros</TabsTrigger>
              </TabsList>
              
              <TabsContent value="calculate" className="space-y-6 pt-4">
                <div className="flex justify-end mb-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Label>Units:</Label>
                    <Select 
                      value={unitSystem} 
                      onValueChange={(value) => setUnitSystem(value as "metric" | "imperial")}
                    >
                      <SelectTrigger className="w-28">
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric</SelectItem>
                        <SelectItem value="imperial">Imperial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="gender" className="block mb-2">Gender</Label>
                    <RadioGroup 
                      defaultValue="male" 
                      value={gender}
                      onValueChange={(value) => setGender(value as "male" | "female")}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male">Male</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female">Female</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="15"
                      max="80"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="weight">
                      Weight ({unitSystem === "metric" ? "kg" : "lbs"})
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter your weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min={unitSystem === "metric" ? "40" : "88"}
                      step="0.1"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="height">
                      Height ({unitSystem === "metric" ? "cm" : "inches"})
                    </Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder={`Enter your height in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      min={unitSystem === "metric" ? "130" : "50"}
                      step="0.1"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="activityLevel" className="block mb-2">Activity Level</Label>
                    <Select 
                      value={activityLevel} 
                      onValueChange={setActivityLevel}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select activity level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">{activityLevels.sedentary.label}</SelectItem>
                        <SelectItem value="light">{activityLevels.light.label}</SelectItem>
                        <SelectItem value="moderate">{activityLevels.moderate.label}</SelectItem>
                        <SelectItem value="active">{activityLevels.active.label}</SelectItem>
                        <SelectItem value="extreme">{activityLevels.extreme.label}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="goal" className="block mb-2">Goal</Label>
                    <Select 
                      value={goal} 
                      onValueChange={setGoal}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your goal" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lose">{goals.lose.label}</SelectItem>
                        <SelectItem value="maintain">{goals.maintain.label}</SelectItem>
                        <SelectItem value="gain">{goals.gain.label}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={calculateMacros} 
                      className="flex-1"
                      disabled={isCalculating}
                    >
                      {isCalculating ? "Calculating..." : "Calculate Macros"}
                    </Button>
                    <Button variant="outline" onClick={resetCalculator}>Reset</Button>
                  </div>
                </div>
                
                {results && (
                  <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-900/50 dark:border-slate-800">
                    <h3 className="font-semibold text-lg mb-4">Your Daily Macros</h3>
                    
                    <div className="mb-6 text-center">
                      <p className="text-sm text-gray-600 dark:text-gray-400">Daily Calorie Target</p>
                      <p className="text-3xl font-bold">{results.calories} calories</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Protein ({Math.round(results.protein * 4 / results.calories * 100)}%)</span>
                          <span className="text-sm font-medium">{results.protein}g</span>
                        </div>
                        <Progress value={Math.round(results.protein * 4 / results.calories * 100)} className="h-2 bg-gray-200 dark:bg-gray-700" 
                          indicatorClassName="bg-red-500 dark:bg-red-600" />
                        <p className="text-xs text-gray-500 mt-1">{results.protein * 4} calories</p>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Carbs ({Math.round(results.carbs * 4 / results.calories * 100)}%)</span>
                          <span className="text-sm font-medium">{results.carbs}g</span>
                        </div>
                        <Progress value={Math.round(results.carbs * 4 / results.calories * 100)} className="h-2 bg-gray-200 dark:bg-gray-700"
                          indicatorClassName="bg-green-500 dark:bg-green-600" />
                        <p className="text-xs text-gray-500 mt-1">{results.carbs * 4} calories</p>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Fats ({Math.round(results.fats * 9 / results.calories * 100)}%)</span>
                          <span className="text-sm font-medium">{results.fats}g</span>
                        </div>
                        <Progress value={Math.round(results.fats * 9 / results.calories * 100)} className="h-2 bg-gray-200 dark:bg-gray-700"
                          indicatorClassName="bg-blue-500 dark:bg-blue-600" />
                        <p className="text-xs text-gray-500 mt-1">{results.fats * 9} calories</p>
                      </div>
                    </div>
                    
                    <div className="mt-6 grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="h-20 w-20 mx-auto rounded-full bg-red-100 flex items-center justify-center dark:bg-red-900/30">
                          <span className="text-xl font-bold text-red-500 dark:text-red-400">{Math.round(results.protein * 4 / results.calories * 100)}%</span>
                        </div>
                        <p className="mt-2 text-sm font-medium">Protein</p>
                      </div>
                      <div className="text-center">
                        <div className="h-20 w-20 mx-auto rounded-full bg-green-100 flex items-center justify-center dark:bg-green-900/30">
                          <span className="text-xl font-bold text-green-500 dark:text-green-400">{Math.round(results.carbs * 4 / results.calories * 100)}%</span>
                        </div>
                        <p className="mt-2 text-sm font-medium">Carbs</p>
                      </div>
                      <div className="text-center">
                        <div className="h-20 w-20 mx-auto rounded-full bg-blue-100 flex items-center justify-center dark:bg-blue-900/30">
                          <span className="text-xl font-bold text-blue-500 dark:text-blue-400">{Math.round(results.fats * 9 / results.calories * 100)}%</span>
                        </div>
                        <p className="mt-2 text-sm font-medium">Fats</p>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="about" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">What Are Macros?</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Macros, or macronutrients, are the three main nutrients your body needs in large amounts: protein, carbohydrates, and fats. Each macro provides energy (calories) and serves different functions in your body:
                  </p>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300 mt-2">
                    <li><strong>Protein (4 calories/gram):</strong> Builds and repairs tissues, supports immune function, and makes enzymes and hormones.</li>
                    <li><strong>Carbohydrates (4 calories/gram):</strong> Primary energy source, especially for the brain and during high-intensity exercise.</li>
                    <li><strong>Fats (9 calories/gram):</strong> Supports hormone production, vitamin absorption, and provides long-lasting energy.</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Why Track Macros?</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Tracking macros (instead of just calories) gives you more control over your body composition and can help you:
                  </p>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300 mt-2">
                    <li>Lose fat while preserving muscle mass</li>
                    <li>Gain muscle with minimal fat gain</li>
                    <li>Optimize athletic performance</li>
                    <li>Address specific health concerns</li>
                    <li>Create more flexible meal plans that fit your preferences</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Macro Recommendations by Goal</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full mt-2 border-collapse">
                      <thead>
                        <tr className="bg-slate-100 dark:bg-slate-800">
                          <th className="p-2 text-left border dark:border-slate-700">Goal</th>
                          <th className="p-2 text-left border dark:border-slate-700">Protein</th>
                          <th className="p-2 text-left border dark:border-slate-700">Carbs</th>
                          <th className="p-2 text-left border dark:border-slate-700">Fats</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Fat Loss</td>
                          <td className="p-2 border dark:border-slate-700">40%</td>
                          <td className="p-2 border dark:border-slate-700">25%</td>
                          <td className="p-2 border dark:border-slate-700">35%</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Maintenance</td>
                          <td className="p-2 border dark:border-slate-700">30%</td>
                          <td className="p-2 border dark:border-slate-700">40%</td>
                          <td className="p-2 border dark:border-slate-700">30%</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Muscle Gain</td>
                          <td className="p-2 border dark:border-slate-700">30%</td>
                          <td className="p-2 border dark:border-slate-700">45%</td>
                          <td className="p-2 border dark:border-slate-700">25%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Note: These are general guidelines. Individual needs may vary based on factors like activity level, body composition, and metabolic health.</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">How to Use This Calculator</h3>
                  <ol className="list-decimal ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li>Enter your personal details (gender, age, weight, height)</li>
                    <li>Select your activity level</li>
                    <li>Choose your goal (lose, maintain, or gain weight)</li>
                    <li>Click "Calculate Macros" to see your personalized recommendations</li>
                    <li>Use the results to plan your daily meals and track your intake</li>
                  </ol>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-6 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Bottom Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
        
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Using Your Macro Calculations</h2>
          <div className="space-y-4">
            <p className="text-gray-700 dark:text-gray-300">
              Once you have your macro targets, follow these steps to implement them into your daily routine:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
                <h3 className="font-semibold text-lg mb-2">Step 1: Plan Your Meals</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Distribute your macros across 3-5 meals per day. Focus on whole foods that provide a good balance of proteins, carbs, and fats.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
                <h3 className="font-semibold text-lg mb-2">Step 2: Track Your Intake</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Use a food tracking app to monitor your daily macro consumption. Adjust as needed to stay within your targets.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
                <h3 className="font-semibold text-lg mb-2">Step 3: Be Consistent</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Aim to hit your macro targets consistently for at least 2-4 weeks before evaluating results or making adjustments.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
                <h3 className="font-semibold text-lg mb-2">Step 4: Adjust As Needed</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Monitor your progress and adjust your macros if you're not seeing the desired results after 3-4 weeks.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/body-fat-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Body Fat Calculator</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Ideal Weight Calculator</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default MacroCalculator;
