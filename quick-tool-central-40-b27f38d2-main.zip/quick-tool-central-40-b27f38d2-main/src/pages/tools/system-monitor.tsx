
import { Cpu, HardDrive, Network, Activity, AlertTriangle, BarChart2, LineChart, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";
import BackButton from "@/components/BackButton";
import { Helmet } from "react-helmet";

const SystemMonitor = () => {
  // Example monitoring data (in a real app, this would come from an API)
  const systemStats = {
    cpu: 45,
    memory: 68,
    disk: 72,
    network: 25
  };

  return (
    <>
      <Helmet>
        <title>Advanced System Tools - Professional System Monitor & Diagnostics</title>
        <meta name="description" content="Real-time CPU, memory, disk, and network monitoring with Advanced System Tools. Professional diagnostics and optimization for IT professionals." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
        {/* Hero Section */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 animate-gradient" />
          <div className="container mx-auto px-4 py-16 relative z-10">
            <BackButton className="mb-8" />
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
                Advanced System Tools
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Powerful Utilities & Diagnostics for Power Users and IT Pros
              </p>
            </motion.div>

            {/* Live Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              <StatsCard 
                title="CPU Usage" 
                value={systemStats.cpu} 
                icon={<Cpu className="h-6 w-6 text-blue-400" />} 
              />
              <StatsCard 
                title="Memory Usage" 
                value={systemStats.memory} 
                icon={<Activity className="h-6 w-6 text-purple-400" />} 
              />
              <StatsCard 
                title="Disk Usage" 
                value={systemStats.disk} 
                icon={<HardDrive className="h-6 w-6 text-green-400" />} 
              />
              <StatsCard 
                title="Network" 
                value={systemStats.network} 
                icon={<Network className="h-6 w-6 text-orange-400" />} 
              />
            </div>

            {/* Features Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <FeatureCard 
                title="System Monitor"
                description="Real-time CPU, memory, disk, and network monitoring with live stats and usage alerts."
                icon={<BarChart2 className="h-8 w-8" />}
                isNew={true}
              />
              <FeatureCard 
                title="Disk Analyzer"
                description="Scan your drives, detect large or junk files, and optimize storage with advanced analysis."
                icon={<LineChart className="h-8 w-8" />}
              />
            </div>

            {/* Coming Soon Section */}
            <div className="text-center p-8 bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-xl backdrop-blur-sm border border-gray-700">
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-purple-400" />
              <h2 className="text-2xl font-bold mb-2">More Tools Coming Soon</h2>
              <p className="text-gray-400">
                We're working on additional professional utilities to enhance your system management capabilities.
              </p>
            </div>
          </div>
        </div>

        {/* Features Detail Section */}
        <section className="py-16 bg-gray-900/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              Professional-Grade Features
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <DetailCard 
                icon={<Zap className="h-6 w-6 text-yellow-400" />}
                title="Real-Time Monitoring"
                description="Monitor system performance metrics in real-time with millisecond accuracy."
              />
              <DetailCard 
                icon={<AlertTriangle className="h-6 w-6 text-red-400" />}
                title="Smart Alerts"
                description="Get instant notifications when system metrics exceed defined thresholds."
              />
              <DetailCard 
                icon={<Activity className="h-6 w-6 text-green-400" />}
                title="Performance Analysis"
                description="Detailed insights and recommendations for system optimization."
              />
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

const StatsCard = ({ title, value, icon }: { title: string; value: number; icon: React.ReactNode }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-sm border border-gray-700"
  >
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-lg font-semibold text-gray-300">{title}</h3>
      {icon}
    </div>
    <div className="flex items-end">
      <span className="text-3xl font-bold">{value}%</span>
      <div className="flex-1 ml-4">
        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${value}%` }}
            transition={{ duration: 1 }}
            className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
          />
        </div>
      </div>
    </div>
  </motion.div>
);

const FeatureCard = ({ title, description, icon, isNew }: { title: string; description: string; icon: React.ReactNode; isNew?: boolean }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="p-8 rounded-xl bg-gradient-to-br from-gray-800/50 to-gray-700/50 backdrop-blur-sm border border-gray-700 relative"
  >
    {isNew && (
      <span className="absolute top-4 right-4 px-3 py-1 bg-green-500/20 text-green-400 text-sm rounded-full border border-green-500/30">
        New
      </span>
    )}
    <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-lg inline-block mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <p className="text-gray-400">{description}</p>
  </motion.div>
);

const DetailCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-sm border border-gray-700"
  >
    <div className="p-3 bg-gray-700/50 rounded-lg inline-block mb-4">
      {icon}
    </div>
    <h3 className="text-lg font-bold mb-2">{title}</h3>
    <p className="text-gray-400">{description}</p>
  </motion.div>
);

export default SystemMonitor;
