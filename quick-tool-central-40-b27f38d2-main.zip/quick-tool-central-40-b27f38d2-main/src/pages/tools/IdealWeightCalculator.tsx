
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Helmet } from "react-helmet";
import { ChevronRight, Scale, Ruler } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const IdealWeightCalculator = () => {
  const [gender, setGender] = useState<"male" | "female">("male");
  const [height, setHeight] = useState<number>(170);
  const [heightUnit, setHeightUnit] = useState<"cm" | "ft">("cm");
  const [heightFt, setHeightFt] = useState<number>(5);
  const [heightIn, setHeightIn] = useState<number>(10);
  const [frame, setFrame] = useState<"small" | "medium" | "large">("medium");
  const [idealWeight, setIdealWeight] = useState<{
    devine: number;
    robinson: number;
    miller: number;
    hamwi: number;
    broca: number;
    average: number;
  } | null>(null);

  const calculateIdealWeight = () => {
    let heightInCm: number;
    let heightInInches: number;
    
    if (heightUnit === "cm") {
      heightInCm = height;
      heightInInches = height / 2.54;
    } else {
      heightInCm = (heightFt * 30.48) + (heightIn * 2.54);
      heightInInches = heightFt * 12 + heightIn;
    }
    
    if (heightInCm < 100 || heightInCm > 250) {
      return; // Height outside reasonable range
    }
    
    // Frame size adjustment factors
    const frameAdjustment = {
      small: 0.9,
      medium: 1.0,
      large: 1.1
    };
    
    // Different formulas for ideal weight calculation
    let devine, robinson, miller, hamwi, broca;
    
    if (gender === "male") {
      devine = 50 + 2.3 * (heightInInches - 60);
      robinson = 52 + 1.9 * (heightInInches - 60);
      miller = 56.2 + 1.41 * (heightInInches - 60);
      hamwi = 48 + 2.7 * (heightInInches - 60);
      broca = (heightInCm - 100) - ((heightInCm - 100) * 0.1);
    } else {
      devine = 45.5 + 2.3 * (heightInInches - 60);
      robinson = 49 + 1.7 * (heightInInches - 60);
      miller = 53.1 + 1.36 * (heightInInches - 60);
      hamwi = 45.5 + 2.2 * (heightInInches - 60);
      broca = (heightInCm - 100) - ((heightInCm - 100) * 0.15);
    }
    
    // Adjust for frame size
    devine *= frameAdjustment[frame];
    robinson *= frameAdjustment[frame];
    miller *= frameAdjustment[frame];
    hamwi *= frameAdjustment[frame];
    broca *= frameAdjustment[frame];
    
    // Calculate average
    const average = (devine + robinson + miller + hamwi + broca) / 5;
    
    setIdealWeight({
      devine: parseFloat(devine.toFixed(1)),
      robinson: parseFloat(robinson.toFixed(1)),
      miller: parseFloat(miller.toFixed(1)),
      hamwi: parseFloat(hamwi.toFixed(1)),
      broca: parseFloat(broca.toFixed(1)),
      average: parseFloat(average.toFixed(1))
    });
  };

  const getWeightRange = () => {
    if (!idealWeight) return null;
    
    const lower = parseFloat((idealWeight.average * 0.90).toFixed(1));
    const upper = parseFloat((idealWeight.average * 1.10).toFixed(1));
    
    return { lower, upper };
  };
  
  const convertHeightFtToInches = () => {
    if (heightFt && heightIn) {
      return heightFt * 12 + heightIn;
    }
    return 0;
  };
  
  const handleHeightUnitChange = (unit: "cm" | "ft") => {
    setHeightUnit(unit);
    
    if (unit === "cm" && heightFt && heightIn) {
      // Convert from ft/in to cm
      const totalInches = convertHeightFtToInches();
      setHeight(Math.round(totalInches * 2.54));
    } else if (unit === "ft" && height) {
      // Convert from cm to ft/in
      const totalInches = height / 2.54;
      setHeightFt(Math.floor(totalInches / 12));
      setHeightIn(Math.round(totalInches % 12));
    }
  };

  return (
    <>
      <Helmet>
        <title>Ideal Weight Calculator | Find Your Healthy Weight Range | MultitoolSet</title>
        <meta name="description" content="Calculate your ideal weight range based on height, gender, and body frame using multiple formulas. Compare results from Devine, Robinson, Miller, and more." />
        <meta name="keywords" content="ideal weight calculator, healthy weight range, ideal body weight, weight calculator, IBW calculator" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How is ideal weight calculated?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Ideal weight is calculated using various formulas like Devine, Robinson, Miller, Hamwi, and Broca. Each formula uses your height and gender to determine a healthy weight range. We provide results from all these formulas and an average for comparison."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is a healthy weight range?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A healthy weight range is typically within 10% of your calculated ideal weight. Keep in mind that ideal weight calculations are estimates and don't account for factors like muscle mass, bone density, and body composition."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How does body frame affect ideal weight?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Body frame size (small, medium, or large) affects ideal weight calculations. People with larger frames typically have higher ideal weights due to heavier bone structure, while those with smaller frames have lower ideal weights."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <ToolLayout
        title="Ideal Weight Calculator"
        description="Calculate your ideal weight based on height, gender, and body frame"
        helpText="This calculator uses multiple formulas to estimate your ideal weight range based on your height, gender, and body frame size."
      >
        <div className="space-y-8">
          <Tabs defaultValue="calculator">
            <TabsList className="mb-4">
              <TabsTrigger value="calculator">Calculator</TabsTrigger>
              <TabsTrigger value="methods">Calculation Methods</TabsTrigger>
            </TabsList>
            
            <TabsContent value="calculator" className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <RadioGroup
                    defaultValue={gender}
                    onValueChange={(value) => setGender(value as "male" | "female")}
                    className="flex space-x-4 mt-1"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female">Female</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div>
                  <Label>Height</Label>
                  <div className="flex space-x-4 mt-1">
                    <Button
                      type="button"
                      variant={heightUnit === "cm" ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleHeightUnitChange("cm")}
                    >
                      Centimeters
                    </Button>
                    <Button
                      type="button"
                      variant={heightUnit === "ft" ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleHeightUnitChange("ft")}
                    >
                      Feet & Inches
                    </Button>
                  </div>
                </div>
                
                {heightUnit === "cm" ? (
                  <div>
                    <Label htmlFor="height-cm">Height (cm)</Label>
                    <Input
                      id="height-cm"
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(parseInt(e.target.value) || 0)}
                      min={100}
                      max={250}
                      className="mt-1"
                    />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="height-ft">Feet</Label>
                      <Input
                        id="height-ft"
                        type="number"
                        value={heightFt}
                        onChange={(e) => setHeightFt(parseInt(e.target.value) || 0)}
                        min={3}
                        max={8}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="height-in">Inches</Label>
                      <Input
                        id="height-in"
                        type="number"
                        value={heightIn}
                        onChange={(e) => setHeightIn(parseInt(e.target.value) || 0)}
                        min={0}
                        max={11}
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
                
                <div>
                  <Label htmlFor="frame">Body Frame</Label>
                  <RadioGroup
                    defaultValue={frame}
                    onValueChange={(value) => setFrame(value as "small" | "medium" | "large")}
                    className="flex space-x-4 mt-1"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="small" id="small" />
                      <Label htmlFor="small">Small</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium">Medium</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="large" id="large" />
                      <Label htmlFor="large">Large</Label>
                    </div>
                  </RadioGroup>
                  <p className="text-xs text-gray-500 mt-1">
                    Measure your wrist circumference or elbow breadth to determine your frame size.
                  </p>
                </div>
                
                <Button onClick={calculateIdealWeight} className="w-full">
                  Calculate Ideal Weight <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              {idealWeight && (
                <div className="mt-6 space-y-6">
                  <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="inline-block bg-green-100 dark:bg-green-800/30 p-3 rounded-full mb-4">
                          <Scale className="h-8 w-8 text-green-600 dark:text-green-400" />
                        </div>
                        <h3 className="text-xl font-bold text-green-800 dark:text-green-300 mb-2">Your Ideal Weight</h3>
                        <p className="text-3xl font-bold">{idealWeight.average} kg</p>
                        {getWeightRange() && (
                          <p className="text-lg mt-2">
                            Healthy range: {getWeightRange()?.lower} - {getWeightRange()?.upper} kg
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div>
                    <h3 className="text-xl font-bold mb-4">Results by Formula</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Devine Formula</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.devine} kg</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Robinson Formula</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.robinson} kg</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Miller Formula</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.miller} kg</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Hamwi Formula</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.hamwi} kg</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Broca Formula</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.broca} kg</p>
                        </CardContent>
                      </Card>
                      <Card className="bg-blue-50 dark:bg-blue-900/20">
                        <CardContent className="pt-6">
                          <h4 className="font-bold text-center">Average</h4>
                          <p className="text-center text-2xl mt-2">{idealWeight.average} kg</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="methods" className="space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-4">About Ideal Weight Calculation</h3>
                <p className="mb-4">
                  Ideal weight calculations are estimates based on your height, gender, and frame size. 
                  Different formulas produce different results, as they were developed in different contexts and for different purposes.
                </p>
                
                <div className="space-y-4 mt-6">
                  <div>
                    <h4 className="font-semibold text-lg">Devine Formula (1974)</h4>
                    <p className="text-gray-700 dark:text-gray-300">
                      Men: 50 kg + 2.3 kg for each inch over 5 feet<br />
                      Women: 45.5 kg + 2.3 kg for each inch over 5 feet
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-lg">Robinson Formula (1983)</h4>
                    <p className="text-gray-700 dark:text-gray-300">
                      Men: 52 kg + 1.9 kg for each inch over 5 feet<br />
                      Women: 49 kg + 1.7 kg for each inch over 5 feet
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-lg">Miller Formula (1983)</h4>
                    <p className="text-gray-700 dark:text-gray-300">
                      Men: 56.2 kg + 1.41 kg for each inch over 5 feet<br />
                      Women: 53.1 kg + 1.36 kg for each inch over 5 feet
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-lg">Hamwi Formula (1964)</h4>
                    <p className="text-gray-700 dark:text-gray-300">
                      Men: 48 kg + 2.7 kg for each inch over 5 feet<br />
                      Women: 45.5 kg + 2.2 kg for each inch over 5 feet
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-lg">Broca Formula (1871)</h4>
                    <p className="text-gray-700 dark:text-gray-300">
                      Men: (Height in cm - 100) - ((Height in cm - 100) × 0.1)<br />
                      Women: (Height in cm - 100) - ((Height in cm - 100) × 0.15)
                    </p>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold text-lg">Body Frame Size</h4>
                  <p className="text-gray-700 dark:text-gray-300 mb-2">
                    Body frame size affects ideal weight calculations. You can determine your frame size by measuring your wrist circumference or elbow breadth:
                  </p>
                  
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center">
                      <span className="w-24 font-medium">Small Frame:</span>
                      <span>Wrist size less than 6.5" (men) or 5.5" (women)</span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-24 font-medium">Medium Frame:</span>
                      <span>Wrist size 6.5-7.5" (men) or 5.5-6.5" (women)</span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-24 font-medium">Large Frame:</span>
                      <span>Wrist size more than 7.5" (men) or 6.5" (women)</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Select your gender (male or female).</li>
              <li>Enter your height in centimeters or feet and inches.</li>
              <li>Select your body frame size (small, medium, or large).</li>
              <li>Click "Calculate Ideal Weight" to see your results.</li>
              <li>View your ideal weight according to various formulas and the average.</li>
            </ol>
          </div>
          
          <div className="mt-6">
            <h2 className="text-2xl font-bold mb-4">FAQs</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">How is ideal weight calculated?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Ideal weight is calculated using various formulas like Devine, Robinson, Miller, Hamwi, and Broca. Each formula uses your height and gender to determine a healthy weight range. We provide results from all these formulas and an average for comparison.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">What is a healthy weight range?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  A healthy weight range is typically within 10% of your calculated ideal weight. Keep in mind that ideal weight calculations are estimates and don't account for factors like muscle mass, bone density, and body composition.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">How does body frame affect ideal weight?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Body frame size (small, medium, or large) affects ideal weight calculations. People with larger frames typically have higher ideal weights due to heavier bone structure, while those with smaller frames have lower ideal weights.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/body-fat-calculator" className="text-blue-600 hover:underline">Body Fat Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/macro-calculator" className="text-blue-600 hover:underline">Macro Calculator</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default IdealWeightCalculator;
