
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { Helmet } from "react-helmet";
import { HeartIcon } from "@/components/icons/ToolIcons";

const HeartRateCalculator = () => {
  const [age, setAge] = useState<string>("");
  const [restingHeartRate, setRestingHeartRate] = useState<string>("");
  const [method, setMethod] = useState<string>("karvonen");
  const [results, setResults] = useState<{
    maxHR: number;
    zones: Array<{ name: string; min: number; max: number; description: string; color: string }>;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateHeartRateZones = () => {
    try {
      setIsCalculating(true);
      
      // Convert inputs to numbers
      const ageValue = parseInt(age);
      const restingHRValue = method === "karvonen" ? parseInt(restingHeartRate) : 0;
      
      // Validate inputs
      if (isNaN(ageValue) || ageValue <= 0 || ageValue > 120) {
        toast.error("Please enter a valid age between 1 and 120.");
        setIsCalculating(false);
        return;
      }
      
      if (method === "karvonen" && (isNaN(restingHRValue) || restingHRValue <= 30 || restingHRValue >= 100)) {
        toast.error("Please enter a valid resting heart rate between 30 and 100 bpm.");
        setIsCalculating(false);
        return;
      }
      
      // Calculate max heart rate using different formulas
      let maxHR;
      
      // Tanaka formula: 208 - (0.7 * age)
      maxHR = Math.round(208 - (0.7 * ageValue));
      
      // Define heart rate reserve (HRR) for Karvonen method
      const hrr = maxHR - restingHRValue;
      
      // Define heart rate zones
      const zones = [
        {
          name: "Zone 1 - Recovery",
          min: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.5)) : Math.round(maxHR * 0.5),
          max: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.6)) : Math.round(maxHR * 0.6),
          description: "Very easy, active recovery, improves basic endurance and fat burning",
          color: "blue"
        },
        {
          name: "Zone 2 - Aerobic",
          min: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.6)) : Math.round(maxHR * 0.6),
          max: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.7)) : Math.round(maxHR * 0.7),
          description: "Light intensity, improves general endurance, long slow distance training",
          color: "green"
        },
        {
          name: "Zone 3 - Tempo",
          min: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.7)) : Math.round(maxHR * 0.7),
          max: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.8)) : Math.round(maxHR * 0.8),
          description: "Moderate intensity, improves efficiency and aerobic capacity",
          color: "yellow"
        },
        {
          name: "Zone 4 - Threshold",
          min: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.8)) : Math.round(maxHR * 0.8),
          max: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.9)) : Math.round(maxHR * 0.9),
          description: "Hard intensity, increases maximum performance and speed",
          color: "orange"
        },
        {
          name: "Zone 5 - Maximum",
          min: method === "karvonen" ? Math.round(restingHRValue + (hrr * 0.9)) : Math.round(maxHR * 0.9),
          max: maxHR,
          description: "Very hard intensity, develops maximum performance and speed, short intervals",
          color: "red"
        }
      ];
      
      // Simulate a small delay for feedback
      setTimeout(() => {
        setResults({
          maxHR,
          zones
        });
        setIsCalculating(false);
        toast.success("Heart rate zones calculated successfully!");
      }, 600);
    } catch (error) {
      setIsCalculating(false);
      toast.error("Error calculating heart rate zones. Please check your inputs.");
      console.error("Heart rate calculation error:", error);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setRestingHeartRate("");
    setMethod("karvonen");
    setResults(null);
  };

  const getZoneColor = (zone: string) => {
    switch (zone) {
      case "blue": return "bg-blue-500";
      case "green": return "bg-green-500";
      case "yellow": return "bg-yellow-500";
      case "orange": return "bg-orange-500";
      case "red": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <>
      <Helmet>
        <title>Heart Rate Calculator | Find Your Target Heart Rate Zones | MultitoolSet</title>
        <meta name="description" content="Calculate your maximum heart rate and target heart rate zones with our free online heart rate calculator. Optimize your workouts with personalized heart rate training zones." />
        <meta name="keywords" content="heart rate calculator, heart rate zones, target heart rate, maximum heart rate, karvonen method, heart rate reserve, cardio training zones" />
        <link rel="canonical" href="https://multitoolset.com/tools/heart-rate-calculator" />
        <meta property="og:title" content="Heart Rate Calculator | Find Your Target Heart Rate Zones" />
        <meta property="og:description" content="Calculate your maximum heart rate and target heart rate zones to optimize your workouts and cardio training." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/heart-rate-calculator" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Heart Rate Calculator | Find Your Target Heart Rate Zones" />
        <meta name="twitter:description" content="Calculate your maximum heart rate and target heart rate zones to optimize your workouts and cardio training." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Heart Rate Calculator",
              "description": "Calculate your maximum heart rate and target heart rate zones to optimize your workouts and cardio training.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What are heart rate training zones?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Heart rate training zones are ranges of heart rates, expressed as percentages of your maximum heart rate, that correspond to different exercise intensities. Typically, there are five zones ranging from very light activity (Zone 1) to maximum effort (Zone 5). Training in different zones provides different physiological benefits."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How do I find my maximum heart rate?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "While the most accurate way to determine your maximum heart rate is through laboratory testing, you can estimate it using age-based formulas. This calculator uses the Tanaka formula: 208 - (0.7 × age), which is considered more accurate than the traditional 220 - age formula."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is the Karvonen method?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "The Karvonen method calculates target heart rate zones using heart rate reserve (HRR), which is the difference between your maximum heart rate and resting heart rate. This method provides more personalized training zones because it accounts for individual fitness levels through the resting heart rate."
                  }
                }
              ]
            }
          `}
        </script>
        <meta name="robots" content="index, follow" />
      </Helmet>
    
      <ToolLayout
        title="Heart Rate Calculator"
        description="Calculate your maximum heart rate and target heart rate zones to optimize your workouts and cardio training."
        helpText="Enter your age and resting heart rate to calculate your maximum heart rate and personalized heart rate training zones."
      >
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="calculate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculate">Calculate Zones</TabsTrigger>
                <TabsTrigger value="about">About Heart Rate</TabsTrigger>
              </TabsList>
              
              <TabsContent value="calculate" className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="1"
                      max="120"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="method">Calculation Method</Label>
                    <Select
                      value={method}
                      onValueChange={setMethod}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select calculation method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="karvonen">Karvonen Method (with Resting HR)</SelectItem>
                        <SelectItem value="percentage">Percentage of Max HR</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {method === "karvonen" && (
                    <div>
                      <Label htmlFor="restingHeartRate">Resting Heart Rate (bpm)</Label>
                      <Input
                        id="restingHeartRate"
                        type="number"
                        placeholder="Enter your resting heart rate"
                        value={restingHeartRate}
                        onChange={(e) => setRestingHeartRate(e.target.value)}
                        min="30"
                        max="100"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Measure your heart rate when you first wake up, before getting out of bed.
                      </p>
                    </div>
                  )}
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={calculateHeartRateZones} 
                      className="flex-1"
                      disabled={isCalculating}
                    >
                      {isCalculating ? "Calculating..." : "Calculate Heart Rate Zones"}
                    </Button>
                    <Button variant="outline" onClick={resetCalculator}>Reset</Button>
                  </div>
                  
                  {results && (
                    <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-900/50 dark:border-slate-800">
                      <h3 className="font-semibold text-lg mb-2">Your Results</h3>
                      
                      <div className="mb-4">
                        <p className="text-sm font-medium">Estimated Maximum Heart Rate</p>
                        <p className="text-2xl font-bold mb-1">{results.maxHR} <span className="text-sm font-normal">bpm</span></p>
                        <p className="text-xs text-gray-500">Based on Tanaka formula: 208 - (0.7 × age)</p>
                      </div>
                      
                      <div className="space-y-4">
                        <h4 className="font-medium">Heart Rate Training Zones</h4>
                        
                        {results.zones.map((zone, index) => (
                          <div key={index} className="space-y-1">
                            <div className="flex justify-between">
                              <span className="text-sm font-medium">{zone.name}</span>
                              <span className="text-sm font-medium">{zone.min} - {zone.max} bpm</span>
                            </div>
                            <Progress 
                              value={(index + 1) * 20} 
                              className="h-2" 
                              indicatorClassName={getZoneColor(zone.color)}
                            />
                            <p className="text-xs text-gray-500">{zone.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="about" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">What are Heart Rate Zones?</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Heart rate training zones are ranges of heart rates, expressed as percentages of your maximum heart rate, that correspond to different exercise intensities. Training in different zones provides specific physiological benefits and adaptations.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Understanding the 5 Heart Rate Zones</h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded border dark:bg-blue-900/20 dark:border-blue-800/30">
                      <h4 className="font-medium text-blue-700 dark:text-blue-400">Zone 1: Recovery (50-60%)</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">Very light intensity exercise. Improves overall health, helps with recovery, and burns fat. Suitable for warm-ups, cool-downs, and recovery days.</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded border dark:bg-green-900/20 dark:border-green-800/30">
                      <h4 className="font-medium text-green-700 dark:text-green-400">Zone 2: Aerobic (60-70%)</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">Light intensity exercise. Builds aerobic endurance and fat-burning capacity. Ideal for longer, steady-state workouts.</p>
                    </div>
                    <div className="p-3 bg-yellow-50 rounded border dark:bg-yellow-900/20 dark:border-yellow-800/30">
                      <h4 className="font-medium text-yellow-700 dark:text-yellow-400">Zone 3: Tempo (70-80%)</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">Moderate intensity exercise. Improves aerobic capacity and efficiency. Good for tempo workouts and aerobic conditioning.</p>
                    </div>
                    <div className="p-3 bg-orange-50 rounded border dark:bg-orange-900/20 dark:border-orange-800/30">
                      <h4 className="font-medium text-orange-700 dark:text-orange-400">Zone 4: Threshold (80-90%)</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">Hard intensity exercise. Increases lactate threshold and maximal performance. Used for interval training and race pace work.</p>
                    </div>
                    <div className="p-3 bg-red-50 rounded border dark:bg-red-900/20 dark:border-red-800/30">
                      <h4 className="font-medium text-red-700 dark:text-red-400">Zone 5: Maximum (90-100%)</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">Very hard intensity exercise. Develops maximum performance and speed. Used for short, intense intervals.</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Calculation Methods</h3>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium">Maximum Heart Rate Formulas</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                        Several formulas exist to estimate maximum heart rate:
                      </p>
                      <ul className="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                        <li><strong>Tanaka Formula (used in this calculator):</strong> 208 - (0.7 × age)</li>
                        <li><strong>Traditional Formula:</strong> 220 - age</li>
                        <li><strong>Gellish Formula:</strong> 207 - (0.7 × age)</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-medium">Karvonen Method vs. Percentage Method</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                        This calculator offers two different methods for calculating heart rate zones:
                      </p>
                      <ul className="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                        <li><strong>Karvonen Method:</strong> Uses Heart Rate Reserve (HRR = Max HR - Resting HR). Target HR = Resting HR + (HRR × percentage). More individualized because it accounts for fitness level.</li>
                        <li><strong>Percentage Method:</strong> Simply calculates percentages of maximum heart rate. Simpler but less individualized.</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">How to Measure Heart Rate</h3>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li><strong>Resting Heart Rate:</strong> Measure first thing in the morning before getting out of bed. Count pulse for 60 seconds or 30 seconds and multiply by 2.</li>
                    <li><strong>During Exercise:</strong> Use a heart rate monitor, fitness watch, or manually check pulse for 15 seconds and multiply by 4.</li>
                    <li><strong>Manual Pulse Check:</strong> Place two fingers (not thumb) on wrist (radial artery) or neck (carotid artery) and count beats for set time.</li>
                  </ul>
                </div>
                
                <div className="py-2">
                  <h3 className="text-lg font-semibold mb-2">Benefits of Heart Rate Training</h3>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li>Provides objective measurement of exercise intensity</li>
                    <li>Helps prevent overtraining and undertraining</li>
                    <li>Allows for targeted training to achieve specific fitness goals</li>
                    <li>Tracks improvements in cardiovascular fitness over time</li>
                    <li>Helps optimize workout efficiency</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/pace-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Pace Calculator</a>
              </li>
              <li>
                <a href="/tools/bmr-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMR Calculator</a>
              </li>
              <li>
                <a href="/tools/workout-planner" className="text-blue-600 hover:underline dark:text-blue-400">Workout Planner</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default HeartRateCalculator;
