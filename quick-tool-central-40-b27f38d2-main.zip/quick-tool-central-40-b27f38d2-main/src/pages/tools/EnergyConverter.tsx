
import React, { useState, useEffect } from "react";
import { Copy, RotateCw, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import ChatBot from "@/components/ChatBot";
import Helmet from "react-helmet";

const EnergyConverter = () => {
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState<number | string>("");
  const [result, setResult] = useState<number | string>("");
  const [fromUnit, setFromUnit] = useState("joule");
  const [toUnit, setToUnit] = useState("calorie");
  const [recentConversions, setRecentConversions] = useState<Array<{
    from: string,
    to: string,
    input: number | string,
    output: number | string,
    timestamp: Date
  }>>([]);

  // Unit conversion rates to joule (base unit)
  const energyUnits = {
    joule: 1,
    kilojoule: 0.001,
    megajoule: 0.000001,
    gigajoule: 0.000000001,
    calorie: 0.239006,
    kilocalorie: 0.000239006,
    wattHour: 0.000277778,
    kilowattHour: 0.000000277778,
    electronVolt: 6.242e+18,
    britishThermalUnit: 0.000947817,
    footPound: 0.737562,
    ergon: 10000000
  };

  const unitNames = {
    joule: "Joule",
    kilojoule: "Kilojoule",
    megajoule: "Megajoule",
    gigajoule: "Gigajoule",
    calorie: "Calorie",
    kilocalorie: "Kilocalorie",
    wattHour: "Watt Hour",
    kilowattHour: "Kilowatt Hour",
    electronVolt: "Electron Volt",
    britishThermalUnit: "British Thermal Unit",
    footPound: "Foot-Pound",
    ergon: "Erg"
  };

  const unitSymbols = {
    joule: "J",
    kilojoule: "kJ",
    megajoule: "MJ",
    gigajoule: "GJ",
    calorie: "cal",
    kilocalorie: "kcal",
    wattHour: "Wh",
    kilowattHour: "kWh",
    electronVolt: "eV",
    britishThermalUnit: "BTU",
    footPound: "ft⋅lb",
    ergon: "erg"
  };

  useEffect(() => {
    if (inputValue !== "") {
      convertEnergy();
    }
  }, [inputValue, fromUnit, toUnit]);

  const convertEnergy = () => {
    if (inputValue === "" || isNaN(Number(inputValue))) {
      setResult("");
      return;
    }

    // Convert from the input unit to joules (base unit)
    const joules = Number(inputValue) / energyUnits[fromUnit as keyof typeof energyUnits];
    
    // Convert from joules to the output unit
    const convertedValue = joules * energyUnits[toUnit as keyof typeof energyUnits];
    
    // Round to a reasonable number of decimal places
    let roundedValue: number;
    if (convertedValue < 0.01) {
      roundedValue = Number(convertedValue.toFixed(6));
    } else if (convertedValue < 1) {
      roundedValue = Number(convertedValue.toFixed(4));
    } else {
      roundedValue = Number(convertedValue.toFixed(2));
    }
    
    setResult(roundedValue);
    
    // Save to recent conversions
    if (inputValue !== "") {
      const newConversion = {
        from: fromUnit,
        to: toUnit,
        input: inputValue,
        output: roundedValue,
        timestamp: new Date()
      };
      
      setRecentConversions(prev => {
        const updated = [newConversion, ...prev].slice(0, 5);
        return updated;
      });
    }
  };

  const handleCopy = () => {
    if (result !== "") {
      navigator.clipboard.writeText(`${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]}`);
      toast({
        title: "Copied!",
        description: `${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]} has been copied to clipboard.`,
      });
    }
  };

  const handleReset = () => {
    setInputValue("");
    setResult("");
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  return (
    <>
      <Helmet>
        <title>Free Online Energy Converter Tool | Convert joules, calories, kWh & more</title>
        <meta name="description" content="Convert energy units instantly with our free online energy converter. Easily convert between joules, calories, kilowatt-hours, BTUs, and more with accurate results." />
        <meta name="keywords" content="energy converter, joules to calories, kWh to BTU, energy units, power conversion" />
        <meta property="og:title" content="Free Online Energy Converter Tool" />
        <meta property="og:description" content="Convert between joules, calories, kilowatt-hours, BTUs and more with our free online energy converter tool." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/energy-converter" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Free Online Energy Converter Tool" />
        <meta name="twitter:description" content="Convert between joules, calories, kilowatt-hours, BTUs and more with our free online energy converter tool." />
        <link rel="canonical" href="https://multitoolset.co/tools/energy-converter" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Energy Converter Tool",
              "url": "https://multitoolset.co/tools/energy-converter",
              "description": "Convert energy units instantly with our free online energy converter. Easily convert between joules, calories, kilowatt-hours, BTUs, and more with accurate results.",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I convert joules to calories?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To convert joules to calories, divide the energy value by 4.184. For example, 1 joule equals 0.239 calories (small calories or gram calories)."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What's the difference between calories and kilocalories?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A kilocalorie (kcal) is 1,000 calories. What we commonly refer to as 'calories' in nutrition and food labeling are actually kilocalories. 1 kcal = 4.184 kilojoules."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many joules are in a kilowatt-hour?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "There are 3,600,000 joules in 1 kilowatt-hour (kWh), as 1 kWh = 3.6 megajoules."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <h1 className="text-3xl font-bold text-center flex-grow text-gray-800 dark:text-gray-100">
              Energy Converter
            </h1>
            <div className="w-[70px]"></div> {/* Spacer for balance */}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-lg border-2 border-gray-100 dark:border-gray-800">
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="fromValue" className="text-base font-medium">
                        From
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="fromValue"
                            type="number"
                            placeholder="Enter value"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="text-lg"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={fromUnit} onValueChange={setFromUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(energyUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={swapUnits}
                      className="mx-auto md:mx-0 h-10 w-10 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
                    >
                      <ArrowRightLeft className="h-5 w-5" />
                    </Button>
                    
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="toValue" className="text-base font-medium">
                        To
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="toValue"
                            readOnly
                            value={result}
                            className="text-lg bg-gray-50 dark:bg-gray-800"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={toUnit} onValueChange={setToUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(energyUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex-grow">
                      {result !== "" && (
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <p className="text-lg font-medium">
                            <span className="text-gray-500 dark:text-gray-400">Result:</span>{" "}
                            <span className="font-bold text-tool-green">
                              {inputValue} {unitSymbols[fromUnit as keyof typeof unitSymbols]} = {result} {unitSymbols[toUnit as keyof typeof unitSymbols]}
                            </span>
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button onClick={handleCopy} disabled={result === ""}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="mt-6">
                <Tabs defaultValue="howto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="howto">How to Use</TabsTrigger>
                    <TabsTrigger value="formulas">Conversion Formulas</TabsTrigger>
                    <TabsTrigger value="history">Recent Conversions</TabsTrigger>
                  </TabsList>
                  <TabsContent value="howto" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">How to Use the Energy Converter</h2>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Enter the value you want to convert in the "From" field.</li>
                      <li>Select the unit you're converting from using the dropdown menu.</li>
                      <li>Select the unit you want to convert to using the second dropdown menu.</li>
                      <li>The result will be calculated automatically and displayed instantly.</li>
                      <li>Use the "Copy" button to copy the result to your clipboard.</li>
                      <li>Use the "Reset" button to clear all fields and start over.</li>
                    </ol>
                  </TabsContent>
                  <TabsContent value="formulas" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Common Energy Conversion Formulas</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Joule to Calorie:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 J = 0.239 cal</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilocalorie to Joule:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 kcal = 4,184 J</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilowatt-hour to Joule:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 kWh = 3,600,000 J</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Joule to BTU:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 J = 0.000948 BTU</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">BTU to Joule:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 BTU = 1,055.06 J</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilowatt-hour to Kilocalorie:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 kWh = 860.42 kcal</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="history" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Recent Conversions</h2>
                    {recentConversions.length > 0 ? (
                      <div className="space-y-2">
                        {recentConversions.map((conversion, index) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md flex justify-between">
                            <div>
                              <span className="font-medium">
                                {conversion.input} {unitSymbols[conversion.from as keyof typeof unitSymbols]} = {conversion.output} {unitSymbols[conversion.to as keyof typeof unitSymbols]}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {conversion.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No recent conversions yet.</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How do I convert joules to calories?</h3>
                    <p className="mt-2">To convert joules to calories, divide the energy value by 4.184. For example, 1 joule equals 0.239 calories (small calories or gram calories).</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What's the difference between calories and kilocalories?</h3>
                    <p className="mt-2">A kilocalorie (kcal) is 1,000 calories. What we commonly refer to as 'calories' in nutrition and food labeling are actually kilocalories. 1 kcal = 4.184 kilojoules.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How many joules are in a kilowatt-hour?</h3>
                    <p className="mt-2">There are 3,600,000 joules in 1 kilowatt-hour (kWh), as 1 kWh = 3.6 megajoules.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <AdBanner 
                size="large" 
                type="vertical"
                className="sticky top-24"
              />
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Related Converters</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/tools/pressure-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Pressure Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/time-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Time Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/temperature-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Temperature Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/power-calculator" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Power Calculator
                    </a>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Common Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("joule");
                        setToUnit("calorie");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 joule to calories
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("kilocalorie");
                        setToUnit("joule");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 kilocalorie to joules
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("kilowattHour");
                        setToUnit("megajoule");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 kWh to megajoules
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("britishThermalUnit");
                        setToUnit("joule");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 BTU to joules
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(2000);
                        setFromUnit("calorie");
                        setToUnit("kilocalorie");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      2000 calories to kilocalories
                    </button>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
          
          <div className="mt-8">
            <AdBanner type="horizontal" size="large" />
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default EnergyConverter;
