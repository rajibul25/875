
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

const CharacterCounter = () => {
  const [text, setText] = useState("");
  const [characterLimit, setCharacterLimit] = useState(280); // Default Twitter limit
  const [ignorePunctuation, setIgnorePunctuation] = useState(false);
  
  const [stats, setStats] = useState({
    charCount: 0,
    charCountNoSpaces: 0,
    charCountNoPunctuation: 0,
    remainingChars: 280,
    percentage: 0
  });

  useEffect(() => {
    analyzeText(text);
  }, [text, characterLimit, ignorePunctuation]);

  const analyzeText = (content: string) => {
    // Character count
    const charCount = content.length;
    const charCountNoSpaces = content.replace(/\s+/g, "").length;
    
    // Character count without punctuation
    const charCountNoPunctuation = ignorePunctuation 
      ? content.replace(/[^\w\s]/g, "").length
      : charCount;
    
    // Remaining characters
    const actualCount = ignorePunctuation ? charCountNoPunctuation : charCount;
    const remainingChars = characterLimit - actualCount;
    
    // Calculate percentage of limit used
    const percentage = Math.min(100, Math.floor((actualCount / characterLimit) * 100));
    
    setStats({
      charCount,
      charCountNoSpaces,
      charCountNoPunctuation,
      remainingChars,
      percentage
    });
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleLimitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || 0;
    setCharacterLimit(value);
  };

  const copyText = () => {
    navigator.clipboard.writeText(text);
    toast.success("Text copied to clipboard");
  };

  const downloadText = () => {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "character-counter-text.txt";
    link.href = url;
    link.click();
    toast.success("Text downloaded successfully");
  };

  const getProgressColor = () => {
    if (stats.remainingChars > characterLimit * 0.2) return "bg-green-500";
    if (stats.remainingChars > 0) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getCommonLimits = () => [
    { name: "Twitter", value: 280 },
    { name: "SMS", value: 160 },
    { name: "Instagram Bio", value: 150 },
    { name: "Meta Title", value: 60 },
    { name: "Meta Description", value: 160 },
  ];

  return (
    <ToolLayout 
      title="Character Counter"
      description="Count characters in your text with or without spaces"
      helpText="Enter your text to count characters with detailed analysis for social media, SMS, and more."
    >
      <div className="space-y-6">
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here..."
            className="min-h-[250px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
            aria-label="Text input for character counting"
          />
          <div className="p-3 bg-muted/20 border-t flex justify-between">
            <div className="flex items-center">
              <Switch 
                id="ignore-punctuation" 
                checked={ignorePunctuation}
                onCheckedChange={setIgnorePunctuation}
              />
              <Label htmlFor="ignore-punctuation" className="ml-2">
                Ignore punctuation
              </Label>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyText}>
                <Copy className="h-4 w-4 mr-2" /> Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadText}>
                <Save className="h-4 w-4 mr-2" /> Save
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="font-medium text-lg">Character Stats</h3>
              <div className="grid grid-cols-1 gap-4">
                <div className="bg-muted/20 p-4 rounded-lg border">
                  <div className="text-2xl font-bold">{stats.charCount}</div>
                  <div className="text-sm text-muted-foreground">Characters (with spaces)</div>
                </div>
                
                <div className="bg-muted/20 p-4 rounded-lg border">
                  <div className="text-2xl font-bold">{stats.charCountNoSpaces}</div>
                  <div className="text-sm text-muted-foreground">Characters (no spaces)</div>
                </div>
                
                {ignorePunctuation && (
                  <div className="bg-muted/20 p-4 rounded-lg border">
                    <div className="text-2xl font-bold">{stats.charCountNoPunctuation}</div>
                    <div className="text-sm text-muted-foreground">Characters (no punctuation)</div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="font-medium text-lg">Character Limit</h3>
              
              <div className="flex flex-wrap gap-2">
                {getCommonLimits().map((limit) => (
                  <Button
                    key={limit.name}
                    variant="outline"
                    size="sm"
                    onClick={() => setCharacterLimit(limit.value)}
                    className={characterLimit === limit.value ? "bg-primary/10" : ""}
                  >
                    {limit.name} ({limit.value})
                  </Button>
                ))}
              </div>
              
              <div className="flex items-center space-x-2">
                <Label htmlFor="custom-limit">Custom limit:</Label>
                <Input
                  id="custom-limit"
                  type="number"
                  value={characterLimit}
                  onChange={handleLimitChange}
                  className="max-w-[120px]"
                  min={1}
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Characters used: {ignorePunctuation ? stats.charCountNoPunctuation : stats.charCount}</span>
                  <span className={stats.remainingChars < 0 ? "text-red-500 font-bold" : ""}>
                    {stats.remainingChars < 0 ? `${Math.abs(stats.remainingChars)} over limit!` : `${stats.remainingChars} remaining`}
                  </span>
                </div>
                
                <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getProgressColor()}`} 
                    style={{ width: `${stats.percentage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the input field above.</li>
            <li>The character count will update automatically.</li>
            <li>Select a predefined character limit or enter a custom one.</li>
            <li>Toggle "Ignore punctuation" if you want to exclude punctuation from the count.</li>
            <li>Copy or save your text using the buttons provided.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">What's the difference between characters with and without spaces?</h3>
              <p className="text-muted-foreground">Characters with spaces counts all characters including spaces, while characters without spaces excludes spaces from the count. Some platforms count spaces, others don't.</p>
            </div>
            <div>
              <h3 className="font-bold">Why would I want to ignore punctuation?</h3>
              <p className="text-muted-foreground">Some platforms don't count punctuation marks towards character limits. The "Ignore punctuation" option helps you get a more accurate count for these platforms.</p>
            </div>
            <div>
              <h3 className="font-bold">What are the common character limits used in social media?</h3>
              <p className="text-muted-foreground">Twitter (280), SMS (160), Instagram Bio (150), Meta Title (60), and Meta Description (160) are some common character limits. You can easily select these presets in our tool.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default CharacterCounter;
