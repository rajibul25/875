
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Shield, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const SHA256Generator = () => {
  const [input, setInput] = useState("");
  const [hash, setHash] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  // Generate SHA-256 hash
  const generateHash = async () => {
    if (!input.trim()) {
      toast.error("Please enter text to hash");
      return;
    }

    setIsProcessing(true);
    
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(input);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      
      setHash(hashHex);
    } catch (err) {
      console.error("Error generating SHA-256 hash:", err);
      toast.error("Failed to generate hash");
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(hash);
      toast.success("Hash copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy hash");
    }
  };

  const resetForm = () => {
    setInput("");
    setHash("");
  };

  useEffect(() => {
    // Auto-generate hash on input change (optional)
    if (input.trim()) {
      const debounce = setTimeout(() => {
        generateHash();
      }, 500);
      
      return () => clearTimeout(debounce);
    }
  }, [input]);

  return (
    <ToolLayout
      title="Free Online SHA256 Hash Generator | Secure Hashing Tool"
      description="Generate SHA-256 hash values instantly for any text or string input. Free, secure online tool for SHA-256 hash generation with no data storage."
      helpText="Enter text in the input field and click 'Generate Hash' to create a SHA-256 hash. Use the copy button to copy the result to your clipboard."
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="input">
                Text to Hash
              </label>
              <Textarea
                id="input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter text to generate SHA-256 hash..."
                className="w-full h-32"
              />
            </div>

            <div className="flex space-x-2">
              <Button 
                onClick={generateHash}
                className="w-full"
                disabled={isProcessing || !input.trim()}
              >
                <Shield className="w-4 h-4 mr-2" />
                Generate SHA-256 Hash
              </Button>
              
              <Button 
                onClick={resetForm}
                variant="outline"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>

            {hash && (
              <div className="mt-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    SHA-256 Hash Result
                  </label>
                  <div className="relative">
                    <Input
                      value={hash}
                      readOnly
                      className="w-full pr-10 font-mono text-sm"
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={copyToClipboard}
                      className="absolute right-1 top-1 h-7"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-4">What is SHA-256 Hashing?</h2>
            <div className="prose dark:prose-invert max-w-none">
              <p>
                SHA-256 (Secure Hash Algorithm 256-bit) is a cryptographic hash function that generates a fixed-size 256-bit (32-byte) hash. It's part of the SHA-2 family designed by the NSA and is widely used in security applications and protocols.
              </p>
              <p>
                SHA-256 is considered highly secure and is used in many security-critical applications, including blockchain technology, digital signatures, and password hashing (with proper salting).
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Is this SHA-256 generator secure?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, all hashing happens directly in your browser using the Web Crypto API. Your input is never sent to our servers, ensuring complete privacy and security.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Can SHA-256 hashes be reversed?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  SHA-256 is a one-way hash function, which means it cannot be mathematically reversed to determine the original input from the hash value alone.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">What are SHA-256 hashes used for?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  SHA-256 is used for secure data verification, digital signatures, blockchain technology, password storage (with proper salting), and other security-critical applications.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolLayout>
  );
};

export default SHA256Generator;
