
import React, { useState, useEffect } from "react";
import { Copy, RotateCw, ArrowRightLeft, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import ChatBot from "@/components/ChatBot";
import Helmet from "react-helmet";

const SpeedConverter = () => {
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState<number | string>("");
  const [result, setResult] = useState<number | string>("");
  const [fromUnit, setFromUnit] = useState("kilometers_per_hour");
  const [toUnit, setToUnit] = useState("miles_per_hour");
  const [recentConversions, setRecentConversions] = useState<Array<{
    from: string,
    to: string,
    input: number | string,
    output: number | string,
    timestamp: Date
  }>>([]);

  // Unit conversion rates to meters per second (base unit)
  const speedUnits = {
    meters_per_second: 1,
    kilometers_per_hour: 3.6,
    miles_per_hour: 2.23694,
    feet_per_second: 3.28084,
    knots: 1.94384,
    mach: 0.00293858,
    speed_of_light: 0.00000000333564
  };

  const unitNames = {
    meters_per_second: "Meters per second",
    kilometers_per_hour: "Kilometers per hour",
    miles_per_hour: "Miles per hour",
    feet_per_second: "Feet per second",
    knots: "Knots",
    mach: "Mach",
    speed_of_light: "Speed of light"
  };

  const unitSymbols = {
    meters_per_second: "m/s",
    kilometers_per_hour: "km/h",
    miles_per_hour: "mph",
    feet_per_second: "ft/s",
    knots: "kn",
    mach: "M",
    speed_of_light: "c"
  };

  useEffect(() => {
    if (inputValue !== "") {
      convertSpeed();
    }
  }, [inputValue, fromUnit, toUnit]);

  const convertSpeed = () => {
    if (inputValue === "" || isNaN(Number(inputValue))) {
      setResult("");
      return;
    }

    // Convert from the input unit to meters per second (base unit)
    const mps = Number(inputValue) / speedUnits[fromUnit as keyof typeof speedUnits];
    
    // Convert from meters per second to the output unit
    const convertedValue = mps * speedUnits[toUnit as keyof typeof speedUnits];
    
    // Round to a reasonable number of decimal places
    let roundedValue: number;
    if (convertedValue < 0.01) {
      roundedValue = Number(convertedValue.toExponential(4));
    } else if (convertedValue < 1) {
      roundedValue = Number(convertedValue.toFixed(4));
    } else {
      roundedValue = Number(convertedValue.toFixed(2));
    }
    
    setResult(roundedValue);
    
    // Save to recent conversions
    if (inputValue !== "") {
      const newConversion = {
        from: fromUnit,
        to: toUnit,
        input: inputValue,
        output: roundedValue,
        timestamp: new Date()
      };
      
      setRecentConversions(prev => {
        const updated = [newConversion, ...prev].slice(0, 5);
        return updated;
      });
    }
  };

  const handleCopy = () => {
    if (result !== "") {
      navigator.clipboard.writeText(`${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]}`);
      toast({
        title: "Copied!",
        description: `${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]} has been copied to clipboard.`,
      });
    }
  };

  const handleReset = () => {
    setInputValue("");
    setResult("");
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  return (
    <>
      <Helmet>
        <title>Free Online Speed Converter Tool | Convert km/h, mph, m/s</title>
        <meta name="description" content="Convert speed units instantly with our free online speed converter. Easily convert between km/h, mph, m/s, knots, and more with accurate results." />
        <meta name="keywords" content="speed converter, kmh to mph, mph to kmh, meters per second converter, knots converter, velocity calculator" />
        <meta property="og:title" content="Free Online Speed Converter Tool" />
        <meta property="og:description" content="Convert between kilometers per hour, miles per hour, meters per second and more with our free online speed converter tool." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/speed-converter" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Free Online Speed Converter Tool" />
        <meta name="twitter:description" content="Convert between kilometers per hour, miles per hour, meters per second and more with our free online speed converter tool." />
        <link rel="canonical" href="https://multitoolset.co/tools/speed-converter" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Speed Converter Tool",
              "url": "https://multitoolset.co/tools/speed-converter",
              "description": "Convert speed units instantly with our free online speed converter. Easily convert between km/h, mph, m/s, knots, and more with accurate results.",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I convert kilometers per hour to miles per hour?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To convert kilometers per hour to miles per hour, multiply the speed value by 0.621371. For example, 100 km/h equals 62.1371 mph."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is a knot in speed measurement?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A knot is a unit of speed equal to one nautical mile per hour, exactly 1.852 km/h or approximately 1.15078 mph. Knots are commonly used in maritime and aviation contexts."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What does Mach speed mean?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Mach is a speed measurement relative to the speed of sound. Mach 1 is the speed of sound (approximately 343 meters per second or 1,235 km/h at sea level). Mach 2 is twice the speed of sound, and so on."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <h1 className="text-3xl font-bold text-center flex-grow text-gray-800 dark:text-gray-100">
              Speed Converter
            </h1>
            <div className="w-[70px]"></div> {/* Spacer for balance */}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-lg border-2 border-gray-100 dark:border-gray-800">
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="fromValue" className="text-base font-medium">
                        From
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="fromValue"
                            type="number"
                            placeholder="Enter value"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="text-lg"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={fromUnit} onValueChange={setFromUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(speedUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={swapUnits}
                      className="mx-auto md:mx-0 h-10 w-10 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
                    >
                      <ArrowRightLeft className="h-5 w-5" />
                    </Button>
                    
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="toValue" className="text-base font-medium">
                        To
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="toValue"
                            readOnly
                            value={result}
                            className="text-lg bg-gray-50 dark:bg-gray-800"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={toUnit} onValueChange={setToUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(speedUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex-grow">
                      {result !== "" && (
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <p className="text-lg font-medium">
                            <span className="text-gray-500 dark:text-gray-400">Result:</span>{" "}
                            <span className="font-bold text-tool-blue">
                              {inputValue} {unitSymbols[fromUnit as keyof typeof unitSymbols]} = {result} {unitSymbols[toUnit as keyof typeof unitSymbols]}
                            </span>
                          </p>
                          {fromUnit !== "speed_of_light" && toUnit !== "speed_of_light" && (
                            <div className="mt-2 flex items-center">
                              <Gauge className="h-5 w-5 mr-2 text-tool-blue" />
                              <div className="h-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-gradient-to-r from-blue-400 to-blue-600"
                                  style={{ 
                                    width: `${Math.min(100, Math.max(1, Number(inputValue) / 100))}%`, 
                                    transition: "width 0.5s ease-in-out" 
                                  }}
                                ></div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button onClick={handleCopy} disabled={result === ""}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="mt-6">
                <Tabs defaultValue="howto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="howto">How to Use</TabsTrigger>
                    <TabsTrigger value="formulas">Conversion Formulas</TabsTrigger>
                    <TabsTrigger value="history">Recent Conversions</TabsTrigger>
                  </TabsList>
                  <TabsContent value="howto" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">How to Use the Speed Converter</h2>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Enter the value you want to convert in the "From" field.</li>
                      <li>Select the unit you're converting from using the dropdown menu.</li>
                      <li>Select the unit you want to convert to using the second dropdown menu.</li>
                      <li>The result will be calculated automatically and displayed instantly.</li>
                      <li>Use the "Copy" button to copy the result to your clipboard.</li>
                      <li>Use the "Reset" button to clear all fields and start over.</li>
                    </ol>
                  </TabsContent>
                  <TabsContent value="formulas" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Common Speed Conversion Formulas</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilometers per hour to Miles per hour:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">mph = km/h × 0.621371</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Miles per hour to Kilometers per hour:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">km/h = mph × 1.60934</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Meters per second to Kilometers per hour:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">km/h = m/s × 3.6</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilometers per hour to Meters per second:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">m/s = km/h ÷ 3.6</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Knots to Miles per hour:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">mph = knots × 1.15078</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Mach to Kilometers per hour:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">km/h = Mach × 1225.08</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="history" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Recent Conversions</h2>
                    {recentConversions.length > 0 ? (
                      <div className="space-y-2">
                        {recentConversions.map((conversion, index) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md flex justify-between">
                            <div>
                              <span className="font-medium">
                                {conversion.input} {unitSymbols[conversion.from as keyof typeof unitSymbols]} = {conversion.output} {unitSymbols[conversion.to as keyof typeof unitSymbols]}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {conversion.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No recent conversions yet.</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How do I convert kilometers per hour to miles per hour?</h3>
                    <p className="mt-2">To convert kilometers per hour to miles per hour, multiply the speed value by 0.621371. For example, 100 km/h equals 62.1371 mph.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What is a knot in speed measurement?</h3>
                    <p className="mt-2">A knot is a unit of speed equal to one nautical mile per hour, exactly 1.852 km/h or approximately 1.15078 mph. Knots are commonly used in maritime and aviation contexts.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What does Mach speed mean?</h3>
                    <p className="mt-2">Mach is a speed measurement relative to the speed of sound. Mach 1 is the speed of sound (approximately 343 meters per second or 1,235 km/h at sea level). Mach 2 is twice the speed of sound, and so on.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <AdBanner 
                size="large" 
                type="vertical"
                className="sticky top-24"
              />
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Related Converters</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/tools/length-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Length Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/weight-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Weight Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/temperature-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Temperature Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/volume-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Volume Converter
                    </a>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Common Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(100);
                        setFromUnit("kilometers_per_hour");
                        setToUnit("miles_per_hour");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      100 km/h to mph
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(60);
                        setFromUnit("miles_per_hour");
                        setToUnit("kilometers_per_hour");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      60 mph to km/h
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("mach");
                        setToUnit("kilometers_per_hour");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      Mach 1 to km/h
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("speed_of_light");
                        setToUnit("kilometers_per_hour");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      Speed of light to km/h
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(30);
                        setFromUnit("knots");
                        setToUnit("kilometers_per_hour");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      30 knots to km/h
                    </button>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
          
          <div className="mt-8">
            <AdBanner type="horizontal" size="large" />
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default SpeedConverter;
