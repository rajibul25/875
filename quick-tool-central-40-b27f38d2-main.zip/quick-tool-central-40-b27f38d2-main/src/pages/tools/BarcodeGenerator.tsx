
import React, { useState, useRef } from "react";
import { Helmet } from "react-helmet";
import { Barcode, Download, RefreshCw, Copy, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import ToolLayout from "@/components/tools/ToolLayout";
import JsBarcode from "jsbarcode";

const BarcodeGenerator = () => {
  const [text, setText] = useState("123456789012");
  const [barcodeType, setBarcodeType] = useState("code128");
  const [lineColor, setLineColor] = useState("#000000");
  const [backgroundColor, setBackgroundColor] = useState("#ffffff");
  const [width, setWidth] = useState(2);
  const [height, setHeight] = useState(100);
  const [fontSize, setFontSize] = useState(20);
  const [displayValue, setDisplayValue] = useState(true);
  const [format, setFormat] = useState("svg");
  const [generated, setGenerated] = useState(true);
  
  const barcodeRef = useRef<SVGSVGElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const barcodeTypes = [
    { value: "code128", label: "Code 128" },
    { value: "ean13", label: "EAN-13" },
    { value: "ean8", label: "EAN-8" },
    { value: "upc", label: "UPC" },
    { value: "code39", label: "Code 39" },
    { value: "itf14", label: "ITF-14" },
    { value: "msi", label: "MSI" },
    { value: "pharmacode", label: "Pharmacode" },
  ];
  
  const generateBarcode = () => {
    if (!text.trim()) {
      toast.error("Please enter a valid text for the barcode");
      return;
    }
    
    try {
      if (format === "svg" && barcodeRef.current) {
        JsBarcode(barcodeRef.current, text, {
          format: barcodeType,
          lineColor,
          background: backgroundColor,
          width,
          height,
          fontSize,
          displayValue,
          margin: 10,
          valid: () => true,
        });
      } else if (format === "canvas" && canvasRef.current) {
        JsBarcode(canvasRef.current, text, {
          format: barcodeType,
          lineColor,
          background: backgroundColor,
          width,
          height,
          fontSize,
          displayValue,
          margin: 10,
          valid: () => true,
        });
      }
      setGenerated(true);
      toast.success("Barcode generated successfully!");
    } catch (error) {
      console.error("Error generating barcode:", error);
      toast.error("Failed to generate barcode. Please check your input.");
    }
  };
  
  const downloadBarcode = () => {
    let element;
    let dataURL;
    let downloadFormat;
    
    if (format === "svg" && barcodeRef.current) {
      // For SVG
      const svgData = new XMLSerializer().serializeToString(barcodeRef.current);
      dataURL = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgData);
      downloadFormat = "svg";
      element = barcodeRef.current;
    } else if (format === "canvas" && canvasRef.current) {
      // For Canvas (PNG)
      dataURL = canvasRef.current.toDataURL("image/png");
      downloadFormat = "png";
      element = canvasRef.current;
    } else {
      toast.error("No barcode has been generated");
      return;
    }
    
    const downloadLink = document.createElement("a");
    downloadLink.href = dataURL;
    downloadLink.download = `barcode.${downloadFormat}`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    
    toast.success(`Barcode downloaded as ${downloadFormat.toUpperCase()}`);
  };
  
  const copyToClipboard = () => {
    let dataURL;
    
    if (format === "svg" && barcodeRef.current) {
      const svgData = new XMLSerializer().serializeToString(barcodeRef.current);
      dataURL = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgData);
    } else if (format === "canvas" && canvasRef.current) {
      dataURL = canvasRef.current.toDataURL("image/png");
    } else {
      toast.error("No barcode has been generated");
      return;
    }
    
    // Create a temporary textarea element to copy the data URL
    const textarea = document.createElement("textarea");
    textarea.value = dataURL;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
    
    toast.success("Barcode data copied to clipboard");
  };
  
  return (
    <ToolLayout
      title="Barcode Generator"
      description="Create and customize barcodes for products, inventory, and tracking systems."
      helpText="Enter text or numbers, select barcode type, and customize appearance. The barcode generator supports various formats including Code 128, EAN-13, and UPC."
    >
      <Helmet>
        <title>Free Online Barcode Generator - Create Custom Barcodes | MultiToolSet</title>
        <meta name="description" content="Generate free custom barcodes online for products, inventory, and tracking. Supports multiple formats including Code 128, EAN-13, UPC, and more. Download as SVG or PNG." />
        <meta name="keywords" content="barcode generator, free barcode maker, product barcode, UPC generator, EAN generator, code 128, barcode creator" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Barcode Generator",
              "applicationCategory": "WebApplication",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "operatingSystem": "Any",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "156"
              }
            }
          `}
        </script>
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Barcode Settings</h2>
            
            <div className="space-y-2">
              <Label htmlFor="text">Text/Number for Barcode</Label>
              <Input
                id="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter text or numbers"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="barcodeType">Barcode Type</Label>
              <Select value={barcodeType} onValueChange={setBarcodeType}>
                <SelectTrigger id="barcodeType">
                  <SelectValue placeholder="Select barcode type" />
                </SelectTrigger>
                <SelectContent>
                  {barcodeTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Tabs defaultValue="appearance" className="mt-4">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="appearance">Appearance</TabsTrigger>
                <TabsTrigger value="format">Format & Text</TabsTrigger>
              </TabsList>
              
              <TabsContent value="appearance" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="lineColor">Line Color</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="lineColor"
                      type="color"
                      value={lineColor}
                      onChange={(e) => setLineColor(e.target.value)}
                      className="w-12 h-8 p-1"
                    />
                    <Input 
                      value={lineColor} 
                      onChange={(e) => setLineColor(e.target.value)}
                      className="flex-grow"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backgroundColor">Background Color</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="backgroundColor"
                      type="color"
                      value={backgroundColor}
                      onChange={(e) => setBackgroundColor(e.target.value)}
                      className="w-12 h-8 p-1"
                    />
                    <Input 
                      value={backgroundColor} 
                      onChange={(e) => setBackgroundColor(e.target.value)}
                      className="flex-grow"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="width">Bar Width: {width}</Label>
                  </div>
                  <Slider
                    id="width"
                    min={1}
                    max={5}
                    step={0.5}
                    value={[width]}
                    onValueChange={(value) => setWidth(value[0])}
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="height">Height: {height}px</Label>
                  </div>
                  <Slider
                    id="height"
                    min={50}
                    max={200}
                    step={5}
                    value={[height]}
                    onValueChange={(value) => setHeight(value[0])}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="format" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="format">Output Format</Label>
                  <RadioGroup 
                    id="format" 
                    value={format} 
                    onValueChange={setFormat} 
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="svg" id="svg" />
                      <Label htmlFor="svg">SVG</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="canvas" id="canvas" />
                      <Label htmlFor="canvas">PNG</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="fontSize">Font Size: {fontSize}px</Label>
                  </div>
                  <Slider
                    id="fontSize"
                    min={8}
                    max={32}
                    step={1}
                    value={[fontSize]}
                    onValueChange={(value) => setFontSize(value[0])}
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="displayValue"
                    checked={displayValue}
                    onChange={(e) => setDisplayValue(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="displayValue">Display Text/Number</Label>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <Button 
            onClick={generateBarcode} 
            className="w-full flex items-center justify-center gap-2"
          >
            <Barcode className="h-5 w-5" />
            Generate Barcode
          </Button>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-6 flex flex-col">
          <h2 className="text-xl font-semibold mb-4">Preview</h2>
          
          <div className="flex-grow flex items-center justify-center bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 p-6 my-4">
            {format === "svg" ? (
              <svg ref={barcodeRef} className="max-w-full"></svg>
            ) : (
              <canvas ref={canvasRef} className="max-w-full"></canvas>
            )}
          </div>
          
          <div className="flex flex-wrap gap-3 mt-4">
            <Button 
              variant="outline" 
              onClick={generateBarcode}
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Regenerate
            </Button>
            
            <Button 
              variant="outline" 
              onClick={downloadBarcode}
              disabled={!generated}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Download
            </Button>
            
            <Button 
              variant="outline" 
              onClick={copyToClipboard}
              disabled={!generated}
              className="flex items-center gap-2"
            >
              <Copy className="h-4 w-4" />
              Copy
            </Button>
          </div>
        </div>
      </div>

      <Separator className="my-8" />
      
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Barcode Types and Uses</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
            <h3 className="font-semibold mb-2">Code 128</h3>
            <p className="text-gray-600 dark:text-gray-300">
              A high-density linear barcode that can encode all 128 ASCII characters.
              Commonly used in shipping and packaging industries.
            </p>
          </div>
          
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
            <h3 className="font-semibold mb-2">EAN-13</h3>
            <p className="text-gray-600 dark:text-gray-300">
              European Article Number with 13 digits, used worldwide for marking retail products.
              First digits identify the country of origin.
            </p>
          </div>
          
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
            <h3 className="font-semibold mb-2">UPC</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Universal Product Code, 12-digit code used primarily in the United States
              and Canada for tracking trade items in stores.
            </p>
          </div>
          
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
            <h3 className="font-semibold mb-2">Code 39</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Alphanumeric barcode that can encode uppercase letters, numbers, and special characters.
              Often used in inventory and manufacturing.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-100 dark:border-blue-800">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <Info className="h-5 w-5 mr-2 text-blue-500" />
          Frequently Asked Questions
        </h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">What is a barcode?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              A barcode is a method of representing data in a visual, machine-readable form. Barcodes store data using parallel lines of varying widths, which are scanned and interpreted by special optical scanners.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">Which barcode type should I choose?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              The best barcode type depends on your specific use case. Code 128 is versatile for general purposes, EAN-13 and UPC are standard for retail products, Code 39 is good for internal inventory, and QR codes can store more information.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">Can I scan these barcodes with a smartphone?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              Yes, most smartphones can scan linear barcodes using built-in camera apps or dedicated barcode scanning apps available on app stores.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium">How do I use the downloaded barcode?</h3>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              After downloading, you can use the barcode image in various applications - print it on labels or packages, add it to documents, or use it in inventory management systems.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <a href="/tools/qr-code-generator" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">QR Code Generator</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Create customizable QR codes for any data</p>
            </div>
          </a>
          
          <a href="/tools/image-to-base64" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Image to Base64</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Convert images to Base64 format</p>
            </div>
          </a>
          
          <a href="/tools/random-string-generator" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Random String Generator</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Generate random strings for unique IDs</p>
            </div>
          </a>
        </div>
      </div>
    </ToolLayout>
  );
};

export default BarcodeGenerator;
