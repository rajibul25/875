
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Hash, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const MD5Generator = () => {
  const [input, setInput] = useState("");
  const [hash, setHash] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  // Generate MD5 hash
  const generateHash = () => {
    if (!input.trim()) {
      toast.error("Please enter text to hash");
      return;
    }

    setIsProcessing(true);
    
    // MD5 implementation
    const generateMD5 = async (text: string) => {
      const encoder = new TextEncoder();
      const data = encoder.encode(text);
      const hashBuffer = await crypto.subtle.digest('MD5', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      return hashHex;
    };

    generateMD5(input)
      .then(result => {
        setHash(result);
        setIsProcessing(false);
      })
      .catch(err => {
        console.error("Error generating MD5 hash:", err);
        toast.error("Failed to generate hash");
        setIsProcessing(false);
      });
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(hash);
      toast.success("Hash copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy hash");
    }
  };

  const resetForm = () => {
    setInput("");
    setHash("");
  };

  useEffect(() => {
    // Auto-generate hash on input change (optional)
    if (input.trim()) {
      const debounce = setTimeout(() => {
        generateHash();
      }, 500);
      
      return () => clearTimeout(debounce);
    }
  }, [input]);

  return (
    <ToolLayout
      title="Free Online MD5 Hash Generator | Secure Hashing Tool"
      description="Generate MD5 hash values instantly for any text, string, or password input. Free online tool for quick and secure MD5 hash generation."
      helpText="Enter text in the input field and click 'Generate Hash' to create an MD5 hash. Use the copy button to copy the result to your clipboard."
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="input">
                Text to Hash
              </label>
              <Textarea
                id="input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter text to generate MD5 hash..."
                className="w-full h-32"
              />
            </div>

            <div className="flex space-x-2">
              <Button 
                onClick={generateHash}
                className="w-full"
                disabled={isProcessing || !input.trim()}
              >
                <Hash className="w-4 h-4 mr-2" />
                Generate MD5 Hash
              </Button>
              
              <Button 
                onClick={resetForm}
                variant="outline"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>

            {hash && (
              <div className="mt-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    MD5 Hash Result
                  </label>
                  <div className="relative">
                    <Input
                      value={hash}
                      readOnly
                      className="w-full pr-10 font-mono text-sm"
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={copyToClipboard}
                      className="absolute right-1 top-1 h-7"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-4">What is MD5 Hashing?</h2>
            <div className="prose dark:prose-invert max-w-none">
              <p>
                MD5 (Message Digest Algorithm 5) is a widely used cryptographic hash function that produces a 128-bit (16-byte) hash value. It's commonly used to verify data integrity but is no longer recommended for security-critical applications due to vulnerabilities.
              </p>
              <p>
                While MD5 is still useful for checksums and non-security applications, consider using stronger alternatives like SHA-256 for security-critical contexts.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Is this MD5 generator secure?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, all hashing happens directly in your browser. Your input is never sent to our servers, ensuring complete privacy and security.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Can MD5 hashes be reversed?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  MD5 is a one-way hash function, meaning it cannot be directly reversed. However, it's vulnerable to rainbow table attacks and should not be used for password storage.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">What are MD5 hashes used for?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  MD5 hashes are commonly used for file integrity verification, checksums, and non-security critical applications where a quick hash is needed.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolLayout>
  );
};

export default MD5Generator;
