
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import { format, addDays, addWeeks, differenceInDays, differenceInWeeks } from "date-fns";
import { Helmet } from "react-helmet";
import { CalendarIcon, ChevronRight, Baby } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";

const PregnancyCalculator = () => {
  const [method, setMethod] = useState<"lmp" | "conception" | "ivf">("lmp");
  const [lmpDate, setLmpDate] = useState<Date | undefined>(undefined);
  const [conceptionDate, setConceptionDate] = useState<Date | undefined>(undefined);
  const [ivfDate, setIvfDate] = useState<Date | undefined>(undefined);
  const [cycleLength, setCycleLength] = useState<number>(28);
  const [dueDate, setDueDate] = useState<Date | undefined>(undefined);
  const [currentWeek, setCurrentWeek] = useState<number>(0);
  const [currentDay, setCurrentDay] = useState<number>(0);
  const [milestones, setMilestones] = useState<Array<{ date: Date; week: number; description: string }>>([]);

  const calculateDueDate = () => {
    let calculatedDueDate: Date | undefined;
    const today = new Date();
    
    if (method === "lmp" && lmpDate) {
      // Calculate due date based on LMP: LMP + 280 days (40 weeks)
      // Naegele's rule with adjustments for cycle length
      const adjustedDays = 280 + (cycleLength - 28) / 2;
      calculatedDueDate = addDays(lmpDate, adjustedDays);
    } else if (method === "conception" && conceptionDate) {
      // Calculate due date based on conception: Conception + 266 days (38 weeks)
      calculatedDueDate = addDays(conceptionDate, 266);
    } else if (method === "ivf" && ivfDate) {
      // Calculate due date based on IVF/embryo transfer
      // For a 3-day embryo, add 263 days (37 weeks + 5 days)
      // For a 5-day embryo, add 261 days (37 weeks + 3 days)
      calculatedDueDate = addDays(ivfDate, 261); // Assuming 5-day embryo transfer
    }
    
    if (calculatedDueDate) {
      setDueDate(calculatedDueDate);
      
      // Calculate current week and day
      let startDate: Date | undefined;
      if (method === "lmp") startDate = lmpDate;
      else if (method === "conception") startDate = addDays(conceptionDate!, -14);
      else if (method === "ivf") startDate = addDays(ivfDate!, -19); // 5-day embryo
      
      if (startDate) {
        const daysSinceStart = differenceInDays(today, startDate);
        if (daysSinceStart > 0) {
          setCurrentWeek(Math.floor(daysSinceStart / 7));
          setCurrentDay(daysSinceStart % 7);
        } else {
          setCurrentWeek(0);
          setCurrentDay(0);
        }
      }
      
      // Calculate key milestones
      let milestoneDates: Array<{ date: Date; week: number; description: string }> = [];
      let startDateForMilestones: Date;
      
      if (method === "lmp") startDateForMilestones = lmpDate!;
      else if (method === "conception") startDateForMilestones = addDays(conceptionDate!, -14);
      else startDateForMilestones = addDays(ivfDate!, -19);
      
      milestoneDates = [
        { date: addWeeks(startDateForMilestones, 4), week: 4, description: "Heartbeat can be detected" },
        { date: addWeeks(startDateForMilestones, 8), week: 8, description: "End of embryonic period, fetus starts forming" },
        { date: addWeeks(startDateForMilestones, 12), week: 12, description: "End of first trimester" },
        { date: addWeeks(startDateForMilestones, 20), week: 20, description: "Halfway point, anatomy scan" },
        { date: addWeeks(startDateForMilestones, 24), week: 24, description: "Viability milestone" },
        { date: addWeeks(startDateForMilestones, 27), week: 27, description: "End of second trimester" },
        { date: addWeeks(startDateForMilestones, 37), week: 37, description: "Full term pregnancy" },
        { date: calculatedDueDate, week: 40, description: "Due date (estimated)" }
      ];
      
      setMilestones(milestoneDates);
    }
  };

  const getProgressPercentage = () => {
    if (!currentWeek) return 0;
    return Math.min(Math.round((currentWeek / 40) * 100), 100);
  };
  
  const formatDate = (date?: Date) => {
    return date ? format(date, "MMMM d, yyyy") : "";
  };

  return (
    <>
      <Helmet>
        <title>Pregnancy Due Date Calculator | Easy Due Date Estimation | MultitoolSet</title>
        <meta name="description" content="Calculate your due date based on last menstrual period, conception date, or IVF transfer date with our pregnancy calculator. Track pregnancy milestones and fetal development." />
        <meta name="keywords" content="pregnancy calculator, due date calculator, pregnancy due date, gestational age calculator, pregnancy calendar, pregnancy timeline" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How accurate is the pregnancy due date calculator?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Due date calculations provide an estimate. Only about 4% of babies are born on their exact due date, with most births occurring within two weeks before or after the calculated date."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How is the due date calculated?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "The most common method uses Naegele's rule, which calculates the due date as the first day of your last menstrual period plus 280 days (40 weeks). For conception date, we add 266 days, and for IVF transfers, we adjust based on embryo age."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What if I have irregular periods?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "If you have irregular periods, the LMP method might be less accurate. In this case, an early ultrasound can provide a more reliable due date estimate."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <ToolLayout
        title="Pregnancy Due Date Calculator"
        description="Calculate your pregnancy due date and track important milestones"
        helpText="Enter your last menstrual period (LMP), conception date, or IVF transfer date to calculate your estimated due date and track pregnancy progress."
      >
        <div className="space-y-8">
          <div className="flex flex-col gap-6">
            <div className="space-y-4">
              <Label>Calculation Method</Label>
              <div className="flex flex-wrap gap-2">
                <Button 
                  variant={method === "lmp" ? "default" : "outline"}
                  onClick={() => setMethod("lmp")}
                  className="flex-1"
                >
                  Last Menstrual Period
                </Button>
                <Button 
                  variant={method === "conception" ? "default" : "outline"}
                  onClick={() => setMethod("conception")}
                  className="flex-1"
                >
                  Conception Date
                </Button>
                <Button 
                  variant={method === "ivf" ? "default" : "outline"}
                  onClick={() => setMethod("ivf")}
                  className="flex-1"
                >
                  IVF Transfer
                </Button>
              </div>
            </div>
            
            {method === "lmp" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="lmp-date">First day of last menstrual period</Label>
                  <div className="mt-1">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {lmpDate ? format(lmpDate, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={lmpDate}
                          onSelect={setLmpDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="cycle-length">Average Menstrual Cycle Length (days)</Label>
                  <Input
                    id="cycle-length"
                    type="number"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(parseInt(e.target.value) || 28)}
                    min={21}
                    max={45}
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Typical cycle length is 28 days, but can vary from 21 to 45 days.
                  </p>
                </div>
              </div>
            )}
            
            {method === "conception" && (
              <div>
                <Label htmlFor="conception-date">Conception Date</Label>
                <div className="mt-1">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {conceptionDate ? format(conceptionDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={conceptionDate}
                        onSelect={setConceptionDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            )}
            
            {method === "ivf" && (
              <div>
                <Label htmlFor="ivf-date">Embryo Transfer Date</Label>
                <div className="mt-1">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {ivfDate ? format(ivfDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={ivfDate}
                        onSelect={setIvfDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  This calculator assumes a 5-day embryo (blastocyst) transfer.
                </p>
              </div>
            )}
            
            <Button 
              onClick={calculateDueDate}
              disabled={
                (method === "lmp" && !lmpDate) || 
                (method === "conception" && !conceptionDate) || 
                (method === "ivf" && !ivfDate)
              }
              className="w-full"
            >
              Calculate Due Date <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          
          {dueDate && (
            <div className="mt-8 space-y-6">
              <Card className="bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="inline-block bg-pink-100 dark:bg-pink-800/30 p-3 rounded-full mb-4">
                      <Baby className="h-8 w-8 text-pink-600 dark:text-pink-400" />
                    </div>
                    <h3 className="text-xl font-bold text-pink-800 dark:text-pink-300 mb-2">Your Due Date</h3>
                    <p className="text-3xl font-bold">{formatDate(dueDate)}</p>
                    {currentWeek > 0 && (
                      <div className="mt-4">
                        <p className="text-lg font-medium">
                          You are currently {currentWeek} weeks and {currentDay} days pregnant
                        </p>
                        <div className="mt-2">
                          <Progress value={getProgressPercentage()} className="h-4" />
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {getProgressPercentage()}% complete
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Pregnancy Timeline</h3>
                <div className="space-y-4">
                  {milestones.map((milestone, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="bg-gray-100 dark:bg-gray-800 rounded-full p-2 flex-shrink-0">
                        <div className="w-8 h-8 flex items-center justify-center font-bold text-gray-700 dark:text-gray-300">
                          {milestone.week}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold">Week {milestone.week}</h4>
                        <p className="text-gray-700 dark:text-gray-300">{milestone.description}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{formatDate(milestone.date)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Trimester Breakdown</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="font-bold text-center mb-2">First Trimester</h4>
                      <p className="text-center text-gray-700 dark:text-gray-300">Weeks 1-12</p>
                      <Separator className="my-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Key developments: Organ formation, heartbeat begins, embryo becomes a fetus
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="font-bold text-center mb-2">Second Trimester</h4>
                      <p className="text-center text-gray-700 dark:text-gray-300">Weeks 13-27</p>
                      <Separator className="my-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Key developments: Gender can be determined, movements felt, rapid growth
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="font-bold text-center mb-2">Third Trimester</h4>
                      <p className="text-center text-gray-700 dark:text-gray-300">Weeks 28-40</p>
                      <Separator className="my-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Key developments: Rapid weight gain, lung maturation, preparing for birth
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          )}
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Select your preferred calculation method (Last Menstrual Period, Conception Date, or IVF Transfer).</li>
              <li>Enter the requested dates. For LMP method, you can also adjust your average cycle length.</li>
              <li>Click "Calculate Due Date" to see your results.</li>
              <li>View your estimated due date, current pregnancy progress, and key milestones.</li>
            </ol>
          </div>
          
          <div className="mt-6">
            <h2 className="text-2xl font-bold mb-4">FAQs</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">How accurate is the pregnancy due date calculator?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Due date calculations provide an estimate. Only about 4% of babies are born on their exact due date, with most births occurring within two weeks before or after the calculated date.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">How is the due date calculated?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  The most common method uses Naegele's rule, which calculates the due date as the first day of your last menstrual period plus 280 days (40 weeks). For conception date, we add 266 days, and for IVF transfers, we adjust based on embryo age.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">What if I have irregular periods?</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  If you have irregular periods, the LMP method might be less accurate. In this case, an early ultrasound can provide a more reliable due date estimate.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/ovulation-calculator" className="text-blue-600 hover:underline">Ovulation Calculator</a>
              </li>
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/weight-gain-calculator" className="text-blue-600 hover:underline">Pregnancy Weight Gain Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline">Calorie Counter</a>
              </li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default PregnancyCalculator;
