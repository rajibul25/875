
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Helmet } from "react-helmet";
import { HeartIcon } from "@/components/icons/ToolIcons";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Save, Download, BarChart2, FileText, Check, AlertTriangle, Eye } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface BloodPressureReading {
  id: string;
  date: string;
  time: string;
  systolic: number;
  diastolic: number;
  pulse: number;
  arm: string;
  position: string;
  notes: string;
  category: string;
}

const BloodPressureLog = () => {
  const [readings, setReadings] = useState<BloodPressureReading[]>([]);
  const [newReading, setNewReading] = useState<{
    date: string;
    time: string;
    systolic: string;
    diastolic: string;
    pulse: string;
    arm: string;
    position: string;
    notes: string;
  }>({
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().split(' ')[0].substring(0, 5),
    systolic: "",
    diastolic: "",
    pulse: "",
    arm: "left",
    position: "sitting",
    notes: ""
  });

  // Load readings from localStorage on initial load
  useEffect(() => {
    const savedReadings = localStorage.getItem('bloodPressureReadings');
    if (savedReadings) {
      try {
        setReadings(JSON.parse(savedReadings));
      } catch (error) {
        console.error("Error loading saved readings:", error);
      }
    }
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setNewReading(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addReading = () => {
    try {
      const systolic = parseInt(newReading.systolic);
      const diastolic = parseInt(newReading.diastolic);
      const pulse = parseInt(newReading.pulse);
      
      // Validate inputs
      if (isNaN(systolic) || systolic < 70 || systolic > 250) {
        toast.error("Please enter a valid systolic pressure between 70 and 250 mmHg.");
        return;
      }
      
      if (isNaN(diastolic) || diastolic < 40 || diastolic > 150) {
        toast.error("Please enter a valid diastolic pressure between 40 and 150 mmHg.");
        return;
      }
      
      if (isNaN(pulse) || pulse < 40 || pulse > 200) {
        toast.error("Please enter a valid pulse rate between 40 and 200 bpm.");
        return;
      }
      
      if (!newReading.date || !newReading.time) {
        toast.error("Please enter date and time for the reading.");
        return;
      }
      
      // Determine blood pressure category
      const category = getBPCategory(systolic, diastolic);
      
      // Create new reading
      const reading: BloodPressureReading = {
        id: crypto.randomUUID(),
        date: newReading.date,
        time: newReading.time,
        systolic,
        diastolic,
        pulse,
        arm: newReading.arm,
        position: newReading.position,
        notes: newReading.notes,
        category
      };
      
      // Add to readings
      const updatedReadings = [...readings, reading];
      setReadings(updatedReadings);
      
      // Save to localStorage
      localStorage.setItem('bloodPressureReadings', JSON.stringify(updatedReadings));
      
      // Reset form except for date and time
      setNewReading(prev => ({
        ...prev,
        systolic: "",
        diastolic: "",
        pulse: "",
        notes: ""
      }));
      
      toast.success("Blood pressure reading added successfully!");
    } catch (error) {
      toast.error("Error adding reading. Please check your inputs.");
      console.error("Error adding reading:", error);
    }
  };

  const deleteReading = (id: string) => {
    const updatedReadings = readings.filter(reading => reading.id !== id);
    setReadings(updatedReadings);
    localStorage.setItem('bloodPressureReadings', JSON.stringify(updatedReadings));
    toast.success("Reading deleted successfully!");
  };

  const downloadReadings = () => {
    try {
      // Create CSV content
      let csvContent = "Date,Time,Systolic,Diastolic,Pulse,Arm,Position,Category,Notes\r\n";
      
      readings.forEach(reading => {
        csvContent += `${reading.date},${reading.time},${reading.systolic},${reading.diastolic},${reading.pulse},${reading.arm},${reading.position},${reading.category},"${reading.notes.replace(/"/g, '""')}"\r\n`;
      });
      
      // Create a Blob and download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'blood_pressure_log.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Blood pressure readings downloaded as CSV!");
    } catch (error) {
      toast.error("Error downloading readings. Please try again.");
      console.error("Download error:", error);
    }
  };

  const exportToPDF = () => {
    toast.info("PDF export feature coming soon!");
  };

  const viewReports = () => {
    document.getElementById('reports-tab')?.click();
  };

  const getBPCategory = (systolic: number, diastolic: number): string => {
    if (systolic >= 180 || diastolic >= 120) {
      return "Hypertensive Crisis";
    } else if (systolic >= 140 || diastolic >= 90) {
      return "Hypertension Stage 2";
    } else if ((systolic >= 130 && systolic < 140) || (diastolic >= 80 && diastolic < 90)) {
      return "Hypertension Stage 1";
    } else if ((systolic >= 120 && systolic < 130) && diastolic < 80) {
      return "Elevated";
    } else if (systolic < 120 && diastolic < 80) {
      return "Normal";
    } else {
      return "Uncategorized";
    }
  };

  const getCategoryColor = (category: string): string => {
    switch (category) {
      case "Normal": return "bg-green-500";
      case "Elevated": return "bg-yellow-500";
      case "Hypertension Stage 1": return "bg-orange-500";
      case "Hypertension Stage 2": return "bg-red-500";
      case "Hypertensive Crisis": return "bg-purple-500";
      default: return "bg-gray-500";
    }
  };

  const getCategoryTextColor = (category: string): string => {
    switch (category) {
      case "Normal": return "text-green-600 dark:text-green-400";
      case "Elevated": return "text-yellow-600 dark:text-yellow-400";
      case "Hypertension Stage 1": return "text-orange-600 dark:text-orange-400";
      case "Hypertension Stage 2": return "text-red-600 dark:text-red-400";
      case "Hypertensive Crisis": return "text-purple-600 dark:text-purple-400";
      default: return "text-gray-600 dark:text-gray-400";
    }
  };

  const sortedReadings = [...readings].sort((a, b) => {
    const dateA = new Date(`${a.date}T${a.time}`);
    const dateB = new Date(`${b.date}T${b.time}`);
    return dateB.getTime() - dateA.getTime(); // Sort by date descending (newest first)
  });

  const getAverages = () => {
    if (readings.length === 0) return { systolic: 0, diastolic: 0, pulse: 0 };
    
    const totalSystolic = readings.reduce((sum, reading) => sum + reading.systolic, 0);
    const totalDiastolic = readings.reduce((sum, reading) => sum + reading.diastolic, 0);
    const totalPulse = readings.reduce((sum, reading) => sum + reading.pulse, 0);
    
    return {
      systolic: Math.round(totalSystolic / readings.length),
      diastolic: Math.round(totalDiastolic / readings.length),
      pulse: Math.round(totalPulse / readings.length)
    };
  };

  const averages = getAverages();

  const getRecentTrend = () => {
    if (readings.length < 2) return null;
    
    const sortedForTrend = [...readings].sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime(); // Sort by date ascending for trend
    });
    
    const recentReadings = sortedForTrend.slice(-5); // Last 5 readings
    if (recentReadings.length < 2) return null;
    
    const firstSystolic = recentReadings[0].systolic;
    const lastSystolic = recentReadings[recentReadings.length - 1].systolic;
    const firstDiastolic = recentReadings[0].diastolic;
    const lastDiastolic = recentReadings[recentReadings.length - 1].diastolic;
    
    const systolicChange = lastSystolic - firstSystolic;
    const diastolicChange = lastDiastolic - firstDiastolic;
    
    return {
      systolicChange,
      diastolicChange,
      improved: systolicChange <= 0 && diastolicChange <= 0
    };
  };

  const trend = getRecentTrend();

  return (
    <>
      <Helmet>
        <title>Blood Pressure Log | Track & Monitor BP Readings | MultitoolSet</title>
        <meta name="description" content="Track and monitor your blood pressure readings over time with our free online blood pressure log. Visualize trends, export data, and stay on top of your cardiovascular health." />
        <meta name="keywords" content="blood pressure log, blood pressure tracker, BP monitor, hypertension tracker, blood pressure diary, heart health tracking, cardiovascular health monitor" />
        <link rel="canonical" href="https://multitoolset.com/tools/blood-pressure-log" />
        <meta property="og:title" content="Blood Pressure Log | Track & Monitor BP Readings" />
        <meta property="og:description" content="Track and monitor your blood pressure readings over time. Visualize trends and export data to share with your healthcare provider." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/blood-pressure-log" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Blood Pressure Log | Track & Monitor BP Readings" />
        <meta name="twitter:description" content="Track and monitor your blood pressure readings over time. Visualize trends and export data to share with your healthcare provider." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Blood Pressure Log",
              "description": "Track and monitor your blood pressure readings over time. Visualize trends and export data to share with your healthcare provider.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What is a normal blood pressure reading?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A normal blood pressure reading is less than 120/80 mmHg. Systolic pressure (the top number) below 120 and diastolic pressure (the bottom number) below 80 is considered optimal for most adults."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How often should I measure my blood pressure?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "If you're monitoring your blood pressure at home, it's best to measure at the same time each day. For most people, measuring once or twice daily is sufficient. Those with serious hypertension may need more frequent measurements, as advised by their healthcare provider."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Why should I keep a blood pressure log?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Keeping a blood pressure log helps you and your healthcare provider monitor trends over time rather than relying on single readings. This provides better insight into your cardiovascular health, helps evaluate the effectiveness of treatments, and can identify patterns related to time of day, medications, or lifestyle factors."
                  }
                }
              ]
            }
          `}
        </script>
        <meta name="robots" content="index, follow" />
      </Helmet>
    
      <ToolLayout
        title="Blood Pressure Log"
        description="Track and monitor your blood pressure readings over time. Visualize trends and export data to share with your healthcare provider."
        helpText="Log your blood pressure readings to track trends over time. All data is stored locally in your browser."
      >
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="log" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="log">Add Readings</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="reports" id="reports-tab">Reports</TabsTrigger>
              </TabsList>
              
              <TabsContent value="log" className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="date">Date</Label>
                      <Input
                        id="date"
                        type="date"
                        value={newReading.date}
                        onChange={(e) => handleInputChange('date', e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="time">Time</Label>
                      <Input
                        id="time"
                        type="time"
                        value={newReading.time}
                        onChange={(e) => handleInputChange('time', e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="systolic">Systolic (mmHg)</Label>
                      <Input
                        id="systolic"
                        type="number"
                        placeholder="120"
                        value={newReading.systolic}
                        onChange={(e) => handleInputChange('systolic', e.target.value)}
                        min="70"
                        max="250"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="diastolic">Diastolic (mmHg)</Label>
                      <Input
                        id="diastolic"
                        type="number"
                        placeholder="80"
                        value={newReading.diastolic}
                        onChange={(e) => handleInputChange('diastolic', e.target.value)}
                        min="40"
                        max="150"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="pulse">Pulse (bpm)</Label>
                      <Input
                        id="pulse"
                        type="number"
                        placeholder="72"
                        value={newReading.pulse}
                        onChange={(e) => handleInputChange('pulse', e.target.value)}
                        min="40"
                        max="200"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="arm">Arm Used</Label>
                      <Select
                        value={newReading.arm}
                        onValueChange={(value) => handleInputChange('arm', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select arm" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="left">Left Arm</SelectItem>
                          <SelectItem value="right">Right Arm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="position">Body Position</Label>
                      <Select
                        value={newReading.position}
                        onValueChange={(value) => handleInputChange('position', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select position" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sitting">Sitting</SelectItem>
                          <SelectItem value="standing">Standing</SelectItem>
                          <SelectItem value="lying">Lying Down</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      placeholder="Add any relevant notes (medications, stress level, etc.)"
                      value={newReading.notes}
                      onChange={(e) => handleInputChange('notes', e.target.value)}
                    />
                  </div>
                  
                  <div>
                    {parseInt(newReading.systolic) > 0 && parseInt(newReading.diastolic) > 0 && (
                      <div className="p-3 rounded-lg border mb-4">
                        <p className="text-sm mb-1">Blood Pressure Category:</p>
                        <p className={`font-semibold ${getCategoryTextColor(getBPCategory(parseInt(newReading.systolic), parseInt(newReading.diastolic)))}`}>
                          {getBPCategory(parseInt(newReading.systolic), parseInt(newReading.diastolic))}
                        </p>
                      </div>
                    )}
                  
                    <Button 
                      onClick={addReading} 
                      className="w-full"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Blood Pressure Reading
                    </Button>
                  </div>
                </div>
                
                {readings.length > 0 && (
                  <div className="flex justify-between items-center flex-wrap gap-2 mt-6">
                    <p className="text-sm text-gray-600 dark:text-gray-400">You have {readings.length} saved reading{readings.length !== 1 ? 's' : ''}</p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={viewReports}>
                        <BarChart2 className="h-4 w-4 mr-1" />
                        <span className="hidden sm:inline">View Reports</span>
                      </Button>
                      <Button variant="outline" size="sm" onClick={downloadReadings}>
                        <Download className="h-4 w-4 mr-1" />
                        <span className="hidden sm:inline">Export to CSV</span>
                      </Button>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="history" className="space-y-6 pt-4">
                {readings.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">No readings yet</h3>
                    <p className="text-gray-500 dark:text-gray-400">Add your first blood pressure reading to get started.</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => document.getElementById('log-tab')?.click()}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Reading
                    </Button>
                  </div>
                ) : (
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold">Blood Pressure History</h3>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={downloadReadings}>
                          <Download className="h-4 w-4 mr-1" />
                          <span className="hidden sm:inline">Export to CSV</span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Date & Time</TableHead>
                            <TableHead>Reading</TableHead>
                            <TableHead>Pulse</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Notes</TableHead>
                            <TableHead></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sortedReadings.map((reading) => (
                            <TableRow key={reading.id}>
                              <TableCell>
                                <div className="font-medium">{new Date(reading.date).toLocaleDateString()}</div>
                                <div className="text-sm text-gray-500">{reading.time}</div>
                              </TableCell>
                              <TableCell className="font-semibold">
                                {reading.systolic}/{reading.diastolic} <span className="text-xs font-normal">mmHg</span>
                              </TableCell>
                              <TableCell>
                                {reading.pulse} <span className="text-xs">bpm</span>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center">
                                  <div className={`h-3 w-3 rounded-full mr-2 ${getCategoryColor(reading.category)}`}></div>
                                  <span className={`text-sm ${getCategoryTextColor(reading.category)}`}>{reading.category}</span>
                                </div>
                              </TableCell>
                              <TableCell className="max-w-[200px] truncate">
                                {reading.notes || <span className="text-gray-400 italic">No notes</span>}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50 px-2"
                                  onClick={() => deleteReading(reading.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="reports" className="space-y-6 pt-4">
                {readings.length < 2 ? (
                  <div className="text-center py-8">
                    <BarChart2 className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Not enough data for reports</h3>
                    <p className="text-gray-500 dark:text-gray-400">Add at least 2 readings to see reports and trends.</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => document.getElementById('log-tab')?.click()}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Reading
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-white rounded-lg border shadow-sm dark:bg-gray-800 dark:border-gray-700">
                        <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Average Blood Pressure</h3>
                        <p className="text-2xl font-bold">{averages.systolic}/{averages.diastolic}</p>
                        <p className="text-sm text-gray-500">Based on {readings.length} readings</p>
                      </div>
                      
                      <div className="p-4 bg-white rounded-lg border shadow-sm dark:bg-gray-800 dark:border-gray-700">
                        <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Average Pulse</h3>
                        <p className="text-2xl font-bold">{averages.pulse} <span className="text-sm font-normal">bpm</span></p>
                        <p className="text-sm text-gray-500">Based on {readings.length} readings</p>
                      </div>
                      
                      <div className="p-4 bg-white rounded-lg border shadow-sm dark:bg-gray-800 dark:border-gray-700">
                        <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Recent Trend</h3>
                        {trend ? (
                          <div>
                            <div className="flex items-center">
                              {trend.improved ? (
                                <Check className="h-5 w-5 text-green-500 mr-1" />
                              ) : (
                                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-1" />
                              )}
                              <p className="font-medium">
                                {trend.improved ? "Improving" : "Monitor closely"}
                              </p>
                            </div>
                            <p className="text-sm text-gray-500 mt-1">
                              {trend.systolicChange >= 0 ? "+" : ""}{trend.systolicChange}/{trend.diastolicChange >= 0 ? "+" : ""}{trend.diastolicChange} mmHg change
                            </p>
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500">Insufficient data for trend analysis</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white rounded-lg border shadow-sm dark:bg-gray-800 dark:border-gray-700">
                      <h3 className="font-medium mb-4">Blood Pressure Categories</h3>
                      <div className="space-y-3">
                        {["Normal", "Elevated", "Hypertension Stage 1", "Hypertension Stage 2", "Hypertensive Crisis"].map(category => {
                          const count = readings.filter(r => r.category === category).length;
                          const percentage = readings.length > 0 ? Math.round((count / readings.length) * 100) : 0;
                          return (
                            <div key={category} className="space-y-1">
                              <div className="flex justify-between">
                                <span className={`text-sm font-medium ${getCategoryTextColor(category)}`}>{category}</span>
                                <span className="text-sm text-gray-500">{count} readings ({percentage}%)</span>
                              </div>
                              <Progress 
                                value={percentage} 
                                className="h-2" 
                                indicatorClassName={getCategoryColor(category)}
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white rounded-lg border shadow-sm dark:bg-gray-800 dark:border-gray-700">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="font-medium">Most Recent Readings</h3>
                        <Button variant="outline" size="sm" onClick={() => document.getElementById('history-tab')?.click()}>
                          <Eye className="h-4 w-4 mr-1" />
                          View All
                        </Button>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date & Time</TableHead>
                              <TableHead>Reading</TableHead>
                              <TableHead>Category</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sortedReadings.slice(0, 5).map((reading) => (
                              <TableRow key={reading.id}>
                                <TableCell>
                                  <div className="font-medium">{new Date(reading.date).toLocaleDateString()}</div>
                                  <div className="text-sm text-gray-500">{reading.time}</div>
                                </TableCell>
                                <TableCell className="font-semibold">
                                  {reading.systolic}/{reading.diastolic} <span className="text-xs font-normal">mmHg</span>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center">
                                    <div className={`h-3 w-3 rounded-full mr-2 ${getCategoryColor(reading.category)}`}></div>
                                    <span className={`text-sm ${getCategoryTextColor(reading.category)}`}>{reading.category}</span>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    <div className="flex justify-between">
                      <Button variant="outline" onClick={() => document.getElementById('log-tab')?.click()}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add New Reading
                      </Button>
                      <Button onClick={downloadReadings}>
                        <Download className="h-4 w-4 mr-1" />
                        Export Data
                      </Button>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/heart-rate-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Heart Rate Calculator</a>
              </li>
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/bmr-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMR Calculator</a>
              </li>
              <li>
                <a href="/tools/workout-planner" className="text-blue-600 hover:underline dark:text-blue-400">Workout Planner</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default BloodPressureLog;
