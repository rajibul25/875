
import { useState, useRef } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Upload, X, Play, Download, Trash2 } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";

const GifMakerComponent = () => {
  const [images, setImages] = useState<{ file: File; url: string }[]>([]);
  const [frameDelay, setFrameDelay] = useState<number>(100);
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewGif, setPreviewGif] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPreviewFrame, setCurrentPreviewFrame] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    // Process only image files
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    if (imageFiles.length !== files.length) {
      toast.warning("Some files were skipped because they are not images");
    }

    // Create preview URLs for each image
    const newImages = imageFiles.map(file => ({
      file,
      url: URL.createObjectURL(file)
    }));

    setImages(prev => [...prev, ...newImages]);
    
    // Reset the input value so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    toast.success(`Added ${imageFiles.length} images`);
  };

  const removeImage = (index: number) => {
    setImages(prev => {
      const newImages = [...prev];
      // Revoke the URL to prevent memory leaks
      URL.revokeObjectURL(newImages[index].url);
      newImages.splice(index, 1);
      return newImages;
    });
  };

  const reorderImages = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === images.length - 1)
    ) {
      return; // Can't move first item up or last item down
    }

    setImages(prev => {
      const newImages = [...prev];
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      [newImages[index], newImages[targetIndex]] = [newImages[targetIndex], newImages[index]];
      return newImages;
    });
  };

  const togglePreview = () => {
    if (images.length < 2) {
      toast.error("Add at least 2 images to preview");
      return;
    }

    if (isPlaying) {
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      previewAnimation();
    }
  };

  const previewAnimation = () => {
    setIsPlaying(true);
    setCurrentPreviewFrame(0);
  };

  // Effect to animate through frames when preview is active
  const animatePreview = () => {
    if (!isPlaying || images.length < 2) return;
    
    const interval = setInterval(() => {
      setCurrentPreviewFrame(prev => {
        if (prev >= images.length - 1) {
          return 0;
        }
        return prev + 1;
      });
    }, frameDelay);
    
    return () => clearInterval(interval);
  };

  // Call animate preview when isPlaying changes
  if (isPlaying) {
    const cleanup = animatePreview();
    // Cleanup function will be called when isPlaying becomes false
    if (!isPlaying) cleanup && cleanup();
  }

  const generateGif = async () => {
    if (images.length < 2) {
      toast.error("Add at least 2 images to create a GIF");
      return;
    }

    setIsGenerating(true);
    
    try {
      // In a real implementation, we would use a library like gif.js to create the GIF
      // For now, we'll simulate the process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate generated GIF - just using the first image for demonstration
      setPreviewGif(images[0].url);
      toast.success("GIF generated successfully!");
    } catch (error) {
      toast.error("Failed to generate GIF. Please try again.");
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadGif = () => {
    if (!previewGif) return;
    
    // In a real implementation, we would generate a downloadable blob
    // For now, we'll just simulate download using the first image
    const link = document.createElement('a');
    link.href = previewGif;
    link.download = 'animation.gif';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("GIF downloaded successfully!");
  };

  return (
    <ToolLayout
      title="Free Online GIF Maker"
      description="Create animated GIFs easily by combining multiple images. Set frame speed, preview, and optimize your GIFs."
      helpText="Upload multiple images, adjust timing, and create animated GIFs in seconds. Perfect for social media and presentations."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">1. Upload Images</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select Images</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              PNG, JPG, WebP, or JPEG files. Maximum size: 5MB per image.
            </p>
          </div>
        </div>

        {images.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">2. Arrange & Preview Images</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {images.map((image, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-2">
                    <div className="relative aspect-square">
                      <img
                        src={image.url}
                        alt={`Frame ${index + 1}`}
                        className="w-full h-full object-cover rounded"
                      />
                      <div className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                        {index + 1}
                      </div>
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute top-2 right-2 bg-black/60 p-1 rounded-full"
                      >
                        <X className="h-3 w-3 text-white" />
                      </button>
                      <div className="absolute bottom-2 right-2 flex space-x-1">
                        <button
                          onClick={() => reorderImages(index, 'up')}
                          disabled={index === 0}
                          className={`bg-black/60 p-1 rounded-full ${
                            index === 0 ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                        >
                          <svg className="h-3 w-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M18 15l-6-6-6 6" />
                          </svg>
                        </button>
                        <button
                          onClick={() => reorderImages(index, 'down')}
                          disabled={index === images.length - 1}
                          className={`bg-black/60 p-1 rounded-full ${
                            index === images.length - 1 ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                        >
                          <svg className="h-3 w-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M6 9l6 6 6-6" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-medium mb-2">Frame Speed</h3>
              <div className="flex items-center space-x-4">
                <span className="text-sm">Slow</span>
                <Slider
                  value={[frameDelay]}
                  onValueChange={(value) => setFrameDelay(value[0])}
                  min={30}
                  max={1000}
                  step={10}
                  className="flex-1"
                />
                <span className="text-sm">Fast</span>
                <span className="text-sm font-medium w-16 text-right">
                  {frameDelay}ms
                </span>
              </div>
            </div>

            <div className="flex flex-col md:flex-row items-center justify-between mt-6 gap-4">
              <Button
                onClick={togglePreview}
                variant="outline"
                className="w-full md:w-auto"
              >
                {isPlaying ? (
                  <span className="flex items-center">
                    <X className="mr-2 h-4 w-4" /> 
                    Stop Preview
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Play className="mr-2 h-4 w-4" /> 
                    Preview Animation
                  </span>
                )}
              </Button>

              <Button
                onClick={() => setImages([])}
                variant="destructive"
                className="w-full md:w-auto"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Clear All
              </Button>
            </div>
          </div>
        )}

        {isPlaying && images.length > 0 && (
          <div className="mt-6 border rounded-lg p-4">
            <h3 className="text-lg font-medium mb-4">Preview</h3>
            <div className="flex justify-center">
              <div className="relative max-w-md w-full">
                <img
                  src={images[currentPreviewFrame]?.url}
                  alt="GIF Preview"
                  className="w-full h-auto rounded"
                />
              </div>
            </div>
          </div>
        )}

        {images.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">3. Generate & Download GIF</h2>
            <div className="flex flex-col md:flex-row gap-4">
              <Button
                onClick={generateGif}
                disabled={isGenerating || images.length < 2}
                className="md:flex-1"
              >
                {isGenerating ? "Generating..." : "Generate GIF"}
              </Button>
              
              <Button
                onClick={downloadGif}
                disabled={!previewGif}
                variant="outline"
                className="md:flex-1"
              >
                <Download className="mr-2 h-4 w-4" />
                Download GIF
              </Button>
            </div>

            {previewGif && (
              <div className="mt-6 border rounded-lg p-4">
                <h3 className="text-lg font-medium mb-4">Generated GIF</h3>
                <div className="flex justify-center">
                  <img src={previewGif} alt="Generated GIF" className="max-w-full h-auto rounded" />
                </div>
              </div>
            )}
          </div>
        )}

        <AdBanner />
        
        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What is a GIF?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                GIF (Graphics Interchange Format) is an image file format that supports both static and animated images. 
                They're commonly used for simple animations, reactions, and short clips on social media.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How many images do I need for a good GIF?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                For a smooth animation, we recommend using at least 5-10 images. The more frames you include, the 
                smoother the animation will be, but this will also increase the file size.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What's the ideal frame speed for GIFs?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                The ideal frame speed depends on your content. For smooth animations, 100-200ms between frames works well. 
                Faster speeds (50-100ms) create rapid animations, while slower speeds (200-500ms) are good for slideshows.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Can I edit my GIF after creating it?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Currently, you need to regenerate your GIF if you want to make changes. We recommend finalizing your image selection 
                and frame speed before generating the GIF.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What's the maximum GIF file size this tool can create?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Our tool optimizes GIFs to keep file sizes manageable. However, if your GIF has many high-resolution frames, 
                the resulting file may be large. We recommend keeping your GIF under 10MB for optimal web performance.
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const GifMaker = withErrorBoundary(GifMakerComponent, "gif-maker");

export default GifMaker;
