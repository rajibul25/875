
import React, { useEffect } from 'react';
import { HardDrive, RefreshCcw, Clock, AlertTriangle } from 'lucide-react';
import ToolLayout from '@/components/tools/ToolLayout';
import { Button } from '@/components/ui/button';
import { Helmet } from "react-helmet";
import { useLocation } from 'react-router-dom';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

const DiskAnalyzerMaintenance: React.FC = () => {
  const location = useLocation();
  
  // Extract tool name from URL for custom title
  const getToolNameFromPath = (path: string) => {
    const parts = path.split('/');
    const lastPart = parts[parts.length - 1];
    return lastPart.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };
  
  const toolName = getToolNameFromPath(location.pathname);
  
  // Log page access for analytics
  useEffect(() => {
    console.log(`Maintenance page accessed for: ${toolName} at ${new Date().toISOString()}`);
  }, [toolName]);

  return (
    <>
      <Helmet>
        <title>Advanced System Tools - {toolName} | Temporarily Unavailable</title>
        <meta name="description" content="Our system tools are temporarily unavailable while we enhance performance and stability. We're working to restore access to all system monitoring and diagnostic tools soon." />
        <meta name="keywords" content="system tools, system monitor, disk analyzer, network diagnostics, database viewer, IT tools, professional utilities, system maintenance" />
      </Helmet>
      
      <ToolLayout 
        title={toolName} 
        description="Temporarily Unavailable"
      >
        <div className="text-center py-12 px-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <div className="bg-yellow-100 dark:bg-yellow-900/30 p-4 rounded-full inline-block mb-6">
            <HardDrive className="h-12 w-12 text-yellow-600 dark:text-yellow-400" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
            Advanced System Tools – Temporarily Unavailable
          </h2>
          
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-6">
            Looking for powerful system utilities and diagnostics? Our Advanced System Tools (System Monitor, Disk Analyzer, Network Diagnostics, Database Viewer) are currently undergoing maintenance to enhance performance and stability.
          </p>
          
          <Alert className="max-w-2xl mx-auto mb-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
            <AlertTriangle className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-800 dark:text-blue-300">We're working hard to restore access</AlertTitle>
            <AlertDescription className="text-blue-700 dark:text-blue-400">
              Please check back soon for the latest updates. Thank you for your patience and support.
            </AlertDescription>
          </Alert>
          
          <div className="flex flex-col items-center space-y-4">
            <div className="flex items-center space-x-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-3 rounded-lg shadow-sm">
              <Clock className="h-5 w-5 text-gray-500 dark:text-gray-400" />
              <span className="text-gray-700 dark:text-gray-300">
                Estimated Restoration Time: Soon
              </span>
            </div>
            
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                variant="outline"
                className="flex items-center gap-2"
                onClick={() => window.location.reload()}
              >
                <RefreshCcw className="h-4 w-4" />
                <span>Refresh Page</span>
              </Button>
              
              <Button 
                variant="secondary"
                onClick={() => window.history.back()}
              >
                Back to Tools
              </Button>
            </div>
          </div>
          
          <div className="mt-12 bg-gray-100 dark:bg-gray-800 p-6 rounded-lg max-w-3xl mx-auto">
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">
              Why Maintenance?
            </h3>
            <ul className="text-gray-600 dark:text-gray-300 list-disc list-inside space-y-2">
              <li>Improving system performance</li>
              <li>Enhancing tool stability</li>
              <li>Adding new features and diagnostics capabilities</li>
              <li>Ensuring the highest quality of service</li>
            </ul>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default DiskAnalyzerMaintenance;
