
import React, { useState, useRef } from "react";
import { toast } from "sonner";
import { 
  Archive, 
  Upload, 
  FileText, 
  Folder, 
  Download, 
  File, 
  ClipboardCopy, 
  ArrowRight, 
  FolderArchive, 
  X 
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import ToolLayout from "@/components/tools/ToolLayout";
import { Label } from "@/components/ui/label";

const ZipFileHandler = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<string>("");
  const [extractedFiles, setExtractedFiles] = useState<{ name: string; type: string; size: number }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      // Check if file is a ZIP
      if (!file.name.toLowerCase().endsWith('.zip')) {
        toast.error("Please select a ZIP file");
        return;
      }
      
      // Check file size (max 50MB)
      const maxSize = 50 * 1024 * 1024; // 50MB in bytes
      if (file.size > maxSize) {
        toast.error("File size exceeds the maximum allowed size of 50MB");
        return;
      }
      
      setSelectedFile(file);
      toast.success(`File "${file.name}" selected successfully!`);
      
      // Reset previous results
      setExtractedFiles([]);
      setResult("");
    }
  };

  const simulateExtractZip = () => {
    if (!selectedFile) return;
    
    setIsProcessing(true);
    setProgress(0);
    
    // Simulate processing with progress updates
    const totalSteps = 10;
    let currentStep = 0;
    
    const interval = setInterval(() => {
      currentStep++;
      setProgress((currentStep / totalSteps) * 100);
      
      if (currentStep >= totalSteps) {
        clearInterval(interval);
        
        // Generate mock extracted files
        const mockFiles = [
          { name: 'index.html', type: 'file', size: 12420 },
          { name: 'styles.css', type: 'file', size: 5843 },
          { name: 'main.js', type: 'file', size: 34251 },
          { name: 'images/', type: 'folder', size: 0 },
          { name: 'images/logo.png', type: 'file', size: 45602 },
          { name: 'images/banner.jpg', type: 'file', size: 132105 },
          { name: 'fonts/', type: 'folder', size: 0 },
          { name: 'fonts/opensans.ttf', type: 'file', size: 87432 }
        ];
        
        setExtractedFiles(mockFiles);
        setResult("ZIP file extracted successfully! " + mockFiles.length + " files found.");
        setIsProcessing(false);
        toast.success("ZIP file processed successfully!");
      }
    }, 300);
  };

  const resetTool = () => {
    setSelectedFile(null);
    setExtractedFiles([]);
    setResult("");
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <ToolLayout
      title="ZIP File Handler"
      description="Upload, extract, and manage ZIP files easily"
      helpText="Use this tool to extract and view the contents of ZIP files. Maximum file size is 50MB."
    >
      <div className="space-y-6">
        {/* File Upload Section */}
        <div className="border rounded-lg p-6 bg-gray-50">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <FolderArchive className="mr-2 h-5 w-5 text-teal-600" />
            Upload ZIP File
          </h2>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileChange}
              accept=".zip"
            />
            
            {!selectedFile ? (
              <div>
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Drag and drop your ZIP file here, or{' '}
                  <button 
                    type="button" 
                    className="text-teal-600 hover:text-teal-500 font-medium"
                    onClick={triggerFileInput}
                  >
                    browse
                  </button>
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Maximum file size: 50MB
                </p>
              </div>
            ) : (
              <div>
                <Archive className="mx-auto h-12 w-12 text-teal-600" />
                <p className="mt-2 text-sm text-gray-800 font-medium">
                  {selectedFile.name}
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  {formatFileSize(selectedFile.size)}
                </p>
                <button
                  type="button"
                  className="mt-2 text-sm text-red-600 hover:text-red-500 font-medium"
                  onClick={resetTool}
                >
                  Remove
                </button>
              </div>
            )}
          </div>

          {selectedFile && (
            <div className="mt-4">
              <Button
                onClick={simulateExtractZip}
                disabled={isProcessing}
                className="bg-teal-600 hover:bg-teal-700"
              >
                {isProcessing ? "Processing..." : "Extract ZIP File"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          )}

          {isProcessing && (
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Processing...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>

        {/* Results Section */}
        {result && (
          <div className="border rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center">
              <Folder className="mr-2 h-5 w-5 text-teal-600" />
              Extracted Files
            </h2>
            
            <div className="bg-gray-50 p-3 rounded mb-4 text-sm text-teal-700">
              {result}
            </div>
            
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-100 px-4 py-3 border-b grid grid-cols-12 text-sm font-medium">
                <div className="col-span-6">Name</div>
                <div className="col-span-3">Type</div>
                <div className="col-span-3">Size</div>
              </div>
              
              <div className="divide-y max-h-80 overflow-y-auto">
                {extractedFiles.map((file, index) => (
                  <div key={index} className="px-4 py-3 grid grid-cols-12 text-sm hover:bg-gray-50">
                    <div className="col-span-6 flex items-center">
                      {file.type === 'folder' ? 
                        <Folder className="mr-2 h-4 w-4 text-teal-600" /> : 
                        <File className="mr-2 h-4 w-4 text-gray-600" />
                      }
                      {file.name}
                    </div>
                    <div className="col-span-3 text-gray-600">
                      {file.type === 'folder' ? 'Directory' : file.name.split('.').pop()?.toUpperCase()}
                    </div>
                    <div className="col-span-3 text-gray-600">
                      {file.type === 'folder' ? '-' : formatFileSize(file.size)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mt-4 flex space-x-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  toast.success("Structure copied to clipboard!");
                }}
              >
                <ClipboardCopy className="mr-1 h-4 w-4" />
                Copy Structure
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  toast.success("ZIP file would be downloaded in a real implementation");
                }}
              >
                <Download className="mr-1 h-4 w-4" />
                Download Files
              </Button>
            </div>
          </div>
        )}
        
        {/* Usage Instructions */}
        <div className="border rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-4">How to Use This Tool</h2>
          <ol className="list-decimal pl-5 space-y-2 text-gray-700">
            <li>Upload a ZIP file by clicking the browse button or drag and drop.</li>
            <li>Click "Extract ZIP File" to process the file.</li>
            <li>View the extracted file structure in the results panel.</li>
            <li>Download the extracted files or copy the file structure as needed.</li>
          </ol>
        </div>
        
        {/* FAQs */}
        <div className="border rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">What ZIP formats are supported?</h3>
              <p className="text-gray-700">This tool supports standard ZIP formats. Large ZIP files with advanced compression may take longer to process.</p>
            </div>
            <div>
              <h3 className="font-semibold">Is my data secure?</h3>
              <p className="text-gray-700">Yes, all processing happens in your browser. We don't store your ZIP files or their contents on our servers.</p>
            </div>
            <div>
              <h3 className="font-semibold">Why can't I download individual files?</h3>
              <p className="text-gray-700">This tool is currently focused on viewing ZIP contents. In a future update, we'll add support for downloading individual files.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default ZipFileHandler;
