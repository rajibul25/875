
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { Calculator, Battery, Info } from "lucide-react";
import { Helmet } from "react-helmet";
import { PercentIcon } from "@/components/icons/ToolIcons";

const BmrCalculator = () => {
  const [age, setAge] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [height, setHeight] = useState<string>("");
  const [gender, setGender] = useState<string>("male");
  const [activityLevel, setActivityLevel] = useState<string>("sedentary");
  const [unitSystem, setUnitSystem] = useState<string>("metric");
  const [results, setResults] = useState<{
    bmr: number;
    tdee: number;
    maintenance: number;
    cutting: number;
    bulking: number;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateBMR = () => {
    try {
      setIsCalculating(true);
      
      // Convert inputs to numbers
      const ageValue = parseInt(age);
      let weightValue = parseFloat(weight);
      let heightValue = parseFloat(height);
      
      // Convert imperial to metric if needed
      if (unitSystem === "imperial") {
        // Convert pounds to kg
        weightValue = weightValue * 0.453592;
        // Convert inches to cm
        heightValue = heightValue * 2.54;
      }
      
      // Validate inputs
      if (isNaN(ageValue) || ageValue <= 0 || ageValue > 120) {
        toast.error("Please enter a valid age between 1 and 120.");
        setIsCalculating(false);
        return;
      }
      
      if (isNaN(weightValue) || weightValue <= 0) {
        toast.error("Please enter a valid weight.");
        setIsCalculating(false);
        return;
      }
      
      if (isNaN(heightValue) || heightValue <= 0) {
        toast.error("Please enter a valid height.");
        setIsCalculating(false);
        return;
      }
      
      // Calculate BMR using Mifflin-St Jeor Equation
      let bmr;
      if (gender === "male") {
        bmr = 10 * weightValue + 6.25 * heightValue - 5 * ageValue + 5;
      } else {
        bmr = 10 * weightValue + 6.25 * heightValue - 5 * ageValue - 161;
      }
      
      // Calculate TDEE based on activity level
      let activityMultiplier;
      switch (activityLevel) {
        case "sedentary":
          activityMultiplier = 1.2;
          break;
        case "light":
          activityMultiplier = 1.375;
          break;
        case "moderate":
          activityMultiplier = 1.55;
          break;
        case "active":
          activityMultiplier = 1.725;
          break;
        case "veryActive":
          activityMultiplier = 1.9;
          break;
        default:
          activityMultiplier = 1.2;
      }
      
      const tdee = bmr * activityMultiplier;
      
      // Calculate calorie goals
      const maintenance = Math.round(tdee);
      const cutting = Math.round(tdee * 0.8); // 20% deficit
      const bulking = Math.round(tdee * 1.15); // 15% surplus
      
      // Simulate a small delay for feedback
      setTimeout(() => {
        setResults({
          bmr: Math.round(bmr),
          tdee: Math.round(tdee),
          maintenance,
          cutting,
          bulking
        });
        setIsCalculating(false);
        toast.success("BMR calculated successfully!");
      }, 600);
    } catch (error) {
      setIsCalculating(false);
      toast.error("Error calculating BMR. Please check your inputs.");
      console.error("BMR calculation error:", error);
    }
  };

  const resetCalculator = () => {
    setAge("");
    setWeight("");
    setHeight("");
    setGender("male");
    setActivityLevel("sedentary");
    setResults(null);
  };

  return (
    <>
      <Helmet>
        <title>BMR Calculator | Calculate Basal Metabolic Rate | MultitoolSet</title>
        <meta name="description" content="Calculate your Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) with our free online BMR calculator. Get personalized calorie goals." />
        <meta name="keywords" content="bmr calculator, basal metabolic rate, tdee calculator, calorie calculator, metabolism calculator, weight loss calculator, fitness calculator" />
        <link rel="canonical" href="https://multitoolset.com/tools/bmr-calculator" />
        <meta property="og:title" content="BMR Calculator | Calculate Basal Metabolic Rate" />
        <meta property="og:description" content="Calculate your Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) to determine your daily calorie needs." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/bmr-calculator" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="BMR Calculator | Calculate Basal Metabolic Rate" />
        <meta name="twitter:description" content="Calculate your Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) to determine your daily calorie needs." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "BMR Calculator",
              "description": "Calculate your Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) to determine your daily calorie needs.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What is BMR (Basal Metabolic Rate)?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "BMR (Basal Metabolic Rate) is the number of calories your body needs to maintain basic physiological functions while at complete rest. This includes breathing, circulation, cell production, nutrient processing, and protein synthesis."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is TDEE and how is it different from BMR?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "TDEE (Total Daily Energy Expenditure) is the total number of calories you burn in a day, including your BMR plus additional calories burned through physical activity and digestion. While BMR represents your resting calorie needs, TDEE accounts for your complete daily energy requirements."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How accurate are BMR calculators?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "BMR calculators provide a reasonable estimate but may have a margin of error of 5-10% compared to laboratory methods. Factors like genetics, body composition, and medical conditions can affect your actual BMR. For more precise measurements, consider consulting with healthcare professionals."
                  }
                }
              ]
            }
          `}
        </script>
        <meta name="robots" content="index, follow" />
      </Helmet>
    
      <ToolLayout
        title="BMR Calculator"
        description="Calculate your Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) to determine your daily calorie needs."
        helpText="Enter your age, gender, weight, height, and activity level to calculate your BMR, TDEE, and personalized calorie goals."
      >
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="calculate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculate">Calculate BMR</TabsTrigger>
                <TabsTrigger value="about">About BMR</TabsTrigger>
              </TabsList>
              
              <TabsContent value="calculate" className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="unitSystem">Unit System</Label>
                    <Select
                      value={unitSystem}
                      onValueChange={setUnitSystem}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit system" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric (kg, cm)</SelectItem>
                        <SelectItem value="imperial">Imperial (lb, in)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="gender">Gender</Label>
                    <Select
                      value={gender}
                      onValueChange={setGender}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="1"
                      max="120"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter your weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="1"
                      step="0.1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="height">Height ({unitSystem === "metric" ? "cm" : "in"})</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder={`Enter your height in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      min="1"
                      step="0.1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="activityLevel">Activity Level</Label>
                    <Select
                      value={activityLevel}
                      onValueChange={setActivityLevel}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select activity level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                        <SelectItem value="light">Light (exercise 1-3 days/week)</SelectItem>
                        <SelectItem value="moderate">Moderate (exercise 3-5 days/week)</SelectItem>
                        <SelectItem value="active">Active (exercise 6-7 days/week)</SelectItem>
                        <SelectItem value="veryActive">Very Active (hard exercise daily)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={calculateBMR} 
                      className="flex-1"
                      disabled={isCalculating}
                    >
                      {isCalculating ? "Calculating..." : "Calculate BMR"}
                    </Button>
                    <Button variant="outline" onClick={resetCalculator}>Reset</Button>
                  </div>
                  
                  {results && (
                    <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-900/50 dark:border-slate-800">
                      <h3 className="font-semibold text-lg mb-4">Your Results</h3>
                      
                      <div className="space-y-6">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Basal Metabolic Rate (BMR)</span>
                            <span className="text-sm font-medium">{results.bmr} calories/day</span>
                          </div>
                          <Progress 
                            value={80} 
                            className="h-2" 
                            indicatorClassName="bg-blue-500"
                          />
                          <p className="text-xs text-gray-500 mt-1">Calories needed at complete rest</p>
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Total Daily Energy Expenditure (TDEE)</span>
                            <span className="text-sm font-medium">{results.tdee} calories/day</span>
                          </div>
                          <Progress 
                            value={100} 
                            className="h-2" 
                            indicatorClassName="bg-green-500"
                          />
                          <p className="text-xs text-gray-500 mt-1">Total calories with activity level</p>
                        </div>
                        
                        <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                          <h4 className="font-medium mb-3">Daily Calorie Goals</h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="p-3 bg-blue-50 rounded border dark:bg-blue-900/20 dark:border-blue-900/30">
                              <p className="text-sm text-gray-600 dark:text-gray-400">Weight Loss</p>
                              <p className="text-xl font-bold">{results.cutting} cal</p>
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">Calorie deficit</p>
                            </div>
                            <div className="p-3 bg-green-50 rounded border dark:bg-green-900/20 dark:border-green-900/30">
                              <p className="text-sm text-gray-600 dark:text-gray-400">Maintenance</p>
                              <p className="text-xl font-bold">{results.maintenance} cal</p>
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">Stay at current weight</p>
                            </div>
                            <div className="p-3 bg-purple-50 rounded border dark:bg-purple-900/20 dark:border-purple-900/30">
                              <p className="text-sm text-gray-600 dark:text-gray-400">Weight Gain</p>
                              <p className="text-xl font-bold">{results.bulking} cal</p>
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">Calorie surplus</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="about" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">What is BMR?</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Basal Metabolic Rate (BMR) is the number of calories your body needs to maintain basic physiological functions while at complete rest. This includes breathing, circulation, cell production, nutrient processing, and protein synthesis.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">BMR vs TDEE</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    While BMR represents your resting calorie needs, TDEE (Total Daily Energy Expenditure) accounts for your complete daily energy requirements including physical activity. Your TDEE is calculated by multiplying your BMR by an activity factor.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">BMR Formula</h3>
                  <p className="text-gray-700 dark:text-gray-300 mb-2">
                    This calculator uses the Mifflin-St Jeor Equation, which is considered one of the most accurate formulas:
                  </p>
                  <div className="bg-slate-100 p-3 rounded-md dark:bg-slate-800">
                    <p className="font-mono text-sm">
                      For men: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) + 5
                    </p>
                    <p className="font-mono text-sm">
                      For women: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) - 161
                    </p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Activity Level Multipliers</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full mt-2 border-collapse">
                      <thead>
                        <tr className="bg-slate-100 dark:bg-slate-800">
                          <th className="p-2 text-left border dark:border-slate-700">Activity Level</th>
                          <th className="p-2 text-left border dark:border-slate-700">Description</th>
                          <th className="p-2 text-left border dark:border-slate-700">Multiplier</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Sedentary</td>
                          <td className="p-2 border dark:border-slate-700">Little or no exercise</td>
                          <td className="p-2 border dark:border-slate-700">1.2</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Light</td>
                          <td className="p-2 border dark:border-slate-700">Exercise 1-3 days/week</td>
                          <td className="p-2 border dark:border-slate-700">1.375</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Moderate</td>
                          <td className="p-2 border dark:border-slate-700">Exercise 3-5 days/week</td>
                          <td className="p-2 border dark:border-slate-700">1.55</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Active</td>
                          <td className="p-2 border dark:border-slate-700">Exercise 6-7 days/week</td>
                          <td className="p-2 border dark:border-slate-700">1.725</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Very Active</td>
                          <td className="p-2 border dark:border-slate-700">Hard exercise daily or twice daily</td>
                          <td className="p-2 border dark:border-slate-700">1.9</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div className="py-2">
                  <h3 className="text-lg font-semibold mb-2">How to Use Your BMR Results</h3>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300 mt-1">
                    <li><strong>Weight Loss:</strong> Consume fewer calories than your TDEE (typically 15-20% deficit)</li>
                    <li><strong>Weight Maintenance:</strong> Consume calories equal to your TDEE</li>
                    <li><strong>Weight Gain:</strong> Consume more calories than your TDEE (typically 10-15% surplus)</li>
                    <li><strong>Healthy Range:</strong> Don't go below your BMR for extended periods</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/macro-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Macro Calculator</a>
              </li>
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Ideal Weight Calculator</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default BmrCalculator;
