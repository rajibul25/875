
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Lock, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const PasswordGenerator = () => {
  const [password, setPassword] = useState("");
  const [length, setLength] = useState(12);
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true
  });

  const generatePassword = () => {
    let chars = "";
    if (options.uppercase) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (options.lowercase) chars += "abcdefghijklmnopqrstuvwxyz";
    if (options.numbers) chars += "0123456789";
    if (options.symbols) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?";

    let result = "";
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(result);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(password);
      toast.success("Password copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy password");
    }
  };

  return (
    <ToolLayout
      title="Free Password Generator | Create Strong & Secure Passwords"
      description="Generate strong, secure passwords with custom requirements. Choose length, include symbols, numbers, and more for maximum security."
      helpText="Customize your password settings and click Generate to create a new password. Use the copy button to copy it to your clipboard."
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="length">
                Password Length
              </label>
              <Input
                id="length"
                type="number"
                min="4"
                max="100"
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full"
              />
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium">Options</label>
              <div className="space-y-2">
                {Object.entries(options).map(([key, value]) => (
                  <div key={key} className="flex items-center space-x-2">
                    <Checkbox
                      id={key}
                      checked={value}
                      onCheckedChange={(checked) =>
                        setOptions((prev) => ({ ...prev, [key]: checked === true }))
                      }
                    />
                    <label htmlFor={key} className="text-sm font-medium capitalize">
                      Include {key}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <Button 
              onClick={generatePassword}
              className="w-full"
              size="lg"
            >
              <Lock className="w-4 h-4 mr-2" />
              Generate Password
            </Button>

            {password && (
              <div className="mt-4 space-y-4">
                <div className="relative">
                  <Input
                    value={password}
                    readOnly
                    className="w-full pr-24 font-mono text-lg"
                  />
                  <div className="absolute right-1 top-1 flex space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={copyToClipboard}
                      className="h-7"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={generatePassword}
                      className="h-7"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-4">Password Strength Tips</h2>
            <div className="prose dark:prose-invert max-w-none">
              <ul className="list-disc pl-5 space-y-2">
                <li>Use a minimum of 12 characters</li>
                <li>Include uppercase and lowercase letters</li>
                <li>Add numbers and special characters</li>
                <li>Avoid personal information</li>
                <li>Use unique passwords for each account</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Are these passwords secure?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Yes, our password generator uses a cryptographically secure random number generator to create unpredictable passwords.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">How often should I change my password?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  It's recommended to change passwords every 3-6 months, or immediately if you suspect a security breach.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolLayout>
  );
};

export default PasswordGenerator;
