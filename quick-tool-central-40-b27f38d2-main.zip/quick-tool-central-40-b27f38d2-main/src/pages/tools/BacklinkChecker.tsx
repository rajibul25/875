
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Search, Copy, Download, AlertCircle, ExternalLink, Link } from "lucide-react";
import { toast } from "sonner";
import AdBanner from "@/components/AdBanner";
import { Badge } from "@/components/ui/badge";

interface Backlink {
  id: number;
  url: string;
  title: string;
  domain: string;
  authority: number; // 0-100
  dofollow: boolean;
  firstSeen: string;
}

interface BacklinkResults {
  domain: string;
  totalBacklinks: number;
  uniqueDomains: number;
  domainAuthority: number; // 0-100
  backlinks: Backlink[];
}

// Mock data generator for demonstration purposes
const generateMockBacklinkData = (domain: string): BacklinkResults => {
  const totalBacklinks = Math.floor(Math.random() * 500) + 50;
  const uniqueDomains = Math.floor(Math.random() * 100) + 10;
  const domainAuthority = Math.floor(Math.random() * 70) + 20;
  
  const backlinks: Backlink[] = [];
  
  const randomDomains = [
    "example.com", "blog.example.org", "news.example.net", 
    "reference-site.com", "industry-blog.org", "news-site.co", 
    "tech-blog.io", "review-site.net", "forum.example.org",
    "social-media.com"
  ];
  
  const randomTitles = [
    "Great Resources About", "Top 10 Tools Including", 
    "Guide to Understanding", "How to Use", "Review of",
    "Best Practices for", "Ultimate Guide to", "Case Study:",
    "Industry News About", "Comparison of Leading"
  ];
  
  for (let i = 0; i < 10; i++) {
    const randomDomain = randomDomains[Math.floor(Math.random() * randomDomains.length)];
    const randomTitle = randomTitles[Math.floor(Math.random() * randomTitles.length)] + " " + domain;
    
    backlinks.push({
      id: i + 1,
      url: `https://${randomDomain}/page-${i + 1}`,
      title: randomTitle,
      domain: randomDomain,
      authority: Math.floor(Math.random() * 100),
      dofollow: Math.random() > 0.3, // 70% chance of being dofollow
      firstSeen: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    });
  }
  
  return {
    domain,
    totalBacklinks,
    uniqueDomains,
    domainAuthority,
    backlinks
  };
};

const BacklinkChecker = () => {
  const [domain, setDomain] = useState("");
  const [results, setResults] = useState<BacklinkResults | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const checkBacklinks = () => {
    if (!domain.trim()) {
      setError("Please enter a domain to check backlinks");
      return;
    }

    // Basic domain validation
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain.trim())) {
      setError("Please enter a valid domain (e.g., example.com)");
      return;
    }

    setIsLoading(true);
    setError("");

    // Simulate API call with timeout
    setTimeout(() => {
      try {
        // In a real implementation, this would be an API call to a backlink service
        const backlinkData = generateMockBacklinkData(domain.trim());
        setResults(backlinkData);
        setIsLoading(false);
      } catch (err) {
        setError("Error checking backlinks. Please try again.");
        setIsLoading(false);
      }
    }, 1500);
  };

  const copyToClipboard = () => {
    if (!results) return;
    
    const textToCopy = `
Backlink Analysis for ${results.domain}:
- Total Backlinks: ${results.totalBacklinks}
- Unique Referring Domains: ${results.uniqueDomains}
- Domain Authority: ${results.domainAuthority}/100

Top Backlinks:
${results.backlinks.map(link => `- ${link.url} (${link.dofollow ? 'Dofollow' : 'Nofollow'}, DA: ${link.authority})`).join('\n')}
`.trim();
    
    navigator.clipboard.writeText(textToCopy);
    toast.success("Backlink analysis results copied to clipboard!");
  };

  const downloadResults = () => {
    if (!results) return;
    
    const content = JSON.stringify(results, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'backlink-analysis-results.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success("Backlink analysis results downloaded as JSON!");
  };

  const visitDomain = () => {
    if (!domain) return;
    window.open(`https://${domain.trim()}`, '_blank');
  };

  // Helper function to get color based on authority score
  const getAuthorityColor = (score: number) => {
    if (score >= 80) return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300";
    if (score >= 50) return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300";
    if (score >= 30) return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300";
    return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300";
  };

  return (
    <ToolLayout
      title="Backlink Checker"
      description="Analyze backlinks and domain authority for any website"
      helpText="Enter a domain to check its backlinks, referring domains, and domain authority score. This tool helps you understand your website's link profile and SEO strength."
    >
      <div className="space-y-6">
        <Tabs defaultValue="check" className="w-full">
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="check">Check Backlinks</TabsTrigger>
          </TabsList>
          
          <TabsContent value="check" className="space-y-4 mt-4">
            <div className="flex flex-col md:flex-row gap-2">
              <Input
                type="text"
                placeholder="Enter domain (e.g., example.com)"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="flex-grow"
              />
              <Button 
                onClick={checkBacklinks} 
                disabled={isLoading}
                className="whitespace-nowrap"
              >
                <Search className="mr-2 h-4 w-4" />
                {isLoading ? "Checking..." : "Check Backlinks"}
              </Button>
            </div>
            
            <div className="text-sm text-muted-foreground">
              <p>Note: This is a demonstration tool with mock data for educational purposes only.</p>
            </div>
          </TabsContent>
        </Tabs>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-3 rounded-md flex items-center">
            <AlertCircle size={16} className="mr-2 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <AdBanner className="my-4" />

        {results && (
          <div className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Backlink Analysis for {results.domain}</h3>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadResults}>
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </Button>
                <Button variant="outline" size="sm" onClick={visitDomain}>
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Visit
                </Button>
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <h4 className="text-sm text-muted-foreground mb-1">Total Backlinks</h4>
                    <p className="text-3xl font-bold">{results.totalBacklinks.toLocaleString()}</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <h4 className="text-sm text-muted-foreground mb-1">Referring Domains</h4>
                    <p className="text-3xl font-bold">{results.uniqueDomains.toLocaleString()}</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <h4 className="text-sm text-muted-foreground mb-1">Domain Authority</h4>
                    <p className="text-3xl font-bold">{results.domainAuthority}/100</p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <div className="p-4 border-b">
                  <h4 className="font-semibold">Top Backlinks</h4>
                </div>
                <div className="divide-y">
                  {results.backlinks.map((backlink) => (
                    <div key={backlink.id} className="p-4 hover:bg-muted/50">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center">
                            <Link className="h-4 w-4 mr-2 text-blue-600" />
                            <a 
                              href={backlink.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="font-medium text-blue-600 hover:underline"
                            >
                              {backlink.title}
                            </a>
                          </div>
                          <p className="text-sm text-muted-foreground">{backlink.url}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className={backlink.dofollow ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300" : "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300"}>
                              {backlink.dofollow ? "Dofollow" : "Nofollow"}
                            </Badge>
                            <Badge className={getAuthorityColor(backlink.authority)}>
                              DA: {backlink.authority}
                            </Badge>
                            <span className="text-xs text-muted-foreground">First seen: {backlink.firstSeen}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
              <h4 className="font-medium mb-2">SEO Insights</h4>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li>Your domain has a {results.domainAuthority >= 50 ? "good" : "moderate"} authority score of {results.domainAuthority}/100.</li>
                <li>You have {results.totalBacklinks} backlinks from {results.uniqueDomains} unique domains.</li>
                <li>{Math.round((results.backlinks.filter(b => b.dofollow).length / results.backlinks.length) * 100)}% of your top backlinks are dofollow links, which pass SEO value.</li>
                <li>Consider building more quality backlinks from high-authority domains to improve your SEO.</li>
              </ul>
            </div>
            
            <AdBanner className="my-4" />
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

export default BacklinkChecker;
