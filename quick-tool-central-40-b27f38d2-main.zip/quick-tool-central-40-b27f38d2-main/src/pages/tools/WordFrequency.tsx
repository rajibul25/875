
import React, { useState, useMemo } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { BarChart3, Copy, Download, SortDesc, ArrowDownAZ, ArrowDownWideNarrow, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

// Common English stop words
const DEFAULT_STOP_WORDS = [
  "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "aren't", "as", "at",
  "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "can't", "cannot", "could",
  "couldn't", "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during", "each", "few", "for",
  "from", "further", "had", "hadn't", "has", "hasn't", "have", "haven't", "having", "he", "he'd", "he'll", "he's",
  "her", "here", "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i", "i'd", "i'll", "i'm",
  "i've", "if", "in", "into", "is", "isn't", "it", "it's", "its", "itself", "let's", "me", "more", "most", "mustn't",
  "my", "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought", "our", "ours",
  "ourselves", "out", "over", "own", "same", "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't",
  "so", "some", "such", "than", "that", "that's", "the", "their", "theirs", "them", "themselves", "then", "there",
  "there's", "these", "they", "they'd", "they'll", "they're", "they've", "this", "those", "through", "to", "too",
  "under", "until", "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're", "we've", "were", "weren't",
  "what", "what's", "when", "when's", "where", "where's", "which", "while", "who", "who's", "whom", "why", "why's",
  "with", "won't", "would", "wouldn't", "you", "you'd", "you'll", "you're", "you've", "your", "yours", "yourself",
  "yourselves"
];

interface WordFrequency {
  word: string;
  count: number;
  percentage: number;
}

const WordFrequency = () => {
  const [text, setText] = useState("");
  const [ignoreCase, setIgnoreCase] = useState(true);
  const [ignorePunctuation, setIgnorePunctuation] = useState(true);
  const [removeStopWords, setRemoveStopWords] = useState(false);
  const [minWordLength, setMinWordLength] = useState(1);
  const [sortBy, setSortBy] = useState<"frequency" | "alphabetical">("frequency");
  const [stopWordsList, setStopWordsList] = useState<string[]>(DEFAULT_STOP_WORDS);
  const [customStopWords, setCustomStopWords] = useState("");
  
  // Process text and calculate word frequency
  const wordFrequencies = useMemo(() => {
    if (!text) return [];
    
    // Process the text based on user settings
    let processedText = text;
    
    // Convert to lowercase if ignore case is set
    if (ignoreCase) {
      processedText = processedText.toLowerCase();
    }
    
    // Remove punctuation if ignore punctuation is set
    if (ignorePunctuation) {
      processedText = processedText.replace(/[^\p{L}\p{N}\s]/gu, " ");
    }
    
    // Split into words
    const words = processedText.split(/\s+/).filter(word => word);
    
    // Count frequency
    const wordCounts: Record<string, number> = {};
    const totalWords = words.length;
    
    words.forEach(word => {
      // Skip words shorter than minimum length
      if (word.length < minWordLength) return;
      
      // Skip stop words if enabled
      if (removeStopWords && stopWordsList.includes(word.toLowerCase())) return;
      
      wordCounts[word] = (wordCounts[word] || 0) + 1;
    });
    
    // Convert to array and sort
    const frequencyArray: WordFrequency[] = Object.entries(wordCounts).map(
      ([word, count]) => ({
        word,
        count,
        percentage: (count / totalWords) * 100
      })
    );
    
    // Sort based on user preference
    if (sortBy === "alphabetical") {
      return frequencyArray.sort((a, b) => a.word.localeCompare(b.word));
    } else {
      return frequencyArray.sort((a, b) => b.count - a.count);
    }
  }, [text, ignoreCase, ignorePunctuation, removeStopWords, minWordLength, stopWordsList, sortBy]);
  
  const totalUniqueWords = wordFrequencies.length;
  const totalWords = text ? text.split(/\s+/).filter(Boolean).length : 0;
  const topWords = wordFrequencies.slice(0, 10);
  
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };
  
  const handleMinLengthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMinWordLength(parseInt(e.target.value) || 1);
  };

  const updateStopWordsList = () => {
    const customList = customStopWords
      .split(/[\s,]+/)
      .filter(Boolean)
      .map(word => word.toLowerCase());
    
    setStopWordsList([...DEFAULT_STOP_WORDS, ...customList]);
    toast.success("Stop words list updated");
  };

  const resetToDefaultStopWords = () => {
    setStopWordsList(DEFAULT_STOP_WORDS);
    setCustomStopWords("");
    toast.success("Reset to default stop words");
  };

  const copyResults = () => {
    const result = wordFrequencies.map(({ word, count, percentage }) => 
      `${word}, ${count}, ${percentage.toFixed(2)}%`
    ).join("\n");
    
    navigator.clipboard.writeText(result);
    toast.success("Results copied to clipboard");
  };

  const downloadCsv = () => {
    // Create CSV content
    const headers = ["Word", "Count", "Percentage"];
    const rows = wordFrequencies.map(({ word, count, percentage }) => 
      [word, count, percentage.toFixed(2) + "%"]
    );
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");
    
    // Create and download the file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "word-frequency.csv");
    link.click();
    
    toast.success("CSV downloaded successfully");
  };

  return (
    <ToolLayout 
      title="Word Frequency Counter"
      description="Analyze and count word occurrences in your text"
      helpText="Enter text to analyze the frequency of each word and visualize the results."
    >
      <div className="space-y-6">
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here to analyze word frequency..."
            className="min-h-[200px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
          />
          <div className="p-3 bg-muted/20 border-t flex flex-wrap justify-between items-center gap-y-2">
            <div className="flex gap-2 flex-wrap">
              <Badge variant="secondary">{totalWords} total words</Badge>
              <Badge variant="secondary">{totalUniqueWords} unique words</Badge>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={copyResults}
                disabled={!wordFrequencies.length}
              >
                <Copy className="h-4 w-4 mr-2" /> Copy Results
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={downloadCsv}
                disabled={!wordFrequencies.length}
              >
                <Download className="h-4 w-4 mr-2" /> Export CSV
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <h3 className="text-lg font-medium">Analysis Options</h3>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Switch
                  id="ignore-case"
                  checked={ignoreCase}
                  onCheckedChange={setIgnoreCase}
                />
                <Label htmlFor="ignore-case">Ignore case</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="ignore-punctuation"
                  checked={ignorePunctuation}
                  onCheckedChange={setIgnorePunctuation}
                />
                <Label htmlFor="ignore-punctuation">Ignore punctuation</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="remove-stop-words"
                  checked={removeStopWords}
                  onCheckedChange={setRemoveStopWords}
                />
                <Label htmlFor="remove-stop-words">Remove common stop words</Label>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="min-word-length">Minimum word length</Label>
              <Input
                id="min-word-length"
                type="number"
                min="1"
                max="10"
                value={minWordLength}
                onChange={handleMinLengthChange}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="sort-by">Sort results by</Label>
              <div className="flex gap-2">
                <Button
                  variant={sortBy === "frequency" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSortBy("frequency")}
                  className="flex-1"
                >
                  <ArrowDownWideNarrow className="h-4 w-4 mr-2" /> Frequency
                </Button>
                <Button
                  variant={sortBy === "alphabetical" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSortBy("alphabetical")}
                  className="flex-1"
                >
                  <ArrowDownAZ className="h-4 w-4 mr-2" /> Alphabetical
                </Button>
              </div>
            </div>
            
            {removeStopWords && (
              <div className="space-y-2">
                <Label htmlFor="custom-stop-words">Add custom stop words</Label>
                <div className="flex gap-2">
                  <Input
                    id="custom-stop-words"
                    placeholder="Enter words separated by commas or spaces"
                    value={customStopWords}
                    onChange={(e) => setCustomStopWords(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={updateStopWordsList}
                    className="flex-1"
                  >
                    Update Stop Words
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={resetToDefaultStopWords}
                    className="flex-shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  {stopWordsList.length} stop words active
                </p>
              </div>
            )}
          </div>
          
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Word Frequency Results</h3>
              <Badge variant="outline">{wordFrequencies.length} unique words found</Badge>
            </div>
            
            {wordFrequencies.length > 0 ? (
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rank</TableHead>
                      <TableHead>Word</TableHead>
                      <TableHead className="text-right">Count</TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {wordFrequencies.slice(0, 100).map((item, index) => (
                      <TableRow key={item.word}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell className="font-medium">{item.word}</TableCell>
                        <TableCell className="text-right">{item.count}</TableCell>
                        <TableCell className="text-right">{item.percentage.toFixed(2)}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-12 border rounded-lg bg-muted/5">
                <BarChart3 className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-muted-foreground">Enter text to analyze word frequency</p>
              </div>
            )}
            
            {wordFrequencies.length > 100 && (
              <p className="text-xs text-muted-foreground text-center">
                Showing top 100 out of {wordFrequencies.length} words. Export to CSV to see all results.
              </p>
            )}
            
            {topWords.length > 0 && (
              <div className="mt-6">
                <h4 className="text-base font-medium mb-2">Top 10 Words Visualization</h4>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={topWords}>
                      <XAxis dataKey="word" />
                      <YAxis />
                      <Tooltip />
                      <Bar 
                        dataKey="count" 
                        fill="var(--primary)" 
                        radius={[4, 4, 0, 0]} 
                        name="Occurrences" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the input field.</li>
            <li>Adjust the analysis options as needed:
              <ul className="list-disc pl-6 mt-1">
                <li><strong>Ignore case:</strong> Count "Word" and "word" as the same word.</li>
                <li><strong>Ignore punctuation:</strong> Remove commas, periods, etc.</li>
                <li><strong>Remove stop words:</strong> Filter out common words like "the," "and," etc.</li>
                <li><strong>Minimum word length:</strong> Ignore words shorter than this length.</li>
              </ul>
            </li>
            <li>View the word frequency results in the table and chart.</li>
            <li>Sort results by frequency or alphabetically.</li>
            <li>Export the results as CSV or copy to clipboard for further analysis.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">What are stop words?</h3>
              <p className="text-muted-foreground">Stop words are common words like "the," "and," "is," etc., that are often removed from text analysis because they appear frequently but carry little meaning for content analysis.</p>
            </div>
            <div>
              <h3 className="font-bold">How can I use word frequency analysis?</h3>
              <p className="text-muted-foreground">Word frequency analysis is useful for content optimization, identifying key themes in text, analyzing writing patterns, and improving SEO by understanding keyword density.</p>
            </div>
            <div>
              <h3 className="font-bold">What's the difference between "total words" and "unique words"?</h3>
              <p className="text-muted-foreground">"Total words" counts all words in your text, including repetitions. "Unique words" counts distinct words only once, regardless of how many times they appear.</p>
            </div>
            <div>
              <h3 className="font-bold">How many words can this tool analyze?</h3>
              <p className="text-muted-foreground">This tool can analyze texts with up to 100,000 words. For very large texts, processing may take a moment, and you might want to use the CSV export feature for comprehensive analysis.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default WordFrequency;
