
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save, ArrowRightLeft } from "lucide-react";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";

interface DiffResult {
  html: string;
  stats: {
    added: number;
    removed: number;
    unchanged: number;
  };
}

const TextDiffChecker = () => {
  const [text1, setText1] = useState("");
  const [text2, setText2] = useState("");
  const [diffResult, setDiffResult] = useState<DiffResult | null>(null);
  const [ignoreWhitespace, setIgnoreWhitespace] = useState(false);
  const [ignoreCase, setIgnoreCase] = useState(false);

  const handleText1Change = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText1(e.target.value);
  };

  const handleText2Change = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText2(e.target.value);
  };

  const swapTexts = () => {
    const temp = text1;
    setText1(text2);
    setText2(temp);
  };

  const compareTexts = () => {
    if (!text1.trim() || !text2.trim()) {
      toast.error("Please enter text in both fields to compare");
      return;
    }

    // Process texts based on options
    let processedText1 = text1;
    let processedText2 = text2;

    if (ignoreCase) {
      processedText1 = processedText1.toLowerCase();
      processedText2 = processedText2.toLowerCase();
    }

    if (ignoreWhitespace) {
      processedText1 = processedText1.replace(/\s+/g, ' ').trim();
      processedText2 = processedText2.replace(/\s+/g, ' ').trim();
    }

    // Simple diff algorithm
    const diff = simpleDiff(processedText1, processedText2);
    setDiffResult(diff);
  };

  // Simple diff algorithm that returns HTML with differences highlighted
  const simpleDiff = (text1: string, text2: string): DiffResult => {
    // Tokenize both texts by words and spaces
    const tokens1 = tokenize(text1);
    const tokens2 = tokenize(text2);

    // Initialize variables for diff HTML
    let html = '';
    let stats = {
      added: 0,
      removed: 0,
      unchanged: 0,
    };

    // Compare tokens
    let i = 0, j = 0;
    while (i < tokens1.length || j < tokens2.length) {
      // Case: tokens match
      if (i < tokens1.length && j < tokens2.length && tokens1[i] === tokens2[j]) {
        html += `<span class="diff-unchanged">${escapeHTML(tokens1[i])}</span>`;
        stats.unchanged++;
        i++;
        j++;
      }
      // Case: token only in text1 (removed)
      else if (i < tokens1.length && (j >= tokens2.length || !tokens2.includes(tokens1[i]))) {
        html += `<span class="diff-removed">${escapeHTML(tokens1[i])}</span>`;
        stats.removed++;
        i++;
      }
      // Case: token only in text2 (added)
      else {
        html += `<span class="diff-added">${escapeHTML(tokens2[j])}</span>`;
        stats.added++;
        j++;
      }
    }

    return { html, stats };
  };

  // Helper function to tokenize text into words and spaces
  const tokenize = (text: string): string[] => {
    return text.match(/\S+|\s+/g) || [];
  };

  // Helper function to escape HTML special characters
  const escapeHTML = (text: string): string => {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };

  // Function to compare texts line by line (for simpler display)
  const lineByLineDiff = (text1: string, text2: string) => {
    const lines1 = text1.split('\n');
    const lines2 = text2.split('\n');
    
    const result = [];
    const maxLines = Math.max(lines1.length, lines2.length);
    
    for (let i = 0; i < maxLines; i++) {
      const line1 = i < lines1.length ? lines1[i] : '';
      const line2 = i < lines2.length ? lines2[i] : '';
      
      let status = 'unchanged';
      if (line1 !== line2) {
        status = 'changed';
      }
      
      result.push({ line1, line2, status });
    }
    
    return result;
  };

  const copyDiffResult = () => {
    const diffText = diffResult?.html.replace(/<[^>]+>/g, '');
    navigator.clipboard.writeText(diffText || '');
    toast.success("Diff result copied to clipboard");
  };

  const downloadResult = () => {
    // Create a visual representation of the diff for download
    const lineByLine = lineByLineDiff(text1, text2);
    let content = "TEXT COMPARISON RESULT\n\n";
    content += "=".repeat(50) + "\n\n";
    
    lineByLine.forEach((line, index) => {
      content += `Line ${index + 1}:\n`;
      content += `Text 1: ${line.line1}\n`;
      content += `Text 2: ${line.line2}\n`;
      content += `Status: ${line.status}\n\n`;
    });
    
    content += "=".repeat(50) + "\n";
    content += `Added: ${diffResult?.stats.added || 0}\n`;
    content += `Removed: ${diffResult?.stats.removed || 0}\n`;
    content += `Unchanged: ${diffResult?.stats.unchanged || 0}\n`;
    
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "text-diff-result.txt";
    link.href = url;
    link.click();
    toast.success("Diff result downloaded successfully");
  };

  return (
    <ToolLayout 
      title="Text Diff Checker"
      description="Compare two texts and find differences between them"
      helpText="Enter two versions of text to identify additions, removals, and unchanged content."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="text1" className="text-lg font-medium">Original Text (Text A)</Label>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Enter or paste the first text here</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="text1"
                  placeholder="Enter or paste the original text here..."
                  className="min-h-[200px] resize-y"
                  value={text1}
                  onChange={handleText1Change}
                />
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="text2" className="text-lg font-medium">Modified Text (Text B)</Label>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Enter or paste the second text here</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="text2"
                  placeholder="Enter or paste the modified text here..."
                  className="min-h-[200px] resize-y"
                  value={text2}
                  onChange={handleText2Change}
                />
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center space-x-2">
              <Switch
                id="ignore-whitespace"
                checked={ignoreWhitespace}
                onCheckedChange={setIgnoreWhitespace}
              />
              <Label htmlFor="ignore-whitespace">Ignore whitespace</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="ignore-case"
                checked={ignoreCase}
                onCheckedChange={setIgnoreCase}
              />
              <Label htmlFor="ignore-case">Ignore case</Label>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" onClick={swapTexts}>
              <ArrowRightLeft className="h-4 w-4 mr-2" />
              Swap Texts
            </Button>
            
            <Button onClick={compareTexts}>
              Compare Texts
            </Button>
          </div>
        </div>
        
        {diffResult && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Comparison Results</CardTitle>
              <CardDescription>
                <div className="flex gap-6 mt-2">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-100 border border-green-500"></div>
                    <span>Added ({diffResult.stats.added})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-red-100 border border-red-500"></div>
                    <span>Removed ({diffResult.stats.removed})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-transparent border border-gray-300"></div>
                    <span>Unchanged ({diffResult.stats.unchanged})</span>
                  </div>
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div 
                className="p-4 border rounded-md bg-muted/10 whitespace-pre-wrap min-h-[200px] max-h-[400px] overflow-y-auto"
                dangerouslySetInnerHTML={{ 
                  __html: diffResult.html
                    .replace(/<span class="diff-added">(.*?)<\/span>/g, '<span style="background-color: rgb(220, 252, 231); color: rgb(22, 101, 52); border: 1px solid rgb(34, 197, 94);">$1</span>')
                    .replace(/<span class="diff-removed">(.*?)<\/span>/g, '<span style="background-color: rgb(254, 226, 226); color: rgb(153, 27, 27); border: 1px solid rgb(239, 68, 68); text-decoration: line-through;">$1</span>')
                    .replace(/<span class="diff-unchanged">(.*?)<\/span>/g, '<span>$1</span>')
                }}
              />
            </CardContent>
            <CardFooter className="justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={copyDiffResult}>
                <Copy className="h-4 w-4 mr-2" /> Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadResult}>
                <Save className="h-4 w-4 mr-2" /> Save
              </Button>
            </CardFooter>
          </Card>
        )}
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste the original text in the "Text A" field.</li>
            <li>Enter or paste the modified text in the "Text B" field.</li>
            <li>Select comparison options if needed (ignore whitespace or case).</li>
            <li>Click "Compare Texts" to see the differences highlighted.</li>
            <li>Added text will be highlighted in green, deleted text in red.</li>
            <li>Use the "Swap Texts" button to reverse the comparison direction if needed.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">What's the maximum text length this tool can handle?</h3>
              <p className="text-muted-foreground">This tool can handle texts up to 100,000 characters. For very large texts, the comparison may take a few seconds to complete.</p>
            </div>
            <div>
              <h3 className="font-bold">Why would I use the "Ignore whitespace" option?</h3>
              <p className="text-muted-foreground">The "Ignore whitespace" option is useful when comparing texts where spacing, tabs, or line breaks may differ but the actual content is the same. This is especially helpful for comparing code or formatted documents.</p>
            </div>
            <div>
              <h3 className="font-bold">How accurate is this diff checker?</h3>
              <p className="text-muted-foreground">Our tool uses a token-based comparison algorithm that's designed to identify differences at the word level. It's highly accurate for most text comparison needs, including documents, code snippets, and other textual content.</p>
            </div>
            <div>
              <h3 className="font-bold">Can I compare code with this tool?</h3>
              <p className="text-muted-foreground">Yes, this tool works well for comparing code snippets. For better results with code, you might want to enable the "Ignore whitespace" option to focus on actual code changes rather than formatting differences.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default TextDiffChecker;
