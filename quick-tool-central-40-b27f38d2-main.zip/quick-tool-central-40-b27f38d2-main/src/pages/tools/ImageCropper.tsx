
import { useState, useRef, useCallback } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Upload, Download, Crop, RefreshCcw } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";

const ImageCropperComponent = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [croppedImage, setCroppedImage] = useState<string | null>(null);
  const [cropWidth, setCropWidth] = useState<number>(300);
  const [cropHeight, setCropHeight] = useState<number>(300);
  const [maintainAspectRatio, setMaintainAspectRatio] = useState<boolean>(true);
  const [aspectRatio, setAspectRatio] = useState<number>(1);
  const [cropX, setCropX] = useState<number>(0);
  const [cropY, setCropY] = useState<number>(0);
  const [naturalWidth, setNaturalWidth] = useState<number>(0);
  const [naturalHeight, setNaturalHeight] = useState<number>(0);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const cropBoxRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setSelectedImage(dataUrl);
      setCroppedImage(null);
      
      // Reset crop position
      setCropX(0);
      setCropY(0);
      
      // Reset the input value so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast.success("Image loaded successfully");
    };
    reader.readAsDataURL(file);
  };

  const handleImageLoad = () => {
    if (!imageRef.current) return;
    
    const imgWidth = imageRef.current.naturalWidth;
    const imgHeight = imageRef.current.naturalHeight;
    
    setNaturalWidth(imgWidth);
    setNaturalHeight(imgHeight);
    
    // Set initial crop dimensions relative to image size
    const initialSize = Math.min(imgWidth, imgHeight) / 2;
    setCropWidth(initialSize);
    setCropHeight(initialSize);
  };

  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newWidth = parseInt(e.target.value);
    setCropWidth(newWidth);
    
    if (maintainAspectRatio) {
      setCropHeight(Math.round(newWidth / aspectRatio));
    }
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newHeight = parseInt(e.target.value);
    setCropHeight(newHeight);
    
    if (maintainAspectRatio) {
      setCropWidth(Math.round(newHeight * aspectRatio));
    }
  };

  const toggleAspectRatio = (checked: boolean) => {
    setMaintainAspectRatio(checked);
    
    if (checked) {
      const newRatio = cropWidth / cropHeight;
      setAspectRatio(newRatio);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    
    const containerRect = containerRef.current.getBoundingClientRect();
    
    setIsDragging(true);
    setDragStart({
      x: e.clientX - cropX,
      y: e.clientY - cropY
    });
  };

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !containerRef.current || !imageRef.current) return;
    
    const containerRect = containerRef.current.getBoundingClientRect();
    const scale = naturalWidth / imageRef.current.offsetWidth;
    
    // Calculate new position
    let newX = e.clientX - dragStart.x;
    let newY = e.clientY - dragStart.y;
    
    // Constrain to image bounds
    newX = Math.max(0, Math.min(newX, imageRef.current.offsetWidth - cropWidth / scale));
    newY = Math.max(0, Math.min(newY, imageRef.current.offsetHeight - cropHeight / scale));
    
    setCropX(newX);
    setCropY(newY);
  }, [isDragging, dragStart, cropWidth, cropHeight, naturalWidth]);

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const cropImage = () => {
    if (!selectedImage || !imageRef.current) return;

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions to crop size
    canvas.width = cropWidth;
    canvas.height = cropHeight;

    // Calculate scale factor between displayed image and original image
    const scale = naturalWidth / imageRef.current.offsetWidth;
    
    // Calculate crop position in original image coordinates
    const sourceX = cropX * scale;
    const sourceY = cropY * scale;
    const sourceWidth = cropWidth;
    const sourceHeight = cropHeight;

    // Draw cropped portion to canvas
    ctx.drawImage(
      imageRef.current,
      sourceX, sourceY, sourceWidth, sourceHeight,
      0, 0, cropWidth, cropHeight
    );

    // Convert canvas to data URL
    const croppedDataUrl = canvas.toDataURL("image/png");
    setCroppedImage(croppedDataUrl);
    toast.success("Image cropped successfully");
  };

  const downloadCroppedImage = () => {
    if (!croppedImage) return;
    
    const link = document.createElement("a");
    link.href = croppedImage;
    link.download = "cropped-image.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("Cropped image downloaded");
  };

  const resetCrop = () => {
    setCropX(0);
    setCropY(0);
    
    if (imageRef.current) {
      const initialSize = Math.min(naturalWidth, naturalHeight) / 2;
      setCropWidth(initialSize);
      setCropHeight(initialSize);
    }
    
    setCroppedImage(null);
  };

  return (
    <ToolLayout
      title="Online Image Cropper"
      description="Crop images to custom sizes with precision. Maintain aspect ratio, set exact dimensions, and download your cropped images."
      helpText="Upload an image, adjust the crop area, and download your perfectly cropped image. Great for social media profiles, thumbnails, and more."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">1. Upload an Image</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select Image</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              PNG, JPG, WebP, or JPEG files. Maximum size: 10MB.
            </p>
          </div>
        </div>

        {selectedImage && (
          <div>
            <h2 className="text-xl font-semibold mb-4">2. Crop Settings</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="crop-width" className="block mb-1">Width (px)</Label>
                <Input
                  id="crop-width"
                  type="number"
                  min="10"
                  max={naturalWidth}
                  value={cropWidth}
                  onChange={handleWidthChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="crop-height" className="block mb-1">Height (px)</Label>
                <Input
                  id="crop-height"
                  type="number"
                  min="10"
                  max={naturalHeight}
                  value={cropHeight}
                  onChange={handleHeightChange}
                  className="w-full"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2 mb-6">
              <Switch
                id="maintain-aspect"
                checked={maintainAspectRatio}
                onCheckedChange={toggleAspectRatio}
              />
              <Label htmlFor="maintain-aspect">Maintain aspect ratio</Label>
            </div>

            <div className="flex justify-center mb-4">
              <Button
                onClick={resetCrop}
                variant="outline"
                size="sm"
                className="flex items-center"
              >
                <RefreshCcw className="h-4 w-4 mr-1" /> Reset Crop
              </Button>
            </div>
            
            <h2 className="text-xl font-semibold mb-4">3. Adjust Crop Area</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Drag the crop box to position it precisely over the area you want to crop.
            </p>
            
            <div 
              ref={containerRef}
              className="relative mx-auto mb-6 border rounded-lg overflow-hidden"
              style={{ maxWidth: '100%', maxHeight: '500px' }}
            >
              <img
                ref={imageRef}
                src={selectedImage}
                alt="Image to crop"
                className="max-w-full h-auto"
                onLoad={handleImageLoad}
              />
              {imageRef.current && (
                <div
                  ref={cropBoxRef}
                  className="absolute border-2 border-white box-content cursor-move"
                  style={{
                    left: `${cropX}px`,
                    top: `${cropY}px`,
                    width: `${cropWidth / (naturalWidth / imageRef.current?.offsetWidth || 1)}px`,
                    height: `${cropHeight / (naturalHeight / imageRef.current?.offsetHeight || 1)}px`,
                    boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)'
                  }}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                />
              )}
            </div>

            <div className="flex justify-center mb-6">
              <Button 
                onClick={cropImage}
                className="flex items-center"
              >
                <Crop className="h-5 w-5 mr-2" />
                Crop Image
              </Button>
            </div>
          </div>
        )}

        {croppedImage && (
          <div>
            <h2 className="text-xl font-semibold mb-4">4. Cropped Result</h2>
            <Card className="p-4 mb-6">
              <div className="flex justify-center">
                <img
                  src={croppedImage}
                  alt="Cropped image"
                  className="max-w-full h-auto border rounded"
                />
              </div>
            </Card>

            <div className="flex justify-center">
              <Button
                onClick={downloadCroppedImage}
                variant="outline"
                className="flex items-center"
              >
                <Download className="h-5 w-5 mr-2" />
                Download Cropped Image
              </Button>
            </div>
          </div>
        )}

        <AdBanner />

        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What image formats can I crop?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Our image cropper supports common formats including PNG, JPG, JPEG, and WebP files. 
                Cropped images are downloaded as PNG files to ensure the highest quality.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Is there a size limit for images?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                We recommend keeping your image under 10MB for optimal performance. Larger files 
                may take longer to process or could cause issues on some devices.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Why should I maintain aspect ratio?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Maintaining aspect ratio ensures your cropped image won't appear stretched or distorted. 
                This is particularly important for social media profile pictures, logos, and any image 
                where proportions matter.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How accurate is the cropping?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Our cropping tool provides pixel-perfect accuracy. The dimensions you specify are exactly 
                what you'll get in the output image. You can precisely position the crop area to capture 
                exactly what you need.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What are common dimensions for social media images?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Common dimensions include: Profile pictures (usually square, e.g., 400×400px), 
                Facebook cover photos (851×315px), Instagram posts (1080×1080px for square), 
                Twitter header images (1500×500px), and YouTube thumbnails (1280×720px).
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const ImageCropper = withErrorBoundary(ImageCropperComponent, "image-cropper");

export default ImageCropper;
