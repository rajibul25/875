
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save } from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";

const CaseConverter = () => {
  const [inputText, setInputText] = useState("");
  const [convertedText, setConvertedText] = useState("");
  const [activeTab, setActiveTab] = useState("uppercase");

  const convertCase = (text: string, type: string): string => {
    switch (type) {
      case "uppercase":
        return text.toUpperCase();
      case "lowercase":
        return text.toLowerCase();
      case "sentenceCase":
        return text
          .toLowerCase()
          .replace(/(^\s*\w|[.!?]\s*\w)/g, (match) => match.toUpperCase());
      case "titleCase":
        return text
          .toLowerCase()
          .replace(/\b\w/g, (match) => match.toUpperCase());
      case "alternatingCase":
        return text
          .split("")
          .map((char, index) => index % 2 === 0 ? char.toLowerCase() : char.toUpperCase())
          .join("");
      case "inverseCase":
        return text
          .split("")
          .map(char => {
            if (char === char.toUpperCase()) return char.toLowerCase();
            return char.toUpperCase();
          })
          .join("");
      case "camelCase":
        return text
          .toLowerCase()
          .replace(/[^a-zA-Z0-9]+(.)/g, (_, char) => char.toUpperCase());
      case "pascalCase":
        return text
          .toLowerCase()
          .replace(/(^|[^a-zA-Z0-9])+(.)/g, (_, __, char) => char.toUpperCase());
      case "snakeCase":
        return text
          .toLowerCase()
          .replace(/\s+/g, "_")
          .replace(/[^a-zA-Z0-9_]/g, "");
      case "kebabCase":
        return text
          .toLowerCase()
          .replace(/\s+/g, "-")
          .replace(/[^a-zA-Z0-9-]/g, "");
      default:
        return text;
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    setInputText(newText);
    setConvertedText(convertCase(newText, activeTab));
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setConvertedText(convertCase(inputText, value));
  };

  const copyText = () => {
    navigator.clipboard.writeText(convertedText);
    toast.success("Converted text copied to clipboard");
  };

  const downloadText = () => {
    const blob = new Blob([convertedText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = `${activeTab}-text.txt`;
    link.href = url;
    link.click();
    toast.success("Converted text downloaded successfully");
  };

  return (
    <ToolLayout 
      title="Case Converter"
      description="Convert text to UPPERCASE, lowercase, Title Case, and more"
      helpText="Easily transform your text between different letter cases."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="input-text" className="text-lg font-medium">Input Text</Label>
            <div className="rounded-lg border shadow-sm">
              <Textarea
                id="input-text"
                placeholder="Enter or paste your text here..."
                className="min-h-[250px] p-4 text-base border-0 resize-y"
                value={inputText}
                onChange={handleInputChange}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="converted-text" className="text-lg font-medium">Converted Text</Label>
            <div className="rounded-lg border shadow-sm">
              <Textarea
                id="converted-text"
                className="min-h-[250px] p-4 text-base border-0 resize-y"
                value={convertedText}
                readOnly
              />
              <div className="p-3 bg-muted/20 border-t flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={copyText} disabled={!convertedText}>
                  <Copy className="h-4 w-4 mr-2" /> Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadText} disabled={!convertedText}>
                  <Save className="h-4 w-4 mr-2" /> Save
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="border rounded-lg p-4 space-y-4">
          <h3 className="font-medium text-lg">Choose Case Type</h3>
          
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="uppercase">UPPERCASE</TabsTrigger>
              <TabsTrigger value="lowercase">lowercase</TabsTrigger>
              <TabsTrigger value="sentenceCase">Sentence case</TabsTrigger>
              <TabsTrigger value="titleCase">Title Case</TabsTrigger>
              <TabsTrigger value="alternatingCase">aLtErNaTiNg</TabsTrigger>
            </TabsList>
            <div className="mt-4">
              <TabsList className="grid grid-cols-2 md:grid-cols-5">
                <TabsTrigger value="inverseCase">InVeRsE cAsE</TabsTrigger>
                <TabsTrigger value="camelCase">camelCase</TabsTrigger>
                <TabsTrigger value="pascalCase">PascalCase</TabsTrigger>
                <TabsTrigger value="snakeCase">snake_case</TabsTrigger>
                <TabsTrigger value="kebabCase">kebab-case</TabsTrigger>
              </TabsList>
            </div>
          </Tabs>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the input field.</li>
            <li>Select the desired case type from the tabs below.</li>
            <li>Your text will be automatically converted to the selected case.</li>
            <li>Use the Copy or Save buttons to export the converted text.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Case Types Explained</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">UPPERCASE</h3>
              <p className="text-muted-foreground">Converts all characters to capital letters.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">lowercase</h3>
              <p className="text-muted-foreground">Converts all characters to small letters.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Sentence case</h3>
              <p className="text-muted-foreground">Capitalizes the first letter of each sentence.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Title Case</h3>
              <p className="text-muted-foreground">Capitalizes the first letter of each word.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">aLtErNaTiNg cAsE</h3>
              <p className="text-muted-foreground">Alternates between lowercase and uppercase characters.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">InVeRsE cAsE</h3>
              <p className="text-muted-foreground">Inverts the case of each character.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">camelCase</h3>
              <p className="text-muted-foreground">Removes spaces and capitalizes each word except the first.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">PascalCase</h3>
              <p className="text-muted-foreground">Removes spaces and capitalizes the first letter of each word.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">snake_case</h3>
              <p className="text-muted-foreground">Replaces spaces with underscores and converts to lowercase.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">kebab-case</h3>
              <p className="text-muted-foreground">Replaces spaces with hyphens and converts to lowercase.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">Why would I need to convert text cases?</h3>
              <p className="text-muted-foreground">Different writing styles and programming conventions require specific text cases. For example, programming variables often use camelCase or snake_case, while titles typically use Title Case.</p>
            </div>
            <div>
              <h3 className="font-bold">Will the case converter work with special characters?</h3>
              <p className="text-muted-foreground">Yes, but case conversion only applies to letters. Numbers and special characters remain unchanged, though some case formats like snake_case may replace certain characters.</p>
            </div>
            <div>
              <h3 className="font-bold">Can I convert multiple texts at once?</h3>
              <p className="text-muted-foreground">Yes, you can paste multiple paragraphs or blocks of text, and all will be converted according to your selected case style.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default CaseConverter;
