
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calculator, Tag } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const DiscountCalculatorComponent = () => {
  const [originalPrice, setOriginalPrice] = useState<string>("");
  const [discountPercent, setDiscountPercent] = useState<string>("");
  const [result, setResult] = useState<{
    discountAmount: number;
    finalPrice: number;
    savedPercentage: number;
  } | null>(null);
  
  const calculateDiscount = () => {
    const price = parseFloat(originalPrice);
    const discount = parseFloat(discountPercent);
    
    if (isNaN(price) || isNaN(discount)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (price <= 0) {
      toast.error("Original price must be greater than zero");
      return;
    }
    
    if (discount < 0 || discount > 100) {
      toast.error("Discount percentage must be between 0 and 100");
      return;
    }
    
    const discountAmount = (price * discount) / 100;
    const finalPrice = price - discountAmount;
    const savedPercentage = (discountAmount / price) * 100;
    
    setResult({
      discountAmount,
      finalPrice,
      savedPercentage
    });
    
    toast.success("Discount calculated successfully!");
  };
  
  return (
    <ToolLayout
      title="Discount Calculator"
      description="Calculate the final price after applying a discount"
      helpText="Enter the original price and discount percentage to calculate the final price"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="originalPrice" className="block text-sm font-medium text-gray-700">
            Original Price
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500">$</span>
            </div>
            <Input
              id="originalPrice"
              type="number"
              value={originalPrice}
              onChange={(e) => setOriginalPrice(e.target.value)}
              placeholder="Enter original price"
              className="pl-8 w-full"
              step="0.01"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="discountPercent" className="block text-sm font-medium text-gray-700">
            Discount Percentage (%)
          </label>
          <div className="relative">
            <Input
              id="discountPercent"
              type="number"
              value={discountPercent}
              onChange={(e) => setDiscountPercent(e.target.value)}
              placeholder="Enter discount percentage"
              className="w-full"
              min="0"
              max="100"
              step="0.1"
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <span className="text-gray-500">%</span>
            </div>
          </div>
        </div>
        
        <Button 
          onClick={calculateDiscount}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!originalPrice || !discountPercent}
        >
          <Tag className="mr-2 h-4 w-4" /> Calculate Discount
        </Button>
        
        {result && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-4">Discount Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Original Price:</span>
                <span className="text-lg font-medium text-gray-700">
                  ${parseFloat(originalPrice).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Discount Amount:</span>
                <span className="text-lg font-medium text-green-600">
                  ${result.discountAmount.toFixed(2)} ({discountPercent}%)
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg shadow-sm">
                <span className="text-gray-700 font-medium">Final Price:</span>
                <span className="text-xl font-bold text-purple-600">
                  ${result.finalPrice.toFixed(2)}
                </span>
              </div>
              <div className="text-center mt-3 text-sm text-gray-600">
                You save ${result.discountAmount.toFixed(2)} ({result.savedPercentage.toFixed(1)}%)
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const DiscountCalculator = withErrorBoundary(DiscountCalculatorComponent, "discount-calculator");

export default DiscountCalculator;
