import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { 
  Globe, 
  ArrowRightLeft, 
  Copy, 
  RotateCw, 
  Volume2, 
  Check, 
  Star, 
  History, 
  Heart, 
  Upload, 
  Download, 
  Settings, 
  ClipboardPaste,
  LanguagesIcon,
  BookOpen
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import ChatBot from "@/components/ChatBot";

// Interface for languages
interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag?: string;
  popular?: boolean;
}

// Interface for translation history
interface TranslationHistory {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  timestamp: Date;
  isFavorite: boolean;
}

// Interface for phrases
interface Phrase {
  id: string;
  text: string;
  translation: string;
  category: string;
}

// Dummy translation function
const translateText = (text: string, from: string, to: string): Promise<string> => {
  return new Promise((resolve) => {
    // For demonstration purposes, we'll simulate a translation
    // In a real app, this would call a translation API
    
    setTimeout(() => {
      if (!text.trim()) {
        resolve("");
        return;
      }
      
      // Basic translations for demo purposes
      const basicTranslations: Record<string, Record<string, string>> = {
        en: {
          es: "Este es un ejemplo de texto traducido. Por favor, conecte una API de traducción real para traducciones precisas.",
          fr: "Ceci est un exemple de texte traduit. Veuillez connecter une véritable API de traduction pour des traductions précises.",
          de: "Dies ist ein Beispiel für übersetzten Text. Bitte verbinden Sie eine echte Übersetzungs-API für genaue Übersetzungen.",
          it: "Questo è un esempio di testo tradotto. Si prega di collegare una vera API di traduzione per traduzioni accurate.",
          zh: "这是翻译文本的示例。请连接真实的翻译 API 以获得准确的翻译。",
          ja: "これは翻訳されたテキストの例です。正確な翻訳を得るには、実際の翻訳 API を接続してください。",
          ru: "Это пример переведенного текста. Пожалуйста, подключите реальный API перевода для точных переводов.",
          pt: "Este é um exemplo de texto traduzido. Por favor, conecte uma API de tradução real para traduções precisas.",
          nl: "Dit is een voorbeeld van vertaalde tekst. Sluit een echte vertaal-API aan voor nauwkeurige vertalingen.",
          ar: "هذا مثال على النص المترجم. يرجى توصيل واجهة برمجة تطبيقات ترجمة حقيقية للحصول على ترجمات دقيقة."
        },
        es: {
          en: "This is an example of translated text. Please connect a real translation API for accurate translations.",
          fr: "Ceci est un exemple de texte traduit. Veuillez connecter une véritable API de traduction pour des traductions précises.",
          de: "Dies ist ein Beispiel für übersetzten Text. Bitte verbinden Sie eine echte Übersetzungs-API für genaue Übersetzungen."
        },
        fr: {
          en: "This is an example of translated text. Please connect a real translation API for accurate translations.",
          es: "Este es un ejemplo de texto traducido. Por favor, conecte una API de traducción real para traducciones precisas.",
          de: "Dies ist ein Beispiel für übersetzten Text. Bitte verbinden Sie eine echte Übersetzungs-API für genaue Übersetzungen."
        }
      };
      
      // If we have a basic translation for this language pair, use it
      if (basicTranslations[from] && basicTranslations[from][to]) {
        resolve(basicTranslations[from][to]);
        return;
      }
      
      // Otherwise, return a generic message about the translation
      resolve(`[Translation from ${from} to ${to}] ${text}\n\nThis is a demonstration. Please connect a real translation API for accurate translations.`);
    }, 1000); // Simulate network delay
  });
};

// List of supported languages
const LANGUAGES: Language[] = [
  { code: "en", name: "English", nativeName: "English", popular: true },
  { code: "es", name: "Spanish", nativeName: "Español", popular: true },
  { code: "fr", name: "French", nativeName: "Français", popular: true },
  { code: "de", name: "German", nativeName: "Deutsch", popular: true },
  { code: "it", name: "Italian", nativeName: "Italiano", popular: true },
  { code: "pt", name: "Portuguese", nativeName: "Português", popular: true },
  { code: "nl", name: "Dutch", nativeName: "Nederlands" },
  { code: "ru", name: "Russian", nativeName: "Русский", popular: true },
  { code: "zh", name: "Chinese", nativeName: "中文", popular: true },
  { code: "ja", name: "Japanese", nativeName: "日本語", popular: true },
  { code: "ko", name: "Korean", nativeName: "한국어" },
  { code: "ar", name: "Arabic", nativeName: "العربية", popular: true },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी", popular: true },
  { code: "bn", name: "Bengali", nativeName: "বাংলা" },
  { code: "ur", name: "Urdu", nativeName: "اردو" },
  { code: "tr", name: "Turkish", nativeName: "Türkçe" },
  { code: "pl", name: "Polish", nativeName: "Polski" },
  { code: "uk", name: "Ukrainian", nativeName: "Українська" },
  { code: "vi", name: "Vietnamese", nativeName: "Tiếng Việt" },
  { code: "th", name: "Thai", nativeName: "ไทย" },
  { code: "sv", name: "Swedish", nativeName: "Svenska" },
  { code: "no", name: "Norwegian", nativeName: "Norsk" },
  { code: "fi", name: "Finnish", nativeName: "Suomi" },
  { code: "da", name: "Danish", nativeName: "Dansk" },
  { code: "cs", name: "Czech", nativeName: "Čeština" },
  { code: "el", name: "Greek", nativeName: "Ελληνικά" },
  { code: "he", name: "Hebrew", nativeName: "עברית" },
  { code: "hu", name: "Hungarian", nativeName: "Magyar" },
  { code: "ro", name: "Romanian", nativeName: "Română" },
  { code: "sk", name: "Slovak", nativeName: "Slovenčina" },
  { code: "id", name: "Indonesian", nativeName: "Bahasa Indonesia" },
  { code: "ms", name: "Malay", nativeName: "Bahasa Melayu" }
];

// Common phrases by category
const COMMON_PHRASES: Phrase[] = [
  // Greetings
  { id: "1", text: "Hello", translation: "", category: "Greetings" },
  { id: "2", text: "Good morning", translation: "", category: "Greetings" },
  { id: "3", text: "Good afternoon", translation: "", category: "Greetings" },
  { id: "4", text: "Good evening", translation: "", category: "Greetings" },
  { id: "5", text: "Welcome", translation: "", category: "Greetings" },
  { id: "6", text: "How are you?", translation: "", category: "Greetings" },
  { id: "7", text: "I'm fine, thank you", translation: "", category: "Greetings" },
  { id: "8", text: "Nice to meet you", translation: "", category: "Greetings" },
  { id: "9", text: "Goodbye", translation: "", category: "Greetings" },
  { id: "10", text: "See you later", translation: "", category: "Greetings" },
  
  // Travel
  { id: "11", text: "Where is the bathroom?", translation: "", category: "Travel" },
  { id: "12", text: "How much does this cost?", translation: "", category: "Travel" },
  { id: "13", text: "I need a taxi", translation: "", category: "Travel" },
  { id: "14", text: "Can you help me?", translation: "", category: "Travel" },
  { id: "15", text: "I am lost", translation: "", category: "Travel" },
  { id: "16", text: "I don't understand", translation: "", category: "Travel" },
  { id: "17", text: "Do you speak English?", translation: "", category: "Travel" },
  { id: "18", text: "Where is the hotel?", translation: "", category: "Travel" },
  { id: "19", text: "I need a doctor", translation: "", category: "Travel" },
  { id: "20", text: "Can I have the bill, please?", translation: "", category: "Travel" },
  
  // Dining
  { id: "21", text: "I would like to order", translation: "", category: "Dining" },
  { id: "22", text: "What do you recommend?", translation: "", category: "Dining" },
  { id: "23", text: "I am vegetarian", translation: "", category: "Dining" },
  { id: "24", text: "I am allergic to...", translation: "", category: "Dining" },
  { id: "25", text: "Water, please", translation: "", category: "Dining" },
  { id: "26", text: "The food is delicious", translation: "", category: "Dining" },
  { id: "27", text: "Can I have the menu?", translation: "", category: "Dining" },
  { id: "28", text: "Cheers!", translation: "", category: "Dining" },
  
  // Emergency
  { id: "29", text: "Help!", translation: "", category: "Emergency" },
  { id: "30", text: "Call the police", translation: "", category: "Emergency" },
  { id: "31", text: "I need a doctor", translation: "", category: "Emergency" },
  { id: "32", text: "There's been an accident", translation: "", category: "Emergency" },
  { id: "33", text: "I've lost my passport", translation: "", category: "Emergency" },
  { id: "34", text: "I've lost my wallet", translation: "", category: "Emergency" },
  
  // Business
  { id: "35", text: "I have a meeting", translation: "", category: "Business" },
  { id: "36", text: "Let's discuss the proposal", translation: "", category: "Business" },
  { id: "37", text: "I agree with your points", translation: "", category: "Business" },
  { id: "38", text: "Can we reschedule?", translation: "", category: "Business" },
  { id: "39", text: "What's your email address?", translation: "", category: "Business" },
  { id: "40", text: "Here's my business card", translation: "", category: "Business" }
];

const LanguageTranslator = () => {
  const [sourceLanguage, setSourceLanguage] = useState("en");
  const [targetLanguage, setTargetLanguage] = useState("es");
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const [history, setHistory] = useState<TranslationHistory[]>([]);
  const [activeTab, setActiveTab] = useState("translator");
  const [selectedPhraseCategory, setSelectedPhraseCategory] = useState("Greetings");
  const [phraseSearchQuery, setPhraseSearchQuery] = useState("");
  const [phrases, setPhrases] = useState<Phrase[]>(COMMON_PHRASES);
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  
  const { toast } = useToast();
  
  // Load history from localStorage on initial render
  useEffect(() => {
    const savedHistory = localStorage.getItem("translationHistory");
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory).map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp)
        })));
      } catch (error) {
        console.error("Error parsing translation history:", error);
      }
    }
  }, []);
  
  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("translationHistory", JSON.stringify(history));
  }, [history]);
  
  // Handle language swap
  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };
  
  // Handle translation
  const handleTranslate = async () => {
    if (!sourceText.trim()) {
      toast({
        title: "Empty text",
        description: "Please enter some text to translate",
        variant: "destructive",
      });
      return;
    }
    
    setIsTranslating(true);
    
    try {
      // In a real app, we would call an API here
      const result = await translateText(sourceText, sourceLanguage, targetLanguage);
      
      setTranslatedText(result);
      
      // Add to history
      if (result && result !== translatedText) {
        const newHistoryItem: TranslationHistory = {
          id: Date.now().toString(),
          sourceText,
          translatedText: result,
          sourceLanguage,
          targetLanguage,
          timestamp: new Date(),
          isFavorite: false,
        };
        
        setHistory(prev => [newHistoryItem, ...prev.slice(0, 49)]); // Keep last 50 items
      }
      
      toast({
        title: "Translation completed",
        description: "Your text has been translated",
      });
    } catch (error) {
      toast({
        title: "Translation failed",
        description: "There was an error translating your text",
        variant: "destructive",
      });
    } finally {
      setIsTranslating(false);
    }
  };
  
  // Handle copy to clipboard
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Text has been copied to your clipboard",
    });
  };
  
  // Handle clearing text
  const handleClear = () => {
    setSourceText("");
    setTranslatedText("");
    setDetectedLanguage(null);
  };
  
  // Handle toggling favorite status
  const handleToggleFavorite = (id: string) => {
    setHistory(prev => 
      prev.map(item => 
        item.id === id ? { ...item, isFavorite: !item.isFavorite } : item
      )
    );
    
    const item = history.find(item => item.id === id);
    
    toast({
      title: item?.isFavorite ? "Removed from favorites" : "Added to favorites",
      description: item?.isFavorite 
        ? "Translation has been removed from favorites" 
        : "Translation has been added to favorites",
    });
  };
  
  // Handle loading a translation from history
  const handleLoadFromHistory = (item: TranslationHistory) => {
    setSourceLanguage(item.sourceLanguage);
    setTargetLanguage(item.targetLanguage);
    setSourceText(item.sourceText);
    setTranslatedText(item.translatedText);
    setActiveTab("translator");
    
    toast({
      title: "Loaded from history",
      description: "Translation has been loaded from your history",
    });
  };
  
  // Handle clearing history
  const handleClearHistory = () => {
    setHistory([]);
    
    toast({
      title: "History cleared",
      description: "Your translation history has been cleared",
    });
  };
  
  // Handle clearing favorites only
  const handleClearFavorites = () => {
    setHistory(prev => prev.map(item => ({ ...item, isFavorite: false })));
    
    toast({
      title: "Favorites cleared",
      description: "Your favorite translations have been cleared",
    });
  };
  
  // Handle text-to-speech
  const handleSpeak = (text: string, languageCode: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = languageCode;
      window.speechSynthesis.speak(utterance);
      
      toast({
        title: "Speaking",
        description: "Text is being spoken",
      });
    } else {
      toast({
        title: "Not supported",
        description: "Text-to-speech is not supported in your browser",
        variant: "destructive",
      });
    }
  };
  
  // Handle pasting from clipboard
  const handlePaste = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      setSourceText(clipboardText);
      
      toast({
        title: "Pasted from clipboard",
        description: "Text has been pasted from your clipboard",
      });
    } catch (error) {
      toast({
        title: "Paste failed",
        description: "Failed to read from clipboard. Please check your browser permissions.",
        variant: "destructive",
      });
    }
  };
  
  // Handle uploading a text file
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setSourceText(content);
      
      toast({
        title: "File uploaded",
        description: `Text from "${file.name}" has been loaded`,
      });
    };
    
    reader.onerror = () => {
      toast({
        title: "Upload failed",
        description: "Failed to read the text file",
        variant: "destructive",
      });
    };
    
    reader.readAsText(file);
    
    // Reset the input value so the same file can be uploaded again
    event.target.value = "";
  };
  
  // Handle downloading translated text
  const handleDownload = () => {
    if (!translatedText) {
      toast({
        title: "No translation",
        description: "Please translate some text first",
        variant: "destructive",
      });
      return;
    }
    
    const sourceLanguageName = LANGUAGES.find(lang => lang.code === sourceLanguage)?.name || sourceLanguage;
    const targetLanguageName = LANGUAGES.find(lang => lang.code === targetLanguage)?.name || targetLanguage;
    
    const element = document.createElement("a");
    const file = new Blob([translatedText], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `translation_${sourceLanguageName}_to_${targetLanguageName}_${Date.now()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Downloaded",
      description: "Translation has been downloaded as a text file",
    });
  };
  
  // Get filtered phrases based on search query and category
  const filteredPhrases = phrases.filter(phrase => {
    const matchesSearch = phrase.text.toLowerCase().includes(phraseSearchQuery.toLowerCase());
    const matchesCategory = selectedPhraseCategory === "All" || phrase.category === selectedPhraseCategory;
    return matchesSearch && matchesCategory;
  });
  
  // Get unique phrase categories
  const phraseCategories = ["All", ...Array.from(new Set(phrases.map(phrase => phrase.category)))];
  
  // Translate a phrase
  const handleTranslatePhrase = async (phrase: Phrase) => {
    try {
      const translation = await translateText(phrase.text, "en", targetLanguage);
      
      // Update the translation in the phrases list
      setPhrases(prev => 
        prev.map(p => 
          p.id === phrase.id ? { ...p, translation } : p
        )
      );
      
      // Set the phrase and translation in the main translator
      setSourceLanguage("en");
      setSourceText(phrase.text);
      setTranslatedText(translation);
      setActiveTab("translator");
      
      toast({
        title: "Phrase translated",
        description: "The phrase has been translated and loaded in the translator",
      });
    } catch (error) {
      toast({
        title: "Translation failed",
        description: "There was an error translating the phrase",
        variant: "destructive",
      });
    }
  };
  
  // Detect language (in a real app, this would use a language detection API)
  const handleDetectLanguage = () => {
    if (!sourceText.trim()) {
      toast({
        title: "Empty text",
        description: "Please enter some text to detect language",
        variant: "destructive",
      });
      return;
    }
    
    // For demonstration, we'll randomly pick a language
    const randomLanguage = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    setDetectedLanguage(randomLanguage.code);
    setSourceLanguage(randomLanguage.code);
    
    toast({
      title: "Language detected",
      description: `Detected language: ${randomLanguage.name} (${randomLanguage.nativeName})`,
    });
  };
  
  return (
    <>
      <Helmet>
        <title>Language Translator | Free Online Translation Tool - MultiToolSet</title>
        <meta
          name="description"
          content="Translate text between 30+ languages with our free online translator. Features include text-to-speech, saved translations, phrase dictionary, and file uploads."
        />
        <meta
          name="keywords"
          content="language translator, online translation, text translator, free translator, multilingual, phrase book, language learning"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/language-translator" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/language-translator" />
        <meta property="og:title" content="Language Translator | Free Online Translation Tool" />
        <meta property="og:description" content="Translate text between 30+ languages with our free online translator. Features include text-to-speech, saved translations, phrase dictionary, and file uploads." />
        <meta property="og:image" content="https://multitoolset.co/images/tools/language-translator.jpg" />
        
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://multitoolset.co/tools/language-translator" />
        <meta property="twitter:title" content="Language Translator | Free Online Translation Tool" />
        <meta property="twitter:description" content="Translate text between 30+ languages with our free online translator. Features include text-to-speech, saved translations, phrase dictionary, and file uploads." />
        <meta property="twitter:image" content="https://multitoolset.co/images/tools/language-translator.jpg" />
        
        {/* JSON-LD structured data */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Language Translator",
              "applicationCategory": "Communication",
              "operatingSystem": "Web",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "description": "Translate text between 30+ languages with our free online translator. Features include text-to-speech, saved translations, phrase dictionary, and file uploads.",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "138"
              },
              "featureList": [
                "Translation between 30+ languages",
                "Text-to-speech pronunciation",
                "Save and access translation history",
                "Phrase dictionary with common expressions",
                "Text file upload/download support",
                "Clipboard integration"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="mb-8">
            <BackButton className="mb-2" />
            <h1 className="text-3xl font-bold">Language Translator</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Translate text between multiple languages with ease
            </p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-1 md:grid-cols-3 w-full mb-6">
              <TabsTrigger value="translator" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                <span>Translator</span>
              </TabsTrigger>
              <TabsTrigger value="phrasebook" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>Phrase Dictionary</span>
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2">
                <History className="h-4 w-4" />
                <span>History</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="translator" className="space-y-6">
              <Card>
                <CardHeader className="pb-4">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="flex flex-col md:flex-row gap-2 md:gap-4 w-full md:w-auto">
                      <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Source language" />
                        </SelectTrigger>
                        <SelectContent>
                          <div className="max-h-[400px] overflow-y-auto px-1">
                            {LANGUAGES.map((lang) => (
                              <SelectItem key={`source-${lang.code}`} value={lang.code}>
                                <div className="flex items-center gap-2">
                                  <span>{lang.name}</span>
                                  <span className="text-gray-500 text-xs">
                                    ({lang.nativeName})
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                          </div>
                        </SelectContent>
                      </Select>
                      
                      <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={handleSwapLanguages}
                        className="hidden md:flex"
                      >
                        <ArrowRightLeft className="h-4 w-4" />
                      </Button>
                      
                      <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Target language" />
                        </SelectTrigger>
                        <SelectContent>
                          <div className="max-h-[400px] overflow-y-auto px-1">
                            {LANGUAGES.map((lang) => (
                              <SelectItem key={`target-${lang.code}`} value={lang.code}>
                                <div className="flex items-center gap-2">
                                  <span>{lang.name}</span>
                                  <span className="text-gray-500 text-xs">
                                    ({lang.nativeName})
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                          </div>
                        </SelectContent>
                      </Select>
                      
                      <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={handleSwapLanguages}
                        className="flex md:hidden"
                      >
                        <ArrowRightLeft className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="icon">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Options</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={handleDetectLanguage}>
                            <LanguagesIcon className="h-4 w-4 mr-2" />
                            Detect language
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handlePaste}>
                            <ClipboardPaste className="h-4 w-4 mr-2" />
                            Paste from clipboard
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <label className="flex items-center w-full cursor-pointer">
                              <Upload className="h-4 w-4 mr-2" />
                              Upload text file
                              <input
                                type="file"
                                className="hidden"
                                accept=".txt,.doc,.docx,.pdf"
                                onChange={handleFileUpload}
                              />
                            </label>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleDownload}>
                            <Download className="h-4 w-4 mr-2" />
                            Download translation
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="source-text">
                          <span className="flex items-center gap-1">
                            Source text
                            {detectedLanguage && (
                              <Badge variant="outline" className="ml-2">
                                Detected: {LANGUAGES.find(l => l.code === detectedLanguage)?.name}
                              </Badge>
                            )}
                          </span>
                        </Label>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleSpeak(sourceText, sourceLanguage)}
                            disabled={!sourceText}
                          >
                            <Volume2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleCopy(sourceText)}
                            disabled={!sourceText}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <Textarea
                        id="source-text"
                        placeholder="Enter text to translate"
                        value={sourceText}
                        onChange={(e) => setSourceText(e.target.value)}
                        className="min-h-[200px] font-sans"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="translated-text">
                          Translated text
                        </Label>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleSpeak(translatedText, targetLanguage)}
                            disabled={!translatedText}
                          >
                            <Volume2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleCopy(translatedText)}
                            disabled={!translatedText}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="relative">
                        <Textarea
                          id="translated-text"
                          placeholder="Translation will appear here"
                          value={translatedText}
                          readOnly
                          className="min-h-[200px] font-sans bg-gray-50 dark:bg-gray-800"
                        />
                        {isTranslating && (
                          <div className="absolute inset-0 bg-gray-50/80 dark:bg-gray-800/80 flex items-center justify-center">
                            <div className="flex flex-col items-center">
                              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Translating...</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={handleClear}>
                    <RotateCw className="h-4 w-4 mr-2" />
                    Clear
                  </Button>
                  <Button onClick={handleTranslate} disabled={isTranslating || !sourceText.trim()}>
                    <Globe className="h-4 w-4 mr-2" />
                    Translate
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Popular Language Pairs</CardTitle>
                  <CardDescription>
                    Quick access to commonly used language combinations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                    {[
                      { from: "en", to: "es" },
                      { from: "en", to: "fr" },
                      { from: "en", to: "de" },
                      { from: "en", to: "zh" },
                      { from: "en", to: "ja" },
                      { from: "en", to: "ru" },
                      { from: "es", to: "en" },
                      { from: "fr", to: "en" },
                      { from: "de", to: "en" },
                      { from: "zh", to: "en" },
                      { from: "ja", to: "en" },
                      { from: "ru", to: "en" }
                    ].map((pair, index) => {
                      const fromLang = LANGUAGES.find(l => l.code === pair.from);
                      const toLang = LANGUAGES.find(l => l.code === pair.to);
                      
                      if (!fromLang || !toLang) return null;
                      
                      return (
                        <Button
                          key={index}
                          variant="outline"
                          className="py-4 h-auto justify-start"
                          onClick={() => {
                            setSourceLanguage(pair.from);
                            setTargetLanguage(pair.to);
                          }}
                        >
                          <div className="flex flex-col items-start text-left">
                            <div className="flex items-center gap-1 text-sm">
                              <span>{fromLang.name}</span>
                              <ArrowRightLeft className="h-3 w-3 mx-1" />
                              <span>{toLang.name}</span>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {fromLang.nativeName} ↔ {toLang.nativeName}
                            </div>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="phrasebook" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Common Phrases and Expressions</CardTitle>
                  <CardDescription>
                    Quickly translate common phrases for travel, business, and everyday situations
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-col sm:flex-row justify-between gap-4">
                    <div className="flex-1">
                      <Input
                        placeholder="Search phrases..."
                        value={phraseSearchQuery}
                        onChange={(e) => setPhraseSearchQuery(e.target.value)}
                      />
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <Label htmlFor="phrase-category" className="whitespace-nowrap">
                        Category:
                      </Label>
                      <Select
                        value={selectedPhraseCategory}
                        onValueChange={setSelectedPhraseCategory}
                      >
                        <SelectTrigger id="phrase-category" className="w-[180px]">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {phraseCategories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <Label htmlFor="phrase-target-language" className="whitespace-nowrap">
                        Target:
                      </Label>
                      <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                        <SelectTrigger id="phrase-target-language" className="w-[180px]">
                          <SelectValue placeholder="Target language" />
                        </SelectTrigger>
                        <SelectContent>
                          {LANGUAGES.filter(lang => lang.code !== "en").map((lang) => (
                            <SelectItem key={`phrase-${lang.code}`} value={lang.code}>
                              {lang.name} ({lang.nativeName})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-3 max-h-[500px] overflow-y-auto pr-2">
                    {filteredPhrases.length > 0 ? (
                      filteredPhrases.map((phrase) => (
                        <Card key={phrase.id} className="overflow-hidden">
                          <div className="p-4">
                            <div className="flex justify-between">
                              <div>
                                <div className="font-medium">{phrase.text}</div>
                                <Badge variant="outline" className="mt-1">
                                  {phrase.category}
                                </Badge>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleTranslatePhrase(phrase)}
                              >
                                <Globe className="h-4 w-4 mr-1" />
                                <span>Translate</span>
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <BookOpen className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600 mb-2" />
                        <h3 className="text-lg font-medium">No phrases found</h3>
                        <p className="text-gray-500 dark:text-gray-400 mt-1">
                          Try changing your search query or category filter
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="history" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Translation History</CardTitle>
                      <CardDescription>
                        View and manage your previous translations
                      </CardDescription>
                    </div>
                    
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <RotateCw className="h-4 w-4 mr-2" />
                            Clear
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Clear History</DialogTitle>
                            <DialogDescription>
                              Choose what you want to clear from your translation history.
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="py-4">
                            <RadioGroup defaultValue="all">
                              <div className="flex items-center space-x-2 mb-2">
                                <RadioGroupItem value="all" id="all" />
                                <Label htmlFor="all">Clear all history</Label>
                              </div>
                              <div className="flex items-center space-x-2 mb-2">
                                <RadioGroupItem value="favorites" id="favorites" />
                                <Label htmlFor="favorites">Clear only favorites</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="non-favorites" id="non-favorites" />
                                <Label htmlFor="non-favorites">Clear non-favorites</Label>
                              </div>
                            </RadioGroup>
                          </div>
                          
                          <DialogFooter>
                            <Button variant="outline" onClick={() => document.body.click()}>
                              Cancel
                            </Button>
                            <Button
                              variant="destructive"
                              onClick={() => {
                                handleClearHistory();
                                document.body.click();
                              }}
                            >
                              Clear History
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {history.length > 0 ? (
                    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className={activeTab === "all" ? "bg-primary text-primary-foreground" : ""}
                          onClick={() => setActiveTab("all")}
                        >
                          All ({history.length})
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className={activeTab === "favorites" ? "bg-primary text-primary-foreground" : ""}
                          onClick={() => setActiveTab("favorites")}
                        >
                          <Star className="h-4 w-4 mr-1" />
                          Favorites ({history.filter(item => item.isFavorite).length})
                        </Button>
                      </div>
                      
                      <Separator />
                      
                      {history
                        .filter(item => activeTab !== "favorites" || item.isFavorite)
                        .map((item) => (
                          <div
                            key={item.id}
                            className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden"
                          >
                            <div className="p-4 space-y-3">
                              <div className="flex justify-between items-start">
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline">
                                    {LANGUAGES.find(l => l.code === item.sourceLanguage)?.name || item.sourceLanguage}
                                    {" → "}
                                    {LANGUAGES.find(l => l.code === item.targetLanguage)?.name || item.targetLanguage}
                                  </Badge>
                                  <span className="text-xs text-gray-500">
                                    {new Date(item.timestamp).toLocaleString()}
                                  </span>
                                </div>
                                
                                <div className="flex gap-1">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-8 w-8 p-0"
                                    onClick={() => handleToggleFavorite(item.id)}
                                  >
                                    {item.isFavorite ? (
                                      <Heart className="h-4 w-4 text-red-500 fill-red-500" />
                                    ) : (
                                      <Heart className="h-4 w-4" />
                                    )}
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-8 w-8 p-0"
                                    onClick={() => handleLoadFromHistory(item)}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <div>
                                  <div className="text-xs font-medium text-gray-500 mb-1">
                                    Source Text:
                                  </div>
                                  <p className="text-sm line-clamp-2">{item.sourceText}</p>
                                </div>
                                
                                <div>
                                  <div className="text-xs font-medium text-gray-500 mb-1">
                                    Translation:
                                  </div>
                                  <p className="text-sm line-clamp-2">{item.translatedText}</p>
                                </div>
                              </div>
                              
                              <div className="flex justify-end gap-2 pt-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 text-xs"
                                  onClick={() => handleCopy(item.sourceText)}
                                >
                                  <Copy className="h-3 w-3 mr-1" />
                                  Copy Source
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 text-xs"
                                  onClick={() => handleCopy(item.translatedText)}
                                >
                                  <Copy className="h-3 w-3 mr-1" />
                                  Copy Translation
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-7 text-xs"
                                  onClick={() => handleLoadFromHistory(item)}
                                >
                                  <span>Load</span>
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <History className="h-16 w-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
                      <h3 className="text-xl font-medium">No translation history</h3>
                      <p className="text-gray-500 dark:text-gray-400 mt-2 mb-6">
                        Your translation history will appear here
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => setActiveTab("translator")}
                      >
                        <Globe className="h-4 w-4 mr-2" />
                        Start Translating
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default LanguageTranslator;
