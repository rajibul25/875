
import { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Code, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CodeBeautifier = () => {
  const [inputCode, setInputCode] = useState("");
  const [outputCode, setOutputCode] = useState("");
  const [language, setLanguage] = useState("json");
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();

  const beautifyCode = () => {
    if (!inputCode.trim()) {
      toast({
        title: "No code to beautify",
        description: "Please enter some code first.",
        variant: "destructive",
      });
      return;
    }

    try {
      let formattedCode = inputCode;
      
      // Simple formatting logic for different languages
      if (language === "json") {
        formattedCode = JSON.stringify(JSON.parse(inputCode), null, 2);
      } else if (language === "html") {
        // Simple HTML formatting (actual implementation would be more complex)
        formattedCode = inputCode
          .replace(/></g, ">\n<")
          .replace(/\s+/g, " ")
          .replace(/ </g, "\n<");
      } else if (language === "css") {
        // Simple CSS formatting
        formattedCode = inputCode
          .replace(/\{/g, " {\n  ")
          .replace(/;/g, ";\n  ")
          .replace(/\}/g, "\n}\n");
      } else if (language === "javascript") {
        // For JavaScript we'd ideally use a library like prettier
        // This is a simplified version
        formattedCode = inputCode
          .replace(/\{/g, " {\n  ")
          .replace(/\}/g, "\n}\n")
          .replace(/;(?!\n)/g, ";\n  ");
      }
      
      setOutputCode(formattedCode);
      toast({
        title: "Code beautified successfully",
        description: "Your code has been formatted.",
      });
    } catch (error) {
      toast({
        title: "Error beautifying code",
        description: "Make sure your code syntax is valid.",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = () => {
    if (!outputCode) return;
    
    navigator.clipboard.writeText(outputCode);
    setIsCopied(true);
    
    toast({
      title: "Copied to clipboard",
      description: "The formatted code has been copied to your clipboard.",
    });
    
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <ToolLayout
      title="Code Beautifier"
      description="Beautify and format your code for better readability"
      helpText="Paste your code, select the language, and click 'Beautify' to format it. Supported languages include JSON, HTML, CSS, and JavaScript."
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">Input Code</h2>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="json">JSON</SelectItem>
                <SelectItem value="html">HTML</SelectItem>
                <SelectItem value="css">CSS</SelectItem>
                <SelectItem value="javascript">JavaScript</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Textarea
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            className="min-h-[300px] font-mono text-sm"
            placeholder={`Paste your ${language.toUpperCase()} code here...`}
          />
          
          <Button 
            onClick={beautifyCode} 
            className="mt-4 w-full"
            disabled={!inputCode.trim()}
          >
            <Code className="mr-2 h-4 w-4" />
            Beautify Code
          </Button>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">Formatted Code</h2>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={copyToClipboard}
              disabled={!outputCode}
            >
              {isCopied ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </>
              )}
            </Button>
          </div>
          
          <div className="bg-gray-100 dark:bg-gray-900 rounded-md p-4 min-h-[300px] overflow-auto">
            <pre className="font-mono text-sm whitespace-pre-wrap">
              {outputCode || "Your formatted code will appear here..."}
            </pre>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default CodeBeautifier;
