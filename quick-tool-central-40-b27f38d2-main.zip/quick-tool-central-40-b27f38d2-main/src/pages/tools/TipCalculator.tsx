
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calculator, DollarSign, Users } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const TipCalculatorComponent = () => {
  const [billAmount, setBillAmount] = useState<string>("");
  const [tipPercent, setTipPercent] = useState<string>("15");
  const [numPeople, setNumPeople] = useState<string>("1");
  const [result, setResult] = useState<{
    tipAmount: number;
    totalAmount: number;
    perPersonAmount: number;
  } | null>(null);
  
  const calculateTip = () => {
    const bill = parseFloat(billAmount);
    const tip = parseFloat(tipPercent);
    const people = parseInt(numPeople);
    
    if (isNaN(bill) || isNaN(tip) || isNaN(people)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (bill <= 0) {
      toast.error("Bill amount must be greater than zero");
      return;
    }
    
    if (people <= 0) {
      toast.error("Number of people must be at least 1");
      return;
    }
    
    const tipAmount = bill * (tip / 100);
    const totalAmount = bill + tipAmount;
    const perPersonAmount = totalAmount / people;
    
    setResult({
      tipAmount,
      totalAmount,
      perPersonAmount
    });
    
    toast.success("Tip calculated successfully!");
  };
  
  const tipPresets = [10, 15, 18, 20, 25];
  
  return (
    <ToolLayout
      title="Tip Calculator"
      description="Calculate the right tip amount for your restaurant bills"
      helpText="Enter the bill amount, tip percentage, and number of people to calculate the tip"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="billAmount" className="block text-sm font-medium text-gray-700">
            Bill Amount
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <DollarSign className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              id="billAmount"
              type="number"
              value={billAmount}
              onChange={(e) => setBillAmount(e.target.value)}
              placeholder="Enter bill amount"
              className="pl-10 w-full"
              step="0.01"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Tip Percentage
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {tipPresets.map(preset => (
              <button
                key={preset}
                type="button"
                className={`px-3 py-1 rounded-md ${
                  tipPercent === preset.toString()
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => setTipPercent(preset.toString())}
              >
                {preset}%
              </button>
            ))}
          </div>
          <Input
            id="tipPercent"
            type="number"
            value={tipPercent}
            onChange={(e) => setTipPercent(e.target.value)}
            placeholder="Enter tip percentage"
            className="w-full"
            min="0"
            max="100"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="numPeople" className="block text-sm font-medium text-gray-700">
            Number of People
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Users className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              id="numPeople"
              type="number"
              value={numPeople}
              onChange={(e) => setNumPeople(e.target.value)}
              placeholder="Enter number of people"
              className="pl-10 w-full"
              min="1"
            />
          </div>
        </div>
        
        <Button 
          onClick={calculateTip}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!billAmount}
        >
          <Calculator className="mr-2 h-4 w-4" /> Calculate Tip
        </Button>
        
        {result && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-4">Tip Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Tip Amount:</span>
                <span className="text-lg font-bold text-purple-600">
                  ${result.tipAmount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Total Amount:</span>
                <span className="text-lg font-bold text-purple-600">
                  ${result.totalAmount.toFixed(2)}
                </span>
              </div>
              {parseInt(numPeople) > 1 && (
                <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                  <span className="text-gray-700">Per Person:</span>
                  <span className="text-lg font-bold text-purple-600">
                    ${result.perPersonAmount.toFixed(2)}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const TipCalculator = withErrorBoundary(TipCalculatorComponent, "tip-calculator");

export default TipCalculator;
