
import { useState, useRef, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, Copy, Download, Image } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";

const ImageColorPickerComponent = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<{
    hex: string;
    rgb: string;
    hsl: string;
  } | null>(null);
  const [palette, setPalette] = useState<string[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setSelectedImage(dataUrl);
      setSelectedColor(null);
      
      // Reset the input value so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast.success("Image loaded successfully");
    };
    reader.readAsDataURL(file);
  };

  // When image loads, draw it on the canvas and extract color palette
  useEffect(() => {
    if (!selectedImage || !canvasRef.current || !imgRef.current) return;

    const img = imgRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    
    if (!ctx) return;

    img.onload = () => {
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
      
      // Extract a simple color palette
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      extractColorPalette(imageData);
    };
  }, [selectedImage]);

  // Simple function to extract a color palette
  // This is a basic implementation - a real tool would use more sophisticated algorithms
  const extractColorPalette = (imageData: ImageData) => {
    const pixelCount = imageData.width * imageData.height;
    const sampleSize = Math.max(1, Math.floor(pixelCount / 5000));
    const colorCounts: Record<string, number> = {};
    
    for (let i = 0; i < imageData.data.length; i += 4 * sampleSize) {
      const r = imageData.data[i];
      const g = imageData.data[i + 1];
      const b = imageData.data[i + 2];
      
      // Skip transparent pixels
      if (imageData.data[i + 3] < 128) continue;
      
      // Convert to hex and add to counts
      const hex = rgbToHex(r, g, b);
      colorCounts[hex] = (colorCounts[hex] || 0) + 1;
    }
    
    // Get the top colors
    const sortedColors = Object.entries(colorCounts)
      .sort((a, b) => b[1] - a[1])
      .map(entry => entry[0])
      .slice(0, 8);
    
    setPalette(sortedColors);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Get click position relative to the canvas
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    const x = Math.floor((e.clientX - rect.left) * scaleX);
    const y = Math.floor((e.clientY - rect.top) * scaleY);
    
    // Get pixel color
    const pixel = ctx.getImageData(x, y, 1, 1).data;
    const r = pixel[0];
    const g = pixel[1];
    const b = pixel[2];
    
    // Convert to different color formats
    const hex = rgbToHex(r, g, b);
    const rgb = `rgb(${r}, ${g}, ${b})`;
    const hsl = rgbToHsl(r, g, b);
    
    setSelectedColor({ hex, rgb, hsl });
    toast.success(`Color picked: ${hex}`);
  };

  // Convert RGB values to hex color string
  const rgbToHex = (r: number, g: number, b: number): string => {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
  };

  // Convert RGB values to HSL string
  const rgbToHsl = (r: number, g: number, b: number): string => {
    r /= 255;
    g /= 255;
    b /= 255;
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      
      h /= 6;
    }
    
    h = Math.round(h * 360);
    s = Math.round(s * 100);
    l = Math.round(l * 100);
    
    return `hsl(${h}, ${s}%, ${l}%)`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`Copied to clipboard: ${text}`);
  };

  const downloadPalette = () => {
    if (palette.length === 0) {
      toast.error("No color palette to download");
      return;
    }

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = 800;
    const height = 100;
    const colorWidth = width / palette.length;

    canvas.width = width;
    canvas.height = height;

    palette.forEach((color, index) => {
      ctx.fillStyle = color;
      ctx.fillRect(index * colorWidth, 0, colorWidth, height);
      
      // Add color code
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "12px Arial";
      ctx.textAlign = "center";
      ctx.fillText(color, (index * colorWidth) + (colorWidth / 2), height / 2);
    });

    const dataUrl = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = "color-palette.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success("Color palette downloaded");
  };

  return (
    <ToolLayout
      title="Image Color Picker"
      description="Extract hex, RGB, and HSL color codes from any image. Create color palettes and find the perfect colors for your designs."
      helpText="Upload an image and click anywhere on it to extract color values. You can also view and download a color palette generated from the image."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload an Image</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select Image</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              PNG, JPG, WebP, or SVG. Maximum size: 5MB.
            </p>
          </div>
        </div>

        {selectedImage && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Click on the Image to Pick a Color</h2>
            <div className="relative border rounded-lg overflow-hidden">
              <img 
                ref={imgRef}
                src={selectedImage} 
                alt="Selected for color picking"
                className="max-w-full h-auto hidden" 
              />
              <canvas 
                ref={canvasRef} 
                onClick={handleCanvasClick}
                className="max-w-full h-auto cursor-crosshair"
              />
            </div>
          </div>
        )}

        {selectedColor && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Selected Color</h2>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="md:w-1/4">
                <div 
                  className="w-full aspect-square rounded-lg border shadow-sm" 
                  style={{ backgroundColor: selectedColor.hex }}
                />
              </div>
              
              <div className="md:w-3/4 space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <span className="font-medium">HEX:</span>
                  <div className="flex items-center">
                    <span className="mr-2">{selectedColor.hex}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(selectedColor.hex)}
                      className="h-8 w-8 p-0"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <span className="font-medium">RGB:</span>
                  <div className="flex items-center">
                    <span className="mr-2">{selectedColor.rgb}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(selectedColor.rgb)}
                      className="h-8 w-8 p-0"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <span className="font-medium">HSL:</span>
                  <div className="flex items-center">
                    <span className="mr-2">{selectedColor.hsl}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(selectedColor.hsl)}
                      className="h-8 w-8 p-0"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {palette.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Color Palette</h2>
              <Button
                variant="outline"
                size="sm"
                onClick={downloadPalette}
              >
                <Download className="h-4 w-4 mr-1" /> Download Palette
              </Button>
            </div>
            
            <div className="grid grid-cols-4 md:grid-cols-8 gap-2 mb-4">
              {palette.map((color, index) => (
                <div 
                  key={index}
                  className="relative group aspect-square rounded-md cursor-pointer overflow-hidden border"
                  style={{ backgroundColor: color }}
                  onClick={() => copyToClipboard(color)}
                >
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center">
                    <span className="text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      {color}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Click on any color to copy its HEX code to clipboard.
            </p>
          </div>
        )}

        <AdBanner />

        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What is a color picker tool?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                A color picker tool allows you to identify and extract color codes from images. 
                It's useful for designers, developers, and anyone who needs to match colors 
                from an existing image or create a consistent color palette.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What's the difference between HEX, RGB, and HSL color formats?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                HEX is a six-digit code preceded by a # sign (e.g., #FF5733) commonly used in web design. 
                RGB uses three values for red, green, and blue components (e.g., rgb(255, 87, 51)). 
                HSL stands for Hue, Saturation, and Lightness (e.g., hsl(14, 100%, 60%)) and is often 
                considered more intuitive for color adjustments.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How accurate is the color extraction?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Our color picker extracts the exact color from the pixel you click on. The color palette 
                feature provides a simplified representation of dominant colors in the image. For the most 
                precise results, use images with clear, defined color areas.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What image formats are supported?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Our color picker supports common image formats including PNG, JPEG, WebP, and SVG files. 
                For best results, use uncompressed images to ensure color accuracy.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How can I use the color codes in my designs?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                You can copy any color code (HEX, RGB, or HSL) and use it in design software like 
                Adobe Photoshop, Illustrator, Figma, or in web development with CSS. The downloaded 
                color palette can be imported into many design tools or used as a reference.
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const ImageColorPicker = withErrorBoundary(ImageColorPickerComponent, "image-color-picker");

export default ImageColorPicker;
