
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { BrainCircuit, Calculator, RefreshCw } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const ScientificCalculatorComponent = () => {
  const [display, setDisplay] = useState<string>("0");
  const [input, setInput] = useState<string>("");
  const [memory, setMemory] = useState<number>(0);
  const [isRadians, setIsRadians] = useState<boolean>(true);
  const [isShift, setIsShift] = useState<boolean>(false);
  
  // Define calculator buttons
  const buttons = [
    { label: "C", action: "clear", className: "bg-red-100 hover:bg-red-200 text-red-600" },
    { label: "Del", action: "delete", className: "bg-orange-100 hover:bg-orange-200 text-orange-600" },
    { label: "%", action: "percent", className: "bg-gray-100 hover:bg-gray-200" },
    { label: "÷", action: "operator", value: "/", className: "bg-purple-100 hover:bg-purple-200 text-purple-600" },
    { label: "7", action: "number", value: "7", className: "bg-white hover:bg-gray-100" },
    { label: "8", action: "number", value: "8", className: "bg-white hover:bg-gray-100" },
    { label: "9", action: "number", value: "9", className: "bg-white hover:bg-gray-100" },
    { label: "×", action: "operator", value: "*", className: "bg-purple-100 hover:bg-purple-200 text-purple-600" },
    { label: "4", action: "number", value: "4", className: "bg-white hover:bg-gray-100" },
    { label: "5", action: "number", value: "5", className: "bg-white hover:bg-gray-100" },
    { label: "6", action: "number", value: "6", className: "bg-white hover:bg-gray-100" },
    { label: "-", action: "operator", value: "-", className: "bg-purple-100 hover:bg-purple-200 text-purple-600" },
    { label: "1", action: "number", value: "1", className: "bg-white hover:bg-gray-100" },
    { label: "2", action: "number", value: "2", className: "bg-white hover:bg-gray-100" },
    { label: "3", action: "number", value: "3", className: "bg-white hover:bg-gray-100" },
    { label: "+", action: "operator", value: "+", className: "bg-purple-100 hover:bg-purple-200 text-purple-600" },
    { label: "±", action: "negate", className: "bg-gray-100 hover:bg-gray-200" },
    { label: "0", action: "number", value: "0", className: "bg-white hover:bg-gray-100" },
    { label: ".", action: "decimal", className: "bg-gray-100 hover:bg-gray-200" },
    { label: "=", action: "calculate", className: "bg-purple-600 hover:bg-purple-700 text-white" },
  ];
  
  // Scientific buttons
  const scientificButtons = [
    { label: "sin", action: "function", value: "sin", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "cos", action: "function", value: "cos", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "tan", action: "function", value: "tan", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "Rad", action: "toggle-rad", className: isRadians ? "bg-green-600 text-white" : "bg-gray-100 hover:bg-gray-200" },
    { label: "π", action: "constant", value: Math.PI, className: "bg-indigo-100 hover:bg-indigo-200 text-indigo-600" },
    { label: "e", action: "constant", value: Math.E, className: "bg-indigo-100 hover:bg-indigo-200 text-indigo-600" },
    { label: "ln", action: "function", value: "ln", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "log", action: "function", value: "log", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "√", action: "function", value: "sqrt", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "^", action: "operator", value: "**", className: "bg-blue-100 hover:bg-blue-200 text-blue-600" },
    { label: "(", action: "parenthesis", value: "(", className: "bg-gray-100 hover:bg-gray-200" },
    { label: ")", action: "parenthesis", value: ")", className: "bg-gray-100 hover:bg-gray-200" },
    { label: "MC", action: "memory-clear", className: "bg-gray-100 hover:bg-gray-200 text-blue-600" },
    { label: "MR", action: "memory-recall", className: "bg-gray-100 hover:bg-gray-200 text-blue-600" },
    { label: "M+", action: "memory-add", className: "bg-gray-100 hover:bg-gray-200 text-blue-600" },
    { label: "M-", action: "memory-subtract", className: "bg-gray-100 hover:bg-gray-200 text-blue-600" },
  ];
  
  // Handle button clicks
  const handleButtonClick = (action: string, value?: string | number) => {
    switch (action) {
      case "number":
        if (display === "0" || display === "Error") {
          setDisplay(value as string);
          setInput(value as string);
        } else {
          setDisplay(prev => prev + value);
          setInput(prev => prev + value);
        }
        break;
        
      case "decimal":
        if (!display.includes(".")) {
          setDisplay(prev => prev + ".");
          setInput(prev => prev + ".");
        }
        break;
        
      case "operator":
        setDisplay(prev => prev + value);
        setInput(prev => prev + value);
        break;
        
      case "calculate":
        try {
          // For security, we use Function instead of eval
          const result = Function('"use strict"; return (' + input + ')')();
          setDisplay(String(result));
          setInput(String(result));
        } catch (error) {
          setDisplay("Error");
          setInput("");
          toast.error("Invalid calculation");
        }
        break;
        
      case "clear":
        setDisplay("0");
        setInput("");
        break;
        
      case "delete":
        if (display.length > 1) {
          setDisplay(prev => prev.slice(0, -1));
          setInput(prev => prev.slice(0, -1));
        } else {
          setDisplay("0");
          setInput("");
        }
        break;
        
      case "negate":
        try {
          const result = -parseFloat(display);
          setDisplay(String(result));
          setInput(String(result));
        } catch (error) {
          setDisplay("Error");
          toast.error("Invalid operation");
        }
        break;
        
      case "percent":
        try {
          const result = parseFloat(display) / 100;
          setDisplay(String(result));
          setInput(String(result));
        } catch (error) {
          setDisplay("Error");
          toast.error("Invalid operation");
        }
        break;
        
      case "function":
        try {
          let result;
          if (value === "sin") {
            const angle = parseFloat(display);
            result = isRadians ? Math.sin(angle) : Math.sin(angle * Math.PI / 180);
          } else if (value === "cos") {
            const angle = parseFloat(display);
            result = isRadians ? Math.cos(angle) : Math.cos(angle * Math.PI / 180);
          } else if (value === "tan") {
            const angle = parseFloat(display);
            result = isRadians ? Math.tan(angle) : Math.tan(angle * Math.PI / 180);
          } else if (value === "ln") {
            result = Math.log(parseFloat(display));
          } else if (value === "log") {
            result = Math.log10(parseFloat(display));
          } else if (value === "sqrt") {
            result = Math.sqrt(parseFloat(display));
          }
          setDisplay(String(result));
          setInput(String(result));
        } catch (error) {
          setDisplay("Error");
          toast.error("Invalid operation");
        }
        break;
        
      case "constant":
        setDisplay(String(value));
        setInput(String(value));
        break;
        
      case "toggle-rad":
        setIsRadians(prev => !prev);
        toast.info(isRadians ? "Switched to Degrees" : "Switched to Radians");
        break;
        
      case "memory-clear":
        setMemory(0);
        toast.info("Memory cleared");
        break;
        
      case "memory-recall":
        setDisplay(String(memory));
        setInput(String(memory));
        break;
        
      case "memory-add":
        try {
          setMemory(prev => prev + parseFloat(display));
          toast.info("Added to memory");
        } catch (error) {
          toast.error("Invalid operation");
        }
        break;
        
      case "memory-subtract":
        try {
          setMemory(prev => prev - parseFloat(display));
          toast.info("Subtracted from memory");
        } catch (error) {
          toast.error("Invalid operation");
        }
        break;
        
      case "parenthesis":
        setDisplay(prev => prev + value);
        setInput(prev => prev + value);
        break;
    }
  };
  
  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (/[0-9]/.test(e.key)) {
        handleButtonClick("number", e.key);
      } else if (e.key === ".") {
        handleButtonClick("decimal");
      } else if (["+", "-", "*", "/"].includes(e.key)) {
        handleButtonClick("operator", e.key);
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleButtonClick("calculate");
      } else if (e.key === "Escape") {
        handleButtonClick("clear");
      } else if (e.key === "Backspace") {
        handleButtonClick("delete");
      } else if (e.key === "(" || e.key === ")") {
        handleButtonClick("parenthesis", e.key);
      } else if (e.key === "^") {
        handleButtonClick("operator", "**");
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [input, display]);
  
  return (
    <ToolLayout
      title="Scientific Calculator"
      description="Perform advanced mathematical calculations with this scientific calculator"
      helpText="Use keyboard or click buttons to perform calculations"
    >
      <div className="max-w-md mx-auto">
        <div className="mb-4 bg-gray-100 p-4 rounded-lg">
          <div className="text-right text-xs text-gray-500 mb-1">{input || "0"}</div>
          <div className="text-right text-2xl font-bold overflow-x-auto">
            {display}
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-2 mb-4">
          {scientificButtons.map((button, index) => (
            <Button
              key={`sci-${index}`}
              className={button.className}
              onClick={() => handleButtonClick(button.action, button.value)}
            >
              {button.label}
            </Button>
          ))}
        </div>
        
        <div className="grid grid-cols-4 gap-2">
          {buttons.map((button, index) => (
            <Button
              key={index}
              className={button.className}
              onClick={() => handleButtonClick(button.action, button.value)}
            >
              {button.label}
            </Button>
          ))}
        </div>
        
        <div className="mt-6 text-xs text-center text-gray-500">
          <p className="flex items-center justify-center">
            <BrainCircuit className="h-3 w-3 mr-1" />
            {isRadians ? "Radians Mode" : "Degrees Mode"} | Memory: {memory}
          </p>
        </div>
      </div>
    </ToolLayout>
  );
};

const ScientificCalculator = withErrorBoundary(ScientificCalculatorComponent, "scientific-calculator");

export default ScientificCalculator;
