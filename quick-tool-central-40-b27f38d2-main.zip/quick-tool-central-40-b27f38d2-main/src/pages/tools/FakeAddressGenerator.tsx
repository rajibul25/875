import React, { useState, useRef } from "react";
import { Helmet } from "react-helmet";
import { MapPin, RefreshCw, Copy, Download, Check, Filter, Globe, Building, User, Mail, Phone, Trash2, Plus, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import ToolLayout from "@/components/tools/ToolLayout";

interface Address {
  name: string;
  streetAddress: string;
  city: string;
  state: string;
  stateAbbr: string;
  zipCode: string;
  country: string;
  countryCode: string;
  phoneNumber: string;
  emailAddress: string;
  username: string;
  company: string;
  jobTitle: string;
}

interface FilterOptions {
  includePhone: boolean;
  includeEmail: boolean;
  includeUsername: boolean;
  includeCompany: boolean;
  includeJobTitle: boolean;
  nameFormat: 'full' | 'firstLast' | 'lastFirst' | 'initial';
}

const FakeAddressGenerator = () => {
  const [quantity, setQuantity] = useState(1);
  const [country, setCountry] = useState("US");
  const [generatedAddresses, setGeneratedAddresses] = useState<Address[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState<{[key: string]: boolean}>({});
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    includePhone: true,
    includeEmail: true,
    includeUsername: false,
    includeCompany: false,
    includeJobTitle: false,
    nameFormat: 'full',
  });
  
  const addressesRef = useRef<HTMLDivElement>(null);
  
  const countries = [
    { code: "US", name: "United States" },
    { code: "CA", name: "Canada" },
    { code: "GB", name: "United Kingdom" },
    { code: "AU", name: "Australia" },
    { code: "DE", name: "Germany" },
    { code: "FR", name: "France" },
    { code: "ES", name: "Spain" },
    { code: "IT", name: "Italy" },
    { code: "JP", name: "Japan" },
    { code: "BR", name: "Brazil" },
    { code: "IN", name: "India" },
    { code: "MX", name: "Mexico" },
  ];
  
  const usStates = [
    { name: "Alabama", abbr: "AL" },
    { name: "Alaska", abbr: "AK" },
    { name: "Arizona", abbr: "AZ" },
    { name: "Arkansas", abbr: "AR" },
    { name: "California", abbr: "CA" },
    { name: "Colorado", abbr: "CO" },
    { name: "Connecticut", abbr: "CT" },
    { name: "Delaware", abbr: "DE" },
    { name: "Florida", abbr: "FL" },
    { name: "Georgia", abbr: "GA" },
    { name: "Hawaii", abbr: "HI" },
    { name: "Idaho", abbr: "ID" },
    { name: "Illinois", abbr: "IL" },
    { name: "Indiana", abbr: "IN" },
    { name: "Iowa", abbr: "IA" },
    { name: "Kansas", abbr: "KS" },
    { name: "Kentucky", abbr: "KY" },
    { name: "Louisiana", abbr: "LA" },
    { name: "Maine", abbr: "ME" },
    { name: "Maryland", abbr: "MD" },
    { name: "Massachusetts", abbr: "MA" },
    { name: "Michigan", abbr: "MI" },
    { name: "Minnesota", abbr: "MN" },
    { name: "Mississippi", abbr: "MS" },
    { name: "Missouri", abbr: "MO" },
    { name: "Montana", abbr: "MT" },
    { name: "Nebraska", abbr: "NE" },
    { name: "Nevada", abbr: "NV" },
    { name: "New Hampshire", abbr: "NH" },
    { name: "New Jersey", abbr: "NJ" },
    { name: "New Mexico", abbr: "NM" },
    { name: "New York", abbr: "NY" },
    { name: "North Carolina", abbr: "NC" },
    { name: "North Dakota", abbr: "ND" },
    { name: "Ohio", abbr: "OH" },
    { name: "Oklahoma", abbr: "OK" },
    { name: "Oregon", abbr: "OR" },
    { name: "Pennsylvania", abbr: "PA" },
    { name: "Rhode Island", abbr: "RI" },
    { name: "South Carolina", abbr: "SC" },
    { name: "South Dakota", abbr: "SD" },
    { name: "Tennessee", abbr: "TN" },
    { name: "Texas", abbr: "TX" },
    { name: "Utah", abbr: "UT" },
    { name: "Vermont", abbr: "VT" },
    { name: "Virginia", abbr: "VA" },
    { name: "Washington", abbr: "WA" },
    { name: "West Virginia", abbr: "WV" },
    { name: "Wisconsin", abbr: "WI" },
    { name: "Wyoming", abbr: "WY" },
    { name: "District of Columbia", abbr: "DC" },
  ];
  
  const citiesByCountry: { [key: string]: string[] } = {
    US: ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose"],
    CA: ["Toronto", "Montreal", "Vancouver", "Calgary", "Edmonton", "Ottawa", "Winnipeg", "Quebec City", "Hamilton", "Halifax"],
    GB: ["London", "Birmingham", "Manchester", "Glasgow", "Liverpool", "Leeds", "Newcastle", "Sheffield", "Bristol", "Edinburgh"],
    AU: ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Newcastle", "Canberra", "Wollongong", "Hobart"],
    DE: ["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Leipzig", "Dortmund", "Essen"],
    FR: ["Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier", "Bordeaux", "Lille"],
    ES: ["Madrid", "Barcelona", "Valencia", "Seville", "Zaragoza", "Málaga", "Murcia", "Palma", "Bilbao", "Alicante"],
    IT: ["Rome", "Milan", "Naples", "Turin", "Palermo", "Genoa", "Bologna", "Florence", "Bari", "Catania"],
    JP: ["Tokyo", "Yokohama", "Osaka", "Nagoya", "Sapporo", "Fukuoka", "Kawasaki", "Kobe", "Kyoto", "Saitama"],
    BR: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador", "Fortaleza", "Belo Horizonte", "Manaus", "Curitiba", "Recife", "Porto Alegre"],
    IN: ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Ahmedabad", "Pune", "Surat", "Jaipur"],
    MX: ["Mexico City", "Guadalajara", "Monterrey", "Puebla", "Tijuana", "León", "Juárez", "Zapopan", "Mérida", "San Luis Potosí"],
  };
  
  const streetTypes = ["Street", "Avenue", "Boulevard", "Drive", "Road", "Lane", "Place", "Way", "Court", "Terrace"];
  const streetNames = [
    "Main", "Oak", "Pine", "Maple", "Cedar", "Elm", "Washington", "Park", "Lake", "Hill",
    "River", "Forest", "Meadow", "Spring", "Sunset", "Valley", "Mountain", "Ocean", "Harbor",
    "Ridge", "Creek", "Bay", "Beach", "Highland", "Garden", "Wood", "Brook", "Mill", "Willow",
    "Rose", "Cherry", "Birch", "Dogwood", "Magnolia", "Azalea", "Laurel", "Ivy", "Fern",
    "Cypress", "Juniper", "Redwood", "Sequoia", "Aspen", "Sycamore", "Poplar", "Chestnut",
    "Walnut", "Pecan", "Hickory", "Peach", "Pear", "Apple", "Plum", "Lemon", "Orange", "Lime",
    "Grapefruit", "Grape", "Berry", "Strawberry", "Raspberry", "Blueberry", "Cranberry"
  ];
  
  const firstNames = [
    "James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", "William", "Elizabeth",
    "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen",
    "Christopher", "Nancy", "Daniel", "Lisa", "Matthew", "Margaret", "Anthony", "Betty", "Mark", "Sandra",
    "Donald", "Ashley", "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna",
    "Kenneth", "Michelle", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa", "Edward", "Deborah",
    "Ronald", "Stephanie", "Timothy", "Rebecca", "Jason", "Laura", "Jeffrey", "Sharon", "Ryan", "Cynthia",
    "Jacob", "Kathleen", "Gary", "Amy", "Nicholas", "Shirley", "Eric", "Angela", "Jonathan", "Helen",
    "Stephen", "Anna", "Larry", "Brenda", "Justin", "Pamela", "Scott", "Nicole", "Brandon", "Samantha",
    "Benjamin", "Katherine", "Samuel", "Emma", "Gregory", "Ruth", "Frank", "Christine", "Alexander", "Catherine",
    "Raymond", "Debra", "Patrick", "Rachel", "Jack", "Carolyn", "Dennis", "Janet", "Jerry", "Virginia"
  ];
  
  const lastNames = [
    "Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor",
    "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson",
    "Clark", "Rodriguez", "Lewis", "Lee", "Walker", "Hall", "Allen", "Young", "Hernandez", "King",
    "Wright", "Lopez", "Hill", "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter",
    "Mitchell", "Perez", "Roberts", "Turner", "Phillips", "Campbell", "Parker", "Evans", "Edwards", "Collins",
    "Stewart", "Sanchez", "Morris", "Rogers", "Reed", "Cook", "Morgan", "Bell", "Murphy", "Bailey",
    "Rivera", "Cooper", "Richardson", "Cox", "Howard", "Ward", "Torres", "Peterson", "Gray", "Ramirez",
    "James", "Watson", "Brooks", "Kelly", "Sanders", "Price", "Bennett", "Wood", "Barnes", "Ross",
    "Henderson", "Coleman", "Jenkins", "Perry", "Powell", "Long", "Patterson", "Hughes", "Flores", "Washington",
    "Butler", "Simmons", "Foster", "Gonzales", "Bryant", "Alexander", "Russell", "Griffin", "Diaz", "Hayes"
  ];
  
  const companyNames = [
    "Acme Corporation", "Globex", "Soylent Corp", "Initech", "Umbrella Corporation", "Stark Industries",
    "Wayne Enterprises", "Cyberdyne Systems", "Oscorp", "Virtucon",
    "TechDynamics", "Quantum Solutions", "Alpha Innovations", "Nexus Enterprises", "Pinnacle Systems",
    "Vertex Technologies", "Horizon Industries", "Fusion Dynamics", "Apex Solutions", "Elevate Corp",
    "StellarTech", "Vortex Labs", "Prime Analytics", "Momentum Ventures", "Inspire Innovations",
    "Pulse Networks", "Catalyst Systems", "Insight Technologies", "Velocity Corp", "Zenith Solutions"
  ];
  
  const jobTitles = [
    "Software Engineer", "Marketing Manager", "Financial Analyst", "Operations Director", "Sales Representative",
    "Human Resources Specialist", "Research Scientist", "Product Manager", "Customer Service Representative", "Legal Counsel",
    "Systems Administrator", "Content Creator", "Data Analyst", "Business Development Manager", "Quality Assurance Specialist",
    "Project Coordinator", "Administrative Assistant", "Executive Assistant", "Graphic Designer", "Web Developer",
    "UX Designer", "IT Support Specialist", "Network Engineer", "Database Administrator", "Security Analyst",
    "Account Manager", "Public Relations Specialist", "Social Media Manager", "Supply Chain Analyst", "Logistics Coordinator"
  ];
  
  const getRandomItem = <T extends any>(array: T[]): T => {
    return array[Math.floor(Math.random() * array.length)];
  };
  
  const generateRandomDigits = (length: number): string => {
    return Array(length).fill(0).map(() => Math.floor(Math.random() * 10)).join('');
  };
  
  const generateRandomPhoneNumber = (countryCode: string): string => {
    switch (countryCode) {
      case "US":
        return `+1 (${generateRandomDigits(3)}) ${generateRandomDigits(3)}-${generateRandomDigits(4)}`;
      case "CA":
        return `+1 (${generateRandomDigits(3)}) ${generateRandomDigits(3)}-${generateRandomDigits(4)}`;
      case "GB":
        return `+44 ${generateRandomDigits(4)} ${generateRandomDigits(6)}`;
      case "AU":
        return `+61 ${generateRandomDigits(1)} ${generateRandomDigits(4)} ${generateRandomDigits(4)}`;
      case "DE":
        return `+49 ${generateRandomDigits(3)} ${generateRandomDigits(7)}`;
      case "FR":
        return `+33 ${generateRandomDigits(1)} ${generateRandomDigits(2)} ${generateRandomDigits(2)} ${generateRandomDigits(2)} ${generateRandomDigits(2)}`;
      case "ES":
        return `+34 ${generateRandomDigits(3)} ${generateRandomDigits(3)} ${generateRandomDigits(3)}`;
      case "IT":
        return `+39 ${generateRandomDigits(3)} ${generateRandomDigits(7)}`;
      case "JP":
        return `+81 ${generateRandomDigits(2)} ${generateRandomDigits(4)} ${generateRandomDigits(4)}`;
      case "BR":
        return `+55 ${generateRandomDigits(2)} ${generateRandomDigits(4)}-${generateRandomDigits(4)}`;
      case "IN":
        return `+91 ${generateRandomDigits(10)}`;
      case "MX":
        return `+52 ${generateRandomDigits(2)} ${generateRandomDigits(4)} ${generateRandomDigits(4)}`;
      default:
        return `+1 (${generateRandomDigits(3)}) ${generateRandomDigits(3)}-${generateRandomDigits(4)}`;
    }
  };
  
  const formatName = (firstName: string, lastName: string, format: 'full' | 'firstLast' | 'lastFirst' | 'initial'): string => {
    const middleInitial = String.fromCharCode(65 + Math.floor(Math.random() * 26));
    
    switch (format) {
      case 'full':
        return `${firstName} ${middleInitial}. ${lastName}`;
      case 'firstLast':
        return `${firstName} ${lastName}`;
      case 'lastFirst':
        return `${lastName}, ${firstName}`;
      case 'initial':
        return `${firstName.charAt(0)}. ${lastName}`;
      default:
        return `${firstName} ${lastName}`;
    }
  };
  
  const generateStreetAddress = (): string => {
    const houseNumber = Math.floor(Math.random() * 9000) + 1000;
    const streetName = getRandomItem(streetNames);
    const streetType = getRandomItem(streetTypes);
    
    const hasApt = Math.random() > 0.7;
    const aptType = getRandomItem(["Apt", "Unit", "Suite", "#"]);
    const aptNumber = Math.floor(Math.random() * 500) + 1;
    
    return hasApt
      ? `${houseNumber} ${streetName} ${streetType}, ${aptType} ${aptNumber}`
      : `${houseNumber} ${streetName} ${streetType}`;
  };
  
  const generateRandomZipCode = (countryCode: string): string => {
    switch (countryCode) {
      case "US":
        return generateRandomDigits(5);
      case "CA":
        return `${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}${generateRandomDigits(1)}${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])} ${generateRandomDigits(1)}${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}${generateRandomDigits(1)}`;
      case "GB":
        return `${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}${generateRandomDigits(1)} ${generateRandomDigits(1)}${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}${getRandomItem(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"])}`;
      case "AU":
        return generateRandomDigits(4);
      case "DE":
        return generateRandomDigits(5);
      case "FR":
        return generateRandomDigits(5);
      case "ES":
        return generateRandomDigits(5);
      case "IT":
        return generateRandomDigits(5);
      case "JP":
        return generateRandomDigits(3) + "-" + generateRandomDigits(4);
      case "BR":
        return generateRandomDigits(5) + "-" + generateRandomDigits(3);
      case "IN":
        return generateRandomDigits(6);
      case "MX":
        return generateRandomDigits(5);
      default:
        return generateRandomDigits(5);
    }
  };
  
  const generateUsername = (firstName: string, lastName: string): string => {
    const usernameStyles = [
      () => `${firstName.toLowerCase()}${lastName.toLowerCase()}`,
      () => `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 100)}`,
      () => `${firstName.toLowerCase()}_${lastName.toLowerCase()}`,
      () => `${firstName.charAt(0).toLowerCase()}${lastName.toLowerCase()}`,
      () => `${lastName.toLowerCase()}${firstName.charAt(0).toLowerCase()}`,
      () => `${firstName.toLowerCase()}${Math.floor(Math.random() * 1000)}`,
    ];
    
    return getRandomItem(usernameStyles)();
  };
  
  const generateEmail = (firstName: string, lastName: string, username: string): string => {
    const emailDomains = [
      "gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com",
      "icloud.com", "protonmail.com", "zoho.com", "mail.com", "yandex.com"
    ];
    
    const emailStyles = [
      () => `${firstName.toLowerCase()}.${lastName.toLowerCase()}@${getRandomItem(emailDomains)}`,
      () => `${firstName.charAt(0).toLowerCase()}${lastName.toLowerCase()}@${getRandomItem(emailDomains)}`,
      () => `${username}@${getRandomItem(emailDomains)}`,
      () => `${lastName.toLowerCase()}${firstName.charAt(0).toLowerCase()}@${getRandomItem(emailDomains)}`,
      () => `${firstName.toLowerCase()}${lastName.charAt(0).toLowerCase()}@${getRandomItem(emailDomains)}`,
    ];
    
    return getRandomItem(emailStyles)();
  };
  
  const generateRandomAddress = (): Address => {
    const firstName = getRandomItem(firstNames);
    const lastName = getRandomItem(lastNames);
    const name = formatName(firstName, lastName, filterOptions.nameFormat);
    const username = generateUsername(firstName, lastName);
    const emailAddress = generateEmail(firstName, lastName, username);
    
    let state = "";
    let stateAbbr = "";
    
    if (country === "US") {
      const randomState = getRandomItem(usStates);
      state = randomState.name;
      stateAbbr = randomState.abbr;
    } else {
      state = "";
      stateAbbr = "";
    }
    
    const countryName = countries.find(c => c.code === country)?.name || "United States";
    const cityList = citiesByCountry[country] || citiesByCountry.US;
    const city = getRandomItem(cityList);
    
    return {
      name,
      streetAddress: generateStreetAddress(),
      city,
      state,
      stateAbbr,
      zipCode: generateRandomZipCode(country),
      country: countryName,
      countryCode: country,
      phoneNumber: generateRandomPhoneNumber(country),
      emailAddress,
      username,
      company: getRandomItem(companyNames),
      jobTitle: getRandomItem(jobTitles),
    };
  };
  
  const generateAddresses = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      const addresses: Address[] = [];
      for (let i = 0; i < quantity; i++) {
        addresses.push(generateRandomAddress());
      }
      setGeneratedAddresses(addresses);
      setIsLoading(false);
      
      setCopied({});
      
      toast.success(`Generated ${quantity} address${quantity > 1 ? 'es' : ''} successfully!`);
    }, 500);
  };
  
  const copyAddress = (address: Address, index: number) => {
    let copyText = formatAddressForCopy(address);
    
    navigator.clipboard.writeText(copyText).then(() => {
      setCopied(prev => ({ ...prev, [index]: true }));
      
      setTimeout(() => {
        setCopied(prev => ({ ...prev, [index]: false }));
      }, 2000);
      
      toast.success("Address copied to clipboard!");
    }).catch(() => {
      toast.error("Failed to copy address.");
    });
  };
  
  const copyAllAddresses = () => {
    if (generatedAddresses.length === 0) {
      toast.error("No addresses to copy.");
      return;
    }
    
    const allAddresses = generatedAddresses.map(addr => formatAddressForCopy(addr)).join("\n\n");
    
    navigator.clipboard.writeText(allAddresses).then(() => {
      toast.success("All addresses copied to clipboard!");
    }).catch(() => {
      toast.error("Failed to copy addresses.");
    });
  };
  
  const downloadAddresses = (format: 'txt' | 'csv' | 'json') => {
    if (generatedAddresses.length === 0) {
      toast.error("No addresses to download.");
      return;
    }
    
    let content = '';
    let filename = `fake-addresses-${new Date().toISOString().slice(0, 10)}`;
    let mimeType = 'text/plain';
    
    if (format === 'txt') {
      content = generatedAddresses.map(addr => formatAddressForCopy(addr)).join("\n\n");
      filename += '.txt';
    } else if (format === 'csv') {
      const headers = ['Name', 'Street Address', 'City'];
      if (country === 'US') headers.push('State', 'State Code');
      headers.push('Postal Code', 'Country', 'Country Code');
      if (filterOptions.includePhone) headers.push('Phone');
      if (filterOptions.includeEmail) headers.push('Email');
      if (filterOptions.includeUsername) headers.push('Username');
      if (filterOptions.includeCompany) headers.push('Company');
      if (filterOptions.includeJobTitle) headers.push('Job Title');
      
      content = headers.join(',') + '\n';
      
      generatedAddresses.forEach(addr => {
        const row = [
          `"${addr.name}"`,
          `"${addr.streetAddress}"`,
          `"${addr.city}"`
        ];
        
        if (country === 'US') row.push(`"${addr.state}"`, `"${addr.stateAbbr}"`);
        
        row.push(
          `"${addr.zipCode}"`,
          `"${addr.country}"`,
          `"${addr.countryCode}"`
        );
        
        if (filterOptions.includePhone) row.push(`"${addr.phoneNumber}"`);
        if (filterOptions.includeEmail) row.push(`"${addr.emailAddress}"`);
        if (filterOptions.includeUsername) row.push(`"${addr.username}"`);
        if (filterOptions.includeCompany) row.push(`"${addr.company}"`);
        if (filterOptions.includeJobTitle) row.push(`"${addr.jobTitle}"`);
        
        content += row.join(',') + '\n';
      });
      
      filename += '.csv';
      mimeType = 'text/csv';
    } else if (format === 'json') {
      content = JSON.stringify(generatedAddresses, null, 2);
      filename += '.json';
      mimeType = 'application/json';
    }
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success(`Addresses downloaded as ${format.toUpperCase()} file.`);
  };
  
  const formatAddressForCopy = (address: Address): string => {
    let lines = [address.name, address.streetAddress];
    
    if (country === 'US') {
      lines.push(`${address.city}, ${address.stateAbbr} ${address.zipCode}`);
    } else {
      lines.push(`${address.city} ${address.zipCode}`);
    }
    
    lines.push(address.country);
    
    if (filterOptions.includePhone) {
      lines.push(`Phone: ${address.phoneNumber}`);
    }
    
    if (filterOptions.includeEmail) {
      lines.push(`Email: ${address.emailAddress}`);
    }
    
    if (filterOptions.includeUsername) {
      lines.push(`Username: ${address.username}`);
    }
    
    if (filterOptions.includeCompany) {
      lines.push(`Company: ${address.company}`);
    }
    
    if (filterOptions.includeJobTitle) {
      lines.push(`Job Title: ${address.jobTitle}`);
    }
    
    return lines.join('\n');
  };
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuantity = parseInt(e.target.value);
    if (newQuantity >= 1 && newQuantity <= 100) {
      setQuantity(newQuantity);
    }
  };
  
  const handleFilterChange = (name: keyof FilterOptions, value: any) => {
    setFilterOptions(prev => ({ ...prev, [name]: value }));
  };
  
  const clearAddresses = () => {
    setGeneratedAddresses([]);
  };
  
  const getCountryFlag = (countryCode: string) => {
    return countryCode
      .toUpperCase()
      .replace(/./g, char => String.fromCodePoint(char.charCodeAt(0) + 127397));
  };
  
  return (
    <ToolLayout
      title="Fake Address Generator"
      description="Generate random addresses for testing, development, and creative purposes."
      helpText="Create realistic fake addresses from various countries. Include additional information like phone numbers and emails as needed."
    >
      <Helmet>
        <title>Fake Address Generator - Create Random Addresses | MultiToolSet</title>
        <meta name="description" content="Generate realistic fake addresses for testing and development. Create random addresses from the US, UK, Canada, and more with customizable options." />
        <meta name="keywords" content="fake address generator, random address, test address, dummy address, address generator, fake personal info" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Fake Address Generator",
              "applicationCategory": "WebApplication",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "operatingSystem": "Any",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "128"
              }
            }
          `}
        </script>
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 space-y-6">
            <h2 className="text-xl font-semibold flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-primary" />
              Address Settings
            </h2>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger id="country" className="w-full">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((c) => (
                      <SelectItem key={c.code} value={c.code}>
                        <span className="mr-2">{getCountryFlag(c.code)}</span>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="quantity">Number of Addresses</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  max="100"
                  value={quantity}
                  onChange={handleQuantityChange}
                />
                <p className="text-sm text-gray-500">Maximum: 100 addresses</p>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label className="text-base">Include Information</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includePhone" 
                      checked={filterOptions.includePhone}
                      onCheckedChange={(checked) => handleFilterChange("includePhone", !!checked)}
                    />
                    <Label htmlFor="includePhone" className="cursor-pointer">Phone Number</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeEmail" 
                      checked={filterOptions.includeEmail}
                      onCheckedChange={(checked) => handleFilterChange("includeEmail", !!checked)}
                    />
                    <Label htmlFor="includeEmail" className="cursor-pointer">Email Address</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeUsername" 
                      checked={filterOptions.includeUsername}
                      onCheckedChange={(checked) => handleFilterChange("includeUsername", !!checked)}
                    />
                    <Label htmlFor="includeUsername" className="cursor-pointer">Username</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeCompany" 
                      checked={filterOptions.includeCompany}
                      onCheckedChange={(checked) => handleFilterChange("includeCompany", !!checked)}
                    />
                    <Label htmlFor="includeCompany" className="cursor-pointer">Company</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeJobTitle" 
                      checked={filterOptions.includeJobTitle}
                      onCheckedChange={(checked) => handleFilterChange("includeJobTitle", !!checked)}
                    />
                    <Label htmlFor="includeJobTitle" className="cursor-pointer">Job Title</Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="nameFormat">Name Format</Label>
                <Select 
                  value={filterOptions.nameFormat} 
                  onValueChange={(value: 'full' | 'firstLast' | 'lastFirst' | 'initial') => handleFilterChange("nameFormat", value)}
                >
                  <SelectTrigger id="nameFormat">
                    <SelectValue placeholder="Select name format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full">Full Name with Middle Initial</SelectItem>
                    <SelectItem value="firstLast">First Last</SelectItem>
                    <SelectItem value="lastFirst">Last, First</SelectItem>
                    <SelectItem value="initial">Initial. Last</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button 
              onClick={generateAddresses} 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <MapPin className="h-4 w-4 mr-2" />
                  Generate Addresses
                </>
              )}
            </Button>
          </div>
          
          {generatedAddresses.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 space-y-4">
              <h2 className="text-xl font-semibold">Export Options</h2>
              
              <div className="space-y-4">
                <Button 
                  variant="outline" 
                  className="w-full flex items-center justify-center"
                  onClick={copyAllAddresses}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy All Addresses
                </Button>
                
                <Tabs defaultValue="txt">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="txt">Text</TabsTrigger>
                    <TabsTrigger value="csv">CSV</TabsTrigger>
                    <TabsTrigger value="json">JSON</TabsTrigger>
                  </TabsList>
                  <TabsContent value="txt" className="mt-4">
                    <Button 
                      className="w-full flex items-center justify-center"
                      onClick={() => downloadAddresses('txt')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download as TXT
                    </Button>
                    <p className="text-xs text-gray-500 mt-2">
                      Plain text format, one address per entry.
                    </p>
                  </TabsContent>
                  <TabsContent value="csv" className="mt-4">
                    <Button 
                      className="w-full flex items-center justify-center"
                      onClick={() => downloadAddresses('csv')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download as CSV
                    </Button>
                    <p className="text-xs text-gray-500 mt-2">
                      Comma-separated values, importable to Excel.
                    </p>
                  </TabsContent>
                  <TabsContent value="json" className="mt-4">
                    <Button 
                      className="w-full flex items-center justify-center"
                      onClick={() => downloadAddresses('json')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download as JSON
                    </Button>
                    <p className="text-xs text-gray-500 mt-2">
                      JSON format for developers, easily parsable.
                    </p>
                  </TabsContent>
                </Tabs>
                
                <Button 
                  variant="destructive" 
                  className="w-full flex items-center justify-center"
                  onClick={clearAddresses}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear All Addresses
                </Button>
              </div>
            </div>
          )}
        </div>
        
        <div className="lg:col-span-2">
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold flex items-center">
                <Globe className="h-5 w-5 mr-2 text-primary" />
                Generated Addresses
              </h2>
              
              {generatedAddresses.length > 0 && (
                <span className="text-sm text-gray-500">
                  {generatedAddresses.length} address{generatedAddresses.length !== 1 ? 'es' : ''} generated
                </span>
              )}
            </div>
            
            <div ref={addressesRef} className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
              {generatedAddresses.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg">
                  <MapPin className="h-12 w-12 mx-auto text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-gray-100">No addresses generated yet</h3>
                  <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                    Set your preferences and click "Generate Addresses" to create fake addresses.
                  </p>
                </div>
              ) : (
                generatedAddresses.map((address, index) => (
                  <div 
                    key={index} 
                    className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-4 border border-gray-200 dark:border-gray-700 relative"
                  >
                    <div className="flex justify-between items-start">
                      <div className="mb-2">
                        <h3 className="text-lg font-semibold flex items-center">
                          <User className="h-4 w-4 mr-2 text-gray-500" />
                          {address.name}
                        </h3>
                        <p className="text-sm text-gray-500">{address.streetAddress}</p>
                        {country === 'US' ? (
                          <p className="text-sm text-gray-500">
                            {address.city}, {address.stateAbbr} {address.zipCode}
                          </p>
                        ) : (
                          <p className="text-sm text-gray-500">
                            {address.city} {address.zipCode}
                          </p>
                        )}
                        <p className="text-sm text-gray-500 flex items-center">
                          <span className="mr-1">{getCountryFlag(address.countryCode)}</span>
                          {address.country}
                        </p>
                      </div>
                      
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={() => copyAddress(address, index)}
                        className="h-8 w-8"
                      >
                        {copied[index] ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    
                    <div className="mt-3 space-y-1 pt-3 border-t border-gray-200 dark:border-gray-700">
                      {filterOptions.includePhone && (
                        <p className="text-sm flex items-center">
                          <Phone className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          {address.phoneNumber}
                        </p>
                      )}
                      
                      {filterOptions.includeEmail && (
                        <p className="text-sm flex items-center">
                          <Mail className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          {address.emailAddress}
                        </p>
                      )}
                      
                      {filterOptions.includeCompany && (
                        <p className="text-sm flex items-center">
                          <Building className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          {address.company}
                        </p>
                      )}
                      
                      {filterOptions.includeJobTitle && (
                        <p className="text-sm text-gray-500 ml-5">
                          {address.jobTitle}
                        </p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      
      <Separator className="my-8" />
      
      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">How to Use Fake Addresses</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-800 p-5 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-lg mb-2">Software Testing</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Use these addresses to fill databases with realistic test data when developing address forms, shipping calculators, or location-based applications.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-5 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-lg mb-2">Design Mockups</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Add realistic addresses to design mockups, UI prototypes, or sample documents to make them look more authentic and complete.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-5 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-lg mb-2">Creative Projects</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Generate fictional addresses for creative writing, role-playing games, or other projects that need realistic-looking locations.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-100 dark:border-blue-800">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Info className="h-5 w-5 mr-2 text-blue-500" />
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-medium">Are these addresses real?</h3>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                No, all addresses generated by this tool are completely fictional. While they follow realistic patterns for their respective countries, they do not correspond to actual physical locations.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Is it legal to use these fake addresses?</h3>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Yes, as long as you're using them for legitimate purposes like software testing, design mockups, or creative projects. However, using fake addresses for fraud, misrepresentation, or other illegal activities is prohibited.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Can I generate addresses for other countries?</h3>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Currently, the tool supports 12 countries including the US, Canada, UK, and major European and Asian countries. We plan to add more countries in future updates.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium">Is my data private when using this tool?</h3>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Yes, this tool operates entirely in your browser. No data is sent to our servers, and your generated addresses are not stored anywhere except on your local device.
              </p>
            </div>
          </div>
        </div>
        
        <div>
          <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <a href="/tools/password-generator" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Password Generator</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Create secure, random passwords</p>
              </div>
            </a>
            
            <a href="/tools/random-string-generator" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Random String Generator</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Generate random alphanumeric strings</p>
              </div>
            </a>
            
            <a href="/tools/lorem-ipsum-generator" className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              <div className="ml-3">
                <h3 className="font-medium">Lorem Ipsum Generator</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Create placeholder text for designs</p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default FakeAddressGenerator;
