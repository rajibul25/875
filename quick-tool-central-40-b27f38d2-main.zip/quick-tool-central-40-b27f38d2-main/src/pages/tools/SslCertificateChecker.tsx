
import { useState } from "react";
import { ArrowRight, Shield, CheckCircle, XCircle, Clock, Calendar, Globe, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import AdBanner from "@/components/AdBanner";

interface CertificateInfo {
  domain: string;
  isValid: boolean;
  issuer: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  subject: string;
  altNames: string[];
  serialNumber: string;
}

const SslCertificateChecker = () => {
  const [domain, setDomain] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [certInfo, setCertInfo] = useState<CertificateInfo | null>(null);
  const [error, setError] = useState("");
  const { toast } = useToast();

  const checkSSLCertificate = async () => {
    // Reset previous results
    setCertInfo(null);
    setError("");
    
    // Validate input
    if (!domain) {
      setError("Please enter a domain name");
      return;
    }
    
    // Clean up domain input (remove protocol if entered)
    const cleanDomain = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    
    setIsLoading(true);
    
    try {
      // In a real implementation, this would make an API call to check the SSL certificate
      // For demo purposes, we'll simulate a response after a short delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate different responses based on domain input
      if (cleanDomain === "expired-ssl.com" || cleanDomain === "invalid.com") {
        setCertInfo({
          domain: cleanDomain,
          isValid: false,
          issuer: "DigiCert Inc",
          validFrom: "2022-01-15",
          validTo: "2023-01-15",
          daysRemaining: -95,
          subject: "CN=" + cleanDomain,
          altNames: [cleanDomain, "www." + cleanDomain],
          serialNumber: "0A:B1:C2:D3:E4:F5:12:34:56:78"
        });
      } else {
        // Generate random days remaining between 30 and 365
        const daysRemaining = Math.floor(Math.random() * 335) + 30;
        
        // Calculate valid from and to dates
        const toDate = new Date();
        toDate.setDate(toDate.getDate() + daysRemaining);
        
        const fromDate = new Date();
        fromDate.setFullYear(fromDate.getFullYear() - 1);
        
        setCertInfo({
          domain: cleanDomain,
          isValid: true,
          issuer: "Let's Encrypt Authority X3",
          validFrom: fromDate.toISOString().split('T')[0],
          validTo: toDate.toISOString().split('T')[0],
          daysRemaining: daysRemaining,
          subject: "CN=" + cleanDomain,
          altNames: [cleanDomain, "www." + cleanDomain],
          serialNumber: Math.random().toString(16).slice(2, 10).toUpperCase() + ":" + 
                       Math.random().toString(16).slice(2, 10).toUpperCase()
        });
      }
      
      toast({
        title: "Certificate check completed",
        description: "Successfully retrieved SSL certificate information",
      });
    } catch (err) {
      setError("Failed to check SSL certificate. Please try again.");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Something went wrong while checking the certificate.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      checkSSLCertificate();
    }
  };

  const getExpiryStatusColor = (daysRemaining: number) => {
    if (daysRemaining < 0) return "text-red-600";
    if (daysRemaining < 30) return "text-amber-600";
    return "text-green-600";
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <BackButton />
          <h1 className="text-3xl font-bold text-center lg:text-left">SSL Certificate Checker</h1>
          <div className="w-[70px]"></div> {/* Empty div for alignment */}
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Shield className="mr-2 text-tool-purple" />
              Check SSL Certificate Status
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Enter a domain name to check its SSL certificate status, expiration date, issuer information and more.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <Input
                type="text"
                placeholder="Enter domain (e.g., example.com)"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1"
              />
              <Button 
                onClick={checkSSLCertificate} 
                disabled={isLoading}
                className="gap-2 bg-tool-purple hover:bg-tool-purple/90"
              >
                {isLoading ? "Checking..." : "Check Certificate"}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {isLoading && (
              <div className="space-y-3">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            )}
            
            {certInfo && (
              <div className="bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-4 mt-2">
                <div className="flex items-center mb-4 justify-between flex-wrap gap-2">
                  <div className="flex items-center">
                    <Badge variant={certInfo.isValid ? "default" : "destructive"} className="mr-3">
                      {certInfo.isValid ? (
                        <CheckCircle className="h-3 w-3 mr-1" />
                      ) : (
                        <XCircle className="h-3 w-3 mr-1" />
                      )}
                      {certInfo.isValid ? "Valid" : "Invalid"}
                    </Badge>
                    <h3 className="font-semibold">{certInfo.domain}</h3>
                  </div>
                  
                  <div className={`flex items-center ${getExpiryStatusColor(certInfo.daysRemaining)}`}>
                    <Clock className="h-4 w-4 mr-1" />
                    {certInfo.daysRemaining < 0 
                      ? `Expired ${Math.abs(certInfo.daysRemaining)} days ago` 
                      : `Expires in ${certInfo.daysRemaining} days`
                    }
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Issued By</p>
                      <p className="font-medium truncate">{certInfo.issuer}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Subject</p>
                      <p className="font-medium truncate">{certInfo.subject}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Serial Number</p>
                      <p className="font-mono text-sm truncate">{certInfo.serialNumber}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Valid From</p>
                        <p className="font-medium">{certInfo.validFrom}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Valid To</p>
                        <p className="font-medium">{certInfo.validTo}</p>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Alternative Names</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {certInfo.altNames.map((name, index) => (
                          <Badge key={index} variant="outline" className="font-mono text-xs">
                            {name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </Card>
          
          <AdBanner className="my-8" />
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">What is SSL Certificate Checker?</h2>
            <p className="mb-4">
              Our SSL Certificate Checker tool allows you to verify SSL certificates on your websites. It gives you detailed information about the SSL certificate including its validity, expiration date, issuer, and more. This information is crucial for ensuring your website's security and preventing potential security breaches.
            </p>
            
            <h3 className="text-lg font-medium mb-2">Why Check Your SSL Certificate?</h3>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Ensure your website is secure and trusted by visitors</li>
              <li>Avoid browser warnings about insecure websites</li>
              <li>Prevent your certificate from expiring unexpectedly</li>
              <li>Verify that the certificate is issued by a trusted authority</li>
              <li>Check for proper domain coverage, including subdomains</li>
            </ul>
            
            <h3 className="text-lg font-medium mb-2">How to Use This Tool</h3>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li>Enter the domain name you want to check (without http:// or https://)</li>
              <li>Click "Check Certificate" button or press Enter</li>
              <li>View the comprehensive results about your SSL certificate</li>
              <li>Take action if your certificate is expiring soon or has issues</li>
            </ol>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">What is an SSL certificate?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  An SSL certificate is a digital certificate that authenticates a website's identity and enables an encrypted connection. It ensures that data passed between a web server and browser remains private and secure.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">Why is my certificate showing as invalid?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Certificates can be invalid for several reasons, including expiration, being issued by an untrusted authority, mismatched domain names, or improper installation on the server.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How do I fix an expired SSL certificate?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  You need to renew your SSL certificate through your certificate provider or hosting company. After renewal, make sure to install the new certificate on your web server.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">How often should I check my SSL certificate?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  It's good practice to check your SSL certificates at least once a month, or set up automated monitoring to alert you when certificates are approaching expiration.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium text-lg">What does "Days Remaining" mean?</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  "Days Remaining" indicates how many days until your SSL certificate expires. A negative number means the certificate has already expired and needs immediate attention.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

// Add schema markup for SEO
const SchemaMarkup = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "SSL Certificate Checker",
    "applicationCategory": "WebApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "All",
    "description": "Check the validity, expiration date, and details of SSL certificates for any website. Free online SSL certificate checker tool."
  };

  return (
    <script type="application/ld+json">
      {JSON.stringify(schema)}
    </script>
  );
};

// Add meta tags for SEO
const SeoHead = () => {
  return (
    <>
      <title>SSL Certificate Checker - Check Certificate Validity & Expiration | MultiToolSet</title>
      <meta
        name="description"
        content="Verify SSL certificates instantly with our free SSL Certificate Checker. Check expiry dates, validity, issuer details, and ensure your website's security."
      />
      <meta
        name="keywords"
        content="ssl checker, ssl certificate checker, certificate verification, ssl expiry checker, website security, ssl validation, https checker"
      />
      <link rel="canonical" href="https://multitoolset.co/tools/ssl-certificate-checker" />
    </>
  );
};

// Export with SEO components
const SslCertificateCheckerWithSeo = () => {
  return (
    <>
      <SeoHead />
      <SchemaMarkup />
      <SslCertificateChecker />
    </>
  );
};

export default SslCertificateCheckerWithSeo;
