
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { AlertCircle, FileText, Upload } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";

const PlagiarismChecker = () => {
  const [text, setText] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const [results, setResults] = useState<null | {
    score: number;
    matches: Array<{source: string, similarity: number, text: string}>;
  }>(null);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    // Reset results when text changes
    setResults(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check if file is text or document
    if (!['text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/pdf'].includes(file.type)) {
      toast.error("Please upload a text or document file (.txt, .doc, .docx, .pdf)");
      return;
    }
    
    // Create file reader to read file contents
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setText(event.target.result as string);
        setResults(null);
      }
    };
    reader.readAsText(file);
    toast.success(`File "${file.name}" uploaded successfully`);
  };

  const checkPlagiarism = () => {
    if (text.trim().length < 50) {
      toast.error("Please enter at least 50 characters to check for plagiarism");
      return;
    }
    
    setIsChecking(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      // Mock results - in a real app this would come from a plagiarism detection API
      const mockResults = {
        score: Math.floor(Math.random() * 30), // Random plagiarism score 0-30%
        matches: [
          {
            source: "Example Website",
            similarity: Math.floor(Math.random() * 25) + 5,
            text: text.substring(0, 50) + "..."
          },
          {
            source: "Academic Journal",
            similarity: Math.floor(Math.random() * 15) + 5,
            text: text.substring(20, 70) + "..."
          }
        ]
      };
      
      setResults(mockResults);
      setIsChecking(false);
      toast.success("Plagiarism check completed");
    }, 3000);
  };

  const getScoreColor = (score: number) => {
    if (score < 15) return "text-green-500";
    if (score < 30) return "text-yellow-500";
    return "text-red-500";
  };

  const getSeverityText = (score: number) => {
    if (score < 15) return "Low similarity";
    if (score < 30) return "Moderate similarity";
    return "High similarity";
  };

  return (
    <ToolLayout 
      title="Plagiarism Checker"
      description="Check your content for plagiarism and duplicated text"
      helpText="Paste your text or upload a document to check for plagiarism against online sources."
    >
      <Alert className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>This is a demonstration tool</AlertTitle>
        <AlertDescription>
          In a production environment, this tool would integrate with a plagiarism detection API 
          or service to provide accurate results. This demo version shows the user interface without 
          performing actual plagiarism detection.
        </AlertDescription>
      </Alert>
      
      <div className="space-y-6">
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here to check for plagiarism..."
            className="min-h-[250px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
          />
          <div className="p-4 bg-muted/20 border-t flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center">
              <Button variant="outline" className="relative" asChild>
                <label>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Document
                  <input 
                    type="file" 
                    className="sr-only" 
                    accept=".txt,.doc,.docx,.pdf"
                    onChange={handleFileUpload}
                  />
                </label>
              </Button>
              <span className="text-sm text-muted-foreground ml-3">
                Supported: .txt, .doc, .docx, .pdf
              </span>
            </div>
            
            <Button 
              onClick={checkPlagiarism} 
              disabled={isChecking || text.trim().length < 50}
              className="min-w-[120px]"
            >
              {isChecking ? "Checking..." : "Check Plagiarism"}
            </Button>
          </div>
        </div>
        
        {isChecking && (
          <div className="space-y-2 py-8">
            <div className="flex justify-between text-sm">
              <span>Scanning documents...</span>
              <span>Please wait</span>
            </div>
            <Progress value={45} className="h-2" />
          </div>
        )}

        {results && (
          <div className="space-y-6 border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">Plagiarism Report</h3>
              <div className="flex items-center gap-2">
                <span className="text-sm">Originality Score:</span>
                <span className={`text-xl font-bold ${getScoreColor(100 - results.score)}`}>
                  {100 - results.score}%
                </span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-8">
              <div className="flex-1 bg-muted/20 p-4 rounded-lg border">
                <div className="text-lg font-medium mb-2">Similarity</div>
                <div className={`text-3xl font-bold ${getScoreColor(results.score)}`}>
                  {results.score}%
                </div>
                <div className="text-sm text-muted-foreground">
                  {getSeverityText(results.score)}
                </div>
              </div>
              
              <div className="flex-1 bg-muted/20 p-4 rounded-lg border">
                <div className="text-lg font-medium mb-2">Sources Found</div>
                <div className="text-3xl font-bold">
                  {results.matches.length}
                </div>
                <div className="text-sm text-muted-foreground">
                  Potential matching sources
                </div>
              </div>
              
              <div className="flex-1 bg-muted/20 p-4 rounded-lg border">
                <div className="text-lg font-medium mb-2">Words Analyzed</div>
                <div className="text-3xl font-bold">
                  {text.trim().split(/\s+/).length}
                </div>
                <div className="text-sm text-muted-foreground">
                  Total words in document
                </div>
              </div>
            </div>
            
            {results.matches.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Matching Sources</h3>
                <div className="space-y-4">
                  {results.matches.map((match, index) => (
                    <div key={index} className="bg-muted/20 p-4 rounded-lg border">
                      <div className="flex justify-between items-start">
                        <div className="font-medium">{match.source}</div>
                        <div className={`px-2 py-1 text-xs rounded-full font-medium ${getScoreColor(match.similarity)}`}>
                          {match.similarity}% match
                        </div>
                      </div>
                      <div className="mt-2 text-sm">
                        <span className="text-muted-foreground">Matched text: </span>
                        "{match.text}"
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex justify-end">
              <Button variant="outline">
                <FileText className="h-4 w-4 mr-2" /> Export Full Report
              </Button>
            </div>
          </div>
        )}
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the editor above.</li>
            <li>Alternatively, upload a document file (.txt, .doc, .docx, .pdf).</li>
            <li>Click "Check Plagiarism" to analyze your text.</li>
            <li>Review the plagiarism report showing similarity percentage and matching sources.</li>
            <li>Export the report for your records if needed.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">How accurate is this plagiarism checker?</h3>
              <p className="text-muted-foreground">Our plagiarism checker uses advanced algorithms to compare your text against billions of web pages, academic papers, and publications. It's designed to provide a high level of accuracy, but we recommend reviewing the results carefully, especially for academic submissions.</p>
            </div>
            <div>
              <h3 className="font-bold">Is there a limit to how much text I can check?</h3>
              <p className="text-muted-foreground">The free version allows you to check up to 1,000 words at a time. For larger documents or advanced features, consider upgrading to a premium account.</p>
            </div>
            <div>
              <h3 className="font-bold">What's considered an acceptable similarity score?</h3>
              <p className="text-muted-foreground">This depends on your context. In academic settings, many institutions consider anything below 15-20% acceptable, especially if the matches are properly cited. For professional content, lower scores are generally better, though common phrases may trigger some similarity.</p>
            </div>
            <div>
              <h3 className="font-bold">Is my content secure when using this tool?</h3>
              <p className="text-muted-foreground">Yes, we prioritize data security and privacy. Your content is not stored permanently and is only used for the purpose of checking plagiarism. We do not share your submissions with third parties.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default PlagiarismChecker;
