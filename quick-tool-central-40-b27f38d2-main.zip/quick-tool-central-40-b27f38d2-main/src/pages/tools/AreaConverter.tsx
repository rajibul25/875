
import React, { useState, useEffect } from "react";
import { Copy, RotateCw, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import ChatBot from "@/components/ChatBot";
import Helmet from "react-helmet";

const AreaConverter = () => {
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState<number | string>("");
  const [result, setResult] = useState<number | string>("");
  const [fromUnit, setFromUnit] = useState("square_meter");
  const [toUnit, setToUnit] = useState("square_foot");
  const [recentConversions, setRecentConversions] = useState<Array<{
    from: string,
    to: string,
    input: number | string,
    output: number | string,
    timestamp: Date
  }>>([]);

  // Unit conversion rates to square meter (base unit)
  const areaUnits = {
    square_meter: 1,
    square_kilometer: 0.000001,
    square_centimeter: 10000,
    square_millimeter: 1000000,
    square_micrometer: 1000000000000,
    hectare: 0.0001,
    square_mile: 3.861e-7,
    square_yard: 1.19599,
    square_foot: 10.7639,
    square_inch: 1550,
    acre: 0.000247105
  };

  const unitNames = {
    square_meter: "Square Meter",
    square_kilometer: "Square Kilometer",
    square_centimeter: "Square Centimeter",
    square_millimeter: "Square Millimeter",
    square_micrometer: "Square Micrometer",
    hectare: "Hectare",
    square_mile: "Square Mile",
    square_yard: "Square Yard",
    square_foot: "Square Foot",
    square_inch: "Square Inch",
    acre: "Acre"
  };

  const unitSymbols = {
    square_meter: "m²",
    square_kilometer: "km²",
    square_centimeter: "cm²",
    square_millimeter: "mm²",
    square_micrometer: "µm²",
    hectare: "ha",
    square_mile: "mi²",
    square_yard: "yd²",
    square_foot: "ft²",
    square_inch: "in²",
    acre: "ac"
  };

  useEffect(() => {
    if (inputValue !== "") {
      convertArea();
    }
  }, [inputValue, fromUnit, toUnit]);

  const convertArea = () => {
    if (inputValue === "" || isNaN(Number(inputValue))) {
      setResult("");
      return;
    }

    // Convert from the input unit to square meters (base unit)
    const squareMeters = Number(inputValue) / areaUnits[fromUnit as keyof typeof areaUnits];
    
    // Convert from square meters to the output unit
    const convertedValue = squareMeters * areaUnits[toUnit as keyof typeof areaUnits];
    
    // Round to a reasonable number of decimal places
    let roundedValue: number;
    if (convertedValue < 0.01) {
      roundedValue = Number(convertedValue.toFixed(6));
    } else if (convertedValue < 1) {
      roundedValue = Number(convertedValue.toFixed(4));
    } else {
      roundedValue = Number(convertedValue.toFixed(2));
    }
    
    setResult(roundedValue);
    
    // Save to recent conversions
    if (inputValue !== "") {
      const newConversion = {
        from: fromUnit,
        to: toUnit,
        input: inputValue,
        output: roundedValue,
        timestamp: new Date()
      };
      
      setRecentConversions(prev => {
        const updated = [newConversion, ...prev].slice(0, 5);
        return updated;
      });
    }
  };

  const handleCopy = () => {
    if (result !== "") {
      navigator.clipboard.writeText(`${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]}`);
      toast({
        title: "Copied!",
        description: `${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]} has been copied to clipboard.`,
      });
    }
  };

  const handleReset = () => {
    setInputValue("");
    setResult("");
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  return (
    <>
      <Helmet>
        <title>Free Online Area Converter Tool | Convert m², ft², acres & more</title>
        <meta name="description" content="Convert area units instantly with our free online area converter. Easily convert between square meters, square feet, acres, hectares, and more with accurate results." />
        <meta name="keywords" content="area converter, square meters to square feet, acres to hectares, area measurement, land area converter" />
        <meta property="og:title" content="Free Online Area Converter Tool" />
        <meta property="og:description" content="Convert between square meters, square feet, acres, hectares and more with our free online area converter tool." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/area-converter" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Free Online Area Converter Tool" />
        <meta name="twitter:description" content="Convert between square meters, square feet, acres, hectares and more with our free online area converter tool." />
        <link rel="canonical" href="https://multitoolset.co/tools/area-converter" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Area Converter Tool",
              "url": "https://multitoolset.co/tools/area-converter",
              "description": "Convert area units instantly with our free online area converter. Easily convert between square meters, square feet, acres, hectares, and more with accurate results.",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I convert square meters to square feet?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To convert square meters to square feet, multiply the area value by 10.764. For example, 1 square meter equals 10.764 square feet."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many acres are in a hectare?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "There are 2.47105 acres in 1 hectare."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is the difference between an acre and a square mile?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A square mile is much larger than an acre. There are 640 acres in 1 square mile."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <h1 className="text-3xl font-bold text-center flex-grow text-gray-800 dark:text-gray-100">
              Area Converter
            </h1>
            <div className="w-[70px]"></div> {/* Spacer for balance */}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-lg border-2 border-gray-100 dark:border-gray-800">
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="fromValue" className="text-base font-medium">
                        From
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="fromValue"
                            type="number"
                            placeholder="Enter value"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="text-lg"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={fromUnit} onValueChange={setFromUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(areaUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={swapUnits}
                      className="mx-auto md:mx-0 h-10 w-10 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
                    >
                      <ArrowRightLeft className="h-5 w-5" />
                    </Button>
                    
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="toValue" className="text-base font-medium">
                        To
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="toValue"
                            readOnly
                            value={result}
                            className="text-lg bg-gray-50 dark:bg-gray-800"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={toUnit} onValueChange={setToUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(areaUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex-grow">
                      {result !== "" && (
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <p className="text-lg font-medium">
                            <span className="text-gray-500 dark:text-gray-400">Result:</span>{" "}
                            <span className="font-bold text-tool-green">
                              {inputValue} {unitSymbols[fromUnit as keyof typeof unitSymbols]} = {result} {unitSymbols[toUnit as keyof typeof unitSymbols]}
                            </span>
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button onClick={handleCopy} disabled={result === ""}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="mt-6">
                <Tabs defaultValue="howto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="howto">How to Use</TabsTrigger>
                    <TabsTrigger value="formulas">Conversion Formulas</TabsTrigger>
                    <TabsTrigger value="history">Recent Conversions</TabsTrigger>
                  </TabsList>
                  <TabsContent value="howto" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">How to Use the Area Converter</h2>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Enter the value you want to convert in the "From" field.</li>
                      <li>Select the unit you're converting from using the dropdown menu.</li>
                      <li>Select the unit you want to convert to using the second dropdown menu.</li>
                      <li>The result will be calculated automatically and displayed instantly.</li>
                      <li>Use the "Copy" button to copy the result to your clipboard.</li>
                      <li>Use the "Reset" button to clear all fields and start over.</li>
                    </ol>
                  </TabsContent>
                  <TabsContent value="formulas" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Common Area Conversion Formulas</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Square Meter to Square Foot:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 m² = 10.764 ft²</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Hectare to Acre:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 ha = 2.471 acres</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Square Kilometer to Square Mile:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 km² = 0.386 mi²</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Square Foot to Square Inch:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 ft² = 144 in²</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Square Mile to Acre:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 mi² = 640 acres</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Square Meter to Hectare:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 m² = 0.0001 ha</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="history" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Recent Conversions</h2>
                    {recentConversions.length > 0 ? (
                      <div className="space-y-2">
                        {recentConversions.map((conversion, index) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md flex justify-between">
                            <div>
                              <span className="font-medium">
                                {conversion.input} {unitSymbols[conversion.from as keyof typeof unitSymbols]} = {conversion.output} {unitSymbols[conversion.to as keyof typeof unitSymbols]}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {conversion.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No recent conversions yet.</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How do I convert square meters to square feet?</h3>
                    <p className="mt-2">To convert square meters to square feet, multiply the area value by 10.764. For example, 1 square meter equals 10.764 square feet.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How many acres are in a hectare?</h3>
                    <p className="mt-2">There are 2.47105 acres in 1 hectare.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What is the difference between an acre and a square mile?</h3>
                    <p className="mt-2">A square mile is much larger than an acre. There are 640 acres in 1 square mile.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <AdBanner 
                size="large" 
                type="vertical"
                className="sticky top-24"
              />
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Related Converters</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/tools/length-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Length Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/volume-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Volume Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/data-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Data Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/temperature-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Temperature Converter
                    </a>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Common Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("square_meter");
                        setToUnit("square_foot");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 square meter to square feet
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("hectare");
                        setToUnit("acre");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 hectare to acres
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("square_kilometer");
                        setToUnit("square_mile");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 square kilometer to square miles
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("square_foot");
                        setToUnit("square_meter");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 square foot to square meters
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("acre");
                        setToUnit("hectare");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 acre to hectares
                    </button>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
          
          <div className="mt-8">
            <AdBanner type="horizontal" size="large" />
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default AreaConverter;
