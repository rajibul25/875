
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, Calculator } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const CompoundInterestComponent = () => {
  const [principal, setPrincipal] = useState<string>("");
  const [rate, setRate] = useState<string>("");
  const [time, setTime] = useState<string>("");
  const [compoundFrequency, setCompoundFrequency] = useState<string>("yearly");
  const [additionalContribution, setAdditionalContribution] = useState<string>("0");
  const [contributionFrequency, setContributionFrequency] = useState<string>("monthly");
  const [result, setResult] = useState<{
    finalAmount: number;
    totalInterest: number;
    totalContributions: number;
  } | null>(null);
  
  const calculateCompoundInterest = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate) / 100;
    const t = parseFloat(time);
    const contribution = parseFloat(additionalContribution);
    
    if (isNaN(p) || isNaN(r) || isNaN(t)) {
      toast.error("Please enter valid numbers for principal, rate, and time");
      return;
    }
    
    if (p <= 0 || r <= 0 || t <= 0) {
      toast.error("Principal, rate, and time must be greater than zero");
      return;
    }
    
    let n = 1; // compounding frequency
    switch (compoundFrequency) {
      case "yearly":
        n = 1;
        break;
      case "half-yearly":
        n = 2;
        break;
      case "quarterly":
        n = 4;
        break;
      case "monthly":
        n = 12;
        break;
      case "daily":
        n = 365;
        break;
    }
    
    // Compound interest calculation
    const amount = p * Math.pow(1 + r / n, n * t);
    
    // Additional contribution calculation
    let totalContributions = 0;
    let futureValueOfContributions = 0;
    
    if (!isNaN(contribution) && contribution > 0) {
      let contributionsPerYear = 0;
      switch (contributionFrequency) {
        case "monthly":
          contributionsPerYear = 12;
          break;
        case "quarterly":
          contributionsPerYear = 4;
          break;
        case "yearly":
          contributionsPerYear = 1;
          break;
      }
      
      const paymentsCount = contributionsPerYear * t;
      totalContributions = contribution * paymentsCount;
      
      // Calculate future value of periodic payments
      // PMT * (((1 + r)^n - 1) / r)
      const contributionRate = r / contributionsPerYear;
      futureValueOfContributions = contribution * 
        ((Math.pow(1 + contributionRate, paymentsCount) - 1) / contributionRate);
    }
    
    const finalAmount = amount + futureValueOfContributions;
    const totalInterest = finalAmount - p - totalContributions;
    
    setResult({
      finalAmount,
      totalInterest,
      totalContributions
    });
    
    toast.success("Compound interest calculated successfully!");
  };
  
  return (
    <ToolLayout
      title="Compound Interest Calculator"
      description="Calculate compound interest with regular contributions"
      helpText="Enter principal amount, interest rate, and time period to calculate compound interest"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="principal" className="block text-sm font-medium text-gray-700">
            Principal Amount
          </label>
          <Input
            id="principal"
            type="number"
            value={principal}
            onChange={(e) => setPrincipal(e.target.value)}
            placeholder="Enter principal amount"
            className="w-full"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="rate" className="block text-sm font-medium text-gray-700">
            Annual Interest Rate (%)
          </label>
          <Input
            id="rate"
            type="number"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
            placeholder="Enter annual interest rate"
            className="w-full"
            step="0.01"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="time" className="block text-sm font-medium text-gray-700">
            Time Period (years)
          </label>
          <Input
            id="time"
            type="number"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            placeholder="Enter time period in years"
            className="w-full"
            step="0.1"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="compoundFrequency" className="block text-sm font-medium text-gray-700">
            Compound Frequency
          </label>
          <Select value={compoundFrequency} onValueChange={setCompoundFrequency}>
            <SelectTrigger id="compoundFrequency">
              <SelectValue placeholder="Select compound frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="yearly">Yearly</SelectItem>
              <SelectItem value="half-yearly">Half-Yearly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="additionalContribution" className="block text-sm font-medium text-gray-700">
            Regular Contribution (optional)
          </label>
          <Input
            id="additionalContribution"
            type="number"
            value={additionalContribution}
            onChange={(e) => setAdditionalContribution(e.target.value)}
            placeholder="Enter regular contribution amount"
            className="w-full"
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="contributionFrequency" className="block text-sm font-medium text-gray-700">
            Contribution Frequency
          </label>
          <Select value={contributionFrequency} onValueChange={setContributionFrequency}>
            <SelectTrigger id="contributionFrequency">
              <SelectValue placeholder="Select contribution frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button 
          onClick={calculateCompoundInterest}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!principal || !rate || !time}
        >
          <TrendingUp className="mr-2 h-4 w-4" /> Calculate Interest
        </Button>
        
        {result && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-4">Interest Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Final Amount:</span>
                <span className="text-lg font-bold text-purple-600">
                  ${result.finalAmount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Total Interest:</span>
                <span className="text-lg font-bold text-purple-600">
                  ${result.totalInterest.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Initial Principal:</span>
                <span className="text-lg font-medium text-gray-700">
                  ${parseFloat(principal).toFixed(2)}
                </span>
              </div>
              {result.totalContributions > 0 && (
                <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                  <span className="text-gray-700">Total Contributions:</span>
                  <span className="text-lg font-medium text-gray-700">
                    ${result.totalContributions.toFixed(2)}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const CompoundInterest = withErrorBoundary(CompoundInterestComponent, "compound-interest");

export default CompoundInterest;
