
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Helmet } from "react-helmet";
import { ActivityIcon } from "@/components/icons/ToolIcons";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Save, Calendar, Download, Printer, Copy } from "lucide-react";

interface Exercise {
  id: string;
  name: string;
  sets: string;
  reps: string;
  weight: string;
  notes: string;
}

interface WorkoutDay {
  id: string;
  day: string;
  name: string;
  exercises: Exercise[];
  notes: string;
}

const WorkoutPlanner = () => {
  const [fitnessGoal, setFitnessGoal] = useState<string>("strength");
  const [experienceLevel, setExperienceLevel] = useState<string>("beginner");
  const [workoutDays, setWorkoutDays] = useState<number>(3);
  const [workoutPlan, setWorkoutPlan] = useState<WorkoutDay[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeDay, setActiveDay] = useState<string | null>(null);

  // Predefined exercise templates
  const exerciseTemplates = {
    strength: {
      beginner: {
        push: [
          { name: "Push-ups", sets: "3", reps: "8-10", weight: "Body" },
          { name: "Bench Press", sets: "3", reps: "8-10", weight: "" },
          { name: "Shoulder Press", sets: "3", reps: "8-10", weight: "" },
          { name: "Tricep Dips", sets: "3", reps: "8-10", weight: "Body" }
        ],
        pull: [
          { name: "Pull-ups", sets: "3", reps: "5-8", weight: "Body" },
          { name: "Bent-over Rows", sets: "3", reps: "8-10", weight: "" },
          { name: "Lat Pulldowns", sets: "3", reps: "8-10", weight: "" },
          { name: "Bicep Curls", sets: "3", reps: "10-12", weight: "" }
        ],
        legs: [
          { name: "Squats", sets: "3", reps: "10-12", weight: "" },
          { name: "Lunges", sets: "3", reps: "10 each", weight: "Body" },
          { name: "Leg Press", sets: "3", reps: "10-12", weight: "" },
          { name: "Calf Raises", sets: "3", reps: "15-20", weight: "" }
        ],
        full: [
          { name: "Squats", sets: "3", reps: "10-12", weight: "" },
          { name: "Push-ups", sets: "3", reps: "8-10", weight: "Body" },
          { name: "Bent-over Rows", sets: "3", reps: "8-10", weight: "" },
          { name: "Plank", sets: "3", reps: "30 sec", weight: "Body" }
        ]
      },
      intermediate: {
        push: [
          { name: "Bench Press", sets: "4", reps: "6-8", weight: "" },
          { name: "Incline Dumbbell Press", sets: "3", reps: "8-10", weight: "" },
          { name: "Shoulder Press", sets: "3", reps: "8-10", weight: "" },
          { name: "Skull Crushers", sets: "3", reps: "10-12", weight: "" }
        ],
        pull: [
          { name: "Weighted Pull-ups", sets: "4", reps: "6-8", weight: "" },
          { name: "Barbell Rows", sets: "4", reps: "6-8", weight: "" },
          { name: "Cable Rows", sets: "3", reps: "8-10", weight: "" },
          { name: "Face Pulls", sets: "3", reps: "12-15", weight: "" }
        ],
        legs: [
          { name: "Barbell Squats", sets: "4", reps: "6-8", weight: "" },
          { name: "Romanian Deadlifts", sets: "3", reps: "8-10", weight: "" },
          { name: "Walking Lunges", sets: "3", reps: "10 each", weight: "" },
          { name: "Leg Extensions", sets: "3", reps: "10-12", weight: "" }
        ],
        full: [
          { name: "Deadlifts", sets: "4", reps: "5-6", weight: "" },
          { name: "Bench Press", sets: "3", reps: "8-10", weight: "" },
          { name: "Pull-ups", sets: "3", reps: "8-10", weight: "Body" },
          { name: "Overhead Press", sets: "3", reps: "8-10", weight: "" }
        ]
      },
      advanced: {
        push: [
          { name: "Barbell Bench Press", sets: "5", reps: "5", weight: "" },
          { name: "Weighted Dips", sets: "4", reps: "6-8", weight: "" },
          { name: "Overhead Press", sets: "4", reps: "6-8", weight: "" },
          { name: "Cable Flyes", sets: "3", reps: "10-12", weight: "" }
        ],
        pull: [
          { name: "Weighted Pull-ups", sets: "5", reps: "5", weight: "" },
          { name: "Barbell Rows", sets: "4", reps: "6-8", weight: "" },
          { name: "T-Bar Rows", sets: "4", reps: "6-8", weight: "" },
          { name: "Face Pulls", sets: "3", reps: "12-15", weight: "" }
        ],
        legs: [
          { name: "Back Squats", sets: "5", reps: "5", weight: "" },
          { name: "Deadlifts", sets: "4", reps: "5", weight: "" },
          { name: "Front Squats", sets: "3", reps: "6-8", weight: "" },
          { name: "Bulgarian Split Squats", sets: "3", reps: "8-10 each", weight: "" }
        ],
        full: [
          { name: "Deadlifts", sets: "5", reps: "5", weight: "" },
          { name: "Bench Press", sets: "5", reps: "5", weight: "" },
          { name: "Pull-ups", sets: "4", reps: "6-8", weight: "" },
          { name: "Overhead Press", sets: "4", reps: "6-8", weight: "" }
        ]
      }
    },
    cardio: {
      beginner: {
        intervals: [
          { name: "Walking", sets: "5 min", reps: "Warm-up", weight: "N/A" },
          { name: "Brisk Walking/Light Jog", sets: "1 min", reps: "8 intervals", weight: "N/A" },
          { name: "Walking Recovery", sets: "2 min", reps: "8 intervals", weight: "N/A" },
          { name: "Cool Down Walk", sets: "5 min", reps: "1", weight: "N/A" }
        ],
        steady: [
          { name: "Brisk Walking", sets: "30 min", reps: "1", weight: "N/A" },
          { name: "Static Stretching", sets: "10 min", reps: "1", weight: "N/A" }
        ],
        cycling: [
          { name: "Easy Cycling", sets: "5 min", reps: "Warm-up", weight: "N/A" },
          { name: "Moderate Cycling", sets: "20 min", reps: "1", weight: "N/A" },
          { name: "Cool Down", sets: "5 min", reps: "1", weight: "N/A" }
        ]
      },
      intermediate: {
        intervals: [
          { name: "Jogging", sets: "5 min", reps: "Warm-up", weight: "N/A" },
          { name: "Running Intervals", sets: "2 min", reps: "8 intervals", weight: "N/A" },
          { name: "Walking Recovery", sets: "1 min", reps: "8 intervals", weight: "N/A" },
          { name: "Cool Down", sets: "5 min", reps: "1", weight: "N/A" }
        ],
        steady: [
          { name: "Jogging/Running", sets: "45 min", reps: "1", weight: "N/A" },
          { name: "Dynamic Stretching", sets: "10 min", reps: "1", weight: "N/A" }
        ],
        cycling: [
          { name: "Moderate Cycling", sets: "5 min", reps: "Warm-up", weight: "N/A" },
          { name: "Hard Cycling", sets: "30 min", reps: "1", weight: "N/A" },
          { name: "Cool Down", sets: "5 min", reps: "1", weight: "N/A" }
        ]
      },
      advanced: {
        intervals: [
          { name: "Jogging", sets: "10 min", reps: "Warm-up", weight: "N/A" },
          { name: "Sprint Intervals", sets: "1 min", reps: "10 intervals", weight: "N/A" },
          { name: "Jogging Recovery", sets: "1 min", reps: "10 intervals", weight: "N/A" },
          { name: "Cool Down", sets: "10 min", reps: "1", weight: "N/A" }
        ],
        steady: [
          { name: "Running", sets: "60 min", reps: "1", weight: "N/A" },
          { name: "Dynamic Stretching", sets: "15 min", reps: "1", weight: "N/A" }
        ],
        cycling: [
          { name: "Moderate Cycling", sets: "10 min", reps: "Warm-up", weight: "N/A" },
          { name: "Hard Cycling", sets: "45 min", reps: "1", weight: "N/A" },
          { name: "Cool Down", sets: "10 min", reps: "1", weight: "N/A" }
        ]
      }
    },
    weightloss: {
      beginner: {
        circuit: [
          { name: "Bodyweight Squats", sets: "3", reps: "15", weight: "Body" },
          { name: "Push-ups (or Modified)", sets: "3", reps: "10", weight: "Body" },
          { name: "Walking Lunges", sets: "3", reps: "10 each", weight: "Body" },
          { name: "Plank", sets: "3", reps: "30 sec", weight: "Body" }
        ],
        hiit: [
          { name: "Marching in Place", sets: "1 min", reps: "Warm-up", weight: "N/A" },
          { name: "Jumping Jacks", sets: "30 sec", reps: "5 rounds", weight: "N/A" },
          { name: "Rest", sets: "30 sec", reps: "5 rounds", weight: "N/A" },
          { name: "Mountain Climbers", sets: "30 sec", reps: "5 rounds", weight: "N/A" }
        ],
        cardio: [
          { name: "Brisk Walking", sets: "30 min", reps: "1", weight: "N/A" },
          { name: "Stretching", sets: "5 min", reps: "1", weight: "N/A" }
        ]
      },
      intermediate: {
        circuit: [
          { name: "Kettlebell Swings", sets: "3", reps: "15", weight: "" },
          { name: "Push-ups", sets: "3", reps: "15", weight: "Body" },
          { name: "Goblet Squats", sets: "3", reps: "15", weight: "" },
          { name: "Renegade Rows", sets: "3", reps: "10 each", weight: "" }
        ],
        hiit: [
          { name: "Jogging in Place", sets: "2 min", reps: "Warm-up", weight: "N/A" },
          { name: "Burpees", sets: "40 sec", reps: "6 rounds", weight: "N/A" },
          { name: "Rest", sets: "20 sec", reps: "6 rounds", weight: "N/A" },
          { name: "High Knees", sets: "40 sec", reps: "6 rounds", weight: "N/A" }
        ],
        cardio: [
          { name: "Jogging/Running", sets: "30 min", reps: "1", weight: "N/A" },
          { name: "Stretching", sets: "10 min", reps: "1", weight: "N/A" }
        ]
      },
      advanced: {
        circuit: [
          { name: "Deadlifts", sets: "4", reps: "12", weight: "" },
          { name: "Box Jumps", sets: "4", reps: "15", weight: "Body" },
          { name: "Dumbbell Thrusters", sets: "4", reps: "15", weight: "" },
          { name: "Battle Ropes", sets: "4", reps: "30 sec", weight: "N/A" }
        ],
        hiit: [
          { name: "Dynamic Warm-up", sets: "5 min", reps: "1", weight: "N/A" },
          { name: "Sprints", sets: "30 sec", reps: "8 rounds", weight: "N/A" },
          { name: "Rest", sets: "15 sec", reps: "8 rounds", weight: "N/A" },
          { name: "Burpee Pull-ups", sets: "30 sec", reps: "8 rounds", weight: "N/A" }
        ],
        cardio: [
          { name: "Running", sets: "45 min", reps: "1", weight: "N/A" },
          { name: "Dynamic Stretching", sets: "15 min", reps: "1", weight: "N/A" }
        ]
      }
    }
  };

  const generateWorkoutPlan = () => {
    try {
      setIsGenerating(true);
      
      // Create days based on workout frequency
      let newWorkoutPlan: WorkoutDay[] = [];
      const dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
      
      // Define workout splits based on number of days
      let workoutTypes: string[];
      
      if (fitnessGoal === "strength") {
        switch (workoutDays) {
          case 3: 
            workoutTypes = ["push", "pull", "legs"];
            break;
          case 4:
            workoutTypes = ["push", "pull", "legs", "full"];
            break;
          case 5:
            workoutTypes = ["push", "pull", "legs", "push", "pull"];
            break;
          case 6:
            workoutTypes = ["push", "pull", "legs", "push", "pull", "legs"];
            break;
          default:
            workoutTypes = ["full", "full", "full"];
        }
      } else if (fitnessGoal === "cardio") {
        switch (workoutDays) {
          case 3:
            workoutTypes = ["intervals", "steady", "intervals"];
            break;
          case 4:
            workoutTypes = ["intervals", "steady", "cycling", "intervals"];
            break;
          case 5:
            workoutTypes = ["intervals", "steady", "intervals", "cycling", "steady"];
            break;
          case 6:
            workoutTypes = ["intervals", "steady", "intervals", "cycling", "steady", "intervals"];
            break;
          default:
            workoutTypes = ["intervals", "steady", "intervals"];
        }
      } else {
        // Weight loss
        switch (workoutDays) {
          case 3:
            workoutTypes = ["circuit", "cardio", "hiit"];
            break;
          case 4:
            workoutTypes = ["circuit", "cardio", "hiit", "circuit"];
            break;
          case 5:
            workoutTypes = ["circuit", "cardio", "hiit", "circuit", "cardio"];
            break;
          case 6:
            workoutTypes = ["circuit", "cardio", "hiit", "circuit", "cardio", "hiit"];
            break;
          default:
            workoutTypes = ["circuit", "cardio", "hiit"];
        }
      }
      
      // Create workout days
      for (let i = 0; i < workoutDays; i++) {
        const workoutType = workoutTypes[i % workoutTypes.length];
        const dayName = dayNames[i];
        const typeDisplayName = workoutType.charAt(0).toUpperCase() + workoutType.slice(1);
        
        // Get exercises from templates based on goal, experience, and workout type
        const templateExercises = (exerciseTemplates as any)[fitnessGoal][experienceLevel][workoutType];
        
        // Create exercises with unique IDs
        const exercises: Exercise[] = templateExercises.map((ex: any) => ({
          id: crypto.randomUUID(),
          name: ex.name,
          sets: ex.sets,
          reps: ex.reps,
          weight: ex.weight,
          notes: ""
        }));
        
        newWorkoutPlan.push({
          id: crypto.randomUUID(),
          day: dayName,
          name: `${fitnessGoal === "strength" ? "Strength" : fitnessGoal === "cardio" ? "Cardio" : "Fat Loss"}: ${typeDisplayName}`,
          exercises: exercises,
          notes: `${dayName} ${typeDisplayName} workout`
        });
      }
      
      // Simulate a small delay for feedback
      setTimeout(() => {
        setWorkoutPlan(newWorkoutPlan);
        setActiveDay(newWorkoutPlan[0]?.id);
        setIsGenerating(false);
        toast.success("Workout plan generated successfully!");
      }, 800);
    } catch (error) {
      setIsGenerating(false);
      toast.error("Error generating workout plan. Please try again.");
      console.error("Workout plan generation error:", error);
    }
  };

  const addExercise = (dayId: string) => {
    setWorkoutPlan(prev => prev.map(day => {
      if (day.id === dayId) {
        return {
          ...day,
          exercises: [
            ...day.exercises,
            {
              id: crypto.randomUUID(),
              name: "",
              sets: "",
              reps: "",
              weight: "",
              notes: ""
            }
          ]
        };
      }
      return day;
    }));
  };

  const removeExercise = (dayId: string, exerciseId: string) => {
    setWorkoutPlan(prev => prev.map(day => {
      if (day.id === dayId) {
        return {
          ...day,
          exercises: day.exercises.filter(ex => ex.id !== exerciseId)
        };
      }
      return day;
    }));
  };

  const updateExercise = (dayId: string, exerciseId: string, field: keyof Exercise, value: string) => {
    setWorkoutPlan(prev => prev.map(day => {
      if (day.id === dayId) {
        return {
          ...day,
          exercises: day.exercises.map(ex => {
            if (ex.id === exerciseId) {
              return {
                ...ex,
                [field]: value
              };
            }
            return ex;
          })
        };
      }
      return day;
    }));
  };

  const updateWorkoutNotes = (dayId: string, notes: string) => {
    setWorkoutPlan(prev => prev.map(day => {
      if (day.id === dayId) {
        return {
          ...day,
          notes
        };
      }
      return day;
    }));
  };

  const saveWorkout = () => {
    localStorage.setItem('workoutPlan', JSON.stringify(workoutPlan));
    toast.success("Workout plan saved successfully!");
  };

  const printWorkout = () => {
    window.print();
  };

  const downloadWorkout = () => {
    try {
      // Create a text representation of the workout plan
      let textContent = "MY WORKOUT PLAN\n\n";
      
      workoutPlan.forEach(day => {
        textContent += `== ${day.day}: ${day.name} ==\n\n`;
        day.exercises.forEach(ex => {
          textContent += `${ex.name}: ${ex.sets} sets × ${ex.reps} reps ${ex.weight ? `(${ex.weight})` : ""}\n`;
          if (ex.notes) textContent += `Notes: ${ex.notes}\n`;
        });
        textContent += `\nDay Notes: ${day.notes}\n\n`;
      });
      
      // Create a Blob with the text
      const blob = new Blob([textContent], { type: 'text/plain' });
      
      // Create a download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'my_workout_plan.txt';
      
      // Trigger download
      document.body.appendChild(a);
      a.click();
      
      // Cleanup
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success("Workout plan downloaded as text file!");
    } catch (error) {
      toast.error("Error downloading workout plan. Please try again.");
      console.error("Download error:", error);
    }
  };

  const copyWorkout = () => {
    try {
      // Create a text representation of the workout plan
      let textContent = "MY WORKOUT PLAN\n\n";
      
      workoutPlan.forEach(day => {
        textContent += `== ${day.day}: ${day.name} ==\n\n`;
        day.exercises.forEach(ex => {
          textContent += `${ex.name}: ${ex.sets} sets × ${ex.reps} reps ${ex.weight ? `(${ex.weight})` : ""}\n`;
          if (ex.notes) textContent += `Notes: ${ex.notes}\n`;
        });
        textContent += `\nDay Notes: ${day.notes}\n\n`;
      });
      
      // Copy to clipboard
      navigator.clipboard.writeText(textContent);
      toast.success("Workout plan copied to clipboard!");
    } catch (error) {
      toast.error("Error copying workout plan. Please try again.");
      console.error("Copy error:", error);
    }
  };

  return (
    <>
      <Helmet>
        <title>Workout Planner | Create Custom Workout Plans | MultitoolSet</title>
        <meta name="description" content="Create personalized workout plans based on your fitness goals, experience level, and schedule. Our free workout planner helps you design effective strength, cardio, or weight loss routines." />
        <meta name="keywords" content="workout planner, workout plan creator, exercise planner, fitness planner, strength training plan, cardio workout plan, weight loss workout, custom workout program" />
        <link rel="canonical" href="https://multitoolset.com/tools/workout-planner" />
        <meta property="og:title" content="Workout Planner | Create Custom Workout Plans" />
        <meta property="og:description" content="Create personalized workout plans based on your fitness goals, experience level, and schedule with our free workout planner." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/workout-planner" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Workout Planner | Create Custom Workout Plans" />
        <meta name="twitter:description" content="Create personalized workout plans based on your fitness goals, experience level, and schedule with our free workout planner." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Workout Planner",
              "description": "Create personalized workout plans based on your fitness goals, experience level, and schedule.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I create an effective workout plan?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To create an effective workout plan, first determine your fitness goals (strength, cardio, weight loss), consider your experience level, decide how many days per week you can train, and plan for progressive overload. Our workout planner helps you generate a personalized plan based on these factors."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many days per week should I work out?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "The ideal workout frequency depends on your goals, schedule, and recovery capacity. Beginners can see results with 2-3 days per week, intermediate exercisers often benefit from 3-4 days, and advanced athletes might train 4-6 days per week. Always include at least 1-2 rest days per week for recovery."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What's the difference between strength, cardio, and weight loss workout plans?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Strength training plans focus on progressive resistance exercise to build muscle and strength. Cardio plans emphasize cardiovascular endurance through activities like running or cycling. Weight loss plans typically combine both resistance training and cardiovascular exercise with an emphasis on calorie burning and metabolic conditioning."
                  }
                }
              ]
            }
          `}
        </script>
        <meta name="robots" content="index, follow" />
      </Helmet>
    
      <ToolLayout
        title="Workout Planner"
        description="Create personalized workout plans based on your fitness goals, experience level, and schedule."
        helpText="Select your fitness goal, experience level, and workout frequency to generate a custom workout plan."
      >
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="generate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="generate">Create Workout Plan</TabsTrigger>
                <TabsTrigger value="tips">Workout Tips</TabsTrigger>
              </TabsList>
              
              <TabsContent value="generate" className="space-y-6 pt-4">
                {workoutPlan.length === 0 ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="fitnessGoal">Fitness Goal</Label>
                      <Select
                        value={fitnessGoal}
                        onValueChange={setFitnessGoal}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your fitness goal" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="strength">Strength & Muscle Building</SelectItem>
                          <SelectItem value="cardio">Cardiovascular Fitness</SelectItem>
                          <SelectItem value="weightloss">Weight Loss</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="experienceLevel">Experience Level</Label>
                      <Select
                        value={experienceLevel}
                        onValueChange={setExperienceLevel}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner (0-1 year)</SelectItem>
                          <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                          <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="workoutDays">Workout Days Per Week</Label>
                      <Select
                        value={workoutDays.toString()}
                        onValueChange={(value) => setWorkoutDays(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select number of workout days" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 days</SelectItem>
                          <SelectItem value="4">4 days</SelectItem>
                          <SelectItem value="5">5 days</SelectItem>
                          <SelectItem value="6">6 days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <Button 
                      onClick={generateWorkoutPlan} 
                      className="w-full mt-4"
                      disabled={isGenerating}
                    >
                      {isGenerating ? "Generating Plan..." : "Generate Workout Plan"}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="font-semibold text-lg">Your Custom Workout Plan</h3>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={saveWorkout} title="Save to browser">
                          <Save className="h-4 w-4 mr-1" />
                          <span className="hidden sm:inline">Save</span>
                        </Button>
                        <Button variant="outline" size="sm" onClick={printWorkout} title="Print workout">
                          <Printer className="h-4 w-4 mr-1" />
                          <span className="hidden sm:inline">Print</span>
                        </Button>
                        <Button variant="outline" size="sm" onClick={downloadWorkout} title="Download as text">
                          <Download className="h-4 w-4 mr-1" />
                          <span className="hidden sm:inline">Download</span>
                        </Button>
                        <Button variant="outline" size="sm" onClick={copyWorkout} title="Copy to clipboard">
                          <Copy className="h-4 w-4 mr-1" />
                          <span className="hidden sm:inline">Copy</span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-7 gap-2 overflow-x-auto">
                      {workoutPlan.map((day) => (
                        <Button
                          key={day.id}
                          variant={activeDay === day.id ? "default" : "outline"}
                          className="text-xs sm:text-sm py-1 h-auto flex flex-col"
                          onClick={() => setActiveDay(day.id)}
                        >
                          <span>{day.day}</span>
                          <span className="text-xs truncate max-w-full">{day.name}</span>
                        </Button>
                      ))}
                    </div>
                    
                    {activeDay && workoutPlan.find(day => day.id === activeDay) && (
                      <div className="border rounded-lg p-4">
                        {workoutPlan.map(day => day.id === activeDay && (
                          <div key={day.id} className="space-y-4">
                            <div className="flex justify-between items-center">
                              <h4 className="font-medium text-lg">{day.day}: {day.name}</h4>
                              <Button 
                                size="sm" 
                                onClick={() => addExercise(day.id)}
                                className="text-xs"
                              >
                                <Plus className="h-3.5 w-3.5 mr-1" />
                                Add Exercise
                              </Button>
                            </div>
                            
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="w-[200px]">Exercise</TableHead>
                                    <TableHead className="w-[80px]">Sets</TableHead>
                                    <TableHead className="w-[100px]">Reps</TableHead>
                                    <TableHead className="w-[100px]">Weight</TableHead>
                                    <TableHead className="w-[200px]">Notes</TableHead>
                                    <TableHead className="w-[50px]"></TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {day.exercises.map(exercise => (
                                    <TableRow key={exercise.id}>
                                      <TableCell>
                                        <Input
                                          value={exercise.name}
                                          onChange={(e) => updateExercise(day.id, exercise.id, 'name', e.target.value)}
                                          placeholder="Exercise name"
                                        />
                                      </TableCell>
                                      <TableCell>
                                        <Input
                                          value={exercise.sets}
                                          onChange={(e) => updateExercise(day.id, exercise.id, 'sets', e.target.value)}
                                          placeholder="Sets"
                                        />
                                      </TableCell>
                                      <TableCell>
                                        <Input
                                          value={exercise.reps}
                                          onChange={(e) => updateExercise(day.id, exercise.id, 'reps', e.target.value)}
                                          placeholder="Reps"
                                        />
                                      </TableCell>
                                      <TableCell>
                                        <Input
                                          value={exercise.weight}
                                          onChange={(e) => updateExercise(day.id, exercise.id, 'weight', e.target.value)}
                                          placeholder="Weight"
                                        />
                                      </TableCell>
                                      <TableCell>
                                        <Input
                                          value={exercise.notes}
                                          onChange={(e) => updateExercise(day.id, exercise.id, 'notes', e.target.value)}
                                          placeholder="Notes"
                                        />
                                      </TableCell>
                                      <TableCell>
                                        <Button 
                                          variant="ghost" 
                                          size="sm"
                                          className="text-red-500 hover:text-red-700 hover:bg-red-50 px-2"
                                          onClick={() => removeExercise(day.id, exercise.id)}
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            
                            <div>
                              <Label htmlFor="workoutNotes">Workout Notes</Label>
                              <Textarea
                                id="workoutNotes"
                                value={day.notes}
                                onChange={(e) => updateWorkoutNotes(day.id, e.target.value)}
                                placeholder="Add notes for this workout day"
                                className="min-h-[100px]"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex justify-between pt-4">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setWorkoutPlan([]);
                          setActiveDay(null);
                        }}
                      >
                        Start Over
                      </Button>
                      <Button onClick={saveWorkout}>
                        <Save className="h-4 w-4 mr-1" />
                        Save Workout Plan
                      </Button>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="tips" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Workout Plan Basics</h3>
                  <p className="text-gray-700 dark:text-gray-300 mb-2">
                    An effective workout plan balances several key components:
                  </p>
                  <ul className="list-disc ml-5 text-gray-700 dark:text-gray-300">
                    <li><strong>Frequency:</strong> How many days per week you'll work out</li>
                    <li><strong>Volume:</strong> The total amount of sets, reps, and exercises</li>
                    <li><strong>Intensity:</strong> How challenging each workout is</li>
                    <li><strong>Recovery:</strong> Planned rest to allow muscles to repair and grow</li>
                    <li><strong>Progression:</strong> Gradually increasing challenge over time</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Goals & Training Types</h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded border dark:bg-blue-900/20 dark:border-blue-800/30">
                      <h4 className="font-medium text-blue-700 dark:text-blue-400">Strength & Muscle Building</h4>
                      <ul className="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                        <li>Focus on resistance training with progressive overload</li>
                        <li>Typical rep ranges: 6-12 reps for hypertrophy, 1-5 reps for strength</li>
                        <li>Rest periods: 1-3 minutes between sets</li>
                        <li>Common splits: Push/Pull/Legs, Upper/Lower, Full Body</li>
                      </ul>
                    </div>
                    <div className="p-3 bg-green-50 rounded border dark:bg-green-900/20 dark:border-green-800/30">
                      <h4 className="font-medium text-green-700 dark:text-green-400">Cardiovascular Fitness</h4>
                      <ul className="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                        <li>Mix of steady-state cardio and interval training</li>
                        <li>Low intensity (Zone 2) builds aerobic base</li>
                        <li>High intensity intervals improve VO2 max</li>
                        <li>Duration typically 20-60 minutes per session</li>
                      </ul>
                    </div>
                    <div className="p-3 bg-orange-50 rounded border dark:bg-orange-900/20 dark:border-orange-800/30">
                      <h4 className="font-medium text-orange-700 dark:text-orange-400">Weight Loss</h4>
                      <ul className="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                        <li>Combination of resistance training and cardio</li>
                        <li>Circuit training and HIIT for calorie burning</li>
                        <li>Focus on compound movements that engage multiple muscle groups</li>
                        <li>Diet plays a major role in weight loss success</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Tips for Success</h3>
                  <ul className="list-disc ml-5 text-gray-700 dark:text-gray-300">
                    <li><strong>Start slowly</strong> and gradually increase intensity to avoid injury and burnout</li>
                    <li><strong>Be consistent</strong> - regularity is more important than perfection</li>
                    <li><strong>Track your progress</strong> to stay motivated and ensure you're improving</li>
                    <li><strong>Listen to your body</strong> and adjust your plan when needed</li>
                    <li><strong>Focus on form</strong> rather than lifting heavier weights with poor technique</li>
                    <li><strong>Include mobility work</strong> and proper warm-ups to prevent injury</li>
                    <li><strong>Plan for deload weeks</strong> every 4-8 weeks to avoid overtraining</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Exercise Selection Tips</h3>
                  <ul className="list-disc ml-5 text-gray-700 dark:text-gray-300">
                    <li><strong>Compound exercises</strong> (squat, deadlift, bench press, rows) give more bang for your buck</li>
                    <li><strong>Isolation exercises</strong> (bicep curls, leg extensions) help target specific muscles</li>
                    <li><strong>Exercise variety</strong> helps prevent plateaus and keeps workouts interesting</li>
                    <li><strong>Equipment availability</strong> should influence your exercise selection</li>
                    <li><strong>Movement patterns</strong> to include: pushing, pulling, squatting, hinging, rotation, and carrying</li>
                  </ul>
                </div>
                
                <div className="py-2">
                  <h3 className="text-lg font-semibold mb-2">Common Mistakes to Avoid</h3>
                  <ul className="list-disc ml-5 text-gray-700 dark:text-gray-300">
                    <li>Trying to do too much too soon</li>
                    <li>Not allowing adequate recovery time</li>
                    <li>Neglecting proper nutrition and hydration</li>
                    <li>Following someone else's plan without personalization</li>
                    <li>Skipping warm-ups and cool-downs</li>
                    <li>Focusing only on strengths and avoiding weaknesses</li>
                    <li>Not adjusting your plan as you progress</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmr-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMR Calculator</a>
              </li>
              <li>
                <a href="/tools/heart-rate-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Heart Rate Calculator</a>
              </li>
              <li>
                <a href="/tools/pace-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Pace Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400">Calorie Counter</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default WorkoutPlanner;
