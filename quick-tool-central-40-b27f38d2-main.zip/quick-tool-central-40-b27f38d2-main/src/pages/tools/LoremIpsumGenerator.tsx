import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save, RefreshCw, Code } from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

const LoremIpsumGenerator = () => {
  const [paragraphCount, setParagraphCount] = useState(3);
  const [sentenceCount, setSentenceCount] = useState(5);
  const [wordCount, setWordCount] = useState(0); // 0 means default
  const [format, setFormat] = useState("plain");
  const [startWithLorem, setStartWithLorem] = useState(true);
  const [generatedText, setGeneratedText] = useState("");
  const [generationType, setGenerationType] = useState("paragraphs");
  const [htmlTag, setHtmlTag] = useState("p");
  
  // Generate text on initial load and when parameters change
  useEffect(() => {
    generateLoremIpsum();
  }, []);

  const generateLoremIpsum = () => {
    // Sample lorem ipsum text pool
    const loremIpsumPool = [
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.",
      "Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante.",
      "Donec eu libero sit amet quam egestas semper.",
      "Aenean ultricies mi vitae est.",
      "Mauris placerat eleifend leo.",
      "Quisque sit amet est et sapien ullamcorper pharetra.",
      "Vestibulum erat wisi, condimentum sed, commodo vitae, ornare sit amet, wisi.",
      "Aenean fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui.",
      "Donec non enim in turpis pulvinar facilisis.",
      "Ut felis.",
      "Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat.",
      "Aliquam erat volutpat.",
      "Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus.",
      "Phasellus ultrices nulla quis nibh.",
      "Quisque a lectus.",
      "Donec consectetuer ligula vulputate sem tristique cursus.",
      "Nam nulla quam, gravida non, commodo a, sodales sit amet, nisi.",
      "Pellentesque fermentum dolor.",
      "Aliquam quam lectus, facilisis auctor, ultrices ut, elementum vulputate, nunc.",
      "Sed adipiscing ornare risus.",
      "Morbi est est, blandit sit amet, sagittis vel, euismod vel, velit.",
      "Pellentesque egestas sem.",
      "Suspendisse commodo ullamcorper magna.",
    ];
    
    const startSentence = startWithLorem ? loremIpsumPool[0] : loremIpsumPool[Math.floor(Math.random() * loremIpsumPool.length)];
    
    let result = "";
    
    // Generate based on selected type
    if (generationType === "paragraphs") {
      // Generate paragraphs
      for (let p = 0; p < paragraphCount; p++) {
        let paragraph = "";
        
        // First paragraph starts with "Lorem ipsum" if selected
        if (p === 0 && startWithLorem) {
          paragraph = startSentence + " ";
          for (let s = 1; s < sentenceCount; s++) {
            const randomIndex = Math.floor(Math.random() * loremIpsumPool.length);
            paragraph += loremIpsumPool[randomIndex] + " ";
          }
        } else {
          // Other paragraphs are completely random
          for (let s = 0; s < sentenceCount; s++) {
            const randomIndex = Math.floor(Math.random() * loremIpsumPool.length);
            paragraph += loremIpsumPool[randomIndex] + " ";
          }
        }
        
        // Format paragraph based on selected format
        if (format === "plain") {
          result += paragraph.trim() + "\n\n";
        } else if (format === "html") {
          result += `<${htmlTag}>${paragraph.trim()}</${htmlTag}>\n`;
        }
      }
    } else if (generationType === "sentences") {
      // Generate sentences
      let sentences = "";
      
      // First sentence is "Lorem ipsum" if selected
      if (startWithLorem) {
        sentences = startSentence + " ";
        for (let s = 1; s < sentenceCount; s++) {
          const randomIndex = Math.floor(Math.random() * loremIpsumPool.length);
          sentences += loremIpsumPool[randomIndex] + " ";
        }
      } else {
        // All sentences are random
        for (let s = 0; s < sentenceCount; s++) {
          const randomIndex = Math.floor(Math.random() * loremIpsumPool.length);
          sentences += loremIpsumPool[randomIndex] + " ";
        }
      }
      
      result = sentences.trim();
      
      if (format === "html") {
        result = `<${htmlTag}>${result}</${htmlTag}>`;
      }
    } else if (generationType === "words") {
      // Generate specific number of words
      const allWords = loremIpsumPool.join(" ").split(/\s+/);
      const actualWordCount = wordCount > 0 ? wordCount : 50; // Default to 50 words if not specified
      
      let words = [];
      
      // Start with "Lorem ipsum" if selected
      if (startWithLorem) {
        const loremWords = "Lorem ipsum dolor sit amet".split(" ");
        words = loremWords;
        
        // Add remaining words
        for (let w = words.length; w < actualWordCount; w++) {
          const randomIndex = Math.floor(Math.random() * allWords.length);
          words.push(allWords[randomIndex]);
        }
      } else {
        // All words are random
        for (let w = 0; w < actualWordCount; w++) {
          const randomIndex = Math.floor(Math.random() * allWords.length);
          words.push(allWords[randomIndex]);
        }
      }
      
      result = words.join(" ");
      
      if (format === "html") {
        result = `<${htmlTag}>${result}</${htmlTag}>`;
      }
    }
    
    setGeneratedText(result.trim());
  };

  const copyText = () => {
    navigator.clipboard.writeText(generatedText);
    toast.success("Lorem ipsum text copied to clipboard");
  };
  
  const downloadText = () => {
    const blob = new Blob([generatedText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "lorem-ipsum.txt";
    link.href = url;
    link.click();
    toast.success("Lorem ipsum text downloaded successfully");
  };
  
  const handleHtmlPreview = () => {
    // Create a new window with the generated HTML
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Lorem Ipsum Preview</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              padding: 20px;
              max-width: 800px;
              margin: 0 auto;
            }
          </style>
        </head>
        <body>
          ${generatedText}
        </body>
        </html>
      `);
    } else {
      toast.error("Unable to open preview window. Please check your popup blocker settings.");
    }
  };

  return (
    <ToolLayout 
      title="Lorem Ipsum Generator"
      description="Generate placeholder text for your designs and layouts"
      helpText="Create custom lorem ipsum placeholder text with controls for paragraphs, sentences, and formatting."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Generator Options</h3>
            
            <Tabs value={generationType} onValueChange={setGenerationType} className="w-full">
              <TabsList>
                <TabsTrigger value="paragraphs">Paragraphs</TabsTrigger>
                <TabsTrigger value="sentences">Sentences</TabsTrigger>
                <TabsTrigger value="words">Words</TabsTrigger>
              </TabsList>
              
              <TabsContent value="paragraphs" className="space-y-4 mt-4">
                <div className="flex items-center gap-4">
                  <div className="w-full max-w-[180px]">
                    <Label htmlFor="paragraph-count">Number of paragraphs</Label>
                    <Input 
                      id="paragraph-count" 
                      type="number" 
                      value={paragraphCount}
                      onChange={(e) => setParagraphCount(parseInt(e.target.value) || 1)}
                      min="1"
                      max="50"
                    />
                  </div>
                  
                  <div className="w-full max-w-[180px]">
                    <Label htmlFor="sentence-count">Sentences per paragraph</Label>
                    <Input 
                      id="sentence-count" 
                      type="number" 
                      value={sentenceCount}
                      onChange={(e) => setSentenceCount(parseInt(e.target.value) || 1)}
                      min="1"
                      max="15"
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="sentences" className="space-y-4 mt-4">
                <div className="w-full max-w-[180px]">
                  <Label htmlFor="sentence-count-only">Number of sentences</Label>
                  <Input 
                    id="sentence-count-only" 
                    type="number" 
                    value={sentenceCount}
                    onChange={(e) => setSentenceCount(parseInt(e.target.value) || 1)}
                    min="1"
                    max="50"
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="words" className="space-y-4 mt-4">
                <div className="w-full max-w-[180px]">
                  <Label htmlFor="word-count">Number of words</Label>
                  <Input 
                    id="word-count" 
                    type="number" 
                    value={wordCount || 50}
                    onChange={(e) => setWordCount(parseInt(e.target.value) || 50)}
                    min="1"
                    max="1000"
                  />
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="space-y-4 pt-4">
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="format-select">Output Format</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger id="format-select" className="w-[180px]">
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="plain">Plain Text</SelectItem>
                      <SelectItem value="html">HTML</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {format === "html" && (
                  <div className="flex items-center justify-between">
                    <Label htmlFor="tag-select">HTML Tag</Label>
                    <Select value={htmlTag} onValueChange={setHtmlTag}>
                      <SelectTrigger id="tag-select" className="w-[180px]">
                        <SelectValue placeholder="Select HTML tag" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="p">Paragraph (p)</SelectItem>
                        <SelectItem value="div">Div (div)</SelectItem>
                        <SelectItem value="span">Span (span)</SelectItem>
                        <SelectItem value="h1">Heading 1 (h1)</SelectItem>
                        <SelectItem value="h2">Heading 2 (h2)</SelectItem>
                        <SelectItem value="h3">Heading 3 (h3)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="start-with-lorem"
                    checked={startWithLorem}
                    onCheckedChange={setStartWithLorem}
                  />
                  <Label htmlFor="start-with-lorem">Start with "Lorem ipsum dolor sit amet"</Label>
                </div>
              </div>
              
              <Button onClick={generateLoremIpsum} className="w-full">
                <RefreshCw className="h-4 w-4 mr-2" />
                Generate Lorem Ipsum
              </Button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Generated Lorem Ipsum</h3>
              {format === "html" && (
                <Button variant="outline" size="sm" onClick={handleHtmlPreview}>
                  <Code className="h-4 w-4 mr-2" />
                  Preview HTML
                </Button>
              )}
            </div>
            
            <div className="rounded-lg border shadow-sm">
              <Textarea
                className="min-h-[300px] p-4 text-base border-0 resize-y font-mono"
                value={generatedText}
                readOnly
              />
              <div className="p-3 bg-muted/20 border-t flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={copyText}>
                  <Copy className="h-4 w-4 mr-2" /> Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadText}>
                  <Save className="h-4 w-4 mr-2" /> Save
                </Button>
              </div>
            </div>
            
            <div>
              <p className="text-sm text-muted-foreground">
                Words: {generatedText.split(/\s+/).filter(Boolean).length} | 
                Characters: {generatedText.length} | 
                Characters (no spaces): {generatedText.replace(/\s+/g, "").length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Select whether you want to generate paragraphs, sentences, or words.</li>
            <li>Set the desired number of paragraphs, sentences per paragraph, or total words.</li>
            <li>Choose the output format (plain text or HTML).</li>
            <li>If HTML is selected, choose the HTML tag to wrap the lorem ipsum text.</li>
            <li>Toggle the option to start with the classic "Lorem ipsum dolor sit amet" text.</li>
            <li>Click "Generate Lorem Ipsum" to create your placeholder text.</li>
            <li>Copy or download the generated text for use in your projects.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">About Lorem Ipsum</h2>
          <div className="space-y-4">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            <p>The text is derived from sections 1.10.32 and 1.10.33 of Cicero's "De Finibus Bonorum et Malorum" (The Extremes of Good and Evil), written in 45 BC.</p>
            <p>It is used by designers, developers, and content creators as placeholder text when the actual copy is not yet available, allowing them to focus on layout and design elements without being distracted by meaningful content.</p>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">Why use Lorem Ipsum instead of real text?</h3>
              <p className="text-muted-foreground">Lorem Ipsum is used because it has a more-or-less normal distribution of letters, making it look like readable English without distracting readers with actual content. This allows designers to focus on layout and formatting.</p>
            </div>
            <div>
              <h3 className="font-bold">What does "Lorem Ipsum" actually mean?</h3>
              <p className="text-muted-foreground">The words in Lorem Ipsum are derived from Latin, but the text itself doesn't have a coherent meaning as it's been scrambled and modified from its original source in Cicero's work "De Finibus Bonorum et Malorum."</p>
            </div>
            <div>
              <h3 className="font-bold">Can I use Lorem Ipsum for commercial projects?</h3>
              <p className="text-muted-foreground">Yes, Lorem Ipsum is free to use for any project, personal or commercial. It's in the public domain and not subject to copyright restrictions.</p>
            </div>
            <div>
              <h3 className="font-bold">How much Lorem Ipsum should I use?</h3>
              <p className="text-muted-foreground">Use an amount that approximates the length of your final content. This helps provide a realistic representation of how your design will look with actual text.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default LoremIpsumGenerator;
