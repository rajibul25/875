
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save, Share2 } from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const WordCounter = () => {
  const [text, setText] = useState("");
  const [stats, setStats] = useState({
    wordCount: 0,
    charCount: 0,
    charCountNoSpaces: 0,
    sentenceCount: 0,
    paragraphCount: 0,
    readingTime: 0,
    speakingTime: 0,
  });
  const [keywordDensity, setKeywordDensity] = useState<{[key: string]: number}>({});

  useEffect(() => {
    analyzeText(text);
  }, [text]);

  const analyzeText = (content: string) => {
    // Word count
    const words = content.trim() ? content.trim().split(/\s+/) : [];
    const wordCount = words.length;

    // Character count
    const charCount = content.length;
    const charCountNoSpaces = content.replace(/\s+/g, "").length;

    // Sentence count
    const sentenceCount = content.trim() ? content.split(/[.!?]+/).filter(Boolean).length : 0;

    // Paragraph count
    const paragraphCount = content.trim() ? content.split(/\n+/).filter(Boolean).length : 0;
    
    // Reading time (average adult reading speed: 225 words per minute)
    const readingTime = Math.ceil(wordCount / 225);
    
    // Speaking time (average speaking speed: 150 words per minute)
    const speakingTime = Math.ceil(wordCount / 150);

    // Keyword density
    const keywordMap: {[key: string]: number} = {};
    if (wordCount > 0) {
      words
        .map(word => word.toLowerCase().replace(/[^\w\s]/g, ""))
        .filter(word => word.length > 3)
        .forEach(word => {
          keywordMap[word] = (keywordMap[word] || 0) + 1;
        });
    }

    // Sort keywords by frequency
    const sortedKeywords = Object.entries(keywordMap)
      .sort(([, countA], [, countB]) => countB - countA)
      .slice(0, 10)
      .reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
      }, {} as {[key: string]: number});

    setStats({
      wordCount,
      charCount,
      charCountNoSpaces,
      sentenceCount,
      paragraphCount,
      readingTime,
      speakingTime
    });

    setKeywordDensity(sortedKeywords);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const copyText = () => {
    navigator.clipboard.writeText(text);
    toast.success("Text copied to clipboard");
  };

  const downloadText = () => {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "word-counter-text.txt";
    link.href = url;
    link.click();
    toast.success("Text downloaded successfully");
  };

  const downloadCsv = () => {
    let csvContent = "Keyword,Count,Percentage\n";
    Object.entries(keywordDensity).forEach(([word, count]) => {
      const percentage = ((count / stats.wordCount) * 100).toFixed(2);
      csvContent += `${word},${count},${percentage}%\n`;
    });
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "keyword-density.csv";
    link.href = url;
    link.click();
    toast.success("CSV downloaded successfully");
  };

  return (
    <ToolLayout 
      title="Word Counter"
      description="Count words, characters & analyze keyword density in your text"
      helpText="Enter your text to analyze word count, character count, reading time, and keyword density."
    >
      <div className="space-y-6">
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here..."
            className="min-h-[250px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
            aria-label="Text input for analysis"
          />
          <div className="p-3 bg-muted/20 border-t flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={copyText}>
              <Copy className="h-4 w-4 mr-2" /> Copy
            </Button>
            <Button variant="outline" size="sm" onClick={downloadText}>
              <Save className="h-4 w-4 mr-2" /> Save as TXT
            </Button>
          </div>
        </div>

        <Tabs defaultValue="statistics" className="w-full">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="statistics">Text Statistics</TabsTrigger>
            <TabsTrigger value="keywords">Keyword Density</TabsTrigger>
          </TabsList>
          
          <TabsContent value="statistics" className="mt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.wordCount}</div>
                <div className="text-sm text-muted-foreground">Words</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.charCount}</div>
                <div className="text-sm text-muted-foreground">Characters</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.charCountNoSpaces}</div>
                <div className="text-sm text-muted-foreground">Characters (no spaces)</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.sentenceCount}</div>
                <div className="text-sm text-muted-foreground">Sentences</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.paragraphCount}</div>
                <div className="text-sm text-muted-foreground">Paragraphs</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.readingTime} min</div>
                <div className="text-sm text-muted-foreground">Reading Time</div>
              </div>
              
              <div className="bg-muted/20 p-4 rounded-lg border">
                <div className="text-2xl font-bold">{stats.speakingTime} min</div>
                <div className="text-sm text-muted-foreground">Speaking Time</div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="keywords" className="mt-4">
            <div className="bg-muted/20 p-4 rounded-lg border">
              <div className="flex justify-between mb-4">
                <h3 className="font-medium">Top Keywords</h3>
                <Button variant="outline" size="sm" onClick={downloadCsv} disabled={Object.keys(keywordDensity).length === 0}>
                  <Save className="h-4 w-4 mr-2" /> Export CSV
                </Button>
              </div>
              
              {Object.keys(keywordDensity).length > 0 ? (
                <div className="space-y-2">
                  {Object.entries(keywordDensity).map(([word, count]) => {
                    const percentage = ((count / stats.wordCount) * 100).toFixed(2);
                    return (
                      <div key={word} className="flex justify-between py-1 border-b last:border-0">
                        <span className="font-medium">{word}</span>
                        <div className="flex gap-4">
                          <span className="text-sm">{count} times</span>
                          <span className="text-sm text-muted-foreground">{percentage}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  Enter text to analyze keyword density
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the input field above.</li>
            <li>The word count and character analysis will update automatically.</li>
            <li>Switch between the Statistics and Keyword tabs to view different analyses.</li>
            <li>Use the Copy or Save buttons to export your text.</li>
            <li>Export keyword density data as CSV for further analysis.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">How accurate is the word count?</h3>
              <p className="text-muted-foreground">Our word counter uses standard algorithms that count groups of characters separated by spaces or punctuation as words. It's accurate for most texts in English and similar languages.</p>
            </div>
            <div>
              <h3 className="font-bold">How is the reading time calculated?</h3>
              <p className="text-muted-foreground">Reading time is calculated based on the average reading speed of 225 words per minute for adults.</p>
            </div>
            <div>
              <h3 className="font-bold">Is my text secure when using this tool?</h3>
              <p className="text-muted-foreground">Yes, all text processing happens directly in your browser. We don't store or transmit your text to any servers.</p>
            </div>
            <div>
              <h3 className="font-bold">What is keyword density and why is it important?</h3>
              <p className="text-muted-foreground">Keyword density shows how frequently certain words appear in your text. It's useful for SEO and content optimization to ensure you're using target keywords appropriately.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default WordCounter;
