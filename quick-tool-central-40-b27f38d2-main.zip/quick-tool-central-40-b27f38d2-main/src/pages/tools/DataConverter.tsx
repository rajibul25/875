
import React, { useState, useEffect } from "react";
import { Copy, RotateCw, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import ChatBot from "@/components/ChatBot";
import Helmet from "react-helmet";

const DataConverter = () => {
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState<number | string>("");
  const [result, setResult] = useState<number | string>("");
  const [fromUnit, setFromUnit] = useState("megabyte");
  const [toUnit, setToUnit] = useState("gigabyte");
  const [recentConversions, setRecentConversions] = useState<Array<{
    from: string,
    to: string,
    input: number | string,
    output: number | string,
    timestamp: Date
  }>>([]);

  // Unit conversion rates to bytes (base unit)
  const dataUnits = {
    bit: 8,
    byte: 1,
    kilobyte: 0.001,
    megabyte: 0.000001,
    gigabyte: 0.000000001,
    terabyte: 0.000000000001,
    petabyte: 0.000000000000001,
    kibibyte: 0.0009765625,
    mebibyte: 0.00000095367432,
    gibibyte: 0.000000000931323,
    tebibyte: 0.000000000000909,
    pebibyte: 0.000000000000000888
  };

  const unitNames = {
    bit: "Bit",
    byte: "Byte",
    kilobyte: "Kilobyte",
    megabyte: "Megabyte",
    gigabyte: "Gigabyte",
    terabyte: "Terabyte",
    petabyte: "Petabyte",
    kibibyte: "Kibibyte",
    mebibyte: "Mebibyte",
    gibibyte: "Gibibyte",
    tebibyte: "Tebibyte",
    pebibyte: "Pebibyte"
  };

  const unitSymbols = {
    bit: "bit",
    byte: "B",
    kilobyte: "KB",
    megabyte: "MB",
    gigabyte: "GB",
    terabyte: "TB",
    petabyte: "PB",
    kibibyte: "KiB",
    mebibyte: "MiB",
    gibibyte: "GiB",
    tebibyte: "TiB",
    pebibyte: "PiB"
  };

  useEffect(() => {
    if (inputValue !== "") {
      convertData();
    }
  }, [inputValue, fromUnit, toUnit]);

  const convertData = () => {
    if (inputValue === "" || isNaN(Number(inputValue))) {
      setResult("");
      return;
    }

    // Convert from the input unit to bytes (base unit)
    const bytes = Number(inputValue) / dataUnits[fromUnit as keyof typeof dataUnits];
    
    // Convert from bytes to the output unit
    const convertedValue = bytes * dataUnits[toUnit as keyof typeof dataUnits];
    
    // Round to a reasonable number of decimal places
    let roundedValue: number;
    if (convertedValue < 0.01) {
      roundedValue = Number(convertedValue.toFixed(6));
    } else if (convertedValue < 1) {
      roundedValue = Number(convertedValue.toFixed(4));
    } else {
      roundedValue = Number(convertedValue.toFixed(2));
    }
    
    setResult(roundedValue);
    
    // Save to recent conversions
    if (inputValue !== "") {
      const newConversion = {
        from: fromUnit,
        to: toUnit,
        input: inputValue,
        output: roundedValue,
        timestamp: new Date()
      };
      
      setRecentConversions(prev => {
        const updated = [newConversion, ...prev].slice(0, 5);
        return updated;
      });
    }
  };

  const handleCopy = () => {
    if (result !== "") {
      navigator.clipboard.writeText(`${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]}`);
      toast({
        title: "Copied!",
        description: `${result} ${unitSymbols[toUnit as keyof typeof unitSymbols]} has been copied to clipboard.`,
      });
    }
  };

  const handleReset = () => {
    setInputValue("");
    setResult("");
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  return (
    <>
      <Helmet>
        <title>Free Online Data Converter Tool | Convert MB, GB, TB & more</title>
        <meta name="description" content="Convert data storage units instantly with our free online data converter. Easily convert between bytes, kilobytes, megabytes, gigabytes, and more with accurate results." />
        <meta name="keywords" content="data converter, MB to GB, bit to byte, data storage converter, digital storage units" />
        <meta property="og:title" content="Free Online Data Converter Tool" />
        <meta property="og:description" content="Convert between bytes, kilobytes, megabytes, gigabytes and more with our free online data converter tool." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/data-converter" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Free Online Data Converter Tool" />
        <meta name="twitter:description" content="Convert between bytes, kilobytes, megabytes, gigabytes and more with our free online data converter tool." />
        <link rel="canonical" href="https://multitoolset.co/tools/data-converter" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Data Converter Tool",
              "url": "https://multitoolset.co/tools/data-converter",
              "description": "Convert data storage units instantly with our free online data converter. Easily convert between bytes, kilobytes, megabytes, gigabytes, and more with accurate results.",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I convert megabytes to gigabytes?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To convert megabytes (MB) to gigabytes (GB), divide the MB value by 1024 if you're using binary units (MiB to GiB) or by 1000 if you're using decimal units (MB to GB). For example, 1024 MB equals 1 GB in binary, or 1000 MB equals 1 GB in decimal."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What's the difference between MB and MiB?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MB (megabyte) is based on decimal units where 1 MB = 1000 KB, while MiB (mebibyte) is based on binary units where 1 MiB = 1024 KiB. Hard drive manufacturers typically use MB, while operating systems often use MiB."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many bytes are in a kilobyte?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "In decimal units, there are 1000 bytes in 1 kilobyte (KB). In binary units, there are 1024 bytes in 1 kibibyte (KiB)."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="mb-6 flex items-center justify-between">
            <BackButton />
            <h1 className="text-3xl font-bold text-center flex-grow text-gray-800 dark:text-gray-100">
              Data Converter
            </h1>
            <div className="w-[70px]"></div> {/* Spacer for balance */}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6 shadow-lg border-2 border-gray-100 dark:border-gray-800">
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="fromValue" className="text-base font-medium">
                        From
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="fromValue"
                            type="number"
                            placeholder="Enter value"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="text-lg"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={fromUnit} onValueChange={setFromUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(dataUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={swapUnits}
                      className="mx-auto md:mx-0 h-10 w-10 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
                    >
                      <ArrowRightLeft className="h-5 w-5" />
                    </Button>
                    
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="toValue" className="text-base font-medium">
                        To
                      </Label>
                      <div className="flex gap-2">
                        <div className="flex-grow">
                          <Input
                            id="toValue"
                            readOnly
                            value={result}
                            className="text-lg bg-gray-50 dark:bg-gray-800"
                          />
                        </div>
                        <div className="w-40">
                          <Select value={toUnit} onValueChange={setToUnit}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select unit" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(dataUnits).map((unit) => (
                                <SelectItem key={unit} value={unit}>
                                  {unitNames[unit as keyof typeof unitNames]} ({unitSymbols[unit as keyof typeof unitSymbols]})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex-grow">
                      {result !== "" && (
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <p className="text-lg font-medium">
                            <span className="text-gray-500 dark:text-gray-400">Result:</span>{" "}
                            <span className="font-bold text-tool-green">
                              {inputValue} {unitSymbols[fromUnit as keyof typeof unitSymbols]} = {result} {unitSymbols[toUnit as keyof typeof unitSymbols]}
                            </span>
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button onClick={handleCopy} disabled={result === ""}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="mt-6">
                <Tabs defaultValue="howto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="howto">How to Use</TabsTrigger>
                    <TabsTrigger value="formulas">Conversion Formulas</TabsTrigger>
                    <TabsTrigger value="history">Recent Conversions</TabsTrigger>
                  </TabsList>
                  <TabsContent value="howto" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">How to Use the Data Converter</h2>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Enter the value you want to convert in the "From" field.</li>
                      <li>Select the unit you're converting from using the dropdown menu.</li>
                      <li>Select the unit you want to convert to using the second dropdown menu.</li>
                      <li>The result will be calculated automatically and displayed instantly.</li>
                      <li>Use the "Copy" button to copy the result to your clipboard.</li>
                      <li>Use the "Reset" button to clear all fields and start over.</li>
                    </ol>
                  </TabsContent>
                  <TabsContent value="formulas" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Common Data Conversion Formulas</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Megabyte to Gigabyte (decimal):</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 MB = 0.001 GB</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Mebibyte to Gibibyte (binary):</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 MiB = 0.00098 GiB</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Byte to Bit:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 B = 8 bits</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Gigabyte to Terabyte:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 GB = 0.001 TB</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Kilobyte to Megabyte:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 KB = 0.001 MB</p>
                      </div>
                      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <p className="font-medium">Petabyte to Terabyte:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">1 PB = 1000 TB</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="history" className="p-4 border rounded-md mt-2">
                    <h2 className="text-xl font-bold mb-4">Recent Conversions</h2>
                    {recentConversions.length > 0 ? (
                      <div className="space-y-2">
                        {recentConversions.map((conversion, index) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md flex justify-between">
                            <div>
                              <span className="font-medium">
                                {conversion.input} {unitSymbols[conversion.from as keyof typeof unitSymbols]} = {conversion.output} {unitSymbols[conversion.to as keyof typeof unitSymbols]}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {conversion.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No recent conversions yet.</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How do I convert megabytes to gigabytes?</h3>
                    <p className="mt-2">To convert megabytes (MB) to gigabytes (GB), divide the MB value by 1024 if you're using binary units (MiB to GiB) or by 1000 if you're using decimal units (MB to GB). For example, 1024 MB equals 1 GB in binary, or 1000 MB equals 1 GB in decimal.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">What's the difference between MB and MiB?</h3>
                    <p className="mt-2">MB (megabyte) is based on decimal units where 1 MB = 1000 KB, while MiB (mebibyte) is based on binary units where 1 MiB = 1024 KiB. Hard drive manufacturers typically use MB, while operating systems often use MiB.</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-bold text-lg">How many bytes are in a kilobyte?</h3>
                    <p className="mt-2">In decimal units, there are 1000 bytes in 1 kilobyte (KB). In binary units, there are 1024 bytes in 1 kibibyte (KiB).</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <AdBanner 
                size="large" 
                type="vertical"
                className="sticky top-24"
              />
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Related Converters</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/tools/energy-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Energy Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/pressure-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Pressure Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/time-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Time Converter
                    </a>
                  </li>
                  <li>
                    <a href="/tools/length-converter" className="text-tool-blue hover:underline flex items-center">
                      <ArrowRightLeft className="h-4 w-4 mr-2" />
                      Length Converter
                    </a>
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4 border-2 border-gray-100 dark:border-gray-800">
                <h3 className="font-bold text-lg mb-3">Common Conversions</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("megabyte");
                        setToUnit("gigabyte");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 MB to GB
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("gigabyte");
                        setToUnit("terabyte");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 GB to TB
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("byte");
                        setToUnit("bit");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 Byte to Bits
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("mebibyte");
                        setToUnit("megabyte");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 MiB to MB
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => {
                        setInputValue(1);
                        setFromUnit("terabyte");
                        setToUnit("gigabyte");
                      }}
                      className="text-tool-purple hover:underline"
                    >
                      1 TB to GB
                    </button>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
          
          <div className="mt-8">
            <AdBanner type="horizontal" size="large" />
          </div>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default DataConverter;
