
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Timer, Ruler } from "lucide-react";
import { Helmet } from "react-helmet";
import { SpeedIcon } from "@/components/icons/ToolIcons";

const PaceCalculator = () => {
  const [distance, setDistance] = useState<string>("");
  const [distanceUnit, setDistanceUnit] = useState<string>("km");
  const [time, setTime] = useState<{ hours: string; minutes: string; seconds: string }>({
    hours: "",
    minutes: "",
    seconds: ""
  });
  const [paceUnit, setPaceUnit] = useState<string>("min/km");
  const [results, setResults] = useState<{
    pace: string;
    speed: string;
    finish: string;
  } | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculatePace = () => {
    try {
      setIsCalculating(true);
      
      // Convert all inputs to numbers
      const distanceValue = parseFloat(distance);
      const hours = parseInt(time.hours) || 0;
      const minutes = parseInt(time.minutes) || 0;
      const seconds = parseInt(time.seconds) || 0;

      // Validate inputs
      if (distanceValue <= 0) {
        toast.error("Please enter a valid distance.");
        setIsCalculating(false);
        return;
      }

      if (hours === 0 && minutes === 0 && seconds === 0) {
        toast.error("Please enter a valid time.");
        setIsCalculating(false);
        return;
      }

      // Convert time to total seconds
      const totalSeconds = hours * 3600 + minutes * 60 + seconds;

      // Calculate pace (seconds per unit distance)
      let paceInSeconds = totalSeconds / distanceValue;

      // Convert pace to chosen unit
      let paceMinutes = Math.floor(paceInSeconds / 60);
      let paceSeconds = Math.floor(paceInSeconds % 60);

      // Calculate speed (distance per hour)
      let speedValue = (distanceValue / totalSeconds) * 3600;
      
      // Adjust units for display
      let paceDisplay, speedDisplay;
      
      if (paceUnit === "min/km") {
        if (distanceUnit === "mi") {
          // Convert miles pace to km pace
          paceInSeconds = paceInSeconds * 0.621371;
          paceMinutes = Math.floor(paceInSeconds / 60);
          paceSeconds = Math.floor(paceInSeconds % 60);
        }
        paceDisplay = `${paceMinutes}:${paceSeconds.toString().padStart(2, "0")} min/km`;
        speedDisplay = `${speedValue.toFixed(2)} km/h`;
      } else {
        if (distanceUnit === "km") {
          // Convert km pace to miles pace
          paceInSeconds = paceInSeconds / 0.621371;
          paceMinutes = Math.floor(paceInSeconds / 60);
          paceSeconds = Math.floor(paceInSeconds % 60);
        }
        paceDisplay = `${paceMinutes}:${paceSeconds.toString().padStart(2, "0")} min/mi`;
        speedDisplay = `${speedValue.toFixed(2)} mph`;
      }
      
      // Calculate finish time for standard distances
      let finishTimeText = "";
      if (distanceUnit === "km") {
        // 5K time
        const time5K = 5 * paceInSeconds;
        const hours5K = Math.floor(time5K / 3600);
        const minutes5K = Math.floor((time5K % 3600) / 60);
        const seconds5K = Math.floor(time5K % 60);
        finishTimeText = `5K: ${hours5K ? hours5K + "h " : ""}${minutes5K}m ${seconds5K}s`;
      } else {
        // Marathon time (26.2 miles)
        const timeMarathon = 26.2 * paceInSeconds;
        const hoursM = Math.floor(timeMarathon / 3600);
        const minutesM = Math.floor((timeMarathon % 3600) / 60);
        const secondsM = Math.floor(timeMarathon % 60);
        finishTimeText = `Marathon: ${hoursM}h ${minutesM}m ${secondsM}s`;
      }

      // Simulate a small delay for feedback
      setTimeout(() => {
        setResults({
          pace: paceDisplay,
          speed: speedDisplay,
          finish: finishTimeText
        });
        setIsCalculating(false);
        toast.success("Pace calculated successfully!");
      }, 600);
    } catch (error) {
      setIsCalculating(false);
      toast.error("Error calculating pace. Please check your inputs.");
      console.error("Pace calculation error:", error);
    }
  };

  const resetCalculator = () => {
    setDistance("");
    setTime({ hours: "", minutes: "", seconds: "" });
    setResults(null);
  };

  return (
    <>
      <Helmet>
        <title>Pace Calculator | Calculate Running & Walking Pace | MultitoolSet</title>
        <meta name="description" content="Calculate your running or walking pace, speed, and estimated finish times for races. Free online pace calculator for runners and walkers." />
        <meta name="keywords" content="pace calculator, running pace calculator, walking pace calculator, race pace calculator, marathon pace calculator, 5k pace calculator" />
        <link rel="canonical" href="https://multitoolset.com/tools/pace-calculator" />
        <meta property="og:title" content="Pace Calculator | Calculate Running & Walking Pace" />
        <meta property="og:description" content="Calculate your running or walking pace, speed, and estimated finish times for races." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.com/tools/pace-calculator" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Pace Calculator | Calculate Running & Walking Pace" />
        <meta name="twitter:description" content="Calculate your running or walking pace, speed, and estimated finish times for races." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Pace Calculator",
              "description": "Calculate your running or walking pace, speed, and estimated finish times for races.",
              "applicationCategory": "HealthApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MultitoolSet"
              }
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "How do I calculate my running pace?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To calculate your running pace, divide your total time by the distance you ran. This calculator does it automatically - just enter your distance and time, and it will calculate your pace in minutes per kilometer or minutes per mile."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What is a good running pace for beginners?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "For beginners, a good running pace is typically between 8:00-10:00 minutes per kilometer (12:50-16:00 minutes per mile). As you build endurance and strength, your pace will naturally improve."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How do I improve my running pace?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To improve your running pace: incorporate interval training into your routine, do tempo runs, add strength training, maintain consistent training, ensure proper recovery, and gradually increase your weekly mileage."
                  }
                }
              ]
            }
          `}
        </script>
        <meta name="robots" content="index, follow" />
      </Helmet>
    
      <ToolLayout
        title="Pace Calculator"
        description="Calculate your running or walking pace, speed, and estimated finish times for races. Free online pace calculator for runners and walkers."
        helpText="Enter your distance and time to calculate your pace, speed, and estimated finish times for standard race distances."
      >
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="calculate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculate">Calculate Pace</TabsTrigger>
                <TabsTrigger value="about">About Pace</TabsTrigger>
              </TabsList>
              
              <TabsContent value="calculate" className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="distance">Distance</Label>
                    <div className="flex gap-2">
                      <Input
                        id="distance"
                        type="number"
                        placeholder="Enter distance"
                        value={distance}
                        onChange={(e) => setDistance(e.target.value)}
                        className="flex-1"
                        min="0"
                        step="0.01"
                      />
                      <Select
                        value={distanceUnit}
                        onValueChange={setDistanceUnit}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue placeholder="Unit" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="km">km</SelectItem>
                          <SelectItem value="mi">miles</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="time">Total Time</Label>
                    <div className="flex gap-2">
                      <Input
                        id="timeHours"
                        type="number"
                        placeholder="Hours"
                        value={time.hours}
                        onChange={(e) => setTime({ ...time, hours: e.target.value })}
                        className="flex-1"
                        min="0"
                      />
                      <Input
                        id="timeMinutes"
                        type="number"
                        placeholder="Minutes"
                        value={time.minutes}
                        onChange={(e) => setTime({ ...time, minutes: e.target.value })}
                        className="flex-1"
                        min="0"
                        max="59"
                      />
                      <Input
                        id="timeSeconds"
                        type="number"
                        placeholder="Seconds"
                        value={time.seconds}
                        onChange={(e) => setTime({ ...time, seconds: e.target.value })}
                        className="flex-1"
                        min="0"
                        max="59"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="paceUnit">Pace Unit</Label>
                    <Select
                      value={paceUnit}
                      onValueChange={setPaceUnit}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pace Unit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="min/km">min/km</SelectItem>
                        <SelectItem value="min/mi">min/mile</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={calculatePace} 
                      className="flex-1"
                      disabled={isCalculating}
                    >
                      {isCalculating ? "Calculating..." : "Calculate"}
                    </Button>
                    <Button variant="outline" onClick={resetCalculator}>Reset</Button>
                  </div>
                  
                  {results && (
                    <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-900/50 dark:border-slate-800">
                      <h3 className="font-semibold text-lg mb-2">Results</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-3 bg-white rounded border dark:bg-slate-800 dark:border-slate-700">
                          <p className="text-sm text-gray-600 dark:text-gray-400">Your Pace</p>
                          <p className="text-xl font-bold">{results.pace}</p>
                        </div>
                        <div className="p-3 bg-white rounded border dark:bg-slate-800 dark:border-slate-700">
                          <p className="text-sm text-gray-600 dark:text-gray-400">Speed</p>
                          <p className="text-xl font-bold">{results.speed}</p>
                        </div>
                        <div className="p-3 bg-white rounded border dark:bg-slate-800 dark:border-slate-700">
                          <p className="text-sm text-gray-600 dark:text-gray-400">Estimated Finish</p>
                          <p className="text-xl font-bold">{results.finish}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="about" className="space-y-4 pt-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">What is Pace?</h3>
                  <p className="text-gray-700 dark:text-gray-300">Pace is the time it takes to cover a specific distance, usually expressed as minutes per kilometer (min/km) or minutes per mile (min/mi). It's commonly used by runners and walkers to measure their speed and plan workouts.</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">How to Use This Calculator</h3>
                  <ol className="list-decimal ml-5 space-y-1 text-gray-700 dark:text-gray-300">
                    <li>Enter the distance you ran or walked</li>
                    <li>Enter the total time it took (hours, minutes, seconds)</li>
                    <li>Select your preferred pace unit (min/km or min/mile)</li>
                    <li>Click "Calculate" to see your pace, speed, and estimated finish times</li>
                  </ol>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Common Pace Targets</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full mt-2 border-collapse">
                      <thead>
                        <tr className="bg-slate-100 dark:bg-slate-800">
                          <th className="p-2 text-left border dark:border-slate-700">Runner Level</th>
                          <th className="p-2 text-left border dark:border-slate-700">5K Pace (min/km)</th>
                          <th className="p-2 text-left border dark:border-slate-700">10K Pace (min/km)</th>
                          <th className="p-2 text-left border dark:border-slate-700">Half Marathon (min/km)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Beginner</td>
                          <td className="p-2 border dark:border-slate-700">7:00-8:00</td>
                          <td className="p-2 border dark:border-slate-700">7:30-8:30</td>
                          <td className="p-2 border dark:border-slate-700">8:00-9:30</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Intermediate</td>
                          <td className="p-2 border dark:border-slate-700">5:30-7:00</td>
                          <td className="p-2 border dark:border-slate-700">6:00-7:30</td>
                          <td className="p-2 border dark:border-slate-700">6:30-8:00</td>
                        </tr>
                        <tr>
                          <td className="p-2 border dark:border-slate-700">Advanced</td>
                          <td className="p-2 border dark:border-slate-700">4:00-5:30</td>
                          <td className="p-2 border dark:border-slate-700">4:30-6:00</td>
                          <td className="p-2 border dark:border-slate-700">5:00-6:30</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div className="py-2">
                  <h3 className="text-lg font-semibold mb-2">Training with Pace</h3>
                  <p className="text-gray-700 dark:text-gray-300">Different training sessions require different paces:</p>
                  <ul className="list-disc ml-5 space-y-1 text-gray-700 dark:text-gray-300 mt-1">
                    <li><strong>Recovery runs:</strong> 60-90 seconds slower than your 5K pace</li>
                    <li><strong>Long runs:</strong> 60-90 seconds slower than your 5K pace</li>
                    <li><strong>Tempo runs:</strong> Between your 10K and half marathon pace</li>
                    <li><strong>Interval training:</strong> Faster than your 5K pace</li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
            <h3 className="font-semibold text-lg mb-2">Related Tools</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <a href="/tools/bmi-calculator" className="text-blue-600 hover:underline dark:text-blue-400">BMI Calculator</a>
              </li>
              <li>
                <a href="/tools/calorie-counter" className="text-blue-600 hover:underline dark:text-blue-400">Calorie Counter</a>
              </li>
              <li>
                <a href="/tools/sleep-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Sleep Calculator</a>
              </li>
              <li>
                <a href="/tools/ideal-weight-calculator" className="text-blue-600 hover:underline dark:text-blue-400">Ideal Weight Calculator</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 mb-4 bg-gray-100 p-4 rounded-lg dark:bg-gray-800">
          <h3 className="text-center text-gray-500 text-sm mb-2 dark:text-gray-400">Advertisement</h3>
          {/* Ad placement - Top Banner */}
          <div className="h-20 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded border border-gray-300 dark:border-gray-600">
            <p className="text-gray-400 dark:text-gray-500">Ad Space</p>
          </div>
        </div>
      </ToolLayout>
    </>
  );
};

export default PaceCalculator;
