
import React, { useState, useRef } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { AlertCircle, Download, Pause, Play, Save, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

const TextToSpeech = () => {
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("");
  const [rate, setRate] = useState([1]);
  const [pitch, setPitch] = useState([1]);
  const [volume, setVolume] = useState([1]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Initialize speech synthesis and get available voices
  React.useEffect(() => {
    if (typeof window !== "undefined" && 'speechSynthesis' in window) {
      // Load voices immediately if they are already available
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        setAvailableVoices(voices);
        setVoice(voices[0].name);
      }

      // Add an event listener for when voices change
      window.speechSynthesis.onvoiceschanged = () => {
        const updatedVoices = window.speechSynthesis.getVoices();
        setAvailableVoices(updatedVoices);
        if (updatedVoices.length > 0 && !voice) {
          setVoice(updatedVoices[0].name);
        }
      };

      // Clean up
      return () => {
        window.speechSynthesis.cancel();
      };
    }
  }, []);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const speakText = () => {
    if (!text.trim()) {
      toast.error("Please enter some text to speak");
      return;
    }

    if (typeof window !== "undefined" && 'speechSynthesis' in window) {
      // Cancel any previous speech
      window.speechSynthesis.cancel();

      // Create a new utterance
      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;

      // Set the selected voice
      const selectedVoice = availableVoices.find(v => v.name === voice);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }

      // Set speech properties
      utterance.rate = rate[0];
      utterance.pitch = pitch[0];
      utterance.volume = volume[0];

      // Add event handlers
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => {
        setIsPlaying(false);
        toast.error("An error occurred while playing speech");
      };

      // Start speaking
      window.speechSynthesis.speak(utterance);
    } else {
      toast.error("Speech synthesis is not supported in this browser");
    }
  };

  const pauseResumeText = () => {
    if (typeof window !== "undefined" && 'speechSynthesis' in window) {
      if (isPlaying) {
        window.speechSynthesis.pause();
      } else {
        window.speechSynthesis.resume();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const stopText = () => {
    if (typeof window !== "undefined" && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  const downloadAudio = () => {
    toast.info("This feature would download the speech as an MP3 file. In a real application, this would require server-side processing or a specialized API.");
  };

  const getLanguageFromVoice = (voiceName: string) => {
    const selectedVoice = availableVoices.find(v => v.name === voiceName);
    return selectedVoice ? selectedVoice.lang : "";
  };

  return (
    <ToolLayout 
      title="Text to Speech"
      description="Convert text to realistic speech in multiple languages and voices"
      helpText="Enter text and choose a voice to hear it spoken aloud with adjustable speed, pitch, and volume."
    >
      <Alert className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Browser Feature</AlertTitle>
        <AlertDescription>
          This tool uses your browser's built-in speech synthesis capabilities.
          Voice availability may vary depending on your browser and operating system.
          For best results, use Chrome or Edge.
        </AlertDescription>
      </Alert>
      
      <div className="space-y-6">
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here to convert to speech..."
            className="min-h-[200px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Voice Settings</h3>
            
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="voice-select">Voice</Label>
                <Select value={voice} onValueChange={setVoice}>
                  <SelectTrigger id="voice-select">
                    <SelectValue placeholder="Select a voice" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {availableVoices.map((voice) => (
                      <SelectItem key={voice.name} value={voice.name}>
                        {voice.name} ({voice.lang})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between mb-2">
                  <Label htmlFor="rate-slider">Rate</Label>
                  <span className="text-sm">{rate[0].toFixed(1)}x</span>
                </div>
                <Slider
                  id="rate-slider"
                  min={0.1}
                  max={3}
                  step={0.1}
                  value={rate}
                  onValueChange={setRate}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between mb-2">
                  <Label htmlFor="pitch-slider">Pitch</Label>
                  <span className="text-sm">{pitch[0].toFixed(1)}</span>
                </div>
                <Slider
                  id="pitch-slider"
                  min={0.1}
                  max={2}
                  step={0.1}
                  value={pitch}
                  onValueChange={setPitch}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between mb-2">
                  <Label htmlFor="volume-slider">Volume</Label>
                  <span className="text-sm">{volume[0].toFixed(1)}</span>
                </div>
                <Slider
                  id="volume-slider"
                  min={0}
                  max={1}
                  step={0.1}
                  value={volume}
                  onValueChange={setVolume}
                />
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Audio Controls</h3>
            
            <div className="bg-muted/20 p-6 rounded-lg border flex flex-col items-center justify-center h-[200px]">
              <div className="text-center mb-6">
                <Volume2 className="h-16 w-16 mx-auto mb-2 text-primary/80" />
                {voice && (
                  <div className="text-sm text-muted-foreground">
                    Selected voice: {voice}
                    <div>Language: {getLanguageFromVoice(voice)}</div>
                  </div>
                )}
              </div>
              
              <div className="flex gap-3">
                <Button onClick={speakText} disabled={!text.trim() || isPlaying}>
                  <Play className="h-4 w-4 mr-2" /> 
                  Play
                </Button>
                <Button 
                  variant="outline" 
                  onClick={pauseResumeText} 
                  disabled={!text.trim()}
                >
                  <Pause className="h-4 w-4 mr-2" /> 
                  {isPlaying ? "Pause" : "Resume"}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={stopText} 
                  disabled={!isPlaying}
                >
                  Stop
                </Button>
              </div>
              
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  onClick={downloadAudio} 
                  disabled={!text.trim()}
                >
                  <Download className="h-4 w-4 mr-2" /> 
                  Download MP3
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the input field above.</li>
            <li>Select a voice from the dropdown menu.</li>
            <li>Adjust the rate, pitch, and volume sliders to customize the speech.</li>
            <li>Click "Play" to hear the text spoken aloud.</li>
            <li>Use the pause/resume and stop buttons to control playback.</li>
            <li>Click "Download MP3" to save the audio (premium feature).</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">Why do I only see a few voices available?</h3>
              <p className="text-muted-foreground">The available voices depend on your operating system and browser. Some browsers offer more voice options than others. For the best experience, try using Google Chrome or Microsoft Edge.</p>
            </div>
            <div>
              <h3 className="font-bold">Can I convert a large amount of text to speech?</h3>
              <p className="text-muted-foreground">Yes, but browsers may limit the length of text that can be processed at once. For very long texts, consider breaking it into smaller sections.</p>
            </div>
            <div>
              <h3 className="font-bold">Why can't I download the audio as an MP3?</h3>
              <p className="text-muted-foreground">The ability to download speech as an audio file requires server-side processing. In a full production implementation, this would be available as a premium feature.</p>
            </div>
            <div>
              <h3 className="font-bold">Does this tool work offline?</h3>
              <p className="text-muted-foreground">Some browsers support offline text-to-speech functionality, but voice availability may be limited. An internet connection provides access to more voices and better quality.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default TextToSpeech;
