import React, { useState, useRef } from "react";
import { Helmet } from "react-helmet";
import { Calculator, ClipboardCopy, RefreshCw, Book, Copy, ImageIcon, Download, FileUp, Check, Info, ChevronRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BackButton from "@/components/BackButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import ChatBot from "@/components/ChatBot";

// Utility functions for solving different types of equations
const solveMathProblem = (equation: string, type: string): { result: string; steps: string[] } => {
  try {
    // Simple expression evaluation
    if (type === "expression") {
      return solveExpression(equation);
    }
    
    // Linear equation (ax + b = c)
    if (type === "linear") {
      return solveLinearEquation(equation);
    }
    
    // Quadratic equation (ax^2 + bx + c = 0)
    if (type === "quadratic") {
      return solveQuadraticEquation(equation);
    }
    
    // System of linear equations
    if (type === "system") {
      return solveSystemOfEquations(equation);
    }
    
    // Factorization
    if (type === "factorization") {
      return factorizePolynomial(equation);
    }
    
    throw new Error("Unsupported equation type");
  } catch (error) {
    console.error("Error solving equation:", error);
    return {
      result: "Error: Could not solve equation. Please check your input format.",
      steps: ["Error occurred during calculation."],
    };
  }
};

// Helper function to evaluate simple expressions
const solveExpression = (expression: string): { result: string; steps: string[] } => {
  // Remove spaces and normalize
  expression = expression.replace(/\s+/g, "");
  
  // Simple evaluation for demonstration
  // In a real implementation, you'd need a proper expression parser
  
  const steps = [];
  steps.push(`Starting with expression: ${expression}`);
  
  // For demonstration, handle basic operations
  // Handle parentheses first
  if (expression.includes("(")) {
    steps.push("Solving parentheses first");
    // This is a simplified approach - a real implementation would need recursion
    const parenRegex = /\(([^()]+)\)/g;
    let match;
    
    while ((match = parenRegex.exec(expression)) !== null) {
      const subExpr = match[1];
      // Recursively evaluate the expression inside parentheses
      const evaluatedSubExpr = evaluateSimpleExpression(subExpr);
      steps.push(`Evaluating (${subExpr}) = ${evaluatedSubExpr}`);
      
      // Replace the parenthetical expression with its value
      expression = expression.replace(`(${subExpr})`, evaluatedSubExpr.toString());
      steps.push(`After substitution: ${expression}`);
    }
  }
  
  // Final calculation
  const result = evaluateSimpleExpression(expression);
  steps.push(`Final calculation: ${expression} = ${result}`);
  
  return {
    result: result.toString(),
    steps,
  };
};

// Basic expression evaluator (for demonstration)
const evaluateSimpleExpression = (expr: string): number => {
  // Handle multiplication and division first
  const mulDivRegex = /(\-?\d+\.?\d*)([\*\/])(\-?\d+\.?\d*)/;
  let match;
  
  while ((match = mulDivRegex.exec(expr)) !== null) {
    const num1 = parseFloat(match[1]);
    const operator = match[2];
    const num2 = parseFloat(match[3]);
    
    let result;
    if (operator === "*") {
      result = num1 * num2;
    } else {
      if (num2 === 0) throw new Error("Division by zero");
      result = num1 / num2;
    }
    
    // Replace the operation with its result
    expr = expr.replace(match[0], result.toString());
  }
  
  // Handle addition and subtraction
  // This is a simplified approach that doesn't handle all cases properly
  // A real implementation would use a proper expression parser
  
  // First convert expressions like "a+-b" to "a-b"
  expr = expr.replace(/\+\-/g, "-");
  
  // Then handle multiple operations from left to right
  const addSubRegex = /(\-?\d+\.?\d*)([\+\-])(\-?\d+\.?\d*)/;
  
  while ((match = addSubRegex.exec(expr)) !== null) {
    const num1 = parseFloat(match[1]);
    const operator = match[2];
    const num2 = parseFloat(match[3]);
    
    let result;
    if (operator === "+") {
      result = num1 + num2;
    } else {
      result = num1 - num2;
    }
    
    // Replace the operation with its result
    expr = expr.replace(match[0], result.toString());
  }
  
  return parseFloat(expr);
};

// Helper function to solve linear equations
const solveLinearEquation = (equation: string): { result: string; steps: string[] } => {
  const steps = [];
  steps.push(`Starting with equation: ${equation}`);
  
  // Normalize the equation by removing spaces
  equation = equation.replace(/\s+/g, "");
  
  // Ensure equation has an equals sign
  if (!equation.includes("=")) {
    throw new Error("Linear equation must contain an equals sign (=)");
  }
  
  // Split the equation into left and right sides
  const [leftSide, rightSide] = equation.split("=");
  
  steps.push(`Left side: ${leftSide}`);
  steps.push(`Right side: ${rightSide}`);
  
  // Find the coefficient of x and the constant term on the left side
  let leftCoefficient = 0;
  let leftConstant = 0;
  
  // Extract terms from the left side
  const leftTerms = leftSide.match(/[+\-]?\d*x|[+\-]?\d+/g) || [];
  
  leftTerms.forEach(term => {
    if (term.includes("x")) {
      // Extract the coefficient of x
      const coefficient = term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
      leftCoefficient += coefficient;
    } else {
      // Extract the constant
      leftConstant += parseFloat(term);
    }
  });
  
  steps.push(`Left side has coefficient of x: ${leftCoefficient} and constant: ${leftConstant}`);
  
  // Find the coefficient of x and the constant term on the right side
  let rightCoefficient = 0;
  let rightConstant = 0;
  
  // Extract terms from the right side
  const rightTerms = rightSide.match(/[+\-]?\d*x|[+\-]?\d+/g) || [];
  
  rightTerms.forEach(term => {
    if (term.includes("x")) {
      // Extract the coefficient of x
      const coefficient = term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
      rightCoefficient += coefficient;
    } else {
      // Extract the constant
      rightConstant += parseFloat(term);
    }
  });
  
  steps.push(`Right side has coefficient of x: ${rightCoefficient} and constant: ${rightConstant}`);
  
  // Move all x terms to the left and all constants to the right
  const netCoefficient = leftCoefficient - rightCoefficient;
  const netConstant = rightConstant - leftConstant;
  
  steps.push(`Rearranging to standard form: ${netCoefficient}x = ${netConstant}`);
  
  // Solve for x
  if (netCoefficient === 0) {
    if (netConstant === 0) {
      return {
        result: "Infinite solutions (Identity)",
        steps: [...steps, "The equation is an identity with infinite solutions."],
      };
    } else {
      return {
        result: "No solution (Contradiction)",
        steps: [...steps, "The equation is a contradiction with no solution."],
      };
    }
  }
  
  const xValue = netConstant / netCoefficient;
  
  steps.push(`Dividing both sides by ${netCoefficient}: x = ${netConstant} / ${netCoefficient}`);
  steps.push(`Simplifying: x = ${xValue}`);
  
  // Return the solution
  return {
    result: `x = ${xValue}`,
    steps,
  };
};

// Helper function to solve quadratic equations
const solveQuadraticEquation = (equation: string): { result: string; steps: string[] } => {
  const steps = [];
  steps.push(`Starting with equation: ${equation}`);
  
  // Normalize the equation by removing spaces
  equation = equation.replace(/\s+/g, "");
  
  // Ensure equation has an equals sign
  if (!equation.includes("=")) {
    throw new Error("Quadratic equation must contain an equals sign (=)");
  }
  
  // Split the equation into left and right sides
  const [leftSide, rightSide] = equation.split("=");
  
  steps.push(`Left side: ${leftSide}`);
  steps.push(`Right side: ${rightSide}`);
  
  // Move all terms to the left side
  steps.push(`Moving all terms to the left side: ${leftSide} - (${rightSide}) = 0`);
  
  // Find coefficients a, b, c where ax^2 + bx + c = 0
  let a = 0, b = 0, c = 0;
  
  // Extract terms from both sides
  const leftTerms = leftSide.match(/[+\-]?\d*x\^2|[+\-]?\d*x|[+\-]?\d+/g) || [];
  const rightTerms = rightSide.match(/[+\-]?\d*x\^2|[+\-]?\d*x|[+\-]?\d+/g) || [];
  
  // Process left side terms
  leftTerms.forEach(term => {
    if (term.includes("x^2")) {
      // Coefficient of x^2
      a += term === "x^2" ? 1 : term === "-x^2" ? -1 : parseFloat(term.replace("x^2", ""));
    } else if (term.includes("x")) {
      // Coefficient of x
      b += term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else {
      // Constant term
      c += parseFloat(term);
    }
  });
  
  // Process right side terms (subtract from the left side)
  rightTerms.forEach(term => {
    if (term.includes("x^2")) {
      // Coefficient of x^2
      a -= term === "x^2" ? 1 : term === "-x^2" ? -1 : parseFloat(term.replace("x^2", ""));
    } else if (term.includes("x")) {
      // Coefficient of x
      b -= term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else {
      // Constant term
      c -= parseFloat(term);
    }
  });
  
  steps.push(`Standard form: ${a}x² + ${b}x + ${c} = 0`);
  
  // Check if it's actually a quadratic equation
  if (a === 0) {
    // If a is 0, it's a linear equation
    steps.push(`This is a linear equation, not quadratic (a = 0).`);
    if (b === 0) {
      // If both a and b are 0, it's just a constant
      if (c === 0) {
        return {
          result: "Infinite solutions (Identity)",
          steps: [...steps, "The equation is an identity with infinite solutions."],
        };
      } else {
        return {
          result: "No solution (Contradiction)",
          steps: [...steps, "The equation is a contradiction with no solution."],
        };
      }
    }
    // Solve as linear equation
    const x = -c / b;
    steps.push(`Solving as linear equation: ${b}x + ${c} = 0`);
    steps.push(`x = -${c} / ${b} = ${x}`);
    return {
      result: `x = ${x}`,
      steps,
    };
  }
  
  // Calculate the discriminant
  const discriminant = b * b - 4 * a * c;
  steps.push(`Calculate discriminant: Δ = b² - 4ac = ${b}² - 4 × ${a} × ${c} = ${discriminant}`);
  
  if (discriminant < 0) {
    // Complex roots
    const realPart = -b / (2 * a);
    const imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
    
    steps.push(`Discriminant is negative, so the equation has complex roots.`);
    steps.push(`Using the quadratic formula: x = (-b ± √Δ) / 2a`);
    steps.push(`x = (${-b} ± √${-discriminant}) / ${2 * a}`);
    steps.push(`x = ${realPart} ± ${imaginaryPart}i`);
    
    return {
      result: `x = ${realPart} + ${imaginaryPart}i or x = ${realPart} - ${imaginaryPart}i`,
      steps,
    };
  } else if (discriminant === 0) {
    // One real root (double root)
    const x = -b / (2 * a);
    
    steps.push(`Discriminant is zero, so the equation has one real root (a double root).`);
    steps.push(`Using the quadratic formula: x = -b / 2a`);
    steps.push(`x = ${-b} / ${2 * a} = ${x}`);
    
    return {
      result: `x = ${x} (double root)`,
      steps,
    };
  } else {
    // Two real roots
    const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
    const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
    
    steps.push(`Discriminant is positive, so the equation has two real roots.`);
    steps.push(`Using the quadratic formula: x = (-b ± √Δ) / 2a`);
    steps.push(`x₁ = (${-b} + √${discriminant}) / ${2 * a} = ${x1}`);
    steps.push(`x₂ = (${-b} - √${discriminant}) / ${2 * a} = ${x2}`);
    
    return {
      result: `x = ${x1} or x = ${x2}`,
      steps,
    };
  }
};

// Helper function to solve systems of linear equations (2 equations, 2 unknowns)
const solveSystemOfEquations = (equations: string): { result: string; steps: string[] } => {
  const steps = [];
  
  // Split into separate equations
  const equationLines = equations.split("\n").filter(line => line.trim() !== "");
  
  if (equationLines.length !== 2) {
    throw new Error("Please provide exactly two equations for a 2×2 system");
  }
  
  steps.push(`System of equations:`);
  steps.push(`Equation 1: ${equationLines[0]}`);
  steps.push(`Equation 2: ${equationLines[1]}`);
  
  // Parse first equation: a1x + b1y = c1
  const equation1 = equationLines[0].replace(/\s+/g, "");
  const [leftSide1, rightSide1] = equation1.split("=");
  
  let a1 = 0, b1 = 0, c1 = 0;
  
  // Extract terms from first equation
  const leftTerms1 = leftSide1.match(/[+\-]?\d*x|[+\-]?\d*y|[+\-]?\d+/g) || [];
  leftTerms1.forEach(term => {
    if (term.includes("x")) {
      a1 += term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else if (term.includes("y")) {
      b1 += term === "y" ? 1 : term === "-y" ? -1 : parseFloat(term.replace("y", ""));
    } else {
      c1 += parseFloat(term);
    }
  });
  
  const rightTerms1 = rightSide1.match(/[+\-]?\d*x|[+\-]?\d*y|[+\-]?\d+/g) || [];
  rightTerms1.forEach(term => {
    if (term.includes("x")) {
      a1 -= term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else if (term.includes("y")) {
      b1 -= term === "y" ? 1 : term === "-y" ? -1 : parseFloat(term.replace("y", ""));
    } else {
      c1 -= parseFloat(term);
    }
  });
  
  c1 = -c1; // Move constants to the right side
  
  steps.push(`Equation 1 in standard form: ${a1}x + ${b1}y = ${c1}`);
  
  // Parse second equation: a2x + b2y = c2
  const equation2 = equationLines[1].replace(/\s+/g, "");
  const [leftSide2, rightSide2] = equation2.split("=");
  
  let a2 = 0, b2 = 0, c2 = 0;
  
  // Extract terms from second equation
  const leftTerms2 = leftSide2.match(/[+\-]?\d*x|[+\-]?\d*y|[+\-]?\d+/g) || [];
  leftTerms2.forEach(term => {
    if (term.includes("x")) {
      a2 += term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else if (term.includes("y")) {
      b2 += term === "y" ? 1 : term === "-y" ? -1 : parseFloat(term.replace("y", ""));
    } else {
      c2 += parseFloat(term);
    }
  });
  
  const rightTerms2 = rightSide2.match(/[+\-]?\d*x|[+\-]?\d*y|[+\-]?\d+/g) || [];
  rightTerms2.forEach(term => {
    if (term.includes("x")) {
      a2 -= term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else if (term.includes("y")) {
      b2 -= term === "y" ? 1 : term === "-y" ? -1 : parseFloat(term.replace("y", ""));
    } else {
      c2 -= parseFloat(term);
    }
  });
  
  c2 = -c2; // Move constants to the right side
  
  steps.push(`Equation 2 in standard form: ${a2}x + ${b2}y = ${c2}`);
  
  // Solve using elimination method
  steps.push(`Using elimination method:`);
  
  // Multiply equation 1 by a2 and equation 2 by a1
  steps.push(`Multiply equation 1 by ${a2}: ${a2 * a1}x + ${a2 * b1}y = ${a2 * c1}`);
  steps.push(`Multiply equation 2 by ${a1}: ${a1 * a2}x + ${a1 * b2}y = ${a1 * c2}`);
  
  // Subtract to eliminate x
  const newB = a2 * b1 - a1 * b2;
  const newC = a2 * c1 - a1 * c2;
  
  steps.push(`Subtract to eliminate x: ${a2 * b1 - a1 * b2}y = ${a2 * c1 - a1 * c2}`);
  
  if (newB === 0) {
    if (newC === 0) {
      steps.push(`The system has infinitely many solutions.`);
      return {
        result: "Infinitely many solutions",
        steps,
      };
    } else {
      steps.push(`The system has no solution.`);
      return {
        result: "No solution",
        steps,
      };
    }
  }
  
  // Solve for y
  const y = newC / newB;
  steps.push(`Solve for y: y = ${newC} / ${newB} = ${y}`);
  
  // Substitute y back to find x
  const x = (c1 - b1 * y) / a1;
  steps.push(`Substitute y = ${y} into equation 1: ${a1}x + ${b1}(${y}) = ${c1}`);
  steps.push(`Solve for x: x = (${c1} - ${b1 * y}) / ${a1} = ${x}`);
  
  return {
    result: `x = ${x}, y = ${y}`,
    steps,
  };
};

// Helper function to factorize polynomials
const factorizePolynomial = (polynomial: string): { result: string; steps: string[] } => {
  const steps = [];
  steps.push(`Starting with polynomial: ${polynomial}`);
  
  // Remove spaces and normalize
  polynomial = polynomial.replace(/\s+/g, "");
  
  // For simplicity, we'll only implement factorization for a few cases:
  // 1. Difference of squares: a² - b² = (a+b)(a-b)
  // 2. Perfect square trinomial: a² + 2ab + b² = (a+b)²
  // 3. Perfect square trinomial: a² - 2ab + b² = (a-b)²
  // 4. Simple quadratics using the quadratic formula
  
  // Check if it's already in factored form
  if (polynomial.includes("(") && polynomial.includes(")")) {
    steps.push(`The polynomial is already in factored form.`);
    return {
      result: polynomial,
      steps,
    };
  }
  
  // Extract terms
  const terms = polynomial.match(/[+\-]?\d*x\^2|[+\-]?\d*x|[+\-]?\d+/g) || [];
  
  let a = 0, b = 0, c = 0;
  
  // Parse coefficients
  terms.forEach(term => {
    if (term.includes("x^2")) {
      a += term === "x^2" ? 1 : term === "-x^2" ? -1 : parseFloat(term.replace("x^2", ""));
    } else if (term.includes("x")) {
      b += term === "x" ? 1 : term === "-x" ? -1 : parseFloat(term.replace("x", ""));
    } else {
      c += parseFloat(term);
    }
  });
  
  steps.push(`Standard form: ${a}x² + ${b}x + ${c}`);
  
  // Check for special cases
  
  // Difference of squares: a² - b² where b=0
  if (a > 0 && b === 0 && c < 0) {
    const squareRoot1 = Math.sqrt(a);
    const squareRoot2 = Math.sqrt(-c);
    
    // Check if both square roots are integers
    if (Number.isInteger(squareRoot1) && Number.isInteger(squareRoot2)) {
      steps.push(`This is a difference of squares: ${a}x² - ${-c} = (√${a}x)² - (√${-c})²`);
      steps.push(`Using the identity a² - b² = (a+b)(a-b)`);
      steps.push(`Factored form: (√${a}x + √${-c})(√${a}x - √${-c})`);
      
      if (squareRoot1 === 1) {
        return {
          result: `(x + ${squareRoot2})(x - ${squareRoot2})`,
          steps,
        };
      } else {
        return {
          result: `(${squareRoot1}x + ${squareRoot2})(${squareRoot1}x - ${squareRoot2})`,
          steps,
        };
      }
    }
  }
  
  // Perfect square trinomial: a² + 2ab + b² = (a+b)²
  if (a > 0 && b > 0) {
    const squareRoot = Math.sqrt(a);
    const perfectB = 2 * squareRoot * Math.sqrt(c);
    
    if (Number.isInteger(squareRoot) && Number.isInteger(Math.sqrt(c)) && Math.abs(b - perfectB) < 0.0001) {
      steps.push(`This is a perfect square trinomial: ${a}x² + ${b}x + ${c}`);
      steps.push(`It matches the pattern a² + 2ab + b² = (a+b)²`);
      
      if (squareRoot === 1) {
        return {
          result: `(x + ${Math.sqrt(c)})²`,
          steps,
        };
      } else {
        return {
          result: `(${squareRoot}x + ${Math.sqrt(c)})²`,
          steps,
        };
      }
    }
  }
  
  // Perfect square trinomial: a² - 2ab + b² = (a-b)²
  if (a > 0 && b < 0) {
    const squareRoot = Math.sqrt(a);
    const perfectB = -2 * squareRoot * Math.sqrt(c);
    
    if (Number.isInteger(squareRoot) && Number.isInteger(Math.sqrt(c)) && Math.abs(b - perfectB) < 0.0001) {
      steps.push(`This is a perfect square trinomial: ${a}x² ${b}x + ${c}`);
      steps.push(`It matches the pattern a² - 2ab + b² = (a-b)²`);
      
      if (squareRoot === 1) {
        return {
          result: `(x - ${Math.sqrt(c)})²`,
          steps,
        };
      } else {
        return {
          result: `(${squareRoot}x - ${Math.sqrt(c)})²`,
          steps,
        };
      }
    }
  }
  
  // Try to factor using quadratic formula
  if (a !== 0) {
    // Find roots
    const discriminant = b * b - 4 * a * c;
    steps.push(`Calculate discriminant: Δ = b² - 4ac = ${b}² - 4 × ${a} × ${c} = ${discriminant}`);
    
    if (discriminant < 0) {
      steps.push(`Discriminant is negative, so the quadratic cannot be factored over the real numbers.`);
      return {
        result: "Cannot be factored over the real numbers",
        steps,
      };
    } else if (discriminant === 0) {
      // One real root (double root)
      const root = -b / (2 * a);
      steps.push(`Discriminant is zero, so there is one double root: ${root}`);
      
      if (a === 1) {
        return {
          result: `(x - ${-root})²`,
          steps,
        };
      } else {
        return {
          result: `${a}(x - ${-root})²`,
          steps,
        };
      }
    } else {
      // Two real roots
      const root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
      const root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
      
      steps.push(`Discriminant is positive, so there are two real roots: ${root1} and ${root2}`);
      
      // Check if roots are "nice" (integers or simple fractions)
      if (Number.isInteger(root1) && Number.isInteger(root2)) {
        if (a === 1) {
          return {
            result: `(x - ${-root1})(x - ${-root2})`,
            steps,
          };
        } else {
          return {
            result: `${a}(x - ${-root1})(x - ${-root2})`,
            steps,
          };
        }
      } else {
        // If roots are messy, just show the factored form
        if (a === 1) {
          return {
            result: `(x - (${-root1}))(x - (${-root2}))`,
            steps,
          };
        } else {
          return {
            result: `${a}(x - (${-root1}))(x - (${-root2}))`,
            steps,
          };
        }
      }
    }
  }
  
  // Default case - unable to factor
  return {
    result: "Unable to factorize this polynomial with current methods",
    steps,
  };
};

// History item interface
interface HistoryItem {
  id: string;
  equation: string;
  type: string;
  result: string;
  timestamp: Date;
}

// Example equations for each type
const exampleEquations = {
  expression: "2 + 3 * (4 - 1)",
  linear: "2x + 3 = 7",
  quadratic: "2x^2 - 5x + 2 = 0",
  system: "2x + y = 5\n3x - 2y = 4",
  factorization: "x^2 - 4",
};

const MathEquationSolver = () => {
  const [equation, setEquation] = useState("");
  const [equationType, setEquationType] = useState("linear");
  const [result, setResult] = useState("");
  const [showSteps, setShowSteps] = useState(true);
  const [solutionSteps, setSolutionSteps] = useState<string[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeTab, setActiveTab] = useState("solver");
  const { toast } = useToast();
  
  const handleTypeChange = (type: string) => {
    setEquationType(type);
    setEquation(exampleEquations[type as keyof typeof exampleEquations] || "");
  };
  
  const handleSolve = () => {
    if (!equation.trim()) {
      toast({
        title: "Error",
        description: "Please enter an equation to solve",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const solution = solveMathProblem(equation, equationType);
      setResult(solution.result);
      setSolutionSteps(solution.steps);
      
      // Add to history
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        equation,
        type: equationType,
        result: solution.result,
        timestamp: new Date(),
      };
      
      setHistory(prev => [historyItem, ...prev].slice(0, 10));
      
      toast({
        title: "Equation solved",
        description: "The solution has been calculated",
      });
    } catch (error) {
      toast({
        title: "Error solving equation",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  };
  
  const handleClear = () => {
    setEquation("");
    setResult("");
    setSolutionSteps([]);
  };
  
  const handleCopyResult = () => {
    navigator.clipboard.writeText(result);
    toast({
      title: "Copied to clipboard",
      description: "The result has been copied to your clipboard",
    });
  };
  
  const handleClearHistory = () => {
    setHistory([]);
    toast({
      title: "History cleared",
      description: "Your calculation history has been cleared",
    });
  };
  
  const loadFromHistory = (item: HistoryItem) => {
    setEquation(item.equation);
    setEquationType(item.type);
    setResult(item.result);
    
    // Recalculate steps
    const solution = solveMathProblem(item.equation, item.type);
    setSolutionSteps(solution.steps);
    
    toast({
      title: "Loaded from history",
      description: "Equation has been loaded from your history",
    });
  };
  
  // Drawing functionality for canvas
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    setIsDrawing(true);
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#000';
  };
  
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.lineTo(x, y);
    ctx.stroke();
  };
  
  const endDrawing = () => {
    setIsDrawing(false);
  };
  
  const clearCanvas = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    toast({
      title: "Canvas cleared",
      description: "Your drawing has been cleared",
    });
  };
  
  const downloadCanvas = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const image = canvas.toDataURL("image/png");
    
    const link = document.createElement('a');
    link.download = `math-equation-${Date.now()}.png`;
    link.href = image;
    link.click();
    
    toast({
      title: "Image downloaded",
      description: "Your drawing has been downloaded as a PNG image",
    });
  };
  
  return (
    <>
      <Helmet>
        <title>Math Equation Solver | Free Online Calculator - MultiToolSet</title>
        <meta
          name="description"
          content="Solve mathematical equations with step-by-step solutions. Handles algebraic expressions, linear and quadratic equations, systems of equations, and more."
        />
        <meta
          name="keywords"
          content="math solver, equation calculator, algebra solver, math problems, step by step math, quadratic equation solver, linear equation"
        />
        <link rel="canonical" href="https://multitoolset.co/tools/math-equation-solver" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/math-equation-solver" />
        <meta property="og:title" content="Math Equation Solver | Free Online Calculator" />
        <meta property="og:description" content="Solve mathematical equations with step-by-step solutions. Handles algebraic expressions, linear and quadratic equations, systems of equations, and more." />
        <meta property="og:image" content="https://multitoolset.co/images/tools/math-equation-solver.jpg" />
        
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://multitoolset.co/tools/math-equation-solver" />
        <meta property="twitter:title" content="Math Equation Solver | Free Online Calculator" />
        <meta property="twitter:description" content="Solve mathematical equations with step-by-step solutions. Handles algebraic expressions, linear and quadratic equations, systems of equations, and more." />
        <meta property="twitter:image" content="https://multitoolset.co/images/tools/math-equation-solver.jpg" />
        
        {/* JSON-LD structured data */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Math Equation Solver",
              "applicationCategory": "Education",
              "operatingSystem": "Web",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "description": "Solve mathematical equations with step-by-step solutions. Handles algebraic expressions, linear and quadratic equations, systems of equations, and more.",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "124"
              },
              "featureList": [
                "Expression evaluation",
                "Linear equation solver",
                "Quadratic equation solver",
                "System of linear equations solver",
                "Polynomial factorization",
                "Step-by-step solutions"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="mb-8">
            <BackButton className="mb-2" />
            <h1 className="text-3xl font-bold">Math Equation Solver</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Solve mathematical equations with step-by-step solutions
            </p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="solver" className="flex items-center gap-2">
                <Calculator className="h-4 w-4" />
                <span>Equation Solver</span>
              </TabsTrigger>
              <TabsTrigger value="draw" className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                <span>Draw Equation</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="solver" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Enter Your Equation</CardTitle>
                  <CardDescription>
                    Choose the type of equation and enter it in the format shown in the example
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="md:col-span-2">
                      <Label htmlFor="equation-type">Equation Type</Label>
                      <Select value={equationType} onValueChange={handleTypeChange}>
                        <SelectTrigger id="equation-type">
                          <SelectValue placeholder="Select equation type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="expression">Mathematical Expression</SelectItem>
                          <SelectItem value="linear">Linear Equation</SelectItem>
                          <SelectItem value="quadratic">Quadratic Equation</SelectItem>
                          <SelectItem value="system">System of Linear Equations</SelectItem>
                          <SelectItem value="factorization">Polynomial Factorization</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="md:col-span-3">
                      <Label htmlFor="equation-input" className="flex items-center justify-between">
                        <span>Equation</span>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 gap-1">
                              <Info className="h-3.5 w-3.5" />
                              <span className="text-xs">Format Help</span>
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Equation Format Guide</DialogTitle>
                              <DialogDescription>
                                Follow these formats for best results with our equation solver.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4 py-4">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Format</TableHead>
                                    <TableHead>Example</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  <TableRow>
                                    <TableCell>Expression</TableCell>
                                    <TableCell>Simple mathematical expression</TableCell>
                                    <TableCell>2 + 3 * (4 - 1)</TableCell>
                                  </TableRow>
                                  <TableRow>
                                    <TableCell>Linear</TableCell>
                                    <TableCell>ax + b = c</TableCell>
                                    <TableCell>2x + 3 = 7</TableCell>
                                  </TableRow>
                                  <TableRow>
                                    <TableCell>Quadratic</TableCell>
                                    <TableCell>ax² + bx + c = 0</TableCell>
                                    <TableCell>2x^2 - 5x + 2 = 0</TableCell>
                                  </TableRow>
                                  <TableRow>
                                    <TableCell>System</TableCell>
                                    <TableCell>One equation per line</TableCell>
                                    <TableCell>2x + y = 5<br/>3x - 2y = 4</TableCell>
                                  </TableRow>
                                  <TableRow>
                                    <TableCell>Factorization</TableCell>
                                    <TableCell>Polynomial expression</TableCell>
                                    <TableCell>x^2 - 4</TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                              
                              <div className="text-sm">
                                <p className="font-semibold">Tips:</p>
                                <ul className="list-disc pl-5 space-y-1 mt-2">
                                  <li>Use ^ for exponents (e.g., x^2 for x²)</li>
                                  <li>Use * for multiplication (e.g., 2*3 or 2*x)</li>
                                  <li>Enter systems of equations with each equation on a new line</li>
                                  <li>For factorization, enter the polynomial you want to factorize</li>
                                </ul>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </Label>
                      {equationType === "system" ? (
                        <Textarea
                          id="equation-input"
                          placeholder="Enter one equation per line (e.g., 2x + y = 5)"
                          value={equation}
                          onChange={(e) => setEquation(e.target.value)}
                          rows={3}
                        />
                      ) : (
                        <Input
                          id="equation-input"
                          placeholder={`Enter your ${equationType} (e.g., ${exampleEquations[equationType as keyof typeof exampleEquations]})`}
                          value={equation}
                          onChange={(e) => setEquation(e.target.value)}
                        />
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="show-steps"
                      checked={showSteps}
                      onCheckedChange={setShowSteps}
                    />
                    <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={handleClear}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Clear
                  </Button>
                  <Button onClick={handleSolve}>
                    <Calculator className="h-4 w-4 mr-2" />
                    Solve
                  </Button>
                </CardFooter>
              </Card>
              
              {result && (
                <Card>
                  <CardHeader>
                    <CardTitle>Solution</CardTitle>
                    <CardDescription>
                      The solution to your equation is shown below
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-semibold">Result:</h3>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleCopyResult}
                          className="h-8 flex items-center gap-1"
                        >
                          <Copy className="h-4 w-4" />
                          <span>Copy</span>
                        </Button>
                      </div>
                      <p className="mt-2 text-xl font-bold break-words">{result}</p>
                    </div>
                    
                    {showSteps && solutionSteps.length > 0 && (
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Step-by-step solution:</h3>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md border border-gray-200 dark:border-gray-700">
                          <ol className="list-decimal pl-5 space-y-2">
                            {solutionSteps.map((step, index) => (
                              <li key={index} className="text-sm">{step}</li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
              
              {history.length > 0 && (
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>Calculation History</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleClearHistory}
                        className="h-8"
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Clear History
                      </Button>
                    </div>
                    <CardDescription>
                      Your recent calculations are saved here
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-[300px] overflow-y-auto">
                      {history.map((item) => (
                        <div
                          key={item.id}
                          className="p-3 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors"
                          onClick={() => loadFromHistory(item)}
                        >
                          <div className="flex justify-between items-start mb-1">
                            <div className="flex items-center">
                              <Badge variant="outline" className="mr-2">
                                {item.type === "expression"
                                  ? "Expression"
                                  : item.type === "linear"
                                  ? "Linear"
                                  : item.type === "quadratic"
                                  ? "Quadratic"
                                  : item.type === "system"
                                  ? "System"
                                  : "Factorization"}
                              </Badge>
                              <span className="text-sm text-gray-500 dark:text-gray-400">
                                {new Date(item.timestamp).toLocaleString()}
                              </span>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={(e) => {
                                e.stopPropagation();
                                loadFromHistory(item);
                              }}
                            >
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="font-medium truncate">{item.equation}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            Result: {item.result}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
              
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="reference">
                  <AccordionTrigger className="text-lg font-semibold">
                    Math Reference Guide
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-md font-semibold mb-2">Common Formulas</h3>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md text-sm space-y-2">
                          <p><strong>Quadratic Formula:</strong> x = (-b ± √(b² - 4ac)) / 2a</p>
                          <p><strong>Pythagorean Theorem:</strong> a² + b² = c²</p>
                          <p><strong>Area of Circle:</strong> A = πr²</p>
                          <p><strong>Volume of Sphere:</strong> V = (4/3)πr³</p>
                          <p><strong>Distance Formula:</strong> d = √((x₂ - x₁)² + (y₂ - y₁)²)</p>
                          <p><strong>Slope Formula:</strong> m = (y₂ - y₁) / (x₂ - x₁)</p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-md font-semibold mb-2">Algebraic Identities</h3>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md text-sm space-y-2">
                          <p><strong>(a + b)²:</strong> a² + 2ab + b²</p>
                          <p><strong>(a - b)²:</strong> a² - 2ab + b²</p>
                          <p><strong>(a + b)(a - b):</strong> a² - b²</p>
                          <p><strong>(a + b)³:</strong> a³ + 3a²b + 3ab² + b³</p>
                          <p><strong>(a - b)³:</strong> a³ - 3a²b + 3ab² - b³</p>
                          <p><strong>(a + b + c)²:</strong> a² + b² + c² + 2ab + 2bc + 2ac</p>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>
            
            <TabsContent value="draw" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Draw Your Equation</CardTitle>
                  <CardDescription>
                    Draw your equation or mathematical notation to visualize it
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white">
                    <canvas
                      ref={canvasRef}
                      width={600}
                      height={300}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={endDrawing}
                      onMouseLeave={endDrawing}
                      className="w-full cursor-crosshair touch-none"
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={clearCanvas}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Clear Canvas
                  </Button>
                  <Button onClick={downloadCanvas}>
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Upload Equation Image</CardTitle>
                  <CardDescription>
                    Upload an image of your written equation
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                    <div className="space-y-2">
                      <div className="flex justify-center">
                        <FileUp className="h-10 w-10 text-gray-400" />
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Drag and drop your equation image, or click to browse
                      </p>
                      <p className="text-xs text-gray-400 dark:text-gray-500">
                        Supported formats: PNG, JPG, JPEG (max 5MB)
                      </p>
                      <Button variant="outline" className="mt-2">
                        <label className="cursor-pointer">
                          <input type="file" className="hidden" accept="image/*" />
                          Browse Files
                        </label>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
        
        <Footer />
        <ChatBot />
      </div>
    </>
  );
};

export default MathEquationSolver;
