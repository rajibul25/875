
import { useState, useEffect, useRef } from "react";
import { Play, Pause, RotateCcw, Bell, Volume2, VolumeX, Settings, Clock, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/components/ui/use-toast";
import { Progress } from "@/components/ui/progress";
import ToolLayout from "@/components/tools/ToolLayout";

const StudyTimer = () => {
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [mode, setMode] = useState<"pomodoro" | "short" | "long">("pomodoro");
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isSound, setIsSound] = useState(true);
  const [autoStartBreaks, setAutoStartBreaks] = useState(false);
  const [autoStartPomodoros, setAutoStartPomodoros] = useState(false);
  const [cycles, setCycles] = useState(0);
  const [completedPomodoros, setCompletedPomodoros] = useState(0);
  
  // Timer settings
  const [pomodoroMinutes, setPomodoroMinutes] = useState(25);
  const [shortBreakMinutes, setShortBreakMinutes] = useState(5);
  const [longBreakMinutes, setLongBreakMinutes] = useState(15);
  const [longBreakInterval, setLongBreakInterval] = useState(4);
  
  const { toast } = useToast();
  const soundRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    soundRef.current = new Audio("https://raw.githubusercontent.com/freeCodeCamp/freeCodeCamp/main/client/static/misc/alarm-clock.mp3");
    
    return () => {
      clearInterval(intervalRef.current || undefined);
    };
  }, []);
  
  useEffect(() => {
    switch (mode) {
      case "pomodoro":
        setSecondsLeft(pomodoroMinutes * 60);
        break;
      case "short":
        setSecondsLeft(shortBreakMinutes * 60);
        break;
      case "long":
        setSecondsLeft(longBreakMinutes * 60);
        break;
      default:
        break;
    }
  }, [mode, pomodoroMinutes, shortBreakMinutes, longBreakMinutes]);
  
  useEffect(() => {
    if (isActive && !isPaused) {
      intervalRef.current = window.setInterval(() => {
        setSecondsLeft((seconds) => {
          if (seconds === 1) {
            // Timer completed
            clearInterval(intervalRef.current || undefined);
            timerCompleted();
            return 0;
          }
          return seconds - 1;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current || undefined);
    }
    
    return () => {
      clearInterval(intervalRef.current || undefined);
    };
  }, [isActive, isPaused]);
  
  const timerCompleted = () => {
    if (isSound) {
      soundRef.current?.play();
    }
    
    if (mode === "pomodoro") {
      const newCompletedPomodoros = completedPomodoros + 1;
      setCompletedPomodoros(newCompletedPomodoros);
      
      if (newCompletedPomodoros % longBreakInterval === 0) {
        toast({
          title: "Pomodoro completed!",
          description: "Take a long break now.",
        });
        setMode("long");
        
        if (autoStartBreaks) {
          setIsActive(true);
          setIsPaused(false);
        } else {
          setIsActive(false);
        }
      } else {
        toast({
          title: "Pomodoro completed!",
          description: "Take a short break now.",
        });
        setMode("short");
        
        if (autoStartBreaks) {
          setIsActive(true);
          setIsPaused(false);
        } else {
          setIsActive(false);
        }
      }
    } else {
      // Break completed, start new pomodoro
      toast({
        title: "Break completed!",
        description: "Ready to start working again?",
      });
      setMode("pomodoro");
      
      if (autoStartPomodoros) {
        setIsActive(true);
        setIsPaused(false);
      } else {
        setIsActive(false);
      }
      
      setCycles(cycles + 1);
    }
  };
  
  const startTimer = () => {
    setIsActive(true);
    setIsPaused(false);
  };
  
  const pauseTimer = () => {
    setIsPaused(true);
  };
  
  const resumeTimer = () => {
    setIsPaused(false);
  };
  
  const resetTimer = () => {
    clearInterval(intervalRef.current || undefined);
    setIsActive(false);
    setIsPaused(false);
    
    switch (mode) {
      case "pomodoro":
        setSecondsLeft(pomodoroMinutes * 60);
        break;
      case "short":
        setSecondsLeft(shortBreakMinutes * 60);
        break;
      case "long":
        setSecondsLeft(longBreakMinutes * 60);
        break;
      default:
        break;
    }
  };
  
  const switchMode = (newMode: "pomodoro" | "short" | "long") => {
    clearInterval(intervalRef.current || undefined);
    setIsActive(false);
    setIsPaused(false);
    setMode(newMode);
    
    switch (newMode) {
      case "pomodoro":
        setSecondsLeft(pomodoroMinutes * 60);
        break;
      case "short":
        setSecondsLeft(shortBreakMinutes * 60);
        break;
      case "long":
        setSecondsLeft(longBreakMinutes * 60);
        break;
      default:
        break;
    }
  };
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };
  
  const getProgress = (): number => {
    let totalSeconds;
    switch (mode) {
      case "pomodoro":
        totalSeconds = pomodoroMinutes * 60;
        break;
      case "short":
        totalSeconds = shortBreakMinutes * 60;
        break;
      case "long":
        totalSeconds = longBreakMinutes * 60;
        break;
      default:
        totalSeconds = pomodoroMinutes * 60;
    }
    
    return 100 - ((secondsLeft / totalSeconds) * 100);
  };
  
  return (
    <ToolLayout
      title="Study Timer"
      description="Focus better and increase productivity with the Pomodoro Technique"
      helpText="The Pomodoro Technique uses timed work and break intervals to improve focus. Work for 25 minutes, then take a short break. After 4 cycles, take a longer break."
    >
      <div className="max-w-3xl mx-auto">
        <Card className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-2">
              <Button
                variant={mode === "pomodoro" ? "default" : "outline"}
                onClick={() => switchMode("pomodoro")}
                className="w-28"
              >
                Pomodoro
              </Button>
              <Button
                variant={mode === "short" ? "default" : "outline"}
                onClick={() => switchMode("short")}
                className="w-28"
              >
                Short Break
              </Button>
              <Button
                variant={mode === "long" ? "default" : "outline"}
                onClick={() => switchMode("long")}
                className="w-28"
              >
                Long Break
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsSound(!isSound)}
                title={isSound ? "Sound On" : "Sound Off"}
              >
                {isSound ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
              </Button>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" title="Settings">
                    <Settings className="h-5 w-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-4">
                    <h3 className="font-medium">Timer Settings</h3>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label>Pomodoro</Label>
                        <span className="text-sm">{pomodoroMinutes} mins</span>
                      </div>
                      <Slider
                        value={[pomodoroMinutes]}
                        min={1}
                        max={60}
                        step={1}
                        onValueChange={(value) => setPomodoroMinutes(value[0])}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label>Short Break</Label>
                        <span className="text-sm">{shortBreakMinutes} mins</span>
                      </div>
                      <Slider
                        value={[shortBreakMinutes]}
                        min={1}
                        max={15}
                        step={1}
                        onValueChange={(value) => setShortBreakMinutes(value[0])}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label>Long Break</Label>
                        <span className="text-sm">{longBreakMinutes} mins</span>
                      </div>
                      <Slider
                        value={[longBreakMinutes]}
                        min={5}
                        max={30}
                        step={1}
                        onValueChange={(value) => setLongBreakMinutes(value[0])}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label>Long Break Interval</Label>
                        <span className="text-sm">{longBreakInterval} pomodoros</span>
                      </div>
                      <Slider
                        value={[longBreakInterval]}
                        min={1}
                        max={8}
                        step={1}
                        onValueChange={(value) => setLongBreakInterval(value[0])}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="auto-break">Auto-start breaks</Label>
                      <Switch
                        id="auto-break"
                        checked={autoStartBreaks}
                        onCheckedChange={setAutoStartBreaks}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="auto-pomodoro">Auto-start pomodoros</Label>
                      <Switch
                        id="auto-pomodoro"
                        checked={autoStartPomodoros}
                        onCheckedChange={setAutoStartPomodoros}
                      />
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-8xl font-bold mb-8 relative">
              <div className="flex justify-center items-center relative">
                <div className="w-72 h-72 rounded-full border-8 border-gray-100 dark:border-gray-700 relative">
                  <div className="w-full h-full rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-b from-primary/70 to-primary"
                      style={{ width: `${getProgress()}%` }}
                    />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    {formatTime(secondsLeft)}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center space-x-4">
              {!isActive ? (
                <Button onClick={startTimer} className="px-8 gap-2">
                  <Play className="h-4 w-4" />
                  Start
                </Button>
              ) : isPaused ? (
                <Button onClick={resumeTimer} className="px-8 gap-2">
                  <Play className="h-4 w-4" />
                  Resume
                </Button>
              ) : (
                <Button onClick={pauseTimer} className="px-8 gap-2">
                  <Pause className="h-4 w-4" />
                  Pause
                </Button>
              )}
              <Button onClick={resetTimer} variant="outline" className="px-8 gap-2">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          
          <div className="mt-10 pt-6 border-t border-gray-100 dark:border-gray-700 flex justify-between">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-gray-500" />
              <span>Cycles: {cycles}</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <span>Completed: {completedPomodoros} pomodoros</span>
            </div>
          </div>
        </Card>
        
        <div className="mt-10 space-y-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">About the Pomodoro Technique</h2>
            <p className="mb-4">
              The Pomodoro Technique is a time management method developed by Francesco Cirillo in the late 1980s. 
              The technique uses a timer to break down work into intervals, traditionally 25 minutes in length, 
              separated by short breaks.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">How it works:</h3>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Choose a task you want to complete</li>
              <li>Set the timer for 25 minutes (one "pomodoro")</li>
              <li>Work on the task until the timer rings</li>
              <li>Take a short break (5 minutes)</li>
              <li>After 4 pomodoros, take a longer break (15-30 minutes)</li>
            </ol>
            
            <h3 className="text-lg font-medium mt-6 mb-2">Benefits:</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>Improved focus and concentration</li>
              <li>Reduced mental fatigue</li>
              <li>Increased productivity and efficiency</li>
              <li>Better work-life balance</li>
              <li>Enhanced time awareness</li>
            </ul>
          </div>
          
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Study Tips</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium">Remove Distractions</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Put your phone away, close unnecessary browser tabs, and create a quiet environment.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Set Clear Goals</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Before starting each pomodoro, decide exactly what you want to accomplish.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Use the Break Wisely</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Stand up, stretch, grab water, or do quick exercises during breaks. Avoid screens.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Track Your Progress</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Keep a log of completed pomodoros and what you accomplished to stay motivated.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Adjust to Your Needs</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Some people work better with longer or shorter intervals. Customize the timer settings.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add schema markup for SEO
const SchemaMarkup = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Study Timer",
    "applicationCategory": "EducationalApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "All",
    "description": "Focus better and increase productivity with this Pomodoro Technique timer for studying and work."
  };

  return (
    <script type="application/ld+json">
      {JSON.stringify(schema)}
    </script>
  );
};

// Add meta tags for SEO
const SeoHead = () => {
  return (
    <>
      <title>Study Timer - Pomodoro Technique Tool for Better Focus | MultiToolSet</title>
      <meta
        name="description"
        content="Boost your productivity and focus with our free online Pomodoro Technique timer. Perfect for studying, work, and any task requiring concentration."
      />
      <meta
        name="keywords"
        content="study timer, pomodoro timer, pomodoro technique, focus timer, productivity timer, work timer, time management"
      />
      <link rel="canonical" href="https://multitoolset.co/tools/study-timer" />
    </>
  );
};

// Export with SEO components
const StudyTimerWithSeo = () => {
  return (
    <>
      <SeoHead />
      <SchemaMarkup />
      <StudyTimer />
    </>
  );
};

export default StudyTimerWithSeo;
