
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { AlertTriangle, ArrowRight, Clock, Copy, KeyRound, User } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

const JwtDecoder = () => {
  const [token, setToken] = useState("");
  const [decodedHeader, setDecodedHeader] = useState<any>(null);
  const [decodedPayload, setDecodedPayload] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isExpired, setIsExpired] = useState<boolean | null>(null);
  const [algorithm, setAlgorithm] = useState<string | null>(null);

  // Decode JWT token and update state
  const decodeToken = () => {
    if (!token.trim()) {
      toast({
        title: "No token provided",
        description: "Please enter a JWT token to decode",
        variant: "destructive"
      });
      return;
    }

    try {
      setError(null);
      setIsExpired(null);
      setAlgorithm(null);
      
      // Split token into parts
      const parts = token.split(".");
      if (parts.length !== 3) {
        throw new Error("Invalid JWT format. A JWT consists of three parts separated by dots (.)");
      }

      // Decode header (first part)
      const header = JSON.parse(atob(parts[0]));
      setDecodedHeader(header);
      setAlgorithm(header.alg);

      // Decode payload (second part)
      const payload = JSON.parse(atob(parts[1]));
      setDecodedPayload(payload);
      
      // Check if token is expired
      if (payload.exp) {
        const expiryDate = new Date(payload.exp * 1000);
        const currentDate = new Date();
        setIsExpired(currentDate > expiryDate);
      }
      
      toast({
        title: "Token decoded successfully",
        description: "JWT has been parsed and decoded",
      });
    } catch (err) {
      setDecodedHeader(null);
      setDecodedPayload(null);
      setError(err instanceof Error ? err.message : "Invalid JWT token");
      
      toast({
        title: "Error decoding token",
        description: err instanceof Error ? err.message : "The provided string is not a valid JWT token",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = (content: string, section: string) => {
    navigator.clipboard.writeText(content);
    toast({
      title: "Copied to clipboard",
      description: `${section} has been copied to your clipboard`,
    });
  };

  const clearContent = () => {
    setToken("");
    setDecodedHeader(null);
    setDecodedPayload(null);
    setError(null);
    setIsExpired(null);
    setAlgorithm(null);
  };

  // Format date from unix timestamp
  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString();
  };
  
  // Get human-readable expiration time
  const getExpirationInfo = () => {
    if (!decodedPayload?.exp) return null;
    
    const expDate = new Date(decodedPayload.exp * 1000);
    const now = new Date();
    
    if (isExpired) {
      const expiredAgo = now.getTime() - expDate.getTime();
      const minutes = Math.floor(expiredAgo / (1000 * 60));
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);
      
      if (days > 0) return `Expired ${days} day(s) ago`;
      if (hours > 0) return `Expired ${hours} hour(s) ago`;
      return `Expired ${minutes} minute(s) ago`;
    } else {
      const timeLeft = expDate.getTime() - now.getTime();
      const minutes = Math.floor(timeLeft / (1000 * 60));
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);
      
      if (days > 0) return `Expires in ${days} day(s)`;
      if (hours > 0) return `Expires in ${hours} hour(s)`;
      return `Expires in ${minutes} minute(s)`;
    }
  };

  return (
    <ToolLayout 
      title="JWT Decoder"
      description="Decode and verify JWT (JSON Web Token) securely in your browser."
      helpText="JWT decoding is performed entirely in your browser - tokens are never sent to a server for processing, ensuring your data remains private and secure."
    >
      <div className="space-y-6">
        <Card>
          <CardContent className="p-4">
            <div className="mb-4">
              <h2 className="text-lg font-medium">JWT Token Input</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Paste your JWT token here
              </p>
            </div>
            <Textarea 
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
              className="min-h-[100px] font-mono"
            />
            <div className="flex justify-center gap-4 mt-4">
              <Button 
                onClick={decodeToken} 
                className="bg-purple-600 hover:bg-purple-700"
              >
                Decode Token <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                onClick={clearContent}
              >
                Clear All
              </Button>
            </div>
          </CardContent>
        </Card>

        {error ? (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
            <div className="flex">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
              <div>
                <p className="font-medium text-red-800 dark:text-red-400">Error decoding JWT</p>
                <p className="text-sm text-red-700 dark:text-red-300 mt-1">{error}</p>
              </div>
            </div>
          </div>
        ) : decodedHeader && decodedPayload ? (
          <div className="space-y-6">
            {/* Summary Card */}
            <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-gray-800 dark:to-gray-800">
              <CardContent className="p-4">
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center">
                    <KeyRound className="h-5 w-5 text-indigo-500 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Algorithm</p>
                      <p className="font-mono">
                        {algorithm || "N/A"}
                      </p>
                    </div>
                  </div>
                  
                  {decodedPayload.sub && (
                    <div className="flex items-center">
                      <User className="h-5 w-5 text-indigo-500 mr-2" />
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Subject</p>
                        <p className="font-mono">{decodedPayload.sub}</p>
                      </div>
                    </div>
                  )}
                  
                  {decodedPayload.exp && (
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-indigo-500 mr-2" />
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Expiration</p>
                        <p className="flex items-center gap-2">
                          <span>{formatDate(decodedPayload.exp)}</span>
                          <Badge variant={isExpired ? "destructive" : "outline"}>
                            {getExpirationInfo()}
                          </Badge>
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Token Parts */}
            <Tabs defaultValue="payload">
              <TabsList className="w-full">
                <TabsTrigger value="payload" className="flex-1">Payload</TabsTrigger>
                <TabsTrigger value="header" className="flex-1">Header</TabsTrigger>
                <TabsTrigger value="signature" className="flex-1">Signature</TabsTrigger>
              </TabsList>
              
              <TabsContent value="payload" className="mt-4">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Payload Data</CardTitle>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => copyToClipboard(JSON.stringify(decodedPayload, null, 2), "Payload")}
                      >
                        <Copy className="h-4 w-4 mr-1" /> Copy
                      </Button>
                    </div>
                    <CardDescription>
                      Claims and data contained in the JWT payload
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <pre className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-[400px] font-mono">
                      {JSON.stringify(decodedPayload, null, 2)}
                    </pre>
                    
                    {/* Common claims explanation */}
                    {(decodedPayload.exp || decodedPayload.iat || decodedPayload.sub || decodedPayload.iss) && (
                      <div className="mt-4 bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg space-y-2">
                        <h3 className="font-medium">Standard Claims Explained:</h3>
                        <ul className="text-sm space-y-1">
                          {decodedPayload.iss && (
                            <li><strong>iss (Issuer)</strong>: {decodedPayload.iss}</li>
                          )}
                          {decodedPayload.sub && (
                            <li><strong>sub (Subject)</strong>: Identifier for the subject of the JWT</li>
                          )}
                          {decodedPayload.aud && (
                            <li><strong>aud (Audience)</strong>: Recipients the JWT is intended for</li>
                          )}
                          {decodedPayload.exp && (
                            <li>
                              <strong>exp (Expiration Time)</strong>: {formatDate(decodedPayload.exp)}
                              {isExpired !== null && (
                                <span className={isExpired ? " text-red-600 dark:text-red-400" : " text-green-600 dark:text-green-400"}>
                                  {" "}({isExpired ? "Expired" : "Valid"})
                                </span>
                              )}
                            </li>
                          )}
                          {decodedPayload.nbf && (
                            <li><strong>nbf (Not Before)</strong>: Time before which the JWT is not valid</li>
                          )}
                          {decodedPayload.iat && (
                            <li><strong>iat (Issued At)</strong>: Time when the JWT was issued: {formatDate(decodedPayload.iat)}</li>
                          )}
                          {decodedPayload.jti && (
                            <li><strong>jti (JWT ID)</strong>: Unique identifier for this JWT</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="header" className="mt-4">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Header Data</CardTitle>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => copyToClipboard(JSON.stringify(decodedHeader, null, 2), "Header")}
                      >
                        <Copy className="h-4 w-4 mr-1" /> Copy
                      </Button>
                    </div>
                    <CardDescription>
                      Metadata about the JWT token type and algorithm
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <pre className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto font-mono">
                      {JSON.stringify(decodedHeader, null, 2)}
                    </pre>
                    
                    {/* Algorithm security note */}
                    {decodedHeader.alg && (
                      <div className="mt-4 p-3 rounded-lg space-y-2 text-sm" 
                        style={{
                          backgroundColor: 
                            decodedHeader.alg === 'none' ? 'rgba(239, 68, 68, 0.1)' : 
                            (decodedHeader.alg === 'HS256' || decodedHeader.alg.startsWith('RS') || decodedHeader.alg.startsWith('ES')) ? 
                              'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)'
                        }}
                      >
                        <h3 className="font-medium">Algorithm Security:</h3>
                        {decodedHeader.alg === 'none' ? (
                          <p className="text-red-600 dark:text-red-400">
                            Warning: The "none" algorithm provides no security and should never be used in production.
                          </p>
                        ) : decodedHeader.alg === 'HS256' ? (
                          <p className="text-green-600 dark:text-green-400">
                            HMAC-SHA256 is a secure algorithm when used with a strong secret key.
                          </p>
                        ) : decodedHeader.alg.startsWith('RS') ? (
                          <p className="text-green-600 dark:text-green-400">
                            RSA signature algorithms provide strong security with public/private key pairs.
                          </p>
                        ) : decodedHeader.alg.startsWith('ES') ? (
                          <p className="text-green-600 dark:text-green-400">
                            ECDSA signature algorithms provide strong security with elliptic curve cryptography.
                          </p>
                        ) : (
                          <p className="text-yellow-600 dark:text-yellow-400">
                            This algorithm should be reviewed for security implications in your specific context.
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="signature" className="mt-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Signature</CardTitle>
                    <CardDescription>
                      The signature verifies the token hasn't been altered
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                      <p className="mb-4">
                        The signature is used to verify that the sender of the JWT is who it says it is and to ensure the message wasn't changed along the way.
                      </p>
                      
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg text-sm">
                        <p className="font-medium mb-2">Important Security Note:</p>
                        <p>
                          This tool only decodes JWT tokens and does not verify signatures. In a production environment, 
                          always verify JWT signatures on the server side using the appropriate secret or public key.
                        </p>
                      </div>
                      
                      <div className="mt-4">
                        <p className="font-medium mb-1">The signature is created using this formula:</p>
                        <pre className="bg-gray-100 dark:bg-gray-700 p-2 rounded font-mono text-sm overflow-x-auto whitespace-pre-wrap">
                          HMACSHA256(
                            base64UrlEncode(header) + "." + base64UrlEncode(payload),
                            secret
                          )
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        ) : null}

        <div className="mt-8 space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <ol className="list-decimal space-y-3 ml-5">
              <li>Paste your JWT token into the input field.</li>
              <li>Click the "Decode Token" button to extract and display the header and payload data.</li>
              <li>View the decoded information in the sections below.</li>
              <li>Check expiration time and validity status.</li>
              <li>Copy individual sections as needed.</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">FAQ</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">What is a JWT?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  JSON Web Token (JWT) is an open standard (RFC 7519) that defines a compact and self-contained way for securely transmitting information between parties as a JSON object. JWTs are commonly used for authentication and secure information exchange.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Is it safe to paste my JWT here?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Yes, this tool processes your JWT entirely in your browser. Your token is never sent to our servers or stored anywhere. However, JWTs may contain sensitive information, so be cautious when using any online tools.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">Can this tool verify JWT signatures?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  No, this tool only decodes the JWT but doesn't verify the signature. Signature verification requires the secret key or public key used to sign the token, which should be kept secure on your server.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold">What are common JWT claims?</h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Common JWT claims include: "iss" (issuer), "sub" (subject), "aud" (audience), "exp" (expiration time), "nbf" (not before), "iat" (issued at), and "jti" (JWT ID). Claims can be registered (predefined), public (custom but with registered name), or private (specific to your application).
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Related Tools</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a href="/tools/base64-encoder" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">Base64 Encoder/Decoder</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Encode or decode data to and from Base64 format.
                </p>
              </a>
              <a href="/tools/json-formatter" className="block p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                <h3 className="font-semibold">JSON Formatter</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Format and validate JSON data with our powerful JSON formatter tool.
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default JwtDecoder;
