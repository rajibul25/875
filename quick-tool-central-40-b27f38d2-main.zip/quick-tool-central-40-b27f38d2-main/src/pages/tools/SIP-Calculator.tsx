
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { ArrowRight, Calculator, PiggyBank, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ToolLayout from "@/components/tools/ToolLayout";
import withErrorBoundary from "@/components/tools/withErrorBoundary";

interface SipResult {
  totalInvestment: number;
  estimatedReturns: number;
  maturityValue: number;
  monthlyContribution?: number;
  targetAmount?: number;
}

const SipCalculatorComponent = () => {
  const [amount, setAmount] = useState<string>("5000");
  const [interestRate, setInterestRate] = useState<string>("12");
  const [years, setYears] = useState<string>("10");
  const [targetAmount, setTargetAmount] = useState<string>("1000000");
  const [calculationType, setCalculationType] = useState<"amount" | "target">("amount");
  const [result, setResult] = useState<SipResult | null>(null);

  useEffect(() => {
    // Calculate on initial load with default values
    handleCalculate();
  }, [calculationType]);

  const handleCalculate = () => {
    if (calculationType === "amount") {
      calculateSipAmount();
    } else {
      calculateTargetSip();
    }
  };

  const calculateSipAmount = () => {
    const monthlyAmount = parseFloat(amount);
    const rate = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const tenure = parseInt(years) * 12; // Tenure in months

    if (isNaN(monthlyAmount) || isNaN(rate) || isNaN(tenure)) {
      toast.error("Please enter valid numbers");
      return;
    }

    if (monthlyAmount <= 0 || rate <= 0 || tenure <= 0) {
      toast.error("All values must be greater than zero");
      return;
    }

    // SIP calculation formula: M × {[(1 + r)^n - 1] / r} × (1 + r)
    // Where M is monthly investment, r is monthly interest rate, n is number of months
    const futureValue = monthlyAmount * ((Math.pow(1 + rate, tenure) - 1) / rate) * (1 + rate);
    const totalInvestment = monthlyAmount * tenure;
    const estimatedReturns = futureValue - totalInvestment;

    setResult({
      totalInvestment,
      estimatedReturns,
      maturityValue: futureValue,
    });

    toast.success("SIP calculation complete!");
  };

  const calculateTargetSip = () => {
    const target = parseFloat(targetAmount);
    const rate = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const tenure = parseInt(years) * 12; // Tenure in months

    if (isNaN(target) || isNaN(rate) || isNaN(tenure)) {
      toast.error("Please enter valid numbers");
      return;
    }

    if (target <= 0 || rate <= 0 || tenure <= 0) {
      toast.error("All values must be greater than zero");
      return;
    }

    // Reverse SIP calculation: P = A / {[(1 + r)^n - 1] / r} × (1 + r)
    // Where P is monthly investment required, A is target amount, r is monthly interest rate, n is number of months
    const monthlyContribution = target / (((Math.pow(1 + rate, tenure) - 1) / rate) * (1 + rate));
    const totalInvestment = monthlyContribution * tenure;
    const estimatedReturns = target - totalInvestment;

    setResult({
      totalInvestment,
      estimatedReturns,
      maturityValue: target,
      monthlyContribution,
      targetAmount: target,
    });

    toast.success("Required SIP calculation complete!");
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <ToolLayout
      title="SIP Calculator"
      description="Calculate your future wealth with our Systematic Investment Plan (SIP) calculator"
      helpText="Enter investment details to calculate returns on your SIP investments"
    >
      <Helmet>
        <title>SIP Calculator | Systematic Investment Plan Returns Calculator | MultiToolSet</title>
        <meta
          name="description"
          content="Calculate your future wealth with our free SIP calculator. Plan your investments and see the power of compounding with our Systematic Investment Plan calculator."
        />
        <meta
          name="keywords"
          content="SIP calculator, systematic investment plan, mutual fund calculator, investment calculator, compounding returns, financial planning"
        />
      </Helmet>

      <div className="space-y-6 max-w-3xl mx-auto">
        <Tabs value={calculationType} onValueChange={(v) => setCalculationType(v as "amount" | "target")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="amount">Calculate Returns</TabsTrigger>
            <TabsTrigger value="target">Calculate Required SIP</TabsTrigger>
          </TabsList>
          
          <TabsContent value="amount" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Calculator className="mr-2 text-purple-600" />
                Calculate SIP Returns
              </h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="monthlyAmount" className="block text-sm font-medium text-gray-700">
                    Monthly Investment Amount (₹)
                  </label>
                  <Input
                    id="monthlyAmount"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter monthly investment amount"
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700">
                    Expected Annual Returns (%)
                  </label>
                  <Input
                    id="interestRate"
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    placeholder="Enter expected annual return rate"
                    className="w-full"
                    step="0.1"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="tenure" className="block text-sm font-medium text-gray-700">
                    Investment Period (Years)
                  </label>
                  <Input
                    id="tenure"
                    type="number"
                    value={years}
                    onChange={(e) => setYears(e.target.value)}
                    placeholder="Enter investment period in years"
                    className="w-full"
                  />
                </div>
                
                <Button 
                  onClick={handleCalculate}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <Calculator className="mr-2 h-4 w-4" /> Calculate SIP Returns
                </Button>
              </div>
            </Card>
          </TabsContent>
          
          <TabsContent value="target" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <TrendingUp className="mr-2 text-purple-600" />
                Calculate Required SIP
              </h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="targetAmount" className="block text-sm font-medium text-gray-700">
                    Target Amount (₹)
                  </label>
                  <Input
                    id="targetAmount"
                    type="number"
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    placeholder="Enter target amount"
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="targetInterestRate" className="block text-sm font-medium text-gray-700">
                    Expected Annual Returns (%)
                  </label>
                  <Input
                    id="targetInterestRate"
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    placeholder="Enter expected annual return rate"
                    className="w-full"
                    step="0.1"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="targetTenure" className="block text-sm font-medium text-gray-700">
                    Investment Period (Years)
                  </label>
                  <Input
                    id="targetTenure"
                    type="number"
                    value={years}
                    onChange={(e) => setYears(e.target.value)}
                    placeholder="Enter investment period in years"
                    className="w-full"
                  />
                </div>
                
                <Button 
                  onClick={handleCalculate}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <Calculator className="mr-2 h-4 w-4" /> Calculate Required SIP
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
        
        {result && (
          <Card className="p-6 bg-gray-50">
            <h3 className="font-bold text-lg mb-4">SIP Investment Summary</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Total Investment</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(result.totalInvestment)}
                </p>
                {calculationType === "target" && result.monthlyContribution && (
                  <p className="text-sm text-gray-500 mt-1">
                    Monthly: {formatCurrency(result.monthlyContribution)}
                  </p>
                )}
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Estimated Returns</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(result.estimatedReturns)}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600">Total Value</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatCurrency(result.maturityValue)}
                </p>
              </div>
            </div>
          </Card>
        )}
        
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <h2 className="text-xl font-bold mb-4">What is SIP?</h2>
          <p className="mb-4">
            A Systematic Investment Plan (SIP) is an investment strategy offered by mutual funds where 
            investors can invest a fixed amount regularly, typically monthly or quarterly. SIP helps in 
            building wealth over time through the power of compounding and rupee cost averaging.
          </p>
          
          <h3 className="text-lg font-medium mb-2">Benefits of SIP Investments</h3>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li>Disciplined approach to investing without timing the market</li>
            <li>Power of compounding helps grow your investments exponentially over time</li>
            <li>Rupee cost averaging reduces the impact of market volatility</li>
            <li>Start with a small amount and increase as your income grows</li>
            <li>Flexibility to pause or stop investments if your financial situation changes</li>
          </ul>
          
          <h3 className="text-lg font-medium mb-2">How Our SIP Calculator Works</h3>
          <p>
            Our SIP calculator uses the compound interest formula to project the future value of your 
            investments. It considers your monthly investment amount, expected rate of return, and 
            investment duration to give you a reasonable estimate of your wealth accumulation.
          </p>
        </div>
      </div>
    </ToolLayout>
  );
};

const SipCalculator = withErrorBoundary(SipCalculatorComponent, "sip-calculator");

export default SipCalculator;
