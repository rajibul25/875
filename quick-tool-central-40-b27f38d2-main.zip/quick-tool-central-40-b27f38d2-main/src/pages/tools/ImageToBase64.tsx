
import { useState, useRef } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, Copy, Download, FileText } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";

const ImageToBase64Component = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [base64String, setBase64String] = useState<string>("");
  const [outputFormat, setOutputFormat] = useState<"raw" | "data-url" | "css" | "html">("raw");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size should be less than 5MB");
      return;
    }

    setImageFile(file);
    
    const reader = new FileReader();
    
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setSelectedImage(dataUrl);
      
      // Extract base64 string from data URL
      const base64 = dataUrl.split(',')[1];
      setBase64String(base64);
      
      // Reset the input value so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast.success("Image converted to Base64");
    };
    
    reader.readAsDataURL(file);
  };

  const copyToClipboard = () => {
    if (!base64String) {
      toast.error("No Base64 string to copy");
      return;
    }
    
    const textToCopy = getFormattedOutput();
    
    navigator.clipboard.writeText(textToCopy);
    toast.success("Base64 string copied to clipboard");
  };

  const getFormattedOutput = (): string => {
    if (!base64String || !imageFile) return "";
    
    switch (outputFormat) {
      case "raw":
        return base64String;
      case "data-url":
        return `data:${imageFile.type};base64,${base64String}`;
      case "css":
        return `.element {\n  background-image: url("data:${imageFile.type};base64,${base64String}");\n}`;
      case "html":
        return `<img src="data:${imageFile.type};base64,${base64String}" alt="Base64 encoded image" />`;
      default:
        return base64String;
    }
  };

  const downloadTextFile = () => {
    if (!base64String) {
      toast.error("No Base64 string to download");
      return;
    }
    
    const textToDownload = getFormattedOutput();
    const blob = new Blob([textToDownload], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `image-base64.${outputFormat === "raw" ? "txt" : outputFormat === "css" ? "css" : outputFormat === "html" ? "html" : "txt"}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Base64 file downloaded");
  };

  return (
    <ToolLayout
      title="Image to Base64 Converter"
      description="Convert images to Base64 encoded strings for embedding directly in your web pages, CSS, or applications."
      helpText="Base64 encoding allows you to include image data directly in your code without external files. Great for small images, icons, and optimizing page load times."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload an Image</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select Image</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              PNG, JPG, WebP, GIF, or SVG. Maximum size: 5MB.
            </p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Note: Larger images will result in very long Base64 strings.
            </p>
          </div>
        </div>

        {selectedImage && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Preview Image</h2>
            <Card className="p-4 mb-4">
              <div className="flex justify-center">
                <img
                  src={selectedImage}
                  alt="Image preview"
                  className="max-w-full h-auto max-h-64 object-contain"
                />
              </div>
              <div className="mt-3 text-center text-sm text-gray-500">
                {imageFile?.name} • {(imageFile?.size || 0) / 1024 < 1024 
                  ? `${Math.round((imageFile?.size || 0) / 1024 * 10) / 10} KB` 
                  : `${Math.round((imageFile?.size || 0) / 1024 / 1024 * 10) / 10} MB`
                }
              </div>
            </Card>

            <h2 className="text-xl font-semibold mb-4">Base64 Output</h2>
            <Tabs defaultValue="raw" onValueChange={(value) => setOutputFormat(value as any)}>
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
                <TabsTrigger value="raw">Raw Base64</TabsTrigger>
                <TabsTrigger value="data-url">Data URL</TabsTrigger>
                <TabsTrigger value="css">CSS</TabsTrigger>
                <TabsTrigger value="html">HTML</TabsTrigger>
              </TabsList>
              
              <TabsContent value="raw" className="mt-4">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  Raw Base64 string without the data URL prefix:
                </p>
              </TabsContent>
              
              <TabsContent value="data-url" className="mt-4">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  Complete data URL with Base64 encoding, ready to use in img src attributes:
                </p>
              </TabsContent>
              
              <TabsContent value="css" className="mt-4">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  CSS declaration with Base64 background image:
                </p>
              </TabsContent>
              
              <TabsContent value="html" className="mt-4">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  HTML img tag with Base64 encoded src:
                </p>
              </TabsContent>
            </Tabs>
            
            <div className="mt-2 mb-4">
              <Textarea
                ref={textareaRef}
                readOnly
                value={getFormattedOutput()}
                className="font-mono text-xs h-48 overflow-auto"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button 
                onClick={copyToClipboard}
                variant="outline"
                className="flex items-center justify-center"
              >
                <Copy className="h-5 w-5 mr-2" />
                Copy to Clipboard
              </Button>
              
              <Button
                onClick={downloadTextFile}
                variant="outline"
                className="flex items-center justify-center"
              >
                <FileText className="h-5 w-5 mr-2" />
                Download as Text File
              </Button>
            </div>
          </div>
        )}

        <AdBanner />

        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What is Base64 encoding?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Base64 is a binary-to-text encoding scheme that represents binary data in an ASCII string format. 
                It's commonly used to embed image data directly within HTML, CSS, or JSON files without requiring 
                an external image file.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Why would I convert an image to Base64?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Using Base64 encoded images can reduce HTTP requests, which may improve page load times for small images. 
                It's useful for embedding small icons, logos, or simple graphics directly in your code, especially when 
                you want to avoid external file dependencies.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Are there any drawbacks to using Base64 images?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Yes, Base64 encoding increases the file size by approximately 33% compared to the original binary data. 
                This means larger images can lead to bloated code and potentially slower page loads. Base64 encoded images 
                also can't be cached separately by browsers like regular image files.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">What image sizes are best for Base64 encoding?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Base64 encoding is best for small images under 10KB, such as icons, small logos, or simple graphics. 
                Larger images are generally better served as separate files through traditional methods.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How do I use the generated Base64 code?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                You can use the "Data URL" format directly in HTML img src attributes or CSS background-image properties. 
                The "CSS" format provides ready-to-use CSS code, and the "HTML" format gives you a complete img tag. 
                The "Raw" format is useful when you need just the encoded data without prefixes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const ImageToBase64 = withErrorBoundary(ImageToBase64Component, "image-to-base64");

export default ImageToBase64;
