
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Search, Camera, AlertCircle, Info } from "lucide-react";
import { toast } from "sonner";
import AdBanner from "@/components/AdBanner";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";

const SerpPreviewTool = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [viewMode, setViewMode] = useState<"desktop" | "mobile">("desktop");
  const [titleLength, setTitleLength] = useState(0);
  const [descriptionLength, setDescriptionLength] = useState(0);
  const [currentDate] = useState(new Date().toLocaleDateString("en-US", { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  }));
  const maxTitleLength = 60;
  const maxDescriptionLength = 160;

  // Update character count when inputs change
  React.useEffect(() => {
    setTitleLength(title.length);
    setDescriptionLength(description.length);
  }, [title, description]);

  const generatePreview = () => {
    // Validation
    if (!title) {
      toast.error("Please enter a title for the SERP preview");
      return;
    }
    
    // No need to do more as preview updates live
    toast.success("SERP preview updated!");
  };

  const importFromPage = () => {
    // This would fetch metadata from a live URL in a real implementation
    // Here we'll just show a toast for the demo
    toast.info("This feature would import metadata from a live URL. Not implemented in this demo.");
  };

  const takeScreenshot = () => {
    const preview = document.getElementById('serp-preview');
    if (!preview) return;
    
    toast.success("Screenshot functionality would capture the preview area in a real implementation.");
  };

  const resetForm = () => {
    setTitle("");
    setDescription("");
    setUrl("");
    setTitleLength(0);
    setDescriptionLength(0);
    toast.info("Form reset complete");
  };

  const getDomainFromUrl = (url: string): string => {
    try {
      // Try to extract domain using URL API
      if (url.trim() === "") return "example.com";
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "https://" + url;
      }
      const parsed = new URL(url);
      return parsed.hostname;
    } catch (e) {
      // If URL is invalid, try to guess the domain
      const domainMatch = url.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:/\n?]+)/i);
      return domainMatch ? domainMatch[1] : "example.com";
    }
  };

  // Truncate strings for display
  const displayTitle = title.length > maxTitleLength ? 
    title.substring(0, maxTitleLength) + "..." : 
    title;
    
  const displayDescription = description.length > maxDescriptionLength ? 
    description.substring(0, maxDescriptionLength) + "..." : 
    description;
    
  const domain = getDomainFromUrl(url || "example.com");
  const displayUrl = url || "https://example.com/page";

  return (
    <ToolLayout
      title="SERP Preview Tool"
      description="Visualize how your page will appear in Google search results"
      helpText="This tool helps you preview and optimize how your webpage will look in Google search results. Enter your meta title, description, and URL to generate a preview."
    >
      <div className="space-y-6">
        <Tabs defaultValue="preview" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="preview">SERP Preview</TabsTrigger>
            <TabsTrigger value="import" disabled>Import from URL (Coming Soon)</TabsTrigger>
          </TabsList>
          
          <TabsContent value="preview" className="space-y-6 mt-4">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    Title Tag 
                    <span className={`ml-2 text-sm ${titleLength > maxTitleLength ? 'text-red-500' : 'text-muted-foreground'}`}>
                      ({titleLength}/{maxTitleLength} characters)
                    </span>
                  </Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter your page title tag..."
                    className={titleLength > maxTitleLength ? "border-red-500" : ""}
                  />
                  {titleLength > maxTitleLength && (
                    <p className="text-xs text-red-500">
                      Title exceeds the recommended length and may be truncated in search results
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">
                    Meta Description 
                    <span className={`ml-2 text-sm ${descriptionLength > maxDescriptionLength ? 'text-red-500' : 'text-muted-foreground'}`}>
                      ({descriptionLength}/{maxDescriptionLength} characters)
                    </span>
                  </Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Enter your meta description..."
                    rows={3}
                    className={descriptionLength > maxDescriptionLength ? "border-red-500" : ""}
                  />
                  {descriptionLength > maxDescriptionLength && (
                    <p className="text-xs text-red-500">
                      Description exceeds the recommended length and may be truncated in search results
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="url">Page URL</Label>
                  <Input
                    id="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://example.com/your-page"
                  />
                </div>
                
                <div className="flex flex-wrap gap-2 mt-4">
                  <Button onClick={generatePreview}>
                    <Search className="mr-2 h-4 w-4" />
                    Generate Preview
                  </Button>
                  <Button variant="outline" onClick={resetForm}>
                    Reset
                  </Button>
                  <Button variant="secondary" onClick={takeScreenshot}>
                    <Camera className="mr-2 h-4 w-4" />
                    Screenshot
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h3 className="text-lg font-medium">Preview</h3>
                <p className="text-sm text-muted-foreground">How your page may appear in Google search results</p>
              </div>
              
              <RadioGroup 
                value={viewMode} 
                onValueChange={(value) => setViewMode(value as "desktop" | "mobile")}
                className="flex items-center space-x-2"
              >
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="desktop" id="desktop" />
                  <Label htmlFor="desktop" className="text-sm cursor-pointer">Desktop</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="mobile" id="mobile" />
                  <Label htmlFor="mobile" className="text-sm cursor-pointer">Mobile</Label>
                </div>
              </RadioGroup>
            </div>
            
            <Separator />
            
            <div
              id="serp-preview"
              className={`font-sans ${viewMode === "mobile" ? "max-w-sm" : "max-w-3xl"} mx-auto bg-white dark:bg-gray-800 p-4 rounded-lg border`}
            >
              <div className={`${viewMode === "mobile" ? "flex flex-col" : ""}`}>
                {viewMode === "desktop" && (
                  <div className="text-gray-800 dark:text-gray-400 text-xs mb-1 overflow-hidden text-ellipsis">
                    {displayUrl}
                  </div>
                )}
                <div className="text-blue-800 dark:text-blue-400 text-xl mb-1 font-medium hover:underline cursor-pointer overflow-hidden">
                  {displayTitle || "This is an example title for your search result preview"}
                </div>
                {viewMode === "mobile" && (
                  <div className="text-green-700 dark:text-green-500 text-xs mb-1">
                    {domain} · {currentDate}
                  </div>
                )}
                <div className="text-gray-600 dark:text-gray-300 text-sm overflow-hidden">
                  {displayDescription || "This is an example meta description that shows how your page will appear in Google search results. Add your own description to customize this preview."}
                </div>
              </div>
            </div>
            
            <AdBanner className="my-4" />
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
              <div className="flex items-start">
                <Info className="h-5 w-5 mr-2 text-blue-700 dark:text-blue-400 mt-0.5" />
                <div>
                  <h4 className="font-medium mb-2">SEO Best Practices</h4>
                  <ul className="text-sm space-y-1 list-disc pl-5">
                    <li>Keep your title between 50-60 characters to avoid truncation</li>
                    <li>Meta descriptions should be under 160 characters and include a call to action</li>
                    <li>Include your primary keyword in both title and description</li>
                    <li>Make titles unique and descriptive of the page content</li>
                    <li>Use structured data to enhance your search listing with rich results</li>
                    <li>Consider including the current year for time-sensitive content</li>
                  </ul>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="import" className="space-y-4 mt-4">
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-6 max-w-md mx-auto text-center">
              <h2 className="text-xl font-semibold mb-3">Coming Soon</h2>
              <p className="text-gray-600 dark:text-gray-300">
                URL import functionality is coming soon. This feature will allow you to import metadata from any webpage.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ToolLayout>
  );
};

export default SerpPreviewTool;
