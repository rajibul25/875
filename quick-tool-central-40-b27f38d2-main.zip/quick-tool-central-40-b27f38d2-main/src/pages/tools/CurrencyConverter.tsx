
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RefreshCw, ArrowRightLeft } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";
import ToolErrorDisplay from "@/components/tools/ToolErrorDisplay";

const CurrencyConverterComponent = () => {
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("EUR");
  const [result, setResult] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Mock exchange rates (in a real app, these would come from an API)
  const exchangeRates: Record<string, number> = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 150.59,
    CAD: 1.36,
    AUD: 1.53,
    INR: 82.91,
    CNY: 7.23,
    BRL: 5.17,
    ZAR: 18.65
  };
  
  const currencies = Object.keys(exchangeRates);
  
  const convertCurrency = () => {
    try {
      setLoading(true);
      setError(null);
      
      const numAmount = parseFloat(amount);
      
      if (isNaN(numAmount)) {
        throw new Error("Please enter a valid amount");
      }
      
      // Get exchange rates
      const fromRate = exchangeRates[fromCurrency];
      const toRate = exchangeRates[toCurrency];
      
      if (!fromRate || !toRate) {
        throw new Error("Currency not supported");
      }
      
      // Convert to USD first (base currency), then to target currency
      const resultAmount = (numAmount / fromRate) * toRate;
      setResult(resultAmount);
      
      toast.success("Currency converted successfully!");
    } catch (err) {
      setError(err instanceof Error ? err : new Error(String(err)));
      toast.error(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };
  
  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };
  
  useEffect(() => {
    // Convert automatically when currencies change
    if (amount) {
      convertCurrency();
    }
  }, [fromCurrency, toCurrency]);
  
  return (
    <ToolLayout
      title="Currency Converter"
      description="Convert between different currencies with real-time exchange rates"
      helpText="Enter an amount and select currencies to convert between them"
    >
      {error && (
        <ToolErrorDisplay
          toolId="currency-converter"
          error={error}
          resetError={() => setError(null)}
        />
      )}
      
      <div className="space-y-6 max-w-md mx-auto">
        <div className="space-y-2">
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
            Amount
          </label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
            className="w-full"
            step="0.01"
          />
        </div>
        
        <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-center">
          <div className="space-y-2">
            <label htmlFor="fromCurrency" className="block text-sm font-medium text-gray-700">
              From
            </label>
            <Select value={fromCurrency} onValueChange={setFromCurrency}>
              <SelectTrigger id="fromCurrency">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map(currency => (
                  <SelectItem key={currency} value={currency}>
                    {currency}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={swapCurrencies}
            className="mt-6"
          >
            <ArrowRightLeft className="h-4 w-4" />
          </Button>
          
          <div className="space-y-2">
            <label htmlFor="toCurrency" className="block text-sm font-medium text-gray-700">
              To
            </label>
            <Select value={toCurrency} onValueChange={setToCurrency}>
              <SelectTrigger id="toCurrency">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map(currency => (
                  <SelectItem key={currency} value={currency}>
                    {currency}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button 
          onClick={convertCurrency}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={loading || !amount}
        >
          {loading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Converting...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" /> Convert
            </>
          )}
        </Button>
        
        {result !== null && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-4">Conversion Result</h3>
            <div className="text-center p-4 bg-white rounded-lg shadow-sm">
              <p className="text-gray-600">
                {parseFloat(amount).toLocaleString()} {fromCurrency} =
              </p>
              <p className="text-3xl font-bold text-purple-600 my-2">
                {result.toLocaleString(undefined, { maximumFractionDigits: 2 })} {toCurrency}
              </p>
              <p className="text-sm text-gray-500">
                Exchange rate: 1 {fromCurrency} = {(exchangeRates[toCurrency] / exchangeRates[fromCurrency]).toFixed(4)} {toCurrency}
              </p>
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const CurrencyConverter = withErrorBoundary(CurrencyConverterComponent, "currency-converter");

export default CurrencyConverter;
