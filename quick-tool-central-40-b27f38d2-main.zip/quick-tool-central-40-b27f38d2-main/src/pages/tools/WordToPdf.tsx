
import React from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const WordToPdf = () => {
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is Word document
    if (file.type !== "application/vnd.openxmlformats-officedocument.wordprocessingml.document" && 
        file.type !== "application/msword") {
      toast.error("Please upload a Word document (DOC or DOCX)");
      return;
    }

    // Here we would process the file, but for now we'll just show a toast
    toast.success(`File "${file.name}" uploaded successfully. Conversion will be available in a future update.`);
  };

  return (
    <ToolLayout 
      title="Word to PDF Converter"
      description="Convert your Word documents to PDF files online, for free."
    >
      <Helmet>
        <title>Word to PDF Converter | Convert DOCX to PDF Online | MultiToolSet</title>
        <meta
          name="description"
          content="Convert Word documents (DOC, DOCX) to PDF online for free. Preserve formatting and layouts with our efficient Word to PDF converter."
        />
      </Helmet>

      <div className="container mx-auto py-8">
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center">
                <Label htmlFor="word-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600">
                      Click to upload or drag and drop
                    </span>
                    <span className="text-xs text-gray-500">Word documents only (max 10MB)</span>
                  </div>
                  <Input
                    id="word-upload"
                    type="file"
                    className="hidden"
                    accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    onChange={handleFileUpload}
                  />
                </Label>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast.info("This feature will be available in a future update.");
                  }}
                  size="lg"
                >
                  Convert to PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Convert Word to PDF</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload your Word document using the upload button above</li>
              <li>Wait for the conversion process to complete</li>
              <li>Download your converted PDF file</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our Word to PDF Converter</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Free to use with no watermarks</li>
              <li>Preserves text, images, formatting and layouts</li>
              <li>Converts DOC and DOCX file formats</li>
              <li>Secure and private conversion - files deleted after processing</li>
              <li>Fast and reliable conversion engine</li>
              <li>No installation required - works in your browser</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default WordToPdf;
