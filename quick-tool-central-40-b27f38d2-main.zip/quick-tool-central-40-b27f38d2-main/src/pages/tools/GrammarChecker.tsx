import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { AlertCircle, Check, Copy, Save, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const GrammarChecker = () => {
  const [text, setText] = useState("");
  const [correctedText, setCorrectedText] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const [language, setLanguage] = useState("en-US");
  const [errors, setErrors] = useState<Array<{
    type: string;
    original: string;
    suggestion: string;
    position: [number, number]; // [start, end]
    severity: "critical" | "major" | "minor";
  }>>([]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    // Reset corrections when text changes
    setCorrectedText("");
    setErrors([]);
  };

  const checkGrammar = () => {
    if (text.trim().length < 5) {
      toast.error("Please enter more text to check for grammar issues");
      return;
    }
    
    setIsChecking(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      // Mock grammar checking - in a real app this would come from a grammar API
      const mockErrors = generateMockErrors(text);
      setErrors(mockErrors);
      
      // Generate corrected text
      let textWithCorrections = text;
      [...mockErrors].reverse().forEach(error => {
        textWithCorrections = 
          textWithCorrections.substring(0, error.position[0]) + 
          error.suggestion + 
          textWithCorrections.substring(error.position[1]);
      });
      
      setCorrectedText(textWithCorrections);
      setIsChecking(false);
      toast.success("Grammar check completed");
    }, 2000);
  };

  const generateMockErrors = (input: string) => {
    const errors = [];
    
    // Common grammar errors to detect
    const patterns = [
      { 
        regex: /\b(its)\s+(?=going|coming|getting|becoming|doing)/gi, 
        type: "Grammar", 
        suggestion: "it's",
        severity: "major" as const
      },
      { 
        regex: /\b(there)\s+(?=is|are|were|was)\b/gi, 
        type: "Grammar", 
        suggestion: "their",
        severity: "major" as const
      },
      { 
        regex: /\b(your)\s+(?=welcome|invited|going)\b/gi, 
        type: "Grammar", 
        suggestion: "you're",
        severity: "major" as const
      },
      { 
        regex: /\b(alot)\b/gi, 
        type: "Spelling", 
        suggestion: "a lot",
        severity: "minor" as const
      },
      { 
        regex: /\b(i)\b/g, 
        type: "Capitalization", 
        suggestion: "I",
        severity: "minor" as const
      },
      { 
        regex: /([.!?])\s*([a-z])/g,
        match: (_match: string, p1: string, p2: string) => ({ 
          original: p1 + " " + p2,
          suggestion: p1 + " " + p2.toUpperCase() 
        }),
        type: "Capitalization",
        severity: "minor" as const
      },
      // Add more patterns as needed
    ];

    // Find matches for each pattern
    patterns.forEach(pattern => {
      if (pattern.regex && !pattern.match) {
        let match;
        while ((match = pattern.regex.exec(input)) !== null) {
          errors.push({
            type: pattern.type,
            original: match[0],
            suggestion: match[0].replace(pattern.regex, pattern.suggestion),
            position: [match.index, match.index + match[0].length],
            severity: pattern.severity
          });
        }
      } else if (pattern.regex && pattern.match) {
        let match;
        while ((match = pattern.regex.exec(input)) !== null) {
          const result = pattern.match(match[0], match[1], match[2]);
          errors.push({
            type: pattern.type,
            original: result.original,
            suggestion: result.suggestion,
            position: [match.index, match.index + match[0].length],
            severity: pattern.severity
          });
        }
      }
    });
    
    // For demonstration, add some random suggestions if none found
    if (errors.length === 0 && input.length > 50) {
      const randomPos = Math.floor(Math.random() * (input.length - 10)) + 5;
      const randomWord = input.substring(randomPos, randomPos + 5);
      errors.push({
        type: "Style",
        original: randomWord,
        suggestion: randomWord + " [improved word choice]",
        position: [randomPos, randomPos + 5],
        severity: "minor"
      });
    }
    
    return errors;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-500";
      case "major": return "bg-yellow-500";
      case "minor": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const copyText = () => {
    navigator.clipboard.writeText(correctedText || text);
    toast.success("Text copied to clipboard");
  };

  const downloadText = () => {
    const blob = new Blob([correctedText || text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "corrected-text.txt";
    link.href = url;
    link.click();
    toast.success("Text downloaded successfully");
  };

  return (
    <ToolLayout 
      title="Grammar Checker"
      description="Check and correct grammar, spelling, and punctuation in your text"
      helpText="Paste your text to identify and fix grammar errors, spelling mistakes, and improve your writing."
    >
      <Alert className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>This is a demonstration tool</AlertTitle>
        <AlertDescription>
          In a production environment, this tool would integrate with a grammar checking API 
          for accurate results. This demo shows limited functionality with basic pattern matching.
        </AlertDescription>
      </Alert>
      
      <div className="space-y-6">
        <div className="flex justify-end">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en-US">English (US)</SelectItem>
              <SelectItem value="en-GB">English (UK)</SelectItem>
              <SelectItem value="en-AU">English (Australia)</SelectItem>
              <SelectItem value="en-CA">English (Canada)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="rounded-lg border shadow-sm">
          <Textarea
            placeholder="Enter or paste your text here to check for grammar errors..."
            className="min-h-[250px] p-4 text-base border-0 resize-y"
            value={text}
            onChange={handleTextChange}
          />
          <div className="p-3 bg-muted/20 border-t flex justify-between">
            <div>
              <Badge variant="secondary">
                {text.trim().split(/\s+/).filter(Boolean).length} words
              </Badge>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={checkGrammar}
                disabled={isChecking || text.trim().length < 5}
              >
                {isChecking ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> 
                    Checking...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 mr-2" /> 
                    Check Grammar
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
        
        {(errors.length > 0 || correctedText) && (
          <div className="space-y-6 border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">Correction Results</h3>
              {errors.length > 0 ? (
                <Badge variant="destructive">{errors.length} issues found</Badge>
              ) : (
                <Badge variant="secondary">No issues found</Badge>
              )}
            </div>
            
            {errors.length > 0 && (
              <div className="space-y-4">
                <h4 className="font-medium">Suggested Corrections:</h4>
                
                <div className="space-y-3 max-h-60 overflow-y-auto p-2">
                  {errors.map((error, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-muted/20 rounded-lg">
                      <div className={`w-3 h-3 rounded-full ${getSeverityColor(error.severity)}`}></div>
                      <div className="flex-1">
                        <div className="font-medium">{error.type}</div>
                        <div className="flex items-center gap-2">
                          <span className="text-red-500 line-through">{error.original}</span>
                          <span>→</span>
                          <span className="text-green-600">{error.suggestion}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {correctedText && (
              <div className="space-y-2">
                <h4 className="font-medium">Corrected Text:</h4>
                <div className="p-4 bg-muted/10 rounded-lg border">
                  {correctedText}
                </div>
                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" size="sm" onClick={copyText}>
                    <Copy className="h-4 w-4 mr-2" /> Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadText}>
                    <Save className="h-4 w-4 mr-2" /> Save
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter or paste your text in the editor above.</li>
            <li>Select your preferred English variant (US, UK, etc.).</li>
            <li>Click "Check Grammar" to analyze your text.</li>
            <li>Review the suggested corrections and corrected text.</li>
            <li>Copy or download the corrected version if needed.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">What types of errors does the grammar checker detect?</h3>
              <p className="text-muted-foreground">Our grammar checker detects spelling errors, grammar mistakes, punctuation issues, style improvements, and more. It helps ensure your writing is clear, effective, and error-free.</p>
            </div>
            <div>
              <h3 className="font-bold">What's the difference between US and UK English?</h3>
              <p className="text-muted-foreground">US and UK English differ in spelling (e.g., "color" vs "colour"), punctuation conventions, and certain vocabulary. Our tool adjusts its corrections based on your selected language variant.</p>
            </div>
            <div>
              <h3 className="font-bold">Is my text secure when using this grammar checker?</h3>
              <p className="text-muted-foreground">Yes, we prioritize your privacy. Your text is processed securely, not stored permanently, and never shared with third parties.</p>
            </div>
            <div>
              <h3 className="font-bold">How can I improve my writing beyond using a grammar checker?</h3>
              <p className="text-muted-foreground">While grammar checkers are useful tools, also consider reading your text aloud, asking for peer reviews, and studying style guides specific to your field or purpose.</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default GrammarChecker;
