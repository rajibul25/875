
import { useState, useRef, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Upload, Download, Code, RefreshCcw, Copy, Eye } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import AdBanner from "@/components/AdBanner";
import { useTheme } from "next-themes";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Default SVG to display when no file is uploaded
const DEFAULT_SVG = `<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg">
  <circle cx="50" cy="50" r="40" stroke="#3B82F6" stroke-width="3" fill="#93C5FD" />
  <text x="50" y="55" text-anchor="middle" font-family="Arial" font-size="14" fill="#1E3A8A">SVG</text>
</svg>`;

const SvgEditorComponent = () => {
  const [svgCode, setSvgCode] = useState<string>(DEFAULT_SVG);
  const [originalSvgCode, setOriginalSvgCode] = useState<string>(DEFAULT_SVG);
  const [fileName, setFileName] = useState<string>("example.svg");
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("edit");
  const [fillColor, setFillColor] = useState<string>("#93C5FD");
  const [strokeColor, setStrokeColor] = useState<string>("#3B82F6");
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const { theme } = useTheme();

  // Update preview when SVG code changes
  useEffect(() => {
    updatePreview();
  }, [svgCode, theme]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== "image/svg+xml") {
      toast.error("Please select a valid SVG file");
      return;
    }

    setFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = () => {
      const svgText = reader.result as string;
      setSvgCode(svgText);
      setOriginalSvgCode(svgText);
      
      // Reset the input value so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast.success("SVG file loaded successfully");
      
      // Extract colors from SVG
      extractColorsFromSvg(svgText);
    };
    reader.readAsText(file);
  };

  const extractColorsFromSvg = (svgText: string) => {
    // Simple regex to find fill and stroke attributes
    const fillMatch = svgText.match(/fill="(#[0-9A-Fa-f]{3,8})"/);
    const strokeMatch = svgText.match(/stroke="(#[0-9A-Fa-f]{3,8})"/);
    const strokeWidthMatch = svgText.match(/stroke-width="([0-9]+)"/);
    
    if (fillMatch && fillMatch[1]) {
      setFillColor(fillMatch[1]);
    }
    
    if (strokeMatch && strokeMatch[1]) {
      setStrokeColor(strokeMatch[1]);
    }
    
    if (strokeWidthMatch && strokeWidthMatch[1]) {
      setStrokeWidth(parseInt(strokeWidthMatch[1]));
    }
  };

  const updatePreview = () => {
    if (!previewRef.current) return;
    
    try {
      // Update the innerHTML with the current SVG code
      previewRef.current.innerHTML = svgCode;
      setPreviewError(null);
    } catch (error) {
      console.error("Error updating SVG preview:", error);
      setPreviewError("Invalid SVG code. Please check for syntax errors.");
    }
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSvgCode(e.target.value);
  };

  const updateSvgColors = () => {
    try {
      // Create a simple DOM parser to work with the SVG
      const parser = new DOMParser();
      const svgDoc = parser.parseFromString(svgCode, "image/svg+xml");
      
      // Apply fill color to all elements with fill attribute
      const elementsWithFill = svgDoc.querySelectorAll('[fill]:not([fill="none"])');
      elementsWithFill.forEach(el => {
        el.setAttribute("fill", fillColor);
      });
      
      // Apply stroke color to all elements with stroke attribute
      const elementsWithStroke = svgDoc.querySelectorAll('[stroke]:not([stroke="none"])');
      elementsWithStroke.forEach(el => {
        el.setAttribute("stroke", strokeColor);
        el.setAttribute("stroke-width", strokeWidth.toString());
      });
      
      // Convert back to string
      const serializer = new XMLSerializer();
      const updatedSvg = serializer.serializeToString(svgDoc);
      
      setSvgCode(updatedSvg);
      toast.success("SVG colors updated");
    } catch (error) {
      toast.error("Error updating SVG colors");
      console.error(error);
    }
  };

  const resetToOriginal = () => {
    setSvgCode(originalSvgCode);
    extractColorsFromSvg(originalSvgCode);
    toast.success("SVG reset to original");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(svgCode);
    toast.success("SVG code copied to clipboard");
  };

  const downloadSvg = () => {
    const blob = new Blob([svgCode], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("SVG file downloaded");
  };

  return (
    <ToolLayout
      title="Online SVG Editor"
      description="Edit and customize SVG files directly in your browser. Change colors, modify code, and download your edited SVG files."
      helpText="SVG (Scalable Vector Graphics) files are perfect for logos, icons, and illustrations that need to look crisp at any size. Use this tool to customize SVG files without specialized software."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload an SVG File</h2>
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
            <input
              ref={fileInputRef}
              type="file"
              accept=".svg,image/svg+xml"
              className="hidden"
              onChange={handleFileSelect}
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Upload className="h-5 w-5" />
              <span>Select SVG File</span>
            </Button>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Only SVG files (.svg) are supported.
            </p>
          </div>
        </div>

        <Tabs defaultValue="edit" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="edit" className="flex items-center">
              <Code className="h-4 w-4 mr-2" /> Edit Code
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center">
              <Eye className="h-4 w-4 mr-2" /> Preview
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="edit" className="mt-4 space-y-6">
            <div>
              <h3 className="text-md font-medium mb-2">SVG Code Editor</h3>
              <Textarea
                value={svgCode}
                onChange={handleCodeChange}
                className="h-64 font-mono text-sm"
                placeholder="Paste or edit SVG code here..."
              />
            </div>
            
            <div>
              <h3 className="text-md font-medium mb-3">Quick Color Editor</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="fill-color" className="block mb-1">Fill Color</Label>
                  <div className="flex">
                    <div 
                      className="w-10 h-10 rounded-l-md border-y border-l border-gray-300 dark:border-gray-600" 
                      style={{ backgroundColor: fillColor }}
                    />
                    <Input
                      id="fill-color"
                      type="text"
                      value={fillColor}
                      onChange={(e) => setFillColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="stroke-color" className="block mb-1">Stroke Color</Label>
                  <div className="flex">
                    <div 
                      className="w-10 h-10 rounded-l-md border-y border-l border-gray-300 dark:border-gray-600" 
                      style={{ backgroundColor: strokeColor }}
                    />
                    <Input
                      id="stroke-color"
                      type="text"
                      value={strokeColor}
                      onChange={(e) => setStrokeColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="stroke-width" className="block mb-1">Stroke Width</Label>
                  <Input
                    id="stroke-width"
                    type="number"
                    min="0"
                    step="0.5"
                    value={strokeWidth}
                    onChange={(e) => setStrokeWidth(parseFloat(e.target.value))}
                  />
                </div>
              </div>
              
              <div className="mt-4">
                <Button onClick={updateSvgColors}>Apply Color Changes</Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="preview" className="mt-4">
            <Card className="p-4">
              <div className="bg-white dark:bg-gray-800 rounded-md p-8 flex items-center justify-center min-h-[300px]">
                {previewError ? (
                  <div className="text-red-500">{previewError}</div>
                ) : (
                  <div ref={previewRef} className="svg-preview" dangerouslySetInnerHTML={{ __html: svgCode }} />
                )}
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            onClick={downloadSvg}
            variant="default"
            className="flex-1 flex items-center justify-center"
          >
            <Download className="h-5 w-5 mr-2" />
            Download SVG
          </Button>
          
          <Button
            onClick={copyToClipboard}
            variant="outline"
            className="flex-1 flex items-center justify-center"
          >
            <Copy className="h-5 w-5 mr-2" />
            Copy Code
          </Button>
          
          <Button
            onClick={resetToOriginal}
            variant="outline"
            className="flex-1 flex items-center justify-center"
          >
            <RefreshCcw className="h-5 w-5 mr-2" />
            Reset
          </Button>
        </div>

        <AdBanner />

        {/* FAQ Section for SEO */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">What is an SVG file?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                SVG (Scalable Vector Graphics) is an XML-based vector image format for two-dimensional graphics. 
                Unlike raster formats like PNG or JPEG, SVGs use mathematical equations to draw shapes, which allows 
                them to scale to any size without losing quality.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Why should I use SVG files?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                SVGs are ideal for logos, icons, and simple illustrations because they remain crisp and clear at any size. 
                They typically have smaller file sizes than raster images, can be styled with CSS, and can be animated. 
                SVGs are also fully accessible and SEO-friendly.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How do I edit colors in an SVG?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                You can edit SVG colors by changing the 'fill' and 'stroke' attributes in the SVG code. 
                Our editor provides a simple interface to modify these values without having to manually 
                edit the code. You can use color names like 'red' or HEX codes like '#FF0000'.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Can I add text or shapes to my SVG?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                Yes, you can add elements by editing the SVG code directly. For example, to add a text element, 
                you can insert code like: &lt;text x="50" y="50" font-family="Arial"&gt;Your Text&lt;/text&gt;. 
                For more complex edits, you might want to use a dedicated vector graphics editor.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg">How do I use my SVG in a website?</h3>
              <p className="text-gray-700 dark:text-gray-300">
                There are multiple ways to use SVGs in websites: you can embed them directly in your HTML using the &lt;svg&gt; element, 
                use them as images with the &lt;img&gt; tag, include them as CSS backgrounds, or embed them as data URLs. 
                Each method has different advantages depending on your needs for interactivity and styling.
              </p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

// Add error boundary
const SvgEditor = withErrorBoundary(SvgEditorComponent, "svg-editor");

export default SvgEditor;
