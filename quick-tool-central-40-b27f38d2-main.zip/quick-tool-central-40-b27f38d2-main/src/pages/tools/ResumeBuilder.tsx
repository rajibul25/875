
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Download, FileText, Eye, EyeOff, PlusCircle } from "lucide-react";
import { toast } from "sonner";
import ToolLayout from "@/components/tools/ToolLayout";

// Define resume templates
const TEMPLATES = [
  { id: "professional", name: "Professional" },
  { id: "modern", name: "Modern" },
  { id: "creative", name: "Creative" },
  { id: "minimalist", name: "Minimalist" },
  { id: "executive", name: "Executive" },
];

const ResumeBuilder = () => {
  // Personal information state
  const [personalInfo, setPersonalInfo] = useState({
    fullName: "",
    jobTitle: "",
    email: "",
    phone: "",
    address: "",
    website: "",
    summary: "",
  });

  // Experience state
  const [experiences, setExperiences] = useState([
    { 
      id: "exp-1", 
      company: "", 
      position: "", 
      startDate: "", 
      endDate: "", 
      current: false, 
      description: "" 
    }
  ]);

  // Education state
  const [education, setEducation] = useState([
    { 
      id: "edu-1", 
      institution: "", 
      degree: "", 
      field: "", 
      startDate: "", 
      endDate: "", 
      description: "" 
    }
  ]);

  // Skills state
  const [skills, setSkills] = useState([""]);

  // State for template
  const [selectedTemplate, setSelectedTemplate] = useState("professional");
  const [previewMode, setPreviewMode] = useState(false);

  // Handle personal info changes
  const handlePersonalInfoChange = (e) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({ ...prev, [name]: value }));
  };

  // Handle experience changes
  const handleExperienceChange = (id, field, value) => {
    setExperiences(prev => 
      prev.map(exp => exp.id === id ? { ...exp, [field]: value } : exp)
    );
  };

  // Add new experience
  const addExperience = () => {
    setExperiences(prev => [...prev, { 
      id: `exp-${Date.now()}`, 
      company: "", 
      position: "", 
      startDate: "", 
      endDate: "", 
      current: false, 
      description: "" 
    }]);
  };

  // Remove experience
  const removeExperience = (id) => {
    if (experiences.length > 1) {
      setExperiences(prev => prev.filter(exp => exp.id !== id));
    } else {
      toast.error("You must have at least one experience entry");
    }
  };

  // Handle education changes
  const handleEducationChange = (id, field, value) => {
    setEducation(prev => 
      prev.map(edu => edu.id === id ? { ...edu, [field]: value } : edu)
    );
  };

  // Add new education
  const addEducation = () => {
    setEducation(prev => [...prev, { 
      id: `edu-${Date.now()}`, 
      institution: "", 
      degree: "", 
      field: "", 
      startDate: "", 
      endDate: "", 
      description: "" 
    }]);
  };

  // Remove education
  const removeEducation = (id) => {
    if (education.length > 1) {
      setEducation(prev => prev.filter(edu => edu.id !== id));
    } else {
      toast.error("You must have at least one education entry");
    }
  };

  // Handle skill changes
  const handleSkillChange = (index, value) => {
    setSkills(prev => {
      const newSkills = [...prev];
      newSkills[index] = value;
      return newSkills;
    });
  };

  // Add new skill
  const addSkill = () => {
    setSkills(prev => [...prev, ""]);
  };

  // Remove skill
  const removeSkill = (index) => {
    if (skills.length > 1) {
      setSkills(prev => prev.filter((_, i) => i !== index));
    } else {
      toast.error("You must have at least one skill");
    }
  };

  // Generate PDF resume
  const generateResume = () => {
    // This would normally connect to a PDF generation library
    // For this example, we'll just show a success toast
    toast.success("Resume generated successfully! Download starting...");
    
    // In a real implementation, this would trigger the PDF download
    setTimeout(() => {
      toast.info("In a production environment, this would download a PDF file.");
    }, 1500);
  };

  // Toggle preview mode
  const togglePreviewMode = () => {
    setPreviewMode(!previewMode);
  };

  return (
    <ToolLayout
      title="Resume Builder"
      description="Create professional resumes with our easy-to-use builder"
      helpText="Fill in your details, choose a template, and generate a professional resume in minutes."
    >
      <Helmet>
        <title>Professional Resume Builder | Create & Download Free Resume Templates</title>
        <meta
          name="description"
          content="Build a professional resume in minutes with our free resume builder. Choose from modern templates, customize your content, and download your resume as a PDF."
        />
        <meta
          name="keywords"
          content="resume builder, CV maker, free resume templates, professional resume, job application, career, employment, resume download"
        />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "Resume Builder",
              "applicationCategory": "WebApplication",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "operatingSystem": "Any",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "243"
              }
            }
          `}
        </script>
      </Helmet>

      <div className="flex flex-col-reverse lg:flex-row gap-8">
        {!previewMode ? (
          <div className="w-full lg:w-2/3 space-y-6">
            <Tabs defaultValue="personal" className="w-full">
              <TabsList className="grid grid-cols-4 mb-4">
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="skills">Skills</TabsTrigger>
              </TabsList>

              {/* Personal Information Tab */}
              <TabsContent value="personal" className="space-y-4">
                <h2 className="text-xl font-bold">Personal Information</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      placeholder="John Doe"
                      value={personalInfo.fullName}
                      onChange={handlePersonalInfoChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="jobTitle">Job Title</Label>
                    <Input
                      id="jobTitle"
                      name="jobTitle"
                      placeholder="Software Engineer"
                      value={personalInfo.jobTitle}
                      onChange={handlePersonalInfoChange}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="john.doe@example.com"
                      value={personalInfo.email}
                      onChange={handlePersonalInfoChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="(123) 456-7890"
                      value={personalInfo.phone}
                      onChange={handlePersonalInfoChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    name="address"
                    placeholder="123 Main St, City, Country"
                    value={personalInfo.address}
                    onChange={handlePersonalInfoChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="website">Website/LinkedIn (optional)</Label>
                  <Input
                    id="website"
                    name="website"
                    placeholder="https://linkedin.com/in/johndoe"
                    value={personalInfo.website}
                    onChange={handlePersonalInfoChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary">Professional Summary</Label>
                  <Textarea
                    id="summary"
                    name="summary"
                    placeholder="Brief overview of your skills and professional background"
                    rows={4}
                    value={personalInfo.summary}
                    onChange={handlePersonalInfoChange}
                  />
                </div>
              </TabsContent>

              {/* Experience Tab */}
              <TabsContent value="experience" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Work Experience</h2>
                  <Button onClick={addExperience} size="sm" className="flex items-center gap-1">
                    <Plus className="h-4 w-4" />
                    Add Experience
                  </Button>
                </div>

                {experiences.map((exp, index) => (
                  <Card key={exp.id} className="mb-4">
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="text-lg font-medium">Experience {index + 1}</h3>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => removeExperience(exp.id)}
                          disabled={experiences.length === 1}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor={`company-${exp.id}`}>Company</Label>
                          <Input
                            id={`company-${exp.id}`}
                            placeholder="Company Name"
                            value={exp.company}
                            onChange={(e) => handleExperienceChange(exp.id, "company", e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`position-${exp.id}`}>Position</Label>
                          <Input
                            id={`position-${exp.id}`}
                            placeholder="Job Title"
                            value={exp.position}
                            onChange={(e) => handleExperienceChange(exp.id, "position", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor={`exp-start-${exp.id}`}>Start Date</Label>
                          <Input
                            id={`exp-start-${exp.id}`}
                            placeholder="MM/YYYY"
                            value={exp.startDate}
                            onChange={(e) => handleExperienceChange(exp.id, "startDate", e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`exp-end-${exp.id}`}>End Date</Label>
                          <Input
                            id={`exp-end-${exp.id}`}
                            placeholder="MM/YYYY or Present"
                            value={exp.endDate}
                            onChange={(e) => handleExperienceChange(exp.id, "endDate", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`exp-desc-${exp.id}`}>Description</Label>
                        <Textarea
                          id={`exp-desc-${exp.id}`}
                          placeholder="Describe your responsibilities and achievements"
                          rows={3}
                          value={exp.description}
                          onChange={(e) => handleExperienceChange(exp.id, "description", e.target.value)}
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Education Tab */}
              <TabsContent value="education" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Education</h2>
                  <Button onClick={addEducation} size="sm" className="flex items-center gap-1">
                    <Plus className="h-4 w-4" />
                    Add Education
                  </Button>
                </div>

                {education.map((edu, index) => (
                  <Card key={edu.id} className="mb-4">
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="text-lg font-medium">Education {index + 1}</h3>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => removeEducation(edu.id)}
                          disabled={education.length === 1}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor={`institution-${edu.id}`}>Institution</Label>
                          <Input
                            id={`institution-${edu.id}`}
                            placeholder="University/School Name"
                            value={edu.institution}
                            onChange={(e) => handleEducationChange(edu.id, "institution", e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`degree-${edu.id}`}>Degree</Label>
                          <Input
                            id={`degree-${edu.id}`}
                            placeholder="Bachelor's, Master's, etc."
                            value={edu.degree}
                            onChange={(e) => handleEducationChange(edu.id, "degree", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor={`field-${edu.id}`}>Field of Study</Label>
                          <Input
                            id={`field-${edu.id}`}
                            placeholder="Computer Science, Business, etc."
                            value={edu.field}
                            onChange={(e) => handleEducationChange(edu.id, "field", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor={`edu-start-${edu.id}`}>Start Date</Label>
                          <Input
                            id={`edu-start-${edu.id}`}
                            placeholder="MM/YYYY"
                            value={edu.startDate}
                            onChange={(e) => handleEducationChange(edu.id, "startDate", e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`edu-end-${edu.id}`}>End Date</Label>
                          <Input
                            id={`edu-end-${edu.id}`}
                            placeholder="MM/YYYY or Present"
                            value={edu.endDate}
                            onChange={(e) => handleEducationChange(edu.id, "endDate", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`edu-desc-${edu.id}`}>Description (optional)</Label>
                        <Textarea
                          id={`edu-desc-${edu.id}`}
                          placeholder="Notable achievements, GPA, relevant coursework"
                          rows={2}
                          value={edu.description}
                          onChange={(e) => handleEducationChange(edu.id, "description", e.target.value)}
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Skills Tab */}
              <TabsContent value="skills" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Skills</h2>
                  <Button onClick={addSkill} size="sm" className="flex items-center gap-1">
                    <Plus className="h-4 w-4" />
                    Add Skill
                  </Button>
                </div>

                <div className="space-y-4">
                  {skills.map((skill, index) => (
                    <div key={index} className="flex gap-2 items-center">
                      <Input
                        placeholder="e.g., JavaScript, Project Management, Customer Service"
                        value={skill}
                        onChange={(e) => handleSkillChange(index, e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={() => removeSkill(index)}
                        disabled={skills.length === 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="w-full lg:w-2/3 bg-white border rounded-lg p-8 shadow-lg">
            <div className={`resume-preview resume-${selectedTemplate}`}>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold">{personalInfo.fullName || "Your Name"}</h1>
                <p className="text-gray-600">{personalInfo.jobTitle || "Your Job Title"}</p>
                <div className="flex justify-center gap-4 text-sm mt-2">
                  {personalInfo.email && <span>{personalInfo.email}</span>}
                  {personalInfo.phone && <span>• {personalInfo.phone}</span>}
                </div>
                {(personalInfo.address || personalInfo.website) && (
                  <div className="flex justify-center gap-4 text-sm mt-1">
                    {personalInfo.address && <span>{personalInfo.address}</span>}
                    {personalInfo.website && <span>• {personalInfo.website}</span>}
                  </div>
                )}
              </div>

              {personalInfo.summary && (
                <div className="mb-6">
                  <h2 className="text-lg font-semibold border-b pb-1 mb-2">Professional Summary</h2>
                  <p className="text-sm">{personalInfo.summary}</p>
                </div>
              )}

              <div className="mb-6">
                <h2 className="text-lg font-semibold border-b pb-1 mb-2">Experience</h2>
                {experiences.map((exp, index) => (
                  <div key={exp.id} className="mb-4">
                    <div className="flex justify-between">
                      <h3 className="font-medium">{exp.position || "Position"}</h3>
                      <span className="text-sm text-gray-600">
                        {exp.startDate || "Start Date"} - {exp.endDate || "End Date"}
                      </span>
                    </div>
                    <p className="text-gray-700">{exp.company || "Company"}</p>
                    <p className="text-sm mt-1">{exp.description || "Job description"}</p>
                  </div>
                ))}
              </div>

              <div className="mb-6">
                <h2 className="text-lg font-semibold border-b pb-1 mb-2">Education</h2>
                {education.map((edu, index) => (
                  <div key={edu.id} className="mb-4">
                    <div className="flex justify-between">
                      <h3 className="font-medium">{edu.degree || "Degree"} in {edu.field || "Field"}</h3>
                      <span className="text-sm text-gray-600">
                        {edu.startDate || "Start Date"} - {edu.endDate || "End Date"}
                      </span>
                    </div>
                    <p className="text-gray-700">{edu.institution || "Institution"}</p>
                    {edu.description && <p className="text-sm mt-1">{edu.description}</p>}
                  </div>
                ))}
              </div>

              <div>
                <h2 className="text-lg font-semibold border-b pb-1 mb-2">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill, index) => (
                    skill && <span key={index} className="bg-gray-100 px-2 py-1 rounded text-sm">{skill}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="w-full lg:w-1/3">
          <div className="sticky top-6 space-y-6">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-xl font-semibold mb-4">Template</h2>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="template">Select Template</Label>
                    <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                      <SelectTrigger id="template">
                        <SelectValue placeholder="Choose a template" />
                      </SelectTrigger>
                      <SelectContent>
                        {TEMPLATES.map(template => (
                          <SelectItem key={template.id} value={template.id}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col gap-3">
              <Button onClick={togglePreviewMode} variant="outline" className="w-full flex items-center gap-2">
                {previewMode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {previewMode ? "Edit Resume" : "Preview Resume"}
              </Button>
              
              <Button onClick={generateResume} className="w-full flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download Resume
              </Button>
            </div>

            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 mb-2 flex items-center">
                <FileText className="h-4 w-4 mr-2" />
                Resume Tips
              </h3>
              <ul className="text-sm text-blue-700 space-y-2 list-disc pl-5">
                <li>Keep your resume to one page for most positions</li>
                <li>Use action verbs to describe your responsibilities</li>
                <li>Quantify your achievements where possible</li>
                <li>Tailor your resume to each job application</li>
                <li>Proofread carefully for spelling and grammar</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Separator className="my-8" />

      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h3 className="font-semibold">What format will my resume be downloaded in?</h3>
            <p className="text-gray-600">Your resume will be available to download as a PDF, which is the most widely accepted format for job applications.</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Can I save my resume and edit it later?</h3>
            <p className="text-gray-600">Currently, this tool doesn't support saving drafts. We recommend completing your resume in one session.</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">How should I list my skills?</h3>
            <p className="text-gray-600">Include skills relevant to the job you're applying for. A mix of technical, soft, and industry-specific skills is ideal.</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Which template should I choose?</h3>
            <p className="text-gray-600">Select a template that matches the industry and company culture. Conservative fields prefer traditional designs, while creative industries may appreciate modern designs.</p>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Related Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <a href="/tools/cover-letter-generator" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Cover Letter Generator</h3>
              <p className="text-sm text-gray-500">Create matching cover letters for your resume</p>
            </div>
          </a>
          <a href="/tools/invoice-generator" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Invoice Generator</h3>
              <p className="text-sm text-gray-500">Create professional invoices</p>
            </div>
          </a>
          <a href="/tools/business-card-maker" className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <div className="ml-3">
              <h3 className="font-medium">Business Card Maker</h3>
              <p className="text-sm text-gray-500">Design custom business cards</p>
            </div>
          </a>
        </div>
      </div>
    </ToolLayout>
  );
};

export default ResumeBuilder;
