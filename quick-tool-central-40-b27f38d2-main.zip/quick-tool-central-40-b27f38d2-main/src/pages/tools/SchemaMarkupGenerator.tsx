
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Copy, Download, AlertCircle, Code } from "lucide-react";
import { toast } from "sonner";
import AdBanner from "@/components/AdBanner";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

type SchemaType = 
  | "Article" 
  | "Product" 
  | "LocalBusiness" 
  | "FAQPage" 
  | "Event" 
  | "Recipe"
  | "Review"
  | "Person"
  | "Organization"
  | "BreadcrumbList";

interface FieldDefinition {
  name: string;
  label: string;
  type: "text" | "textarea" | "number" | "url" | "date";
  required?: boolean;
  description?: string;
  placeholder?: string;
}

// Define schema types and their fields
const schemaTypeDefinitions: Record<SchemaType, FieldDefinition[]> = {
  Article: [
    { name: "headline", label: "Headline", type: "text", required: true, placeholder: "Article Title" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Brief description of the article" },
    { name: "author", label: "Author Name", type: "text", placeholder: "Author's full name" },
    { name: "publishDate", label: "Publish Date", type: "date" },
    { name: "imageUrl", label: "Image URL", type: "url", placeholder: "https://example.com/image.jpg" },
    { name: "articleUrl", label: "Article URL", type: "url", placeholder: "https://example.com/article" }
  ],
  Product: [
    { name: "name", label: "Product Name", type: "text", required: true, placeholder: "Product Name" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Product description" },
    { name: "price", label: "Price", type: "number", placeholder: "29.99" },
    { name: "currency", label: "Currency", type: "text", placeholder: "USD" },
    { name: "imageUrl", label: "Image URL", type: "url", placeholder: "https://example.com/product.jpg" },
    { name: "availability", label: "Availability", type: "text", placeholder: "InStock" },
    { name: "ratingValue", label: "Rating Value", type: "number", placeholder: "4.5" },
    { name: "reviewCount", label: "Review Count", type: "number", placeholder: "89" }
  ],
  LocalBusiness: [
    { name: "name", label: "Business Name", type: "text", required: true, placeholder: "Business Name" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Business description" },
    { name: "address", label: "Street Address", type: "text", placeholder: "123 Main St" },
    { name: "city", label: "City", type: "text", placeholder: "New York" },
    { name: "state", label: "State", type: "text", placeholder: "NY" },
    { name: "postalCode", label: "Postal Code", type: "text", placeholder: "10001" },
    { name: "country", label: "Country", type: "text", placeholder: "USA" },
    { name: "telephone", label: "Telephone", type: "text", placeholder: "+1-212-555-0123" },
    { name: "websiteUrl", label: "Website URL", type: "url", placeholder: "https://example.com" }
  ],
  FAQPage: [
    { name: "question1", label: "Question 1", type: "text", required: true, placeholder: "Frequently asked question" },
    { name: "answer1", label: "Answer 1", type: "textarea", required: true, placeholder: "Answer to the question" },
    { name: "question2", label: "Question 2", type: "text", placeholder: "Another frequently asked question" },
    { name: "answer2", label: "Answer 2", type: "textarea", placeholder: "Answer to the second question" },
    { name: "question3", label: "Question 3", type: "text", placeholder: "One more frequently asked question" },
    { name: "answer3", label: "Answer 3", type: "textarea", placeholder: "Answer to the third question" }
  ],
  Event: [
    { name: "name", label: "Event Name", type: "text", required: true, placeholder: "Event Name" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Event description" },
    { name: "startDate", label: "Start Date", type: "date", required: true },
    { name: "endDate", label: "End Date", type: "date" },
    { name: "location", label: "Location Name", type: "text", placeholder: "Event Venue Name" },
    { name: "address", label: "Street Address", type: "text", placeholder: "123 Main St" },
    { name: "city", label: "City", type: "text", placeholder: "New York" },
    { name: "imageUrl", label: "Image URL", type: "url", placeholder: "https://example.com/event.jpg" },
    { name: "eventUrl", label: "Event URL", type: "url", placeholder: "https://example.com/event" }
  ],
  Recipe: [
    { name: "name", label: "Recipe Name", type: "text", required: true, placeholder: "Recipe Name" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Brief recipe description" },
    { name: "author", label: "Author", type: "text", placeholder: "Recipe author" },
    { name: "prepTime", label: "Prep Time (mins)", type: "number", placeholder: "20" },
    { name: "cookTime", label: "Cook Time (mins)", type: "number", placeholder: "30" },
    { name: "ingredients", label: "Ingredients", type: "textarea", placeholder: "One ingredient per line" },
    { name: "instructions", label: "Instructions", type: "textarea", placeholder: "Step-by-step cooking instructions" },
    { name: "imageUrl", label: "Image URL", type: "url", placeholder: "https://example.com/recipe.jpg" }
  ],
  Review: [
    { name: "itemName", label: "Reviewed Item Name", type: "text", required: true, placeholder: "Product or Service Name" },
    { name: "reviewRating", label: "Rating", type: "number", required: true, placeholder: "5" },
    { name: "reviewBody", label: "Review Text", type: "textarea", placeholder: "Detailed review content" },
    { name: "author", label: "Author Name", type: "text", placeholder: "Reviewer's name" },
    { name: "publishDate", label: "Date Published", type: "date" }
  ],
  Person: [
    { name: "name", label: "Full Name", type: "text", required: true, placeholder: "John Doe" },
    { name: "jobTitle", label: "Job Title", type: "text", placeholder: "Software Engineer" },
    { name: "worksFor", label: "Company", type: "text", placeholder: "Google" },
    { name: "url", label: "Website", type: "url", placeholder: "https://johndoe.com" },
    { name: "imageUrl", label: "Image URL", type: "url", placeholder: "https://example.com/johndoe.jpg" },
    { name: "description", label: "Biography", type: "textarea", placeholder: "Short biography" }
  ],
  Organization: [
    { name: "name", label: "Organization Name", type: "text", required: true, placeholder: "Company Name" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Company description" },
    { name: "url", label: "Website", type: "url", placeholder: "https://example.com" },
    { name: "logoUrl", label: "Logo URL", type: "url", placeholder: "https://example.com/logo.png" },
    { name: "contactPoint", label: "Contact Phone", type: "text", placeholder: "+1-212-555-0123" },
    { name: "email", label: "Email", type: "text", placeholder: "contact@example.com" },
    { name: "address", label: "Address", type: "text", placeholder: "123 Main St, New York, NY 10001" }
  ],
  BreadcrumbList: [
    { name: "name1", label: "Page 1 Name", type: "text", required: true, placeholder: "Home" },
    { name: "url1", label: "Page 1 URL", type: "url", required: true, placeholder: "https://example.com" },
    { name: "name2", label: "Page 2 Name", type: "text", placeholder: "Products" },
    { name: "url2", label: "Page 2 URL", type: "url", placeholder: "https://example.com/products" },
    { name: "name3", label: "Page 3 Name", type: "text", placeholder: "Product Category" },
    { name: "url3", label: "Page 3 URL", type: "url", placeholder: "https://example.com/products/category" },
    { name: "name4", label: "Current Page Name", type: "text", placeholder: "Product Name" },
    { name: "url4", label: "Current Page URL", type: "url", placeholder: "https://example.com/products/category/product" }
  ]
};

const SchemaMarkupGenerator = () => {
  const [schemaType, setSchemaType] = useState<SchemaType>("Article");
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [schemaJSON, setSchemaJSON] = useState<string>("");
  const [schemaHTML, setSchemaHTML] = useState<string>("");
  const [error, setError] = useState("");

  // Reset form when schema type changes
  React.useEffect(() => {
    setFormData({});
    setSchemaJSON("");
    setSchemaHTML("");
    setError("");
  }, [schemaType]);

  const handleInputChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const generateSchema = () => {
    try {
      setError("");
      
      // Validate required fields
      const requiredFields = schemaTypeDefinitions[schemaType]
        .filter(field => field.required)
        .map(field => field.name);
      
      const missingFields = requiredFields.filter(field => !formData[field]);
      
      if (missingFields.length > 0) {
        setError(`Please fill in all required fields: ${missingFields.map(field => {
          const fieldDef = schemaTypeDefinitions[schemaType].find(f => f.name === field);
          return fieldDef?.label || field;
        }).join(", ")}`);
        return;
      }

      // Generate schema based on schema type
      let schema: any = {
        "@context": "https://schema.org"
      };

      switch (schemaType) {
        case "Article":
          schema["@type"] = "Article";
          schema.headline = formData.headline;
          if (formData.description) schema.description = formData.description;
          if (formData.author) schema.author = { "@type": "Person", name: formData.author };
          if (formData.publishDate) schema.datePublished = formData.publishDate;
          if (formData.imageUrl) schema.image = formData.imageUrl;
          if (formData.articleUrl) schema.url = formData.articleUrl;
          break;

        case "Product":
          schema["@type"] = "Product";
          schema.name = formData.name;
          if (formData.description) schema.description = formData.description;
          if (formData.imageUrl) schema.image = formData.imageUrl;
          
          // Add offers if price is provided
          if (formData.price) {
            schema.offers = {
              "@type": "Offer",
              price: formData.price,
              priceCurrency: formData.currency || "USD"
            };
            
            if (formData.availability) {
              schema.offers.availability = `https://schema.org/${formData.availability}`;
            }
          }
          
          // Add aggregate rating if rating value is provided
          if (formData.ratingValue) {
            schema.aggregateRating = {
              "@type": "AggregateRating",
              ratingValue: formData.ratingValue,
              reviewCount: formData.reviewCount || "1"
            };
          }
          break;

        case "LocalBusiness":
          schema["@type"] = "LocalBusiness";
          schema.name = formData.name;
          if (formData.description) schema.description = formData.description;
          
          // Add address information
          if (formData.address || formData.city || formData.state || formData.postalCode || formData.country) {
            schema.address = {
              "@type": "PostalAddress"
            };
            
            if (formData.address) schema.address.streetAddress = formData.address;
            if (formData.city) schema.address.addressLocality = formData.city;
            if (formData.state) schema.address.addressRegion = formData.state;
            if (formData.postalCode) schema.address.postalCode = formData.postalCode;
            if (formData.country) schema.address.addressCountry = formData.country;
          }
          
          if (formData.telephone) schema.telephone = formData.telephone;
          if (formData.websiteUrl) schema.url = formData.websiteUrl;
          break;

        case "FAQPage":
          schema["@type"] = "FAQPage";
          
          const mainEntity = [];
          
          // Add FAQ questions and answers
          for (let i = 1; i <= 3; i++) {
            const question = formData[`question${i}`];
            const answer = formData[`answer${i}`];
            
            if (question && answer) {
              mainEntity.push({
                "@type": "Question",
                name: question,
                acceptedAnswer: {
                  "@type": "Answer",
                  text: answer
                }
              });
            }
          }
          
          schema.mainEntity = mainEntity;
          break;

        case "Event":
          schema["@type"] = "Event";
          schema.name = formData.name;
          if (formData.description) schema.description = formData.description;
          schema.startDate = formData.startDate;
          if (formData.endDate) schema.endDate = formData.endDate;
          
          // Add location information
          if (formData.location || formData.address || formData.city) {
            schema.location = {
              "@type": "Place",
              name: formData.location || ""
            };
            
            if (formData.address || formData.city) {
              schema.location.address = {
                "@type": "PostalAddress"
              };
              
              if (formData.address) schema.location.address.streetAddress = formData.address;
              if (formData.city) schema.location.address.addressLocality = formData.city;
            }
          }
          
          if (formData.imageUrl) schema.image = formData.imageUrl;
          if (formData.eventUrl) schema.url = formData.eventUrl;
          break;

        case "Recipe":
          schema["@type"] = "Recipe";
          schema.name = formData.name;
          if (formData.description) schema.description = formData.description;
          if (formData.author) schema.author = { "@type": "Person", name: formData.author };
          
          // Add time information
          if (formData.prepTime) schema.prepTime = `PT${formData.prepTime}M`;
          if (formData.cookTime) schema.cookTime = `PT${formData.cookTime}M`;
          
          // Add ingredients
          if (formData.ingredients) {
            schema.recipeIngredient = formData.ingredients
              .split("\n")
              .map(item => item.trim())
              .filter(item => item.length > 0);
          }
          
          // Add instructions
          if (formData.instructions) {
            schema.recipeInstructions = formData.instructions
              .split("\n")
              .map(item => item.trim())
              .filter(item => item.length > 0)
              .map(step => ({
                "@type": "HowToStep",
                text: step
              }));
          }
          
          if (formData.imageUrl) schema.image = formData.imageUrl;
          break;

        case "Review":
          schema["@type"] = "Review";
          schema.itemReviewed = {
            "@type": "Thing",
            name: formData.itemName
          };
          
          schema.reviewRating = {
            "@type": "Rating",
            ratingValue: formData.reviewRating
          };
          
          if (formData.reviewBody) schema.reviewBody = formData.reviewBody;
          if (formData.author) schema.author = { "@type": "Person", name: formData.author };
          if (formData.publishDate) schema.datePublished = formData.publishDate;
          break;

        case "Person":
          schema["@type"] = "Person";
          schema.name = formData.name;
          if (formData.jobTitle) schema.jobTitle = formData.jobTitle;
          if (formData.worksFor) schema.worksFor = { "@type": "Organization", name: formData.worksFor };
          if (formData.url) schema.url = formData.url;
          if (formData.imageUrl) schema.image = formData.imageUrl;
          if (formData.description) schema.description = formData.description;
          break;

        case "Organization":
          schema["@type"] = "Organization";
          schema.name = formData.name;
          if (formData.description) schema.description = formData.description;
          if (formData.url) schema.url = formData.url;
          if (formData.logoUrl) schema.logo = formData.logoUrl;
          
          // Add contact point
          if (formData.contactPoint || formData.email) {
            schema.contactPoint = {
              "@type": "ContactPoint",
              contactType: "customer service"
            };
            
            if (formData.contactPoint) schema.contactPoint.telephone = formData.contactPoint;
            if (formData.email) schema.contactPoint.email = formData.email;
          }
          
          if (formData.address) {
            schema.address = {
              "@type": "PostalAddress",
              streetAddress: formData.address
            };
          }
          break;

        case "BreadcrumbList":
          schema["@type"] = "BreadcrumbList";
          
          const itemListElement = [];
          
          // Add breadcrumb items
          for (let i = 1; i <= 4; i++) {
            const name = formData[`name${i}`];
            const url = formData[`url${i}`];
            
            if (name && url) {
              itemListElement.push({
                "@type": "ListItem",
                position: i,
                name: name,
                item: url
              });
            }
          }
          
          schema.itemListElement = itemListElement;
          break;
      }

      // Generate JSON and HTML
      const json = JSON.stringify(schema, null, 2);
      const html = `<script type="application/ld+json">\n${json}\n</script>`;
      
      setSchemaJSON(json);
      setSchemaHTML(html);
    } catch (err) {
      console.error(err);
      setError("Error generating schema. Please check your input and try again.");
    }
  };

  const copyToClipboard = (type: "json" | "html") => {
    const textToCopy = type === "json" ? schemaJSON : schemaHTML;
    
    navigator.clipboard.writeText(textToCopy);
    toast.success(`Schema ${type.toUpperCase()} copied to clipboard!`);
  };

  const downloadSchema = (type: "json" | "html") => {
    const textToDownload = type === "json" ? schemaJSON : schemaHTML;
    const fileExtension = type === "json" ? "json" : "html";
    const fileName = `schema-${schemaType.toLowerCase()}.${fileExtension}`;
    
    const blob = new Blob([textToDownload], { type: type === "json" ? "application/json" : "text/html" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success(`Schema ${type.toUpperCase()} downloaded!`);
  };

  return (
    <ToolLayout
      title="Schema Markup Generator"
      description="Create structured data markup for better search visibility"
      helpText="Generate JSON-LD structured data for your website to help search engines understand your content and possibly display rich results in search."
    >
      <div className="space-y-6">
        <Tabs defaultValue="generator" className="w-full">
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="generator">Schema Generator</TabsTrigger>
          </TabsList>
          
          <TabsContent value="generator" className="space-y-6 mt-4">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div>
                  <Label htmlFor="schemaType" className="block mb-2">Schema Type</Label>
                  <Select
                    value={schemaType}
                    onValueChange={(value) => setSchemaType(value as SchemaType)}
                  >
                    <SelectTrigger id="schemaType" className="w-full">
                      <SelectValue placeholder="Select Schema Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Article">Article</SelectItem>
                      <SelectItem value="Product">Product</SelectItem>
                      <SelectItem value="LocalBusiness">Local Business</SelectItem>
                      <SelectItem value="FAQPage">FAQ Page</SelectItem>
                      <SelectItem value="Event">Event</SelectItem>
                      <SelectItem value="Recipe">Recipe</SelectItem>
                      <SelectItem value="Review">Review</SelectItem>
                      <SelectItem value="Person">Person</SelectItem>
                      <SelectItem value="Organization">Organization</SelectItem>
                      <SelectItem value="BreadcrumbList">Breadcrumb</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-4 mt-4">
                  <h3 className="text-lg font-medium">Schema Properties</h3>
                  
                  {schemaTypeDefinitions[schemaType].map((field) => (
                    <div key={field.name} className="space-y-2">
                      <Label htmlFor={field.name} className="block">
                        {field.label} {field.required && <span className="text-red-500">*</span>}
                      </Label>
                      
                      {field.type === "textarea" ? (
                        <Textarea
                          id={field.name}
                          value={formData[field.name] || ""}
                          onChange={(e) => handleInputChange(field.name, e.target.value)}
                          placeholder={field.placeholder}
                          rows={3}
                        />
                      ) : (
                        <Input
                          id={field.name}
                          type={field.type}
                          value={formData[field.name] || ""}
                          onChange={(e) => handleInputChange(field.name, e.target.value)}
                          placeholder={field.placeholder}
                        />
                      )}
                      
                      {field.description && (
                        <p className="text-xs text-muted-foreground">{field.description}</p>
                      )}
                    </div>
                  ))}
                </div>
                
                <Button className="w-full mt-4" onClick={generateSchema}>
                  <Code className="mr-2 h-4 w-4" />
                  Generate Schema
                </Button>
                
                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-3 rounded-md flex items-center">
                    <AlertCircle size={16} className="mr-2 flex-shrink-0" />
                    <p className="text-sm">{error}</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <AdBanner className="my-4" />
            
            {schemaJSON && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Generated Schema</h3>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={() => copyToClipboard("json")}>
                      <Copy className="h-4 w-4 mr-1" />
                      Copy JSON
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => copyToClipboard("html")}>
                      <Copy className="h-4 w-4 mr-1" />
                      Copy HTML
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => downloadSchema("json")}>
                      <Download className="h-4 w-4 mr-1" />
                      Download JSON
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                <Tabs defaultValue="json">
                  <TabsList>
                    <TabsTrigger value="json">JSON-LD</TabsTrigger>
                    <TabsTrigger value="html">HTML</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="json" className="mt-4">
                    <div className="relative bg-slate-950 text-slate-50 rounded-md overflow-hidden">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="absolute top-2 right-2 h-8 w-8 p-0"
                        onClick={() => copyToClipboard("json")}
                      >
                        <Copy className="h-4 w-4" />
                        <span className="sr-only">Copy</span>
                      </Button>
                      <pre className="p-4 overflow-x-auto text-sm">
                        {schemaJSON}
                      </pre>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="html" className="mt-4">
                    <div className="relative bg-slate-950 text-slate-50 rounded-md overflow-hidden">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="absolute top-2 right-2 h-8 w-8 p-0"
                        onClick={() => copyToClipboard("html")}
                      >
                        <Copy className="h-4 w-4" />
                        <span className="sr-only">Copy</span>
                      </Button>
                      <pre className="p-4 overflow-x-auto text-sm">
                        {schemaHTML}
                      </pre>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
                  <h4 className="font-medium mb-2">Implementation Instructions</h4>
                  <ol className="text-sm space-y-1 list-decimal pl-5">
                    <li>Copy the HTML code above.</li>
                    <li>Paste it in the <code className="bg-blue-100 dark:bg-blue-800 px-1 rounded text-xs">&lt;head&gt;</code> section of your webpage.</li>
                    <li>Test your implementation with <a href="https://validator.schema.org/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Schema.org Validator</a> or <a href="https://search.google.com/test/rich-results" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Google's Rich Results Test</a>.</li>
                  </ol>
                </div>
                
                <AdBanner className="my-4" />
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </ToolLayout>
  );
};

export default SchemaMarkupGenerator;
