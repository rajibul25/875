import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calculator } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Helmet } from "react-helmet";

const LoanCalculatorComponent = () => {
  const [loanAmount, setLoanAmount] = useState<string>("100000");
  const [interestRate, setInterestRate] = useState<string>("8");
  const [loanTerm, setLoanTerm] = useState<string>("5");
  const [result, setResult] = useState<{
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
  } | null>(null);
  
  const calculateLoan = () => {
    const amount = parseFloat(loanAmount);
    const rate = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const term = parseInt(loanTerm) * 12; // Term in months
    
    if (isNaN(amount) || isNaN(rate) || isNaN(term)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (amount <= 0 || rate <= 0 || term <= 0) {
      toast.error("All values must be greater than zero");
      return;
    }
    
    // Calculate monthly payment
    const x = Math.pow(1 + rate, term);
    const monthlyPayment = (amount * x * rate) / (x - 1);
    
    // Calculate total payment and interest
    const totalPayment = monthlyPayment * term;
    const totalInterest = totalPayment - amount;
    
    setResult({
      monthlyPayment,
      totalPayment,
      totalInterest
    });
    
    toast.success("Loan calculation complete!");
  };
  
  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
    });
  };
  
  const generateSchemaMarkup = () => {
    if (!result) return null;
    
    const schema = {
      "@context": "https://schema.org",
      "@type": "FinancialProduct",
      "name": "Loan Calculator",
      "description": "Calculate loan EMI, total payment, and total interest for your loans",
      "feesAndCommissionsSpecification": "Calculate monthly installment for a loan of " + loanAmount + " at " + interestRate + "% for " + loanTerm + " years",
      "amount": {
        "@type": "MonetaryAmount",
        "currency": "USD",
        "value": loanAmount
      }
    };
    
    return (
      <script type="application/ld+json">
        {JSON.stringify(schema)}
      </script>
    );
  };
  
  return (
    <>
      <Helmet>
        <title>Loan EMI Calculator | Calculate Monthly Payments, Interest & More</title>
        <meta name="description" content="Free online loan EMI calculator. Calculate monthly loan payments, total interest, and full loan costs instantly with our easy-to-use calculator tool." />
        <meta name="keywords" content="loan calculator, EMI calculator, monthly payment calculator, loan interest, mortgage payments, personal loan, auto loan calculator" />
        <link rel="canonical" href="https://multitoolset.co/tools/loan-calculator" />
        <meta property="og:title" content="Loan EMI Calculator | Calculate Monthly Payments" />
        <meta property="og:description" content="Calculate your exact monthly loan payments, total interest costs, and payment breakdowns with our free online loan calculator." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://multitoolset.co/tools/loan-calculator" />
        {generateSchemaMarkup()}
      </Helmet>
      <ToolLayout
        title="Loan EMI Calculator"
        description="Calculate loan EMI, total payment, and total interest for your loans"
        helpText="Enter loan details to calculate EMI and other payment information"
      >
        <div className="space-y-6 max-w-3xl mx-auto">
          <Card>
            <CardContent className="pt-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label htmlFor="loanAmount" className="block text-sm font-medium text-gray-700">
                    Loan Amount
                  </label>
                  <Input
                    id="loanAmount"
                    type="number"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    placeholder="Enter loan amount"
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700">
                    Interest Rate (% per annum)
                  </label>
                  <Input
                    id="interestRate"
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    placeholder="Enter interest rate"
                    className="w-full"
                    step="0.01"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="loanTerm" className="block text-sm font-medium text-gray-700">
                    Loan Term (years)
                  </label>
                  <Input
                    id="loanTerm"
                    type="number"
                    value={loanTerm}
                    onChange={(e) => setLoanTerm(e.target.value)}
                    placeholder="Enter loan term in years"
                    className="w-full"
                  />
                </div>
              </div>
              
              <Button 
                onClick={calculateLoan}
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={!loanAmount || !interestRate || !loanTerm}
              >
                <Calculator className="mr-2 h-4 w-4" /> Calculate EMI
              </Button>
            </CardContent>
          </Card>
          
          {result && (
            <Card className="overflow-hidden">
              <CardContent className="pt-6 space-y-6">
                <h3 className="font-bold text-xl">Loan Summary</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500 mb-1">Monthly EMI</p>
                    <p className="text-2xl font-bold text-purple-600">{formatCurrency(result.monthlyPayment)}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500 mb-1">Total Payment</p>
                    <p className="text-2xl font-bold text-blue-600">{formatCurrency(result.totalPayment)}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500 mb-1">Total Interest</p>
                    <p className="text-2xl font-bold text-red-600">{formatCurrency(result.totalInterest)}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Principal Amount</span>
                      <span>Total Interest</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-purple-600 h-2.5 rounded-full" 
                        style={{ 
                          width: `${(parseFloat(loanAmount) / result.totalPayment) * 100}%` 
                        }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>{formatCurrency(parseFloat(loanAmount))}</span>
                      <span>{formatCurrency(result.totalInterest)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-bold text-xl mb-4">About Loan EMI Calculator</h3>
              <p className="text-gray-600 mb-4">
                Our Loan EMI Calculator helps you estimate your monthly installments (EMI) for any loan based on:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-gray-600 mb-4">
                <li>Principal loan amount</li>
                <li>Interest rate (annual)</li>
                <li>Loan tenure (in years)</li>
              </ul>
              <p className="text-gray-600">
                The calculator also shows you the total payment amount and the total interest you will pay over the entire loan tenure. This helps you make informed decisions about your loans and financial planning.
              </p>
              
              <h4 className="font-semibold text-lg mt-6 mb-2">How is EMI calculated?</h4>
              <p className="text-gray-600 mb-4">
                The EMI for a loan is calculated using the formula: EMI = P × r × (1 + r)^n / ((1 + r)^n - 1) where:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-gray-600 mb-4">
                <li>P is the principal loan amount</li>
                <li>r is the monthly interest rate (annual rate divided by 12 and then by 100)</li>
                <li>n is the loan tenure in months</li>
              </ul>
              
              <h4 className="font-semibold text-lg mt-6 mb-2">Common Loan EMI Questions</h4>
              <div className="space-y-3 mt-4">
                <div>
                  <p className="font-medium">How can I reduce my EMI amount?</p>
                  <p className="text-gray-600">You can reduce your EMI by negotiating a lower interest rate, extending the loan term, or making a larger down payment.</p>
                </div>
                <div>
                  <p className="font-medium">Is it better to choose a longer loan tenure?</p>
                  <p className="text-gray-600">Longer tenures reduce your monthly EMI but increase the total interest paid over the loan period. Choose based on your monthly budget constraints and overall cost considerations.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </ToolLayout>
    </>
  );
};

const LoanCalculator = withErrorBoundary(LoanCalculatorComponent, "loan-calculator");

export default LoanCalculator;
