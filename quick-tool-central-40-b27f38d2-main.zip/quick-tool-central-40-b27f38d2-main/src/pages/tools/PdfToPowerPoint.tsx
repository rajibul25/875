
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import ToolLayout from "../../components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const PdfToPowerPoint = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [converting, setConverting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error("Please select a PDF file");
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB
      toast.error("File size exceeds 10MB limit");
      return;
    }

    setSelectedFile(file);
    toast.success("PDF file selected successfully");
  };

  const handleConvert = () => {
    if (!selectedFile) {
      toast.error("Please select a PDF file first");
      return;
    }

    setConverting(true);
    // Simulate conversion process
    setTimeout(() => {
      setConverting(false);
      toast.success("Conversion complete! Your PowerPoint presentation is ready for download.");
    }, 2000);
  };

  return (
    <ToolLayout
      title="PDF to PowerPoint Converter"
      description="Convert PDF files to editable PowerPoint presentations"
      helpText="Upload your PDF file and convert it to a PowerPoint presentation that you can edit."
    >
      <Helmet>
        <title>PDF to PowerPoint Converter | MultiToolSet</title>
        <meta name="description" content="Convert PDF files to editable PowerPoint presentations online for free." />
      </Helmet>
      
      <div className="space-y-6">
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-10 text-center">
                <Label htmlFor="pdf-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {selectedFile ? selectedFile.name : "Click to upload or drag and drop"}
                    </span>
                    <span className="text-xs text-gray-500">PDF files only (max 10MB)</span>
                  </div>
                  <Input
                    id="pdf-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,application/pdf"
                    onChange={handleFileChange}
                  />
                </Label>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={handleConvert}
                  disabled={!selectedFile || converting}
                  className="w-full md:w-auto"
                >
                  {converting ? "Converting..." : "Convert to PowerPoint"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 max-w-3xl mx-auto">
          <div>
            <h2 className="text-2xl font-bold mb-3">How to Convert PDF to PowerPoint</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Upload your PDF file using the button above</li>
              <li>Click the "Convert to PowerPoint" button</li>
              <li>Wait for the conversion process to complete</li>
              <li>Download your converted PowerPoint presentation</li>
            </ol>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3">Why Use Our PDF to PowerPoint Converter</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Fast and accurate conversion</li>
              <li>Preserves slides, images, and layouts</li>
              <li>Secure and private - your files are deleted after processing</li>
              <li>Free to use with no watermarks</li>
              <li>No installation required - works in your browser</li>
              <li>Support for all PDF versions</li>
            </ul>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default PdfToPowerPoint;
