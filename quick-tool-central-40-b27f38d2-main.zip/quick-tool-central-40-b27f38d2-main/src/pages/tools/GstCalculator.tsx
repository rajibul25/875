
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, Percent } from "lucide-react";
import withErrorBoundary from "@/components/tools/withErrorBoundary";
import { toast } from "sonner";

const GstCalculatorComponent = () => {
  const [amount, setAmount] = useState<string>("");
  const [gstRate, setGstRate] = useState<string>("10");
  const [isInclusive, setIsInclusive] = useState<boolean>(false);
  const [result, setResult] = useState<{
    gstAmount: number;
    netAmount: number;
    totalAmount: number;
  } | null>(null);
  
  const calculateGst = () => {
    const value = parseFloat(amount);
    const rate = parseFloat(gstRate);
    
    if (isNaN(value) || isNaN(rate)) {
      toast.error("Please enter valid numbers");
      return;
    }
    
    if (value <= 0) {
      toast.error("Amount must be greater than zero");
      return;
    }
    
    if (rate < 0) {
      toast.error("GST rate must be greater than or equal to zero");
      return;
    }
    
    let gstAmount: number;
    let netAmount: number;
    let totalAmount: number;
    
    if (isInclusive) {
      // GST is included in the amount
      netAmount = value / (1 + (rate / 100));
      gstAmount = value - netAmount;
      totalAmount = value;
    } else {
      // GST is to be added to the amount
      netAmount = value;
      gstAmount = (value * rate) / 100;
      totalAmount = value + gstAmount;
    }
    
    setResult({
      gstAmount,
      netAmount,
      totalAmount
    });
    
    toast.success("GST calculated successfully!");
  };
  
  const gstPresets = [5, 10, 12, 18, 28];
  
  return (
    <ToolLayout
      title="GST Calculator"
      description="Calculate GST (Goods and Services Tax) for inclusive or exclusive amounts"
      helpText="Calculate GST by entering the amount and selecting the GST rate"
    >
      <div className="space-y-6 max-w-md mx-auto">
        <Tabs defaultValue={isInclusive ? "inclusive" : "exclusive"} onValueChange={(value) => setIsInclusive(value === "inclusive")}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="exclusive">GST Exclusive</TabsTrigger>
            <TabsTrigger value="inclusive">GST Inclusive</TabsTrigger>
          </TabsList>
          
          <TabsContent value="exclusive">
            <p className="text-sm text-gray-500 mb-4">
              Calculate GST to be added to the amount (amount + GST)
            </p>
          </TabsContent>
          
          <TabsContent value="inclusive">
            <p className="text-sm text-gray-500 mb-4">
              Extract GST from an amount that already includes GST
            </p>
          </TabsContent>
        </Tabs>
        
        <div className="space-y-2">
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
            {isInclusive ? "Amount (Including GST)" : "Amount (Excluding GST)"}
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500">$</span>
            </div>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              className="pl-8 w-full"
              step="0.01"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            GST Rate (%)
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {gstPresets.map(preset => (
              <button
                key={preset}
                type="button"
                className={`px-3 py-1 rounded-md ${
                  gstRate === preset.toString()
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => setGstRate(preset.toString())}
              >
                {preset}%
              </button>
            ))}
          </div>
          <div className="relative">
            <Input
              id="gstRate"
              type="number"
              value={gstRate}
              onChange={(e) => setGstRate(e.target.value)}
              placeholder="Enter GST rate"
              className="w-full"
              min="0"
              step="0.1"
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <span className="text-gray-500">%</span>
            </div>
          </div>
        </div>
        
        <Button 
          onClick={calculateGst}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!amount}
        >
          <Calculator className="mr-2 h-4 w-4" /> Calculate GST
        </Button>
        
        {result && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-lg mb-4">GST Calculation Result</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">Net Amount:</span>
                <span className="text-lg font-medium text-gray-700">
                  ${result.netAmount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white rounded-lg shadow-sm">
                <span className="text-gray-700">GST ({gstRate}%):</span>
                <span className="text-lg font-medium text-green-600">
                  ${result.gstAmount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg shadow-sm">
                <span className="text-gray-700 font-medium">Total Amount:</span>
                <span className="text-xl font-bold text-purple-600">
                  ${result.totalAmount.toFixed(2)}
                </span>
              </div>
              <div className="text-center mt-3 text-sm text-gray-600">
                {isInclusive ? 
                  `Net amount is ${((result.netAmount / result.totalAmount) * 100).toFixed(1)}% of the total` :
                  `GST adds ${((result.gstAmount / result.netAmount) * 100).toFixed(1)}% to the net amount`}
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

const GstCalculator = withErrorBoundary(GstCalculatorComponent, "gst-calculator");

export default GstCalculator;
