
import React, { useState, useEffect } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Copy, Save, Repeat } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const TextRepeater = () => {
  const [text, setText] = useState("");
  const [repeatCount, setRepeatCount] = useState(10);
  const [separator, setSeparator] = useState("none"); // none, space, newline, custom
  const [customSeparator, setCustomSeparator] = useState("");
  const [result, setResult] = useState("");
  const [totalChars, setTotalChars] = useState(0);
  
  // Generate repeated text whenever inputs change
  useEffect(() => {
    generateRepeatedText();
  }, [text, repeatCount, separator, customSeparator]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleRepeatCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setRepeatCount(value > 10000 ? 10000 : value); // Limit to 10,000 for performance
    } else {
      setRepeatCount(1);
    }
  };

  const handleSeparatorChange = (value: string) => {
    setSeparator(value);
  };

  const handleCustomSeparatorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCustomSeparator(e.target.value);
  };

  const generateRepeatedText = () => {
    if (!text) {
      setResult("");
      setTotalChars(0);
      return;
    }
    
    let sep = "";
    switch (separator) {
      case "space":
        sep = " ";
        break;
      case "newline":
        sep = "\n";
        break;
      case "custom":
        sep = customSeparator;
        break;
      default:
        sep = "";
    }
    
    // Create array of specified length and join with separator
    const repeatedText = Array(repeatCount).fill(text).join(sep);
    
    setResult(repeatedText);
    setTotalChars(repeatedText.length);
  };

  const copyText = () => {
    navigator.clipboard.writeText(result);
    toast.success("Repeated text copied to clipboard");
  };

  const downloadText = () => {
    const blob = new Blob([result], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "repeated-text.txt";
    link.href = url;
    link.click();
    toast.success("Repeated text downloaded successfully");
  };

  const formatCharCount = (count: number): string => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <ToolLayout 
      title="Text Repeater"
      description="Repeat text multiple times with custom separators"
      helpText="Enter any text or emoji to repeat it the desired number of times with optional separators."
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="input-text" className="text-lg font-medium">Text to Repeat</Label>
              <Textarea
                id="input-text"
                placeholder="Enter text or emoji to repeat..."
                className="min-h-[100px]"
                value={text}
                onChange={handleTextChange}
              />
              <p className="text-xs text-muted-foreground">
                Character count: {text.length}
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="repeat-count" className="text-lg font-medium">Number of Repetitions</Label>
              <Input
                id="repeat-count"
                type="number"
                min="1"
                max="10000"
                value={repeatCount}
                onChange={handleRepeatCountChange}
              />
              <p className="text-xs text-muted-foreground">
                Maximum: 10,000 repetitions
              </p>
            </div>
            
            <div className="space-y-2">
              <Label className="text-lg font-medium">Separator</Label>
              <RadioGroup value={separator} onValueChange={handleSeparatorChange}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="none" id="none" />
                  <Label htmlFor="none">No separator</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="space" id="space" />
                  <Label htmlFor="space">Space</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="newline" id="newline" />
                  <Label htmlFor="newline">New line</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="custom" id="custom" />
                  <Label htmlFor="custom">Custom separator</Label>
                </div>
              </RadioGroup>
              
              {separator === "custom" && (
                <div className="mt-2">
                  <Input
                    placeholder="Enter custom separator"
                    value={customSeparator}
                    onChange={handleCustomSeparatorChange}
                  />
                </div>
              )}
            </div>
            
            <Button onClick={generateRepeatedText} className="w-full">
              <Repeat className="h-4 w-4 mr-2" />
              Generate Repeated Text
            </Button>
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label htmlFor="result-text" className="text-lg font-medium">Result</Label>
              <div className="text-sm text-muted-foreground">
                Characters: {formatCharCount(totalChars)}
              </div>
            </div>
            
            <div className="rounded-lg border shadow-sm">
              <Textarea
                id="result-text"
                className="min-h-[300px] p-4 text-base border-0 resize-y"
                value={result}
                readOnly
              />
              <div className="p-3 bg-muted/20 border-t flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={copyText} disabled={!result}>
                  <Copy className="h-4 w-4 mr-2" /> Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadText} disabled={!result}>
                  <Save className="h-4 w-4 mr-2" /> Save
                </Button>
              </div>
            </div>
            
            {totalChars > 100000 && (
              <p className="text-xs text-amber-600">
                Warning: Large text may cause browser performance issues.
              </p>
            )}
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">How to Use This Tool</h2>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Enter the text or emoji you want to repeat in the "Text to Repeat" field.</li>
            <li>Specify the number of times you want to repeat it (1-10,000).</li>
            <li>Choose a separator option: none, space, new line, or custom.</li>
            <li>If you selected "Custom separator", enter your desired separator.</li>
            <li>The result will be generated automatically.</li>
            <li>Use the Copy or Save buttons to export the repeated text.</li>
          </ol>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Common Uses</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Testing</h3>
              <p className="text-muted-foreground">Generate test data for forms, databases, or applications.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Emoji Art</h3>
              <p className="text-muted-foreground">Create emoji patterns or art by repeating emoji characters.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Text Effects</h3>
              <p className="text-muted-foreground">Generate dividers or decorative text elements for documents.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Development</h3>
              <p className="text-muted-foreground">Create large text files for testing software performance.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Social Media</h3>
              <p className="text-muted-foreground">Create eye-catching patterns for comments or posts.</p>
            </div>
            <div className="bg-muted/20 p-4 rounded-lg border">
              <h3 className="font-bold">Design</h3>
              <p className="text-muted-foreground">Generate placeholder text patterns for visual designs.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold">Is there a limit to how much text I can repeat?</h3>
              <p className="text-muted-foreground">For performance reasons, we limit repetitions to 10,000 times. Very large results (over 100,000 characters) may cause browser slowdowns.</p>
            </div>
            <div>
              <h3 className="font-bold">Can I repeat emojis with this tool?</h3>
              <p className="text-muted-foreground">Yes! This tool works great for repeating emoji characters. Just enter your favorite emoji and set the number of repetitions.</p>
            </div>
            <div>
              <h3 className="font-bold">What can I use as a custom separator?</h3>
              <p className="text-muted-foreground">You can use any character or string as a custom separator, including multiple characters, emojis, or even HTML tags (though the HTML won't be rendered).</p>
            </div>
            <div>
              <h3 className="font-bold">How can I create a divider line with this tool?</h3>
              <p className="text-muted-foreground">Enter a character like "-", "=", "*", or "~", and set the repeat count to the desired length (e.g., 80 for a standard width divider).</p>
            </div>
          </div>
        </div>
      </div>
    </ToolLayout>
  );
};

export default TextRepeater;
