
import React, { useState } from "react";
import ToolLayout from "@/components/tools/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Link, 
  Plus, 
  ArrowUp, 
  ArrowDown, 
  Trash2, 
  Copy, 
  Image as ImageIcon,
  Instagram,
  Twitter,
  Facebook,
  Linkedin,
  Youtube,
  Github,
  Mail,
  Globe,
  ExternalLink,
  DollarSign,
  Music
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

// Type definitions
interface LinkItem {
  id: string;
  title: string;
  url: string;
  icon: string;
}

interface BioLinkProfile {
  username: string;
  title: string;
  bio: string;
  image: string;
  theme: string;
  backgroundColor: string;
  textColor: string;
  buttonStyle: string;
  buttonColor: string;
  buttonTextColor: string;
}

// Icon options for links
const iconOptions = [
  { value: 'link', label: 'Link', icon: <Link className="h-4 w-4" /> },
  { value: 'instagram', label: 'Instagram', icon: <Instagram className="h-4 w-4" /> },
  { value: 'twitter', label: 'Twitter', icon: <Twitter className="h-4 w-4" /> },
  { value: 'facebook', label: 'Facebook', icon: <Facebook className="h-4 w-4" /> },
  { value: 'linkedin', label: 'LinkedIn', icon: <Linkedin className="h-4 w-4" /> },
  { value: 'youtube', label: 'YouTube', icon: <Youtube className="h-4 w-4" /> },
  { value: 'github', label: 'GitHub', icon: <Github className="h-4 w-4" /> },
  { value: 'mail', label: 'Email', icon: <Mail className="h-4 w-4" /> },
  { value: 'globe', label: 'Website', icon: <Globe className="h-4 w-4" /> },
  { value: 'store', label: 'Store', icon: <DollarSign className="h-4 w-4" /> },
  { value: 'music', label: 'Music', icon: <Music className="h-4 w-4" /> },
];

// Get icon component based on icon name
const getIconComponent = (iconName: string) => {
  const icon = iconOptions.find(option => option.value === iconName);
  return icon ? icon.icon : <Link className="h-4 w-4" />;
};

// Theme options
const themes = [
  { value: 'default', label: 'Default', bg: 'bg-white', text: 'text-black' },
  { value: 'dark', label: 'Dark', bg: 'bg-gray-900', text: 'text-white' },
  { value: 'gradient-purple', label: 'Purple Gradient', bg: 'bg-gradient-to-b from-purple-500 to-pink-500', text: 'text-white' },
  { value: 'gradient-blue', label: 'Blue Gradient', bg: 'bg-gradient-to-b from-blue-500 to-teal-500', text: 'text-white' },
  { value: 'minimal', label: 'Minimal', bg: 'bg-gray-100', text: 'text-gray-800' },
];

// Button style options
const buttonStyles = [
  { value: 'rounded', label: 'Rounded' },
  { value: 'pill', label: 'Pill' },
  { value: 'square', label: 'Square' },
  { value: 'outline', label: 'Outlined' },
  { value: 'shadow', label: 'Shadow' },
];

const BioLink = () => {
  const { toast } = useToast();
  const [links, setLinks] = useState<LinkItem[]>([
    { id: '1', title: 'My Website', url: 'https://example.com', icon: 'globe' },
    { id: '2', title: 'Follow me on Instagram', url: 'https://instagram.com/username', icon: 'instagram' }
  ]);
  
  const [profile, setProfile] = useState<BioLinkProfile>({
    username: 'username',
    title: 'My Bio Link',
    bio: 'Welcome to my links page!',
    image: '',
    theme: 'default',
    backgroundColor: '#ffffff',
    textColor: '#000000',
    buttonStyle: 'rounded',
    buttonColor: '#3b82f6',
    buttonTextColor: '#ffffff'
  });

  const [newLink, setNewLink] = useState<Partial<LinkItem>>({
    title: '',
    url: '',
    icon: 'link'
  });

  const [previewUrl, setPreviewUrl] = useState('username');
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('mobile');

  const handleAddLink = () => {
    if (!newLink.title || !newLink.url) {
      toast({
        title: "Missing information",
        description: "Please enter both title and URL for your link.",
        variant: "destructive",
      });
      return;
    }

    const link: LinkItem = {
      id: Date.now().toString(),
      title: newLink.title || '',
      url: newLink.url || '',
      icon: newLink.icon || 'link'
    };

    setLinks([...links, link]);
    setNewLink({ title: '', url: '', icon: 'link' });
    
    toast({
      title: "Link added",
      description: `"${link.title}" has been added to your bio link page.`,
    });
  };

  const handleRemoveLink = (id: string) => {
    setLinks(links.filter(link => link.id !== id));
    
    toast({
      title: "Link removed",
      description: "The link has been removed from your bio link page.",
    });
  };

  const moveLink = (id: string, direction: 'up' | 'down') => {
    const index = links.findIndex(link => link.id === id);
    if (
      (direction === 'up' && index === 0) || 
      (direction === 'down' && index === links.length - 1)
    ) {
      return;
    }
    
    const newLinks = [...links];
    const movingLink = newLinks[index];
    
    if (direction === 'up') {
      newLinks[index] = newLinks[index - 1];
      newLinks[index - 1] = movingLink;
    } else {
      newLinks[index] = newLinks[index + 1];
      newLinks[index + 1] = movingLink;
    }
    
    setLinks(newLinks);
  };

  const handleProfileChange = (field: keyof BioLinkProfile, value: string) => {
    setProfile({ ...profile, [field]: value });
    
    if (field === 'username') {
      setPreviewUrl(value || 'username');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setProfile({ ...profile, image: e.target.result as string });
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const copyLinkToClipboard = () => {
    const linkText = `yourbiolink.com/${previewUrl}`;
    navigator.clipboard.writeText(linkText);
    
    toast({
      title: "Link copied",
      description: "Your bio link URL has been copied to clipboard.",
    });
  };

  const getButtonClasses = () => {
    let classes = 'w-full py-3 px-4 mb-3 flex items-center justify-center';
    
    switch (profile.buttonStyle) {
      case 'rounded':
        classes += ' rounded-lg';
        break;
      case 'pill':
        classes += ' rounded-full';
        break;
      case 'square':
        classes += ' rounded-none';
        break;
      case 'outline':
        classes += ' rounded-lg border-2';
        break;
      case 'shadow':
        classes += ' rounded-lg shadow-lg';
        break;
      default:
        classes += ' rounded-lg';
    }
    
    return classes;
  };

  return (
    <ToolLayout 
      title="Bio Link Generator"
      description="Create a personal link-in-bio landing page with all your important links."
      helpText="Customize your profile, add multiple links, and get a clean landing page for social media profiles."
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Editor Panel */}
        <div className="space-y-6">
          <Tabs defaultValue="links">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="links">Links</TabsTrigger>
              <TabsTrigger value="design">Design</TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile" className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <div className="flex items-center mt-1.5">
                  <span className="bg-gray-100 dark:bg-gray-800 py-2 px-3 rounded-l-md text-sm text-gray-500 dark:text-gray-400">
                    yourbiolink.com/
                  </span>
                  <Input 
                    id="username"
                    value={profile.username} 
                    onChange={(e) => handleProfileChange('username', e.target.value)}
                    className="rounded-l-none"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="title">Page Title</Label>
                <Input 
                  id="title"
                  value={profile.title} 
                  onChange={(e) => handleProfileChange('title', e.target.value)}
                  className="mt-1.5"
                />
              </div>
              
              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea 
                  id="bio"
                  value={profile.bio} 
                  onChange={(e) => handleProfileChange('bio', e.target.value)}
                  placeholder="Tell visitors about yourself..."
                  className="mt-1.5"
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="profileImage">Profile Image</Label>
                <div className="mt-1.5 flex items-center space-x-4">
                  <div 
                    className="w-20 h-20 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden"
                  >
                    {profile.image ? (
                      <img 
                        src={profile.image} 
                        alt="Profile" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ImageIcon className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                  <Button 
                    variant="outline"
                    onClick={() => document.getElementById('profile-image-upload')?.click()}
                  >
                    Upload Image
                  </Button>
                  <input 
                    type="file" 
                    id="profile-image-upload"
                    className="hidden" 
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                  {profile.image && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setProfile({ ...profile, image: '' })}
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="links" className="space-y-4">
              <Card className="p-4 space-y-4">
                <h3 className="font-medium">Add New Link</h3>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="link-title">Link Title</Label>
                    <Input 
                      id="link-title"
                      placeholder="e.g., Follow me on Instagram"
                      value={newLink.title} 
                      onChange={(e) => setNewLink({...newLink, title: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="link-url">URL</Label>
                    <Input 
                      id="link-url"
                      placeholder="https://"
                      value={newLink.url} 
                      onChange={(e) => setNewLink({...newLink, url: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="link-icon">Icon</Label>
                    <Select 
                      value={newLink.icon} 
                      onValueChange={(value) => setNewLink({...newLink, icon: value})}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select an icon" />
                      </SelectTrigger>
                      <SelectContent>
                        {iconOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            <div className="flex items-center">
                              {option.icon}
                              <span className="ml-2">{option.label}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button onClick={handleAddLink} className="w-full">
                    <Plus className="h-4 w-4 mr-2" /> Add Link
                  </Button>
                </div>
              </Card>
              
              <div className="space-y-2">
                <h3 className="font-medium">Your Links</h3>
                {links.length === 0 ? (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No links added yet. Add your first link above.
                  </p>
                ) : (
                  links.map((link, index) => (
                    <Card key={link.id} className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mr-3">
                            {getIconComponent(link.icon)}
                          </div>
                          <div>
                            <p className="font-medium">{link.title}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-[180px]">
                              {link.url}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => moveLink(link.id, 'up')}
                            disabled={index === 0}
                            className="h-8 w-8"
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => moveLink(link.id, 'down')}
                            disabled={index === links.length - 1}
                            className="h-8 w-8"
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleRemoveLink(link.id)}
                            className="h-8 w-8 text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="design" className="space-y-4">
              <div>
                <Label>Theme</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  {themes.map((theme) => (
                    <button
                      key={theme.value}
                      className={`p-4 border rounded-lg text-center transition-all ${
                        profile.theme === theme.value
                          ? 'border-blue-500 ring-2 ring-blue-500/20'
                          : 'border-gray-200 dark:border-gray-700'
                      }`}
                      onClick={() => handleProfileChange('theme', theme.value)}
                    >
                      <div className={`h-16 mb-2 rounded ${theme.bg}`}></div>
                      <p className="text-sm font-medium">{theme.label}</p>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="background-color">Background Color</Label>
                  <div className="flex mt-1.5">
                    <input 
                      type="color"
                      id="background-color"
                      value={profile.backgroundColor}
                      onChange={(e) => handleProfileChange('backgroundColor', e.target.value)}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={profile.backgroundColor}
                      onChange={(e) => handleProfileChange('backgroundColor', e.target.value)}
                      className="w-28 ml-2"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="text-color">Text Color</Label>
                  <div className="flex mt-1.5">
                    <input 
                      type="color"
                      id="text-color"
                      value={profile.textColor}
                      onChange={(e) => handleProfileChange('textColor', e.target.value)}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={profile.textColor}
                      onChange={(e) => handleProfileChange('textColor', e.target.value)}
                      className="w-28 ml-2"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="button-style">Button Style</Label>
                <Select 
                  value={profile.buttonStyle} 
                  onValueChange={(value) => handleProfileChange('buttonStyle', value)}
                >
                  <SelectTrigger id="button-style" className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {buttonStyles.map((style) => (
                      <SelectItem key={style.value} value={style.value}>
                        {style.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="button-color">Button Color</Label>
                  <div className="flex mt-1.5">
                    <input 
                      type="color"
                      id="button-color"
                      value={profile.buttonColor}
                      onChange={(e) => handleProfileChange('buttonColor', e.target.value)}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={profile.buttonColor}
                      onChange={(e) => handleProfileChange('buttonColor', e.target.value)}
                      className="w-28 ml-2"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="button-text-color">Button Text Color</Label>
                  <div className="flex mt-1.5">
                    <input 
                      type="color"
                      id="button-text-color"
                      value={profile.buttonTextColor}
                      onChange={(e) => handleProfileChange('buttonTextColor', e.target.value)}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={profile.buttonTextColor}
                      onChange={(e) => handleProfileChange('buttonTextColor', e.target.value)}
                      className="w-28 ml-2"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="pt-2 border-t">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-medium">Your Bio Link</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Ready to share with your followers
                </p>
              </div>
              <Button onClick={copyLinkToClipboard}>
                <Copy className="h-4 w-4 mr-2" /> Copy Link
              </Button>
            </div>
            
            <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center">
              <div className="flex-1 truncate">
                <span className="text-sm">yourbiolink.com/{previewUrl}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={copyLinkToClipboard}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Preview Panel */}
        <div className="flex flex-col items-center">
          <div className="mb-4 flex items-center space-x-3">
            <Button
              variant={viewMode === 'mobile' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('mobile')}
            >
              Mobile Preview
            </Button>
            <Button
              variant={viewMode === 'desktop' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('desktop')}
            >
              Desktop Preview
            </Button>
          </div>
          
          <div 
            className={`overflow-hidden border rounded-lg shadow-lg mx-auto ${
              viewMode === 'mobile' ? 'w-[320px]' : 'w-full max-w-[600px]'
            }`}
            style={{
              backgroundColor: profile.theme === 'default' ? profile.backgroundColor : undefined,
              background: profile.theme.startsWith('gradient') ? 
                (profile.theme === 'gradient-purple' ? 'linear-gradient(to bottom, #8b5cf6, #ec4899)' : 
                 profile.theme === 'gradient-blue' ? 'linear-gradient(to bottom, #3b82f6, #14b8a6)' : 
                 undefined) : undefined,
              color: profile.theme === 'default' ? profile.textColor : undefined,
              maxHeight: viewMode === 'mobile' ? '600px' : '800px',
              overflow: 'auto'
            }}
          >
            <div className="p-6 flex flex-col items-center text-center">
              {/* Profile Section */}
              <div className="mb-6">
                <div className="w-24 h-24 rounded-full overflow-hidden bg-white shadow-md mb-4 mx-auto">
                  {profile.image ? (
                    <img 
                      src={profile.image} 
                      alt={profile.title} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-200">
                      <ImageIcon className="text-gray-400 h-10 w-10" />
                    </div>
                  )}
                </div>
                <h1 className="text-xl font-bold mb-2" style={{ color: profile.theme === 'default' ? profile.textColor : undefined }}>
                  {profile.title || 'My Bio Link'}
                </h1>
                <p className="text-sm opacity-80" style={{ color: profile.theme === 'default' ? profile.textColor : undefined }}>
                  {profile.bio || 'Welcome to my links page!'}
                </p>
              </div>
              
              {/* Links Section */}
              <div className="w-full max-w-md">
                {links.map((link) => (
                  <a 
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={getButtonClasses()}
                    style={{ 
                      backgroundColor: profile.buttonStyle === 'outline' ? 'transparent' : profile.buttonColor,
                      color: profile.buttonTextColor,
                      borderColor: profile.buttonStyle === 'outline' ? profile.buttonColor : undefined
                    }}
                  >
                    <div className="mr-2">
                      {getIconComponent(link.icon)}
                    </div>
                    <span>{link.title}</span>
                    <ExternalLink className="h-3 w-3 ml-2 opacity-70" />
                  </a>
                ))}
                
                {links.length === 0 && (
                  <div className="text-center py-4 opacity-50">
                    <p>No links added yet. Add some links to see them here!</p>
                  </div>
                )}
              </div>
              
              <div className="mt-8 text-xs opacity-50" style={{ color: profile.theme === 'default' ? profile.textColor : undefined }}>
                Made with Bio Link Generator
              </div>
            </div>
          </div>
          
          {/* How to Use */}
          <div className="mt-8 w-full">
            <h3 className="text-lg font-medium mb-3">How to Use This Tool</h3>
            <ol className="list-decimal pl-5 space-y-2 text-gray-700 dark:text-gray-300">
              <li>Customize your profile with a name, bio, and image</li>
              <li>Add your important links with appropriate icons</li>
              <li>Customize the design to match your personal brand</li>
              <li>Copy your bio link URL to use in your social media profiles</li>
            </ol>
          </div>
        </div>
      </div>
      
      {/* FAQ Section */}
      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">What is a bio link?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              A bio link is a dedicated landing page that contains multiple links to your content, products, social media, or other important pages. It's perfect for social platforms that only allow one link in your bio.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">How do I use my bio link?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Once you've created your bio link page, copy the URL and paste it into your social media profile's bio section. Visitors will be able to click this link and see all your important links in one place.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Is this tool completely free?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              The basic version is free to use. We also offer premium features like custom domains, advanced analytics, and removal of our branding for a small monthly fee.
            </p>
          </Card>
          <Card className="p-4">
            <h3 className="font-semibold text-lg mb-2">Can I update my bio link later?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Yes, you can return to this tool anytime to update your existing bio link. The changes will be reflected immediately on your live bio link page.
            </p>
          </Card>
        </div>
      </div>
    </ToolLayout>
  );
};

export default BioLink;
