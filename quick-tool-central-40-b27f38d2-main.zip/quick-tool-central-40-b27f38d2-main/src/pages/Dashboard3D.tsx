
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import BackButton from "@/components/BackButton";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { 
  LayoutDashboard, 
  Activity, 
  Users, 
  Globe, 
  Clock, 
  MousePointer, 
  Search, 
  FileText, 
  BarChart as BarChartIcon,
  RotateCw,
  User,
  Zap,
  TrendingUp,
  FileBarChart,
  Calendar,
  Settings,
  Upload,
  Download,
  RefreshCw,
  ChevronRight,
  Plus,
  BellRing
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ChatBot from "@/components/ChatBot";

// Mock data for dashboard
const trafficData = [
  { name: 'Jan', visits: 4000 },
  { name: 'Feb', visits: 3000 },
  { name: 'Mar', visits: 2000 },
  { name: 'Apr', visits: 2780 },
  { name: 'May', visits: 1890 },
  { name: 'Jun', visits: 2390 },
  { name: 'Jul', visits: 3490 },
  { name: 'Aug', visits: 4200 },
  { name: 'Sep', visits: 5000 },
  { name: 'Oct', visits: 4800 },
  { name: 'Nov', visits: 4900 },
  { name: 'Dec', visits: 6000 },
];

const visitorSourceData = [
  { name: 'Direct', value: 400 },
  { name: 'Search', value: 300 },
  { name: 'Social', value: 300 },
  { name: 'Referral', value: 200 },
];

const toolUsageData = [
  { name: 'Word Counter', usage: 1200 },
  { name: 'Image Resizer', usage: 900 },
  { name: 'PNG Converter', usage: 800 },
  { name: 'PDF Tools', usage: 600 },
  { name: 'System Tools', usage: 400 },
];

const COLORS = ['#8B5CF6', '#1EAEDB', '#F97316', '#10B981'];

const recentActivityData = [
  { id: 1, user: "Alice Brown", action: "Used Word Counter", time: "5 minutes ago", icon: FileText },
  { id: 2, user: "John Smith", action: "Resized Image", time: "10 minutes ago", icon: Upload },
  { id: 3, user: "Emma Wilson", action: "Converted to PNG", time: "25 minutes ago", icon: Download },
  { id: 4, user: "Michael Johnson", action: "Used PDF Tools", time: "1 hour ago", icon: FileBarChart },
  { id: 5, user: "Sophia Garcia", action: "System Maintenance", time: "2 hours ago", icon: Settings },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<string>("overview");
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center mb-4 sm:mb-0">
            <BackButton className="mr-4" />
            <h1 className="text-3xl font-bold">Dashboard</h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              <span>Today</span>
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
            <Button variant="default" size="sm" className="flex items-center gap-1">
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </Button>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="border-l-4 border-l-tool-purple">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Users</p>
                <h3 className="text-2xl font-bold mt-1">12,548</h3>
                <p className="text-xs text-green-500 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />+12.5% from last month
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-tool-purple">
                <Users className="h-6 w-6" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-tool-blue">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Session</p>
                <h3 className="text-2xl font-bold mt-1">3m 42s</h3>
                <p className="text-xs text-red-500 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1 rotate-180" />-3.8% from last month
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-tool-blue">
                <Clock className="h-6 w-6" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-tool-green">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Tools</p>
                <h3 className="text-2xl font-bold mt-1">152</h3>
                <p className="text-xs text-green-500 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />+5 new this month
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-tool-green">
                <FileBarChart className="h-6 w-6" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-tool-orange">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Conversion Rate</p>
                <h3 className="text-2xl font-bold mt-1">24.8%</h3>
                <p className="text-xs text-green-500 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />+2.1% from last month
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-tool-orange">
                <MousePointer className="h-6 w-6" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar with options */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                  <LayoutDashboard className="w-5 h-5 text-tool-purple" />
                  Dashboard Views
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-2">
                  <Button 
                    variant={activeView === "overview" ? "default" : "ghost"} 
                    onClick={() => setActiveView("overview")}
                    className="justify-start"
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    Overview
                  </Button>
                  <Button 
                    variant={activeView === "users" ? "default" : "ghost"} 
                    onClick={() => setActiveView("users")}
                    className="justify-start"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    User Analytics
                  </Button>
                  <Button 
                    variant={activeView === "tools" ? "default" : "ghost"} 
                    onClick={() => setActiveView("tools")}
                    className="justify-start"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Tool Usage
                  </Button>
                  <Button 
                    variant={activeView === "sources" ? "default" : "ghost"} 
                    onClick={() => setActiveView("sources")}
                    className="justify-start"
                  >
                    <Globe className="w-4 h-4 mr-2" />
                    Traffic Sources
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                  <Zap className="w-5 h-5 text-tool-orange" />
                  Key Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-tool-purple" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Users</span>
                      </div>
                      <span className="font-semibold">12,548</span>
                    </div>
                    <Progress value={75} className="h-1.5" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-tool-blue" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Avg. Session</span>
                      </div>
                      <span className="font-semibold">3m 42s</span>
                    </div>
                    <Progress value={45} className="h-1.5" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <MousePointer className="w-4 h-4 text-tool-green" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Click Rate</span>
                      </div>
                      <span className="font-semibold">24.8%</span>
                    </div>
                    <Progress value={24} className="h-1.5" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <RotateCw className="w-4 h-4 text-tool-orange" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Return Rate</span>
                      </div>
                      <span className="font-semibold">42.3%</span>
                    </div>
                    <Progress value={42} className="h-1.5" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main content area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Main chart */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                  <Activity className="w-5 h-5 text-tool-blue" />
                  Website Traffic
                </CardTitle>
                <Tabs defaultValue="monthly" className="w-auto">
                  <TabsList className="grid w-[250px] grid-cols-3">
                    <TabsTrigger value="weekly">Weekly</TabsTrigger>
                    <TabsTrigger value="monthly">Monthly</TabsTrigger>
                    <TabsTrigger value="yearly">Yearly</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                <ChartContainer 
                  className="h-[300px]" 
                  config={{
                    visits: {
                      label: "Monthly Visitors",
                      theme: {
                        light: "#8B5CF6",
                        dark: "#9b87f5"
                      }
                    }
                  }}
                >
                  <AreaChart data={trafficData}>
                    <defs>
                      <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <ChartTooltip 
                      content={<ChartTooltipContent />} 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="visits" 
                      stroke="#8B5CF6" 
                      fillOpacity={1} 
                      fill="url(#colorVisits)" 
                    />
                  </AreaChart>
                </ChartContainer>
              </CardContent>
            </Card>
            
            {/* Data visualizations - show based on active view */}
            {activeView === "overview" && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Globe className="w-4 h-4 text-tool-blue" />
                      Traffic Sources
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer 
                      className="h-[250px]" 
                      config={{
                        direct: {
                          label: "Direct",
                          theme: {
                            light: "#8B5CF6",
                            dark: "#9b87f5"
                          }
                        },
                        search: {
                          label: "Search",
                          theme: {
                            light: "#1EAEDB",
                            dark: "#38BDF8"
                          }
                        },
                        social: {
                          label: "Social",
                          theme: {
                            light: "#F97316",
                            dark: "#FB923C"
                          }
                        },
                        referral: {
                          label: "Referral",
                          theme: {
                            light: "#10B981",
                            dark: "#34D399"
                          }
                        }
                      }}
                    >
                      <PieChart>
                        <Pie
                          data={visitorSourceData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                        >
                          {visitorSourceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Legend />
                      </PieChart>
                    </ChartContainer>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2 flex flex-row items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BellRing className="w-4 h-4 text-tool-orange" />
                      Recent Activity
                    </CardTitle>
                    <Button variant="ghost" size="sm" className="text-xs">
                      View All <ChevronRight className="ml-1 h-3 w-3" />
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivityData.map((item) => (
                        <div key={item.id} className="flex items-center gap-3 pb-3 border-b border-gray-100 dark:border-gray-800 last:border-0 last:pb-0">
                          <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                            <item.icon className="h-4 w-4 text-tool-purple" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{item.user}</p>
                            <p className="text-xs text-gray-500">{item.action}</p>
                          </div>
                          <div className="text-xs text-gray-400">{item.time}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {activeView === "tools" && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileBarChart className="w-4 h-4 text-tool-blue" />
                    Tool Usage Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer 
                    className="h-[400px]" 
                    config={{
                      usage: {
                        label: "Tool Usage",
                        theme: {
                          light: "#1EAEDB",
                          dark: "#38BDF8"
                        }
                      }
                    }}
                  >
                    <BarChart data={toolUsageData}>
                      <XAxis dataKey="name" />
                      <YAxis />
                      <CartesianGrid strokeDasharray="3 3" />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="usage" fill="#1EAEDB" />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            )}
            
            {activeView === "users" && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Users className="w-4 h-4 text-tool-purple" />
                      User Demographics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Age 18-24</span>
                        <span className="text-sm font-medium">24%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-purple h-2.5 rounded-full" style={{ width: '24%' }}></div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Age 25-34</span>
                        <span className="text-sm font-medium">38%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-blue h-2.5 rounded-full" style={{ width: '38%' }}></div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Age 35-44</span>
                        <span className="text-sm font-medium">27%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-green h-2.5 rounded-full" style={{ width: '27%' }}></div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Age 45+</span>
                        <span className="text-sm font-medium">11%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-orange h-2.5 rounded-full" style={{ width: '11%' }}></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Activity className="w-4 h-4 text-tool-green" />
                      User Engagement
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-2 text-tool-purple" />
                          <span className="text-sm">New Visitors</span>
                        </div>
                        <span className="font-medium">57.8%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-purple h-2.5 rounded-full" style={{ width: '57.8%' }}></div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <RotateCw className="w-4 h-4 mr-2 text-tool-blue" />
                          <span className="text-sm">Returning Visitors</span>
                        </div>
                        <span className="font-medium">42.2%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-tool-blue h-2.5 rounded-full" style={{ width: '42.2%' }}></div>
                      </div>
                    </div>
                    
                    <div className="pt-4">
                      <h4 className="text-sm font-medium mb-3">Reasons for Visit</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <FileText className="w-4 h-4 mr-2 text-tool-green" />
                            <span className="text-sm">Document Conversion</span>
                          </div>
                          <span className="font-medium">45%</span>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <Search className="w-4 h-4 mr-2 text-tool-orange" />
                            <span className="text-sm">Tool Search</span>
                          </div>
                          <span className="font-medium">32%</span>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <BarChartIcon className="w-4 h-4 mr-2 text-tool-blue" />
                            <span className="text-sm">Data Analysis</span>
                          </div>
                          <span className="font-medium">23%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {activeView === "sources" && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Globe className="w-4 h-4 text-tool-blue" />
                    Traffic Sources Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <ChartContainer 
                      className="h-[300px]" 
                      config={{
                        value: {
                          label: "Traffic Source",
                          theme: {
                            light: "#8B5CF6",
                            dark: "#9b87f5"
                          }
                        }
                      }}
                    >
                      <PieChart>
                        <Pie
                          data={visitorSourceData}
                          cx="50%"
                          cy="50%"
                          labelLine={true}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          nameKey="name"
                          label
                        >
                          {visitorSourceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Legend />
                      </PieChart>
                    </ChartContainer>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Top Referrers</h4>
                        <ul className="space-y-2">
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">google.com</span>
                            <span className="text-sm font-medium">48%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">facebook.com</span>
                            <span className="text-sm font-medium">24%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">twitter.com</span>
                            <span className="text-sm font-medium">16%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">reddit.com</span>
                            <span className="text-sm font-medium">12%</span>
                          </li>
                        </ul>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Top Countries</h4>
                        <ul className="space-y-2">
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">United States</span>
                            <span className="text-sm font-medium">35%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">United Kingdom</span>
                            <span className="text-sm font-medium">22%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Canada</span>
                            <span className="text-sm font-medium">18%</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Australia</span>
                            <span className="text-sm font-medium">14%</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
      <ChatBot />
    </div>
  );
};

export default Dashboard;
