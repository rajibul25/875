import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, AlertTriangle, CheckCircle, RefreshCw, Trash, Wrench } from "lucide-react";
import { Tool, ToolCategory } from "@/lib/tool-model";
import { getErrorLogs, clearErrorLogs, ErrorLog } from "@/services/ErrorLoggingService";

// Import all tool categories
import { 
  conversionTools,
  dataTools, 
  developerTools, 
  contentTools,
  aiTools
} from "@/lib/tool-categories";

// Create a mock authentication check for admin access
// In a real app, this would connect to an authentication system
const useAdminAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Check for admin access
    // This is just a mock - in a real app, use actual authentication
    const adminPassword = localStorage.getItem("admin_password");
    setIsAuthenticated(!!adminPassword);
    setIsLoading(false);
  }, []);
  
  const login = (password: string) => {
    if (password === "admin123") { // Hard-coded for demo - NEVER do this in production
      localStorage.setItem("admin_password", "true");
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };
  
  const logout = () => {
    localStorage.removeItem("admin_password");
    setIsAuthenticated(false);
  };
  
  return { isAuthenticated, isLoading, login, logout };
};

// Combine all tools
const allTools: Tool[] = [
  ...conversionTools,
  ...dataTools,
  ...developerTools,
  ...contentTools,
  ...aiTools
];

// Group tools by category
const toolCategories: ToolCategory[] = [
  {
    name: "conversion",
    id: "conversion",
    displayName: "Conversion Tools",
    description: "Tools for converting between different formats",
    tools: conversionTools
  },
  {
    name: "data",
    id: "data",
    displayName: "Data & Analytics Tools",
    description: "Tools for data analysis and visualization",
    tools: dataTools
  },
  {
    name: "developer",
    id: "developer",
    displayName: "Developer Tools",
    description: "Tools for software developers",
    tools: developerTools
  },
  {
    name: "content",
    id: "content",
    displayName: "Content Creation Tools",
    description: "Tools for creating and editing content",
    tools: contentTools
  },
  {
    name: "ai",
    id: "ai",
    displayName: "AI Tools",
    description: "AI-powered tools",
    tools: aiTools
  }
];

// Login form for admin access
const LoginForm = ({ onLogin }: { onLogin: (password: string) => boolean }) => {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onLogin(password)) {
      setError("");
    } else {
      setError("Invalid password");
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>Admin Login</CardTitle>
            <CardDescription>Enter admin password to access the tool checker</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter admin password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  {error && <p className="text-sm text-red-500">{error}</p>}
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full">Login</Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
};

// Tool status checker component
const ToolChecker = () => {
  const { isAuthenticated, isLoading, login, logout } = useAdminAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [toolStatuses, setToolStatuses] = useState<Record<string, boolean>>({});
  const [isChecking, setIsChecking] = useState(false);
  const [errorLogs, setErrorLogs] = useState<ErrorLog[]>([]);
  const navigate = useNavigate();
  
  // Load error logs
  useEffect(() => {
    if (isAuthenticated) {
      setErrorLogs(getErrorLogs());
    }
  }, [isAuthenticated]);
  
  // Filter tools based on search and category
  const getFilteredTools = () => {
    let filteredTools = allTools;
    
    if (activeCategory !== "all") {
      const category = toolCategories.find(c => c.id === activeCategory);
      filteredTools = category ? category.tools : [];
    }
    
    if (searchQuery) {
      filteredTools = filteredTools.filter(tool => 
        tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return filteredTools;
  };
  
  // Check all tool statuses
  const checkAllTools = async () => {
    setIsChecking(true);
    const statuses: Record<string, boolean> = {};
    
    // In a real app, we would make actual HTTP requests to check tool status
    // For demo purposes, we're just simulating status checks
    for (const tool of allTools) {
      try {
        // Simulate an API check with some random results
        await new Promise(resolve => setTimeout(resolve, 50));
        statuses[tool.id] = Math.random() > 0.1; // 90% chance of being online
      } catch (error) {
        statuses[tool.id] = false;
      }
    }
    
    setToolStatuses(statuses);
    setIsChecking(false);
  };
  
  // Navigate to a specific tool
  const goToTool = (path: string) => {
    navigate(path);
  };
  
  // Handle tool refresh
  const refreshTool = (toolId: string) => {
    setToolStatuses(prev => ({
      ...prev,
      [toolId]: Math.random() > 0.1
    }));
  };
  
  // Clear all error logs
  const handleClearLogs = () => {
    clearErrorLogs();
    setErrorLogs([]);
  };
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  
  if (!isAuthenticated) {
    return <LoginForm onLogin={login} />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Tool Health Checker</h1>
            <p className="text-gray-600 dark:text-gray-300">
              Monitor and verify the status of all tools on the site
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={checkAllTools} 
              disabled={isChecking}
            >
              <RefreshCw className={`mr-2 h-4 w-4 ${isChecking ? 'animate-spin' : ''}`} />
              {isChecking ? 'Checking...' : 'Check All Tools'}
            </Button>
            <Button 
              variant="destructive" 
              onClick={logout}
            >
              Logout
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Tool status checker section */}
            <Card>
              <CardHeader>
                <CardTitle>Tool Status</CardTitle>
                <CardDescription>Check if tools are functioning correctly</CardDescription>
                <div className="mt-4 flex gap-2">
                  <div className="relative flex-grow">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Search tools..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory}>
                  <TabsList className="mb-4 flex flex-wrap">
                    <TabsTrigger value="all">All Tools</TabsTrigger>
                    {toolCategories.map(category => (
                      <TabsTrigger key={category.id} value={category.id || ''}>
                        {category.displayName || category.name}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  
                  <div className="space-y-2">
                    {getFilteredTools().map(tool => (
                      <div 
                        key={tool.id} 
                        className="p-3 border rounded-lg flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                            {tool.icon}
                          </div>
                          <div>
                            <h3 className="font-medium">{tool.title}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {tool.category}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {toolStatuses[tool.id] !== undefined && (
                            <Badge 
                              variant={toolStatuses[tool.id] ? "default" : "destructive"}
                              className="mr-2"
                            >
                              {toolStatuses[tool.id] ? 'Online' : 'Offline'}
                            </Badge>
                          )}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => refreshTool(tool.id)}
                            title="Refresh tool status"
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => goToTool(tool.path)}
                            title="Open tool"
                          >
                            <span className="sr-only">Open tool</span>
                            →
                          </Button>
                        </div>
                      </div>
                    ))}
                    
                    {getFilteredTools().length === 0 && (
                      <div className="py-8 text-center text-gray-500 dark:text-gray-400">
                        No tools found matching your search
                      </div>
                    )}
                  </div>
                </Tabs>
              </CardContent>
            </Card>
          </div>
          
          <div>
            {/* Error logs section */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Error Logs</CardTitle>
                  <CardDescription>Recent errors across all tools</CardDescription>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleClearLogs}
                  disabled={errorLogs.length === 0}
                >
                  <Trash className="h-4 w-4 mr-1" />
                  Clear
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {errorLogs.length === 0 ? (
                    <div className="py-8 text-center text-gray-500 dark:text-gray-400">
                      No errors logged yet
                    </div>
                  ) : (
                    errorLogs.map((log, index) => (
                      <div 
                        key={index} 
                        className="p-3 border border-red-200 dark:border-red-900 rounded-lg bg-red-50 dark:bg-red-900/20"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                          <h4 className="font-medium text-red-700 dark:text-red-400">
                            {log.toolId}: {log.errorType}
                          </h4>
                        </div>
                        <p className="text-sm text-red-600 dark:text-red-300 mb-1">
                          {log.message}
                        </p>
                        <div className="text-xs text-gray-500 dark:text-gray-400 flex justify-between">
                          <span>{new Date(log.timestamp).toLocaleString()}</span>
                          <Badge variant="outline" className="bg-red-100 dark:bg-red-900/30">
                            {log.toolId}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ToolChecker;
