
import React, { useState, useEffect } from "react";
import ThemeToggle from "../components/ThemeToggle";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import SearchBar from "@/components/SearchBar";
import Features from "@/components/Features";
import WhyChooseUs from "@/components/WhyChooseUs";
import ChatBot from "@/components/ChatBot";
import { Link } from "react-router-dom";
import { Shield, Wrench } from "lucide-react";
import { initializeErrorLogging } from "@/services/ErrorLoggingService";
import useAdvancedToolSearch from "@/hooks/useAdvancedToolSearch";
import ContentDetectiveCard from "@/components/ContentDetectiveCard";

// Import the tool section components
import ImageMediaTools from "@/components/tool-sections/ImageMediaTools";
import TextContentToolsWrapper from "@/components/tool-sections/TextContentToolsWrapper";
import DeveloperTools from "@/components/tool-sections/DeveloperTools";
import SocialMediaTools from "@/components/tool-sections/SocialMediaTools";
import MathCalculators from "@/components/tool-sections/MathCalculators";
import HealthWellnessToolsWrapper from "@/components/tool-sections/HealthWellnessToolsWrapper";
import AdvancedSystemTools from "@/components/tool-sections/AdvancedSystemTools";
import AdditionalCategories from "@/components/tool-sections/AdditionalCategories";
import { Tool } from "@/lib/tool-model";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllCategories, setShowAllCategories] = useState(false);

  const foundToolsByCat = useAdvancedToolSearch(searchQuery);

  useEffect(() => {
    initializeErrorLogging();
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    console.log("Searching for:", query);
  };

  const toggleCategories = () => {
    setShowAllCategories(!showAllCategories);
  };

  return (
    <div className="relative min-h-screen bg-background text-foreground transition-colors">
      <ThemeToggle />
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-blue-purple-pink">
            Free Online Tools for Everyone
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
            Powerful, free, and easy-to-use online tools to help you be more productive.
          </p>
          <div className="max-w-3xl mx-auto transform hover:scale-[1.01] transition-transform duration-300">
            <SearchBar onSearch={handleSearch} placeholder="Search for tools, calculators, converters..." />
          </div>
        </div>

        <ContentDetectiveCard />

        {localStorage.getItem("admin_password") && (
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 mb-8 max-w-4xl mx-auto">
            <div className="flex items-center">
              <Shield className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mr-2" />
              <h2 className="text-lg font-semibold text-yellow-800 dark:text-yellow-300">Admin Tools</h2>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link 
                to="/admin/tool-checker" 
                className="inline-flex items-center px-3 py-1.5 bg-yellow-100 dark:bg-yellow-800/40 hover:bg-yellow-200 dark:hover:bg-yellow-800/60 text-yellow-800 dark:text-yellow-300 text-sm rounded-md transition-colors"
              >
                <Wrench className="h-4 w-4 mr-1.5" />
                Tool Checker
              </Link>
            </div>
          </div>
        )}

        <div className="space-y-8">
          {(!searchQuery || (foundToolsByCat["conversion"] && foundToolsByCat["conversion"].length > 0)) && (
            <ImageMediaTools tools={searchQuery ? foundToolsByCat["conversion"] : undefined} />
          )}

          {(!searchQuery || (foundToolsByCat["content"] && foundToolsByCat["content"].length > 0)) && (
            <TextContentToolsWrapper tools={searchQuery ? foundToolsByCat["content"] : undefined} />
          )}

          {(!searchQuery || (foundToolsByCat["developer"] && foundToolsByCat["developer"].length > 0)) && (
            <DeveloperTools tools={searchQuery ? foundToolsByCat["developer"] : undefined} />
          )}

          {(!searchQuery || (foundToolsByCat["social"] && foundToolsByCat["social"].length > 0)) && (
            <SocialMediaTools tools={searchQuery ? foundToolsByCat["social"] : undefined} />
          )}

          <AdBanner className="my-8" size="large" />

          {(!searchQuery || (foundToolsByCat["math"] && foundToolsByCat["math"].length > 0)) && (
            <MathCalculators tools={searchQuery ? foundToolsByCat["math"] : undefined} />
          )}

          {(!searchQuery || (foundToolsByCat["health"] && foundToolsByCat["health"].length > 0)) && (
            <HealthWellnessToolsWrapper tools={searchQuery ? foundToolsByCat["health"] : undefined} />
          )}

          {(!searchQuery || (foundToolsByCat["advanced"] && foundToolsByCat["advanced"].length > 0)) && (
            <AdvancedSystemTools tools={searchQuery ? foundToolsByCat["advanced"] : undefined} />
          )}
        </div>
        
        {showAllCategories && <AdditionalCategories />}
        
        <div className="text-center mt-10 mb-16">
          <button
            onClick={toggleCategories}
            className="px-6 py-3 bg-gradient-to-r from-tool-blue to-tool-purple text-white rounded-full font-medium hover:shadow-lg transition-all duration-300 hover:scale-105"
          >
            {showAllCategories ? "Show Less Tools" : "View More Tools"}
          </button>
        </div>
        
        <Features />
        <WhyChooseUs />
      </main>
      <Footer />
      
      <ChatBot />
    </div>
  );
};

export default Index;
