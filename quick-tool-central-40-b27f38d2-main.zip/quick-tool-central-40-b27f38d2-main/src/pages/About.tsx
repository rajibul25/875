
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Building, Users, Zap, Heart } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-tool-purple">About Us</h1>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 mb-10">
            <div className="flex items-start mb-6">
              <div className="flex-shrink-0 mr-4">
                <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full">
                  <Building className="h-8 w-8 text-tool-purple" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-semibold mb-3">Welcome to MultiToolSet</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Your trusted partner in providing online utilities and tools. We are committed to delivering high-quality tools that simplify your life and empower your goals. Our mission is to create innovative, reliable, and user-friendly solutions for a better digital experience.
                </p>
                <p className="text-gray-700 dark:text-gray-300">
                  With a team of passionate professionals and years of experience, MultiToolSet stands for trust, transparency, and technological excellence.
                </p>
              </div>
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 flex flex-col items-center text-center transition-transform hover:scale-105">
              <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-4">
                <Users className="h-7 w-7 text-tool-blue" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Our Team</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Skilled professionals dedicated to creating the best online tools for our users.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 flex flex-col items-center text-center transition-transform hover:scale-105">
              <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-full mb-4">
                <Zap className="h-7 w-7 text-tool-orange" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
              <p className="text-gray-600 dark:text-gray-400">
                To make powerful utilities accessible to everyone, completely free of charge.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 flex flex-col items-center text-center transition-transform hover:scale-105">
              <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-full mb-4">
                <Heart className="h-7 w-7 text-red-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Our Values</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We believe in quality, accessibility, and putting our users first in everything we do.
              </p>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 mb-10">
            <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
            <p className="text-gray-700 dark:text-gray-300 mb-4">
              MultiToolSet began with a simple idea: to create a one-stop platform where users could access various online tools without needing to visit multiple websites or download different applications.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-4">
              What started as a small project has grown into a comprehensive suite of tools used by thousands of people daily. We continuously strive to expand our offerings and improve existing tools based on user feedback.
            </p>
            <p className="text-gray-700 dark:text-gray-300">
              Today, we're proud to offer dozens of free tools across multiple categories, from file conversion to calculators, and we're just getting started.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;
