
import React from "react";
import ToolLayout from "@/components/tools/ToolLayout";

const ComingSoon = () => {
  return (
    <ToolLayout 
      title="Coming Soon"
      description="This tool is under development and will be available soon."
      helpText="Check back later for this exciting new feature!"
    >
      <div className="flex flex-col items-center justify-center py-12">
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-6 max-w-md text-center">
          <h2 className="text-xl font-semibold mb-3">Coming Soon</h2>
          <p className="text-gray-600 dark:text-gray-300">
            We're working on implementing this tool. Please check back soon!
          </p>
        </div>
      </div>
    </ToolLayout>
  );
};

export default ComingSoon;
