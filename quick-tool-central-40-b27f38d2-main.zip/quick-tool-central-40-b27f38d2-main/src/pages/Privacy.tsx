
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Shield, Calendar, Eye, Lock } from "lucide-react";

const Privacy = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-tool-purple">Privacy Policy</h1>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 mb-8">
            <div className="flex items-start mb-6">
              <div className="flex-shrink-0 mr-4">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                  <Shield className="h-8 w-8 text-tool-blue" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-semibold mb-3">Our Commitment to Privacy</h2>
                <p className="text-gray-700 dark:text-gray-300">
                  At MultiToolSet, we respect your privacy. We collect only the necessary information to improve our services and ensure a better experience. Your data is never shared with third parties without consent.
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between border-t border-gray-200 dark:border-gray-700 pt-5 mt-5 text-sm text-gray-500 dark:text-gray-400">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Effective Date: April 17, 2025</span>
              </div>
              <div className="flex items-center">
                <Eye className="h-4 w-4 mr-2" />
                <span>Last Updated: April 17, 2025</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Information We Collect</h2>
              <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                <li>Usage data (pages visited, tools used, time spent)</li>
                <li>Device information (browser type, operating system)</li>
                <li>IP addresses and general location data</li>
                <li>Files uploaded for processing (temporarily stored)</li>
              </ul>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">How We Use Your Information</h2>
              <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                <li>To provide and improve our tools and services</li>
                <li>To understand how users interact with our website</li>
                <li>To detect and prevent technical issues or abuse</li>
                <li>To send important updates about our services (if you opt-in)</li>
              </ul>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Cookies and Tracking</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-4">
                We use cookies, analytics tools, and third-party services to understand user behavior and enhance functionality. These technologies help us remember your preferences and analyze how our website is used.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                You can control cookies through your browser settings, but disabling certain cookies may limit your ability to use some features of our website.
              </p>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Data Security</h2>
              <div className="flex items-start">
                <Lock className="h-6 w-6 text-tool-green mt-1 mr-3 flex-shrink-0" />
                <p className="text-gray-700 dark:text-gray-300">
                  We implement appropriate security measures to protect your data against unauthorized access, alteration, disclosure, or destruction. Files uploaded for processing are automatically deleted after processing or within a maximum of 24 hours.
                </p>
              </div>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Your Rights</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-4">
                Depending on your location, you may have rights regarding your personal data, including:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                <li>Accessing and receiving a copy of your data</li>
                <li>Correcting inaccurate information</li>
                <li>Requesting deletion of your data</li>
                <li>Restricting or objecting to processing</li>
                <li>Data portability</li>
              </ul>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Contact Us About Privacy</h2>
              <p className="text-gray-700 dark:text-gray-300">
                If you have questions or concerns about our privacy practices, please contact us at privacy@multitoolset.co
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;
