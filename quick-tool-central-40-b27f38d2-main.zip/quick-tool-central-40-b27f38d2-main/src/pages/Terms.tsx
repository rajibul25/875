
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { BookOpen, AlertTriangle, CheckCircle, ScrollText } from "lucide-react";

const Terms = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-tool-purple">Terms & Conditions</h1>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 mb-8">
            <div className="flex items-start mb-6">
              <div className="flex-shrink-0 mr-4">
                <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-full">
                  <BookOpen className="h-8 w-8 text-tool-orange" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-semibold mb-3">Agreement to Terms</h2>
                <p className="text-gray-700 dark:text-gray-300">
                  By accessing and using MultiToolSet's services, you agree to be bound by these Terms and Conditions, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between border-t border-gray-200 dark:border-gray-700 pt-5 mt-5 text-sm text-gray-500 dark:text-gray-400">
              <div className="flex items-center">
                <ScrollText className="h-4 w-4 mr-2" />
                <span>Effective Date: April 17, 2025</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Use License</h2>
              <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                <li>Permission is granted to temporarily use the tools and services on MultiToolSet for personal, non-commercial purposes.</li>
                <li>This license does not include: modifying or copying our materials; using the materials for commercial purposes; attempting to decompile or reverse engineer any software; removing any copyright or proprietary notations; or transferring the materials to another person.</li>
                <li>This license shall automatically terminate if you violate any of these restrictions and may be terminated by MultiToolSet at any time.</li>
              </ul>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">User Responsibilities</h2>
              <div className="flex items-start mb-4">
                <CheckCircle className="h-6 w-6 text-tool-green mt-1 mr-3 flex-shrink-0" />
                <p className="text-gray-700 dark:text-gray-300">
                  You agree to use the tools and services for lawful purposes only and in a way that does not infringe the rights of, restrict, or inhibit anyone else's use and enjoyment of the website.
                </p>
              </div>
              <div className="flex items-start">
                <AlertTriangle className="h-6 w-6 text-tool-orange mt-1 mr-3 flex-shrink-0" />
                <p className="text-gray-700 dark:text-gray-300">
                  You must not upload any content that contains viruses, malware, or any material that is malicious or technologically harmful. MultiToolSet reserves the right to remove any content that violates these terms.
                </p>
              </div>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Disclaimer</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-4">
                The materials on MultiToolSet's website are provided on an 'as is' basis. MultiToolSet makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                MultiToolSet does not warrant that the website will be error-free or uninterrupted, that defects will be corrected, or that the site or the server is free of viruses or other harmful components.
              </p>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Limitations</h2>
              <p className="text-gray-700 dark:text-gray-300">
                In no event shall MultiToolSet or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on MultiToolSet's website, even if MultiToolSet or a MultiToolSet authorized representative has been notified orally or in writing of the possibility of such damage.
              </p>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Governing Law</h2>
              <p className="text-gray-700 dark:text-gray-300">
                These terms and conditions are governed by and construed in accordance with the laws, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.
              </p>
            </section>
            
            <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
              <h2 className="text-xl font-semibold mb-4">Changes to Terms</h2>
              <p className="text-gray-700 dark:text-gray-300">
                MultiToolSet may revise these terms of service at any time without notice. By using this website, you are agreeing to be bound by the then-current version of these terms of service.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Terms;
